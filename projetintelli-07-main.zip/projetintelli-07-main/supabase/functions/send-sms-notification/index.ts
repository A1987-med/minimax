
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SMSRequest {
  telephone: string;
  message: string;
  soustraitant: string;
  contremaitre: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { telephone, message, soustraitant, contremaitre }: SMSRequest = await req.json()
    
    console.log('Traitement SMS pour:', contremaitre, 'Téléphone:', telephone);

    // Vérifier qu'on a un numéro de téléphone
    if (!telephone) {
      throw new Error('Numéro de téléphone manquant');
    }

    // Simuler l'envoi du SMS
    // En production, vous intégreriez ici Twilio, AWS SNS, etc.
    console.log('SMS envoyé à:', telephone);
    console.log('Message:', message);

    // Log du SMS dans la console
    const smsLog = {
      destinataire: telephone,
      contremaitre: contremaitre,
      soustraitant: soustraitant,
      message: message,
      date_envoi: new Date().toISOString(),
      statut: 'envoye'
    };

    console.log('SMS logged:', smsLog);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'SMS envoyé avec succès',
        details: {
          telephone: telephone,
          contremaitre: contremaitre,
          soustraitant: soustraitant
        }
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  } catch (error) {
    console.error('Erreur dans send-sms-notification:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})
