
import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

// Clé API Anthropic - à configurer dans les secrets Supabase
const anthropicApiKey = Deno.env.get('ANTHROPIC_API_KEY') || 'sk-demo-key-replace-with-real-key';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PhotoAnalysisResult {
  nonConformites: Array<{
    type: string;
    description: string;
    gravite: 'faible' | 'moyen' | 'eleve' | 'critique';
    solution: string;
  }>;
  risques: Array<{
    type: string;
    description: string;
    probabilite: 'faible' | 'moyen' | 'eleve';
    impact: 'faible' | 'moyen' | 'eleve' | 'critique';
    prevention: string;
  }>;
  scoreGlobal: number;
  recommandations: string[];
  environmentAnalysis: {
    humans: {
      detected: boolean;
      count: string;
      equipmentStatus: string;
      activities: string[];
      positions?: string;
      safetyDistance?: string;
    };
    safety: {
      helmet: string;
      vest: string;
      harness: string;
      boots: string;
      badges?: string;
      compliance?: string;
    };
    materials: {
      construction?: string[];
      tools?: string[];
      storage: string;
      vehicles?: string;
      machinery?: string;
    };
    hazards: {
      level: string;
      zones: string[];
      conditions: string;
      signage?: string;
      barriers?: string;
    };
    infrastructure: {
      lighting: string;
      surfaces: string;
      access: string;
      weather?: string;
      organization?: string;
    };
  };
  environmentDescription: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('🔍 === DÉBUT ANALYSE PHOTO AVEC COMPRESSION AUTOMATIQUE ===');
    
    const { imageUrl } = await req.json();

    if (!imageUrl) {
      console.error('❌ URL de l\'image manquante');
      throw new Error('URL de l\'image manquante');
    }

    console.log('🔍 URL image reçue:', imageUrl.substring(0, 100) + '...');
    console.log('🔑 Clé API Anthropic disponible:', anthropicApiKey ? 'OUI' : 'NON');
    console.log('🔑 Longueur clé API:', anthropicApiKey?.length || 0);

    // Vérification de la clé API
    if (!anthropicApiKey || anthropicApiKey === 'sk-demo-key-replace-with-real-key') {
      console.error('❌ Clé API Anthropic non configurée');
      const fallbackAnalysis: PhotoAnalysisResult = {
        nonConformites: [{
          type: "🔑 Configuration Claude AI requise",
          description: "La clé API Anthropic (Claude) n'est pas configurée dans les secrets Supabase. L'analyse IA automatique est impossible.",
          gravite: 'critique',
          solution: "Configurer la clé API Anthropic dans les secrets Supabase (nom: ANTHROPIC_API_KEY)"
        }],
        risques: [],
        scoreGlobal: 0,
        recommandations: [
          "Aller dans le dashboard Supabase > Settings > Edge Functions",
          "Ajouter le secret ANTHROPIC_API_KEY avec votre clé Claude",
          "Relancer l'analyse après configuration"
        ],
        environmentAnalysis: {
          humans: { detected: false, count: 'Configuration requise', equipmentStatus: 'Non analysable', activities: [] },
          safety: { helmet: 'Config requise', vest: 'Config requise', harness: 'Config requise', boots: 'Config requise' },
          materials: { storage: 'Configuration API requise' },
          hazards: { level: 'Indéterminé', zones: [], conditions: 'Configuration requise' },
          infrastructure: { lighting: 'Non analysable', surfaces: 'Non analysables', access: 'Configuration requise' }
        },
        environmentDescription: "Configuration Claude AI requise pour l'analyse automatique"
      };

      return new Response(
        JSON.stringify({ success: true, analysis: fallbackAnalysis, configurationRequired: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const prompt = `Tu es un expert SST avec 25 ans d'expérience sur les chantiers. Ta mission : analyser UNIQUEMENT ce qui est RÉELLEMENT VISIBLE sur cette photo avec une précision chirurgicale.

RÈGLES ABSOLUES - ZÉRO SUPPOSITION :
1. Ne décris QUE ce que tes yeux voient sur la photo
2. Si tu ne vois pas quelque chose clairement → dis "Non visible"
3. Chaque détail doit être observable et vérifiable
4. INTERDICTION FORMELLE de supposer ou d'imaginer
5. Sois hyper-précis sur les couleurs, positions, nombres

ANALYSE ULTRA-FACTUELLE REQUISE :

🔍 OBSERVATION MICROSCOPIQUE :
- Compte exact de personnes visibles (si aucune : "0 personne visible")
- Position PRÉCISE de chaque personne (mètres, direction)
- Équipements EXACTS portés (couleur, type, état visible)
- Activité PRÉCISE observée (geste, position, outil en main)

🏗️ MATÉRIAUX ULTRA-SPÉCIFIQUES :
- Armatures : nombre exact, hauteur, protection visible ou absente
- Béton : état (coulé, en cours, durci), couleur, texture
- Outils : identification précise, position, état
- Matériaux stockés : type exact, organisation visible

⚠️ DANGERS OBSERVABLES :
- Armatures d'attente : compte précis, hauteur, protection OUI/NON
- Chutes potentielles : hauteur mesurable, protection visible
- Équipements manquants : basé sur ce qui DEVRAIT être visible

🌍 ENVIRONNEMENT FACTUEL :
- Météo : ciel visible, lumière, ombres
- Sol : type, état, obstacles visibles
- Organisation : rangement observé, signalisation présente
- Infrastructure : éclairage, barrières, accès visibles

RETOURNE un JSON ultra-précis basé UNIQUEMENT sur tes OBSERVATIONS RÉELLES avec la structure suivante:
{
  "nonConformites": [
    {
      "type": "Type de non-conformité",
      "description": "Description détaillée",
      "gravite": "faible|moyen|eleve|critique",
      "solution": "Solution recommandée"
    }
  ],
  "risques": [
    {
      "type": "Type de risque",
      "description": "Description détaillée",
      "probabilite": "faible|moyen|eleve",
      "impact": "faible|moyen|eleve|critique",
      "prevention": "Mesure préventive"
    }
  ],
  "scoreGlobal": 75,
  "recommandations": ["Recommandation 1", "Recommandation 2"],
  "environmentAnalysis": {
    "humans": {
      "detected": true|false,
      "count": "nombre exact",
      "equipmentStatus": "description des équipements",
      "activities": ["activité 1", "activité 2"],
      "positions": "description précise des positions",
      "safetyDistance": "distances de sécurité observées"
    },
    "safety": {
      "helmet": "description casques",
      "vest": "description gilets",
      "harness": "description harnais",
      "boots": "description chaussures",
      "badges": "badges/dossards visibles",
      "compliance": "conformité globale EPI"
    },
    "materials": {
      "construction": ["matériau 1", "matériau 2"],
      "tools": ["outil 1", "outil 2"],
      "storage": "organisation du stockage",
      "vehicles": "véhicules présents",
      "machinery": "machines présentes"
    },
    "hazards": {
      "level": "niveau global",
      "zones": ["zone 1", "zone 2"],
      "conditions": "conditions dangereuses",
      "signage": "signalisation présente",
      "barriers": "barrières de protection"
    },
    "infrastructure": {
      "lighting": "conditions d'éclairage",
      "surfaces": "état des surfaces",
      "access": "contrôle d'accès",
      "weather": "conditions météo visibles",
      "organization": "organisation du chantier"
    }
  },
  "environmentDescription": "Description générale factuelle de l'environnement de travail avec une analyse poussée des interactions humains-matériel-environnement. Inclure tous les détails observables sur les postures, l'ergonomie et le respect des procédures visibles."
}

IMPORTANT: NE METS AUCUN RETOUR À LA LIGNE DANS LES CHAÎNES JSON, remplace tous les retours à la ligne par des espaces.`;

    // Préparation et compression de l'image
    let imageData = '';
    let mediaType = 'image/jpeg';
    
    try {
      if (imageUrl.startsWith('data:')) {
        console.log('📷 Image au format data URL détectée');
        const parts = imageUrl.split(',');
        if (parts.length === 2) {
          const header = parts[0];
          let rawImageData = parts[1];
          
          const mimeMatch = header.match(/data:([^;]+)/);
          if (mimeMatch) {
            mediaType = mimeMatch[1];
          }
          
          console.log('📏 Taille image originale (base64):', rawImageData.length);
          
          // Vérifier la taille et compresser si nécessaire
          const sizeInBytes = (rawImageData.length * 3) / 4; // Estimation taille réelle
          const maxSizeBytes = 4.5 * 1024 * 1024; // 4.5 MB de sécurité (limite Claude = 5MB)
          
          console.log('📏 Taille estimée:', Math.round(sizeInBytes / (1024 * 1024)), 'MB');
          
          if (sizeInBytes > maxSizeBytes) {
            console.log('🔄 Compression requise, taille trop importante');
            imageData = await compressBase64Image(rawImageData, mediaType);
            console.log('✅ Image compressée, nouvelle taille base64:', imageData.length);
          } else {
            console.log('✅ Taille acceptable, pas de compression nécessaire');
            imageData = rawImageData;
          }
        } else {
          throw new Error('Format data URL invalide');
        }
      } else {
        console.log('🔄 Conversion URL vers base64 avec compression...');
        const result = await safeUrlToBase64WithCompression(imageUrl);
        imageData = result.data;
        mediaType = result.mediaType;
        console.log('✅ Conversion et compression réussies:', { mediaType, dataLength: imageData.length });
      }
    } catch (imageError) {
      console.error('❌ Erreur traitement image:', imageError);
      throw new Error(`Erreur traitement image: ${imageError.message}`);
    }

    console.log('📤 Envoi vers Claude API...');
    console.log('📊 Taille image base64 finale:', imageData.length);
    console.log('🎯 Type média:', mediaType);

    const claudeResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': anthropicApiKey,
        'Content-Type': 'application/json',
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 4000,
        messages: [
          {
            role: 'user',
            content: [
              {
                type: 'text',
                text: prompt
              },
              {
                type: 'image',
                source: {
                  type: 'base64',
                  media_type: mediaType,
                  data: imageData
                }
              }
            ]
          }
        ]
      }),
    });

    console.log('📊 Statut réponse Claude:', claudeResponse.status);
    console.log('📊 Headers réponse Claude:', Object.fromEntries(claudeResponse.headers.entries()));

    if (!claudeResponse.ok) {
      const errorText = await claudeResponse.text();
      console.error('❌ Erreur API Claude:', {
        status: claudeResponse.status,
        statusText: claudeResponse.statusText,
        error: errorText
      });
      
      // Analyser le type d'erreur
      let errorType = 'Erreur API Claude inconnue';
      let errorSolution = 'Vérifier la configuration de la clé API';
      
      if (claudeResponse.status === 401) {
        errorType = 'Clé API Claude invalide';
        errorSolution = 'Vérifier que la clé API Anthropic est correcte dans les secrets Supabase';
      } else if (claudeResponse.status === 429) {
        errorType = 'Limite de taux API Claude dépassée';
        errorSolution = 'Attendre quelques minutes avant de relancer l\'analyse';
      } else if (claudeResponse.status === 400) {
        errorType = 'Requête invalide vers Claude';
        errorSolution = 'L\'image pourrait être corrompue ou dans un format non supporté';
      }
      
      const errorAnalysis: PhotoAnalysisResult = {
        nonConformites: [{
          type: errorType,
          description: `Erreur ${claudeResponse.status}: ${errorText}`,
          gravite: 'eleve',
          solution: errorSolution
        }],
        risques: [],
        scoreGlobal: 50,
        recommandations: [
          "Vérifier la clé API Anthropic dans les secrets Supabase",
          "Réessayer l'analyse dans quelques minutes",
          "Vérifier la qualité et le format de l'image"
        ],
        environmentAnalysis: {
          humans: { detected: false, count: 'Erreur API', equipmentStatus: 'Non analysable', activities: [] },
          safety: { helmet: 'Erreur API', vest: 'Erreur API', harness: 'Erreur API', boots: 'Erreur API' },
          materials: { storage: 'Erreur API Claude' },
          hazards: { level: 'Indéterminé', zones: [], conditions: 'Erreur API' },
          infrastructure: { lighting: 'Erreur API', surfaces: 'Erreur API', access: 'Erreur API' }
        },
        environmentDescription: `Erreur lors de l'appel à l'API Claude: ${errorType}. ${errorSolution}.`
      };

      return new Response(
        JSON.stringify({ success: true, analysis: errorAnalysis, apiError: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const data = await claudeResponse.json();
    console.log('📊 Réponse Claude reçue');
    console.log('📊 Structure réponse:', {
      hasContent: !!data.content,
      contentLength: data.content?.length || 0,
      contentType: data.content?.[0]?.type || 'unknown'
    });

    if (!data.content?.[0]?.text) {
      console.error('❌ Réponse Claude invalide:', data);
      throw new Error('Réponse Claude invalide - pas de contenu texte');
    }

    let analysisResult: PhotoAnalysisResult;
    
    try {
      let cleanContent = data.content[0].text.trim();
      console.log('🧹 Contenu brut (premiers 200 chars):', cleanContent.substring(0, 200));
      
      // Nettoyage agressif
      if (cleanContent.startsWith('```json')) {
        cleanContent = cleanContent.slice(7);
      }
      if (cleanContent.endsWith('```')) {
        cleanContent = cleanContent.slice(0, -3);
      }
      
      cleanContent = cleanContent
        .replace(/[\x00-\x1F\x7F-\x9F]/g, ' ')
        .replace(/\\n/g, ' ')
        .replace(/\\r/g, ' ')
        .replace(/\\t/g, ' ')
        .replace(/\n/g, ' ')
        .replace(/\r/g, ' ')
        .replace(/\t/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();
      
      console.log('🧹 Contenu nettoyé (premiers 200 chars):', cleanContent.substring(0, 200));
      console.log('🧹 Longueur finale:', cleanContent.length);
      
      analysisResult = JSON.parse(cleanContent);
      console.log('✅ JSON parsé avec succès');
      console.log('📊 Analyse structurée:', {
        nonConformitesCount: analysisResult.nonConformites?.length || 0,
        risquesCount: analysisResult.risques?.length || 0,
        scoreGlobal: analysisResult.scoreGlobal,
        hasEnvironmentAnalysis: !!analysisResult.environmentAnalysis
      });
      
    } catch (parseError) {
      console.error('❌ Erreur parsing JSON:', parseError);
      console.error('❌ Contenu problématique:', cleanContent.substring(0, 500));
      
      const parseErrorAnalysis: PhotoAnalysisResult = {
        nonConformites: [{
          type: "Erreur de parsing Claude",
          description: `Parsing JSON échoué: ${parseError.message}. La réponse de Claude contient des caractères non parsables.`,
          gravite: 'moyen',
          solution: "Relancer l'analyse ou effectuer une inspection manuelle"
        }],
        risques: [],
        scoreGlobal: 50,
        recommandations: [
          "Relancer l'analyse photo",
          "Vérifier la qualité de l'image",
          "Effectuer une inspection manuelle si le problème persiste"
        ],
        environmentAnalysis: {
          humans: { detected: false, count: 'Erreur parsing', equipmentStatus: 'Non analysé', activities: [] },
          safety: { helmet: 'Erreur parsing', vest: 'Erreur parsing', harness: 'Erreur parsing', boots: 'Erreur parsing' },
          materials: { storage: 'Erreur parsing' },
          hazards: { level: 'Erreur parsing', zones: [], conditions: 'Erreur parsing' },
          infrastructure: { lighting: 'Erreur parsing', surfaces: 'Erreur parsing', access: 'Erreur parsing' }
        },
        environmentDescription: `Erreur de parsing de la réponse Claude. Contenu reçu mais non parsable: ${parseError.message}`
      };
      
      return new Response(
        JSON.stringify({ success: true, analysis: parseErrorAnalysis, parseError: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ === ANALYSE RÉUSSIE ===');
    return new Response(
      JSON.stringify({ success: true, analysis: analysisResult }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('❌ === ERREUR CRITIQUE ===');
    console.error('❌ Message:', error.message);
    console.error('❌ Stack:', error.stack);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message,
        timestamp: new Date().toISOString()
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500
      }
    );
  }
});

// Fonction de compression d'image base64
async function compressBase64Image(base64Data: string, mediaType: string): Promise<string> {
  try {
    console.log('🔄 Début compression image base64...');
    
    // Convertir base64 en blob
    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: mediaType });
    
    console.log('📏 Taille blob originale:', blob.size, 'bytes');
    
    // Créer un canvas pour redimensionner
    const canvas = new OffscreenCanvas(1, 1);
    const ctx = canvas.getContext('2d');
    
    if (!ctx) {
      throw new Error('Impossible de créer le contexte canvas');
    }
    
    // Créer une image
    const img = new Image();
    const imageLoadPromise = new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = reject;
    });
    
    img.src = URL.createObjectURL(blob);
    await imageLoadPromise;
    
    console.log('🖼️ Dimensions originales:', img.width, 'x', img.height);
    
    // Calculer les nouvelles dimensions (max 1500px)
    const maxSize = 1500;
    let newWidth = img.width;
    let newHeight = img.height;
    
    if (img.width > maxSize || img.height > maxSize) {
      const ratio = Math.min(maxSize / img.width, maxSize / img.height);
      newWidth = Math.round(img.width * ratio);
      newHeight = Math.round(img.height * ratio);
    }
    
    console.log('🖼️ Nouvelles dimensions:', newWidth, 'x', newHeight);
    
    // Redimensionner le canvas
    canvas.width = newWidth;
    canvas.height = newHeight;
    
    // Dessiner l'image redimensionnée
    ctx.drawImage(img, 0, 0, newWidth, newHeight);
    
    // Convertir en blob compressé (qualité 0.8)
    const compressedBlob = await canvas.convertToBlob({
      type: 'image/jpeg',
      quality: 0.8
    });
    
    console.log('📏 Taille blob compressée:', compressedBlob.size, 'bytes');
    
    // Convertir en base64
    const reader = new FileReader();
    const base64Promise = new Promise<string>((resolve, reject) => {
      reader.onload = () => {
        const result = reader.result as string;
        const base64 = result.split(',')[1];
        resolve(base64);
      };
      reader.onerror = reject;
    });
    
    reader.readAsDataURL(compressedBlob);
    const compressedBase64 = await base64Promise;
    
    console.log('✅ Compression terminée, réduction de', 
                Math.round((1 - compressedBase64.length / base64Data.length) * 100), '%');
    
    return compressedBase64;
    
  } catch (error) {
    console.error('❌ Erreur compression:', error);
    console.warn('⚠️ Utilisation image originale sans compression');
    return base64Data;
  }
}

// Fonction de conversion URL vers base64 avec compression
async function safeUrlToBase64WithCompression(url: string): Promise<{ data: string; mediaType: string }> {
  try {
    console.log('🔄 Début conversion URL vers base64 avec compression:', url.substring(0, 100) + '...');
    
    const response = await fetch(url);
    console.log('📊 Réponse fetch URL:', {
      status: response.status,
      statusText: response.statusText,
      contentType: response.headers.get('content-type'),
      contentLength: response.headers.get('content-length')
    });
    
    if (!response.ok) {
      throw new Error(`Erreur HTTP ${response.status}: ${response.statusText}`);
    }
    
    const arrayBuffer = await response.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    
    console.log('📊 Données image récupérées:', {
      size: bytes.length,
      sizeKB: Math.round(bytes.length / 1024),
      sizeMB: Math.round(bytes.length / (1024 * 1024))
    });
    
    // Convertir en base64 temporaire pour vérifier la taille
    let binary = '';
    const chunkSize = 8192;
    
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const chunk = bytes.slice(i, i + chunkSize);
      binary += String.fromCharCode.apply(null, Array.from(chunk));
    }
    
    const originalBase64 = btoa(binary);
    const originalMediaType = response.headers.get('content-type') || 'image/jpeg';
    
    // Vérifier si compression nécessaire
    const maxSizeBytes = 4.5 * 1024 * 1024; // 4.5 MB
    
    if (bytes.length > maxSizeBytes) {
      console.log('🔄 Compression nécessaire pour l\'URL');
      const compressedBase64 = await compressBase64Image(originalBase64, originalMediaType);
      return {
        data: compressedBase64,
        mediaType: 'image/jpeg' // Toujours JPEG après compression
      };
    } else {
      console.log('✅ Taille acceptable, pas de compression nécessaire');
      return {
        data: originalBase64,
        mediaType: originalMediaType
      };
    }
    
  } catch (error) {
    console.error('❌ Erreur conversion base64:', error);
    throw new Error(`Impossible de convertir l'image en base64: ${error.message}`);
  }
}
