
import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface DerogationData {
  numero: string;
  type: string;
  referenceLegale: string;
  observations: string;
  echeancier: string;
  dateInspection: string;
}

interface ContremaireData {
  nom?: string;
  prenom?: string;
  email?: string;
  telephone?: string;
}

interface NotificationRequest {
  soustraitant: string;
  contremaitre: ContremaireData;
  derogation: DerogationData;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { soustraitant, contremaitre, derogation }: NotificationRequest = await req.json()
    
    console.log('Traitement notification pour:', soustraitant, 'Contremaître:', contremaitre, 'Dérogation:', derogation);

    // Vérifier qu'on a les informations du contremaître
    if (!contremaitre || (!contremaitre.email && !contremaitre.telephone)) {
      throw new Error('Aucune information de contact disponible pour le contremaître');
    }

    const nomComplet = `${contremaitre.prenom || ''} ${contremaitre.nom || ''}`.trim();

    // Template d'email pour la dérogation
    const emailTemplate = `
    Objet: Nouvelle dérogation SST - ${derogation.numero}
    
    Bonjour ${nomComplet},
    
    Une nouvelle dérogation SST a été identifiée lors de l'inspection du ${derogation.dateInspection} pour l'entreprise ${soustraitant}.
    
    Détails de la dérogation:
    - Numéro: ${derogation.numero}
    - Article CSTC: ${derogation.type}
    - Référence légale: ${derogation.referenceLegale}
    - Observations: ${derogation.observations}
    - Délai de correction: ${derogation.echeancier}
    
    En tant que contremaître, veuillez prendre les mesures correctives nécessaires dans les délais impartis.
    
    Cordialement,
    L'équipe SST
    `;

    // Template SMS pour la dérogation
    const smsTemplate = `SST - ${soustraitant}: Nouvelle dérogation #${derogation.numero} - Article ${derogation.type}. Correction requise avant le ${derogation.echeancier}. Consultez vos emails pour les détails.`;

    // Simuler l'envoi d'email et SMS
    // En production, vous intégreriez ici SendGrid, Twilio, etc.
    if (contremaitre.email) {
      console.log('Email envoyé à:', contremaitre.email);
      console.log('Contenu:', emailTemplate);
    }
    
    if (contremaitre.telephone) {
      console.log('SMS envoyé à:', contremaitre.telephone);
      console.log('Contenu:', smsTemplate);
    }

    // Log de la notification dans la base de données
    const notificationLog = {
      soustraitant: soustraitant,
      contremaitre: nomComplet,
      email: contremaitre.email,
      telephone: contremaitre.telephone,
      type: 'derogation',
      contenu: emailTemplate,
      date_envoi: new Date().toISOString(),
      statut: 'envoye'
    };

    console.log('Notification logged:', notificationLog);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Notification envoyée avec succès au contremaître',
        details: {
          email_sent: !!contremaitre.email,
          sms_sent: !!contremaitre.telephone,
          soustraitant: soustraitant,
          contremaitre: nomComplet
        }
      }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  } catch (error) {
    console.error('Erreur dans send-derogation-notification:', error)
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message 
      }),
      { 
        status: 400,
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    )
  }
})
