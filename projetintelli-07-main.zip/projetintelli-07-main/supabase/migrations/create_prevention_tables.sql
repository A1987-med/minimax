
-- Créer les tables manquantes pour le service de prévention

-- Table pour les checklists de prévention
CREATE TABLE public.checklists_prevention (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type_checklist TEXT NOT NULL,
  titre TEXT NOT NULL,
  items JSONB DEFAULT '[]'::jsonb,
  completee_par TEXT,
  date_completion DATE,
  statut TEXT DEFAULT 'en_cours' CHECK (statut IN ('en_cours', 'complete', 'incomplete')),
  observations TEXT DEFAULT '',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Trigger pour mettre à jour updated_at automatiquement
CREATE TRIGGER update_checklists_prevention_updated_at 
  BEFORE UPDATE ON public.checklists_prevention 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();

-- Activer RLS
ALTER TABLE public.checklists_prevention ENABLE ROW LEVEL SECURITY;

-- Politique permissive pour toutes les opérations
CREATE POLICY "Allow all operations on checklists_prevention" 
  ON public.checklists_prevention 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);

-- Ajouter les colonnes manquantes à la table inspections existante
ALTER TABLE public.inspections 
ADD COLUMN IF NOT EXISTS type_inspection TEXT,
ADD COLUMN IF NOT EXISTS equipement_zone TEXT,
ADD COLUMN IF NOT EXISTS heure_inspection TIME,
ADD COLUMN IF NOT EXISTS resultats JSONB DEFAULT '{}'::jsonb,
ADD COLUMN IF NOT EXISTS conformite BOOLEAN,
ADD COLUMN IF NOT EXISTS actions_correctives TEXT DEFAULT '',
ADD COLUMN IF NOT EXISTS date_prochaine_inspection DATE;

-- Mettre à jour la contrainte de statut
ALTER TABLE public.inspections 
DROP CONSTRAINT IF EXISTS inspections_status_check;

ALTER TABLE public.inspections 
ADD CONSTRAINT inspections_status_check 
CHECK (status IN ('planifiee', 'en_cours', 'complete', 'reportee'));
