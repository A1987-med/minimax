
-- Créer le bucket pour les inspections photos
INSERT INTO storage.buckets (id, name, public)
VALUES ('photo-inspections', 'photo-inspections', true);

-- Créer les politiques RLS pour le bucket photo-inspections
CREATE POLICY "Allow public uploads to photo-inspections bucket" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'photo-inspections');

CREATE POLICY "Allow public access to photo-inspections bucket" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'photo-inspections');

CREATE POLICY "Allow public updates to photo-inspections bucket" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'photo-inspections');

CREATE POLICY "Allow public deletes from photo-inspections bucket" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'photo-inspections');
