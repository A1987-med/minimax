
-- Créer la table pour stocker les données AST dans le cloud
CREATE TABLE public.ast_data (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  corps_metier TEXT NOT NULL UNIQUE,
  data JSONB NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Ajouter un index sur le corps de métier pour les recherches rapides
CREATE INDEX idx_ast_data_corps_metier ON public.ast_data(corps_metier);

-- Ajouter un trigger pour mettre à jour automatiquement updated_at
CREATE TRIGGER update_ast_data_updated_at
  BEFORE UPDATE ON public.ast_data
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Commentaires pour documenter la table
COMMENT ON TABLE public.ast_data IS 'Stockage des données d''Analyse de Sécurité du Travail par corps de métier';
COMMENT ON COLUMN public.ast_data.corps_metier IS 'Nom du corps de métier (unique)';
COMMENT ON COLUMN public.ast_data.data IS 'Données AST complètes au format JSON';
