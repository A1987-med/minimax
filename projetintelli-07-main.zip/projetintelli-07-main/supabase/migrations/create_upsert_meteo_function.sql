
-- Fonction pour faire un upsert des données météo
CREATE OR REPLACE FUNCTION upsert_meteo_data(
  p_user_id UUID,
  p_date DATE,
  p_temperature INTEGER,
  p_temperature_ressentie INTEGER,
  p_vent INTEGER,
  p_rafales INTEGER,
  p_humidite INTEGER,
  p_conditions TEXT,
  p_icone TEXT,
  p_location TEXT DEFAULT NULL,
  p_is_real_data BOOLEAN DEFAULT FALSE,
  p_projet_id TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
  INSERT INTO meteo_data (
    user_id, date, temperature, temperature_ressentie, vent, rafales, 
    humidite, conditions, icone, location, is_real_data, projet_id
  ) VALUES (
    p_user_id, p_date, p_temperature, p_temperature_ressentie, p_vent, p_rafales,
    p_humidite, p_conditions, p_icone, p_location, p_is_real_data, p_projet_id
  )
  ON CONFLICT (user_id, date, COALESCE(projet_id, ''))
  DO UPDATE SET
    temperature = EXCLUDED.temperature,
    temperature_ressentie = EXCLUDED.temperature_ressentie,
    vent = EXCLUDED.vent,
    rafales = EXCLUDED.rafales,
    humidite = EXCLUDED.humidite,
    conditions = EXCLUDED.conditions,
    icone = EXCLUDED.icone,
    location = EXCLUDED.location,
    is_real_data = EXCLUDED.is_real_data,
    updated_at = NOW();
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Donner les permissions nécessaires
GRANT EXECUTE ON FUNCTION upsert_meteo_data TO authenticated;
