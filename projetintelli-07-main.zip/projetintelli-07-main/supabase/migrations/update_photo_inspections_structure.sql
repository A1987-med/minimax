
-- Mise à jour de la structure de la table photo_inspections pour correspondre au code existant
ALTER TABLE public.photo_inspections 
ADD COLUMN IF NOT EXISTS file_name TEXT,
ADD COLUMN IF NOT EXISTS file_size BIGINT,
ADD COLUMN IF NOT EXISTS file_type TEXT,
ADD COLUMN IF NOT EXISTS analysis JSONB,
ADD COLUMN IF NOT EXISTS timestamp BIGINT,
ADD COLUMN IF NOT EXISTS analysis_start_time BIGINT;

-- Supprimer les colonnes qui ne sont pas utilisées par le code
ALTER TABLE public.photo_inspections 
DROP COLUMN IF EXISTS nom_fichier,
DROP COLUMN IF EXISTS taille_fichier,
DROP COLUMN IF EXISTS type_fichier,
DROP COLUMN IF EXISTS analysis_result,
DROP COLUMN IF EXISTS date_inspection;

-- Mettre à jour la contrainte NOT NULL sur image_url pour permettre les valeurs null temporairement
ALTER TABLE public.photo_inspections ALTER COLUMN image_url DROP NOT NULL;
