
-- Créer la table photo_inspections pour le stockage des photos et analyses
CREATE TABLE public.photo_inspections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  image_url TEXT NOT NULL,
  image_path TEXT,
  nom_fichier TEXT,
  taille_fichier BIGINT,
  type_fichier TEXT,
  date_inspection DATE NOT NULL DEFAULT CURRENT_DATE,
  analysis_result JSONB,
  analyzing BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Ajouter un index pour améliorer les performances des requêtes
CREATE INDEX idx_photo_inspections_date ON public.photo_inspections(date_inspection);
CREATE INDEX idx_photo_inspections_analyzing ON public.photo_inspections(analyzing);

-- Créer une fonction pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Créer le trigger pour mettre à jour automatiquement updated_at
CREATE TRIGGER update_photo_inspections_updated_at 
  BEFORE UPDATE ON public.photo_inspections 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();

-- Activer RLS (Row Level Security) - pour l'instant on permet tout
ALTER TABLE public.photo_inspections ENABLE ROW LEVEL SECURITY;

-- Créer une politique permissive pour permettre toutes les opérations
CREATE POLICY "Allow all operations on photo_inspections" 
  ON public.photo_inspections 
  FOR ALL 
  USING (true) 
  WITH CHECK (true);
