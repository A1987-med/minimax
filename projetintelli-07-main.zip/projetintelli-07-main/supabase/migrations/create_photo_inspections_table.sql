
-- Table pour stocker les métadonnées des photos d'inspection
CREATE TABLE IF NOT EXISTS photo_inspections (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    file_size INTEGER,
    file_type TEXT,
    image_url TEXT NOT NULL,
    analysis JSONB,
    analyzing BOOLEAN DEFAULT false,
    timestamp BIGINT NOT NULL,
    analysis_start_time BIGINT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_photo_inspections_timestamp ON photo_inspections(timestamp DESC);
CREATE INDEX IF NOT EXISTS idx_photo_inspections_analyzing ON photo_inspections(analyzing);

-- RLS (Row Level Security) - désactivé temporairement pour les tests
ALTER TABLE photo_inspections DISABLE ROW LEVEL SECURITY;

-- Alternative : Si vous voulez garder RLS activé mais avec accès complet
-- ALTER TABLE photo_inspections ENABLE ROW LEVEL SECURITY;
-- 
-- -- Supprimer les anciennes politiques si elles existent
-- DROP POLICY IF EXISTS "Allow all operations on photo_inspections" ON photo_inspections;
-- 
-- -- Nouvelle politique plus permissive
-- CREATE POLICY "Enable all access for photo_inspections" 
-- ON photo_inspections 
-- FOR ALL 
-- USING (true) 
-- WITH CHECK (true);

-- Trigger pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER IF NOT EXISTS update_photo_inspections_updated_at 
    BEFORE UPDATE ON photo_inspections 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();
