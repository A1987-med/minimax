
-- Add missing columns to signalements table to match the application expectations
ALTER TABLE public.signalements 
ADD COLUMN IF NOT EXISTS type_incident TEXT,
ADD COLUMN IF NOT EXISTS date_incident DATE,
ADD COLUMN IF NOT EXISTS heure_incident TIME,
ADD COLUMN IF NOT EXISTS gravite TEXT CHECK (gravite IN ('faible', 'moyenne', 'elevee', 'critique')),
ADD COLUMN IF NOT EXISTS rapporte_par TEXT,
ADD COLUMN IF NOT EXISTS temoin_nom TEXT,
ADD COLUMN IF NOT EXISTS temoin_contact TEXT,
ADD COLUMN IF NOT EXISTS mesures_prises TEXT,
ADD COLUMN IF NOT EXISTS statut TEXT CHECK (statut IN ('ouvert', 'en_cours', 'ferme', 'resolu'));

-- Copy existing data to new columns
UPDATE public.signalements 
SET 
  type_incident = type,
  statut = status
WHERE type_incident IS NULL;

-- Add missing columns to photo_inspections table  
ALTER TABLE public.photo_inspections
ADD COLUMN IF NOT EXISTS file_name TEXT,
ADD COLUMN IF NOT EXISTS file_size BIGINT,
ADD COLUMN IF NOT EXISTS file_type TEXT,
ADD COLUMN IF NOT EXISTS analysis JSONB,
ADD COLUMN IF NOT EXISTS analyzing_status BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS timestamp BIGINT,
ADD COLUMN IF NOT EXISTS analysis_start_time BIGINT;

-- Copy existing data to new columns
UPDATE public.photo_inspections 
SET 
  file_name = nom_fichier,
  file_size = taille_fichier,
  file_type = type_fichier,
  analysis = analysis_result,
  analyzing_status = analyzing
WHERE file_name IS NULL;

-- Create missing checklists_prevention table
CREATE TABLE IF NOT EXISTS public.checklists_prevention (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type_checklist TEXT NOT NULL,
  titre TEXT NOT NULL,
  items JSONB DEFAULT '[]',
  completee_par TEXT,
  date_completion DATE,
  statut TEXT CHECK (statut IN ('en_cours', 'complete', 'incomplete')) DEFAULT 'en_cours',
  observations TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Add missing columns to inspections table
ALTER TABLE public.inspections
ADD COLUMN IF NOT EXISTS type_inspection TEXT,
ADD COLUMN IF NOT EXISTS equipement_zone TEXT,
ADD COLUMN IF NOT EXISTS heure_inspection TIME,
ADD COLUMN IF NOT EXISTS resultats JSONB DEFAULT '{}',
ADD COLUMN IF NOT EXISTS conformite BOOLEAN DEFAULT true,
ADD COLUMN IF NOT EXISTS actions_correctives TEXT,
ADD COLUMN IF NOT EXISTS date_prochaine_inspection DATE;

-- Copy existing data to new columns in inspections
UPDATE public.inspections 
SET 
  type_inspection = titre,
  equipement_zone = description
WHERE type_inspection IS NULL;
