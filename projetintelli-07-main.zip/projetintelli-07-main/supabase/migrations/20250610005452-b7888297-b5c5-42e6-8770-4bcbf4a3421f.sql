
-- Create video_inspections table
CREATE TABLE IF NOT EXISTS public.video_inspections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  nom_fichier TEXT NOT NULL,
  chemin_video TEXT NOT NULL,
  taille_fichier BIGINT,
  duree_video INTEGER,
  date_inspection DATE NOT NULL,
  statut_analyse TEXT CHECK (statut_analyse IN ('en_attente', 'en_cours', 'terminee', 'erreur')) DEFAULT 'en_attente',
  description_environnement TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create non_conformites_video table
CREATE TABLE IF NOT EXISTS public.non_conformites_video (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  video_inspection_id UUID NOT NULL REFERENCES public.video_inspections(id) ON DELETE CASCADE,
  timestamp_video INTEGER NOT NULL,
  type_non_conformite TEXT NOT NULL,
  description TEXT NOT NULL,
  niveau_gravite TEXT CHECK (niveau_gravite IN ('faible', 'moyen', 'eleve', 'critique')) NOT NULL,
  confiance_score DECIMAL(3,2),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create transcriptions_audio table
CREATE TABLE IF NOT EXISTS public.transcriptions_audio (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  video_inspection_id UUID NOT NULL REFERENCES public.video_inspections(id) ON DELETE CASCADE,
  timestamp_debut INTEGER NOT NULL,
  timestamp_fin INTEGER NOT NULL,
  texte_transcrit TEXT NOT NULL,
  locuteur TEXT,
  mots_cles_securite TEXT[],
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create storage bucket for video-inspections if it doesn't exist
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('video-inspections', 'video-inspections', true, 2147483648, ARRAY['video/mp4', 'video/avi', 'video/mov', 'video/wmv', 'video/webm'])
ON CONFLICT (id) DO NOTHING;

-- Create storage policies for video-inspections bucket (without IF NOT EXISTS)
DO $$
BEGIN
  -- Drop existing policies if they exist and recreate them
  DROP POLICY IF EXISTS "Public Access for videos" ON storage.objects;
  DROP POLICY IF EXISTS "Authenticated users can upload videos" ON storage.objects;
  DROP POLICY IF EXISTS "Users can update own video files" ON storage.objects;
  DROP POLICY IF EXISTS "Users can delete own video files" ON storage.objects;
  
  -- Create new policies
  CREATE POLICY "Public Access for videos" ON storage.objects FOR SELECT USING (bucket_id = 'video-inspections');
  CREATE POLICY "Authenticated users can upload videos" ON storage.objects FOR INSERT WITH CHECK (bucket_id = 'video-inspections');
  CREATE POLICY "Users can update own video files" ON storage.objects FOR UPDATE USING (bucket_id = 'video-inspections');
  CREATE POLICY "Users can delete own video files" ON storage.objects FOR DELETE USING (bucket_id = 'video-inspections');
END $$;
