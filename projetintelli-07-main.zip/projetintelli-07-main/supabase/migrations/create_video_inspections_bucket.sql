
-- Créer le bucket pour les inspections vidéo
INSERT INTO storage.buckets (id, name, public)
VALUES ('video-inspections', 'video-inspections', true)
ON CONFLICT (id) DO NOTHING;

-- Créer les politiques RLS pour le bucket video-inspections
CREATE POLICY IF NOT EXISTS "Allow public uploads to video-inspections bucket" 
ON storage.objects FOR INSERT 
WITH CHECK (bucket_id = 'video-inspections');

CREATE POLICY IF NOT EXISTS "Allow public access to video-inspections bucket" 
ON storage.objects FOR SELECT 
USING (bucket_id = 'video-inspections');

CREATE POLICY IF NOT EXISTS "Allow public updates to video-inspections bucket" 
ON storage.objects FOR UPDATE 
USING (bucket_id = 'video-inspections');

CREATE POLICY IF NOT EXISTS "Allow public deletes from video-inspections bucket" 
ON storage.objects FOR DELETE 
USING (bucket_id = 'video-inspections');
