
-- Create presences_journalieres table
CREATE TABLE IF NOT EXISTS public.presences_journalieres (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    date DATE NOT NULL,
    sous_traitant TEXT NOT NULL,
    nombre_travailleurs INTEGER NOT NULL CHECK (nombre_travailleurs > 0),
    heure_saisie TIME NOT NULL,
    contremaître TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    created_by UUID REFERENCES auth.users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_presences_date ON public.presences_journalieres(date);
CREATE INDEX IF NOT EXISTS idx_presences_sous_traitant ON public.presences_journalieres(sous_traitant);
CREATE INDEX IF NOT EXISTS idx_presences_created_at ON public.presences_journalieres(created_at);

-- Enable Row Level Security
ALTER TABLE public.presences_journalieres ENABLE ROW LEVEL SECURITY;

-- Create policy to allow all operations for authenticated users
CREATE POLICY "Allow all operations for authenticated users" ON public.presences_journalieres
    FOR ALL USING (true);

-- Create policy to allow read access for anonymous users (for QR code functionality)
CREATE POLICY "Allow read access for anonymous users" ON public.presences_journalieres
    FOR SELECT USING (true);

-- Create policy to allow insert for anonymous users (for QR code functionality)
CREATE POLICY "Allow insert for anonymous users" ON public.presences_journalieres
    FOR INSERT WITH CHECK (true);

-- Add updated_at trigger
CREATE OR REPLACE FUNCTION public.handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = timezone('utc'::text, now());
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER handle_presences_updated_at
    BEFORE UPDATE ON public.presences_journalieres
    FOR EACH ROW
    EXECUTE PROCEDURE public.handle_updated_at();
