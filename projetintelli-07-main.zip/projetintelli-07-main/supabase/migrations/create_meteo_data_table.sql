
-- Migration pour créer la table des données météorologiques
CREATE TABLE IF NOT EXISTS meteo_data (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  date DATE NOT NULL,
  temperature INTEGER NOT NULL,
  temperature_ressentie INTEGER NOT NULL,
  vent INTEGER NOT NULL,
  rafales INTEGER NOT NULL,
  humidite INTEGER NOT NULL,
  conditions TEXT NOT NULL,
  icone TEXT NOT NULL,
  location TEXT,
  is_real_data BOOLEAN DEFAULT false,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  projet_id TEXT, -- Pour associer à un projet/chantier spécifique
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Index pour améliorer les performances des requêtes
CREATE INDEX IF NOT EXISTS idx_meteo_data_date ON meteo_data(date);
CREATE INDEX IF NOT EXISTS idx_meteo_data_user_id ON meteo_data(user_id);
CREATE INDEX IF NOT EXISTS idx_meteo_data_projet_id ON meteo_data(projet_id);
CREATE INDEX IF NOT EXISTS idx_meteo_data_user_date ON meteo_data(user_id, date);

-- Contrainte unique pour éviter les doublons par utilisateur/date/projet
CREATE UNIQUE INDEX IF NOT EXISTS unique_meteo_user_date_projet 
ON meteo_data(user_id, date, COALESCE(projet_id, ''));

-- RLS (Row Level Security) pour la sécurité
ALTER TABLE meteo_data ENABLE ROW LEVEL SECURITY;

-- Politique pour que les utilisateurs ne voient que leurs propres données
CREATE POLICY "Users can view their own meteo data" ON meteo_data
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own meteo data" ON meteo_data
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own meteo data" ON meteo_data
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own meteo data" ON meteo_data
  FOR DELETE USING (auth.uid() = user_id);

-- Fonction pour mettre à jour automatiquement updated_at
CREATE OR REPLACE FUNCTION update_meteo_data_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger pour mettre à jour automatiquement updated_at
CREATE TRIGGER update_meteo_data_updated_at_trigger
  BEFORE UPDATE ON meteo_data
  FOR EACH ROW
  EXECUTE FUNCTION update_meteo_data_updated_at();
