
import React from 'react';
import { SaisiePresenceForm } from '@/components/sections/rapport/SaisiePresenceForm';

const SaisiePresence = () => {
  return <SaisiePresenceForm />;
};

export default SaisiePresence;
