
import React from 'react';
import SSTApp from '@/components/SSTApp';

const Index = () => {
  console.log('Index page rendering...');
  return <SSTApp />;
};

export default Index;
