
import { videoUploadService } from './video/videoUploadService';
import { videoDataService } from './video/videoDataService';
import { databaseOperations } from './video/databaseOperations';
import { supabase } from '@/integrations/supabase/client';

// Export des types pour compatibilité
export type { VideoInspection, NonConformiteVideo, TranscriptionAudio } from './video/types';

// Service principal qui agrège tous les sous-services
export const videoInspectionService = {
  // Upload
  uploadVideo: videoUploadService.uploadVideoFile,
  startAnalysis: videoUploadService.startAnalysis,
  
  // Data operations - map to correct methods
  getAllVideoInspections: videoDataService.getAllVideos,
  getVideoUrl: async (videoPath: string) => {
    // Generate video URL using Supabase storage
    const { data } = supabase.storage
      .from('video-inspections')
      .getPublicUrl(videoPath);
    
    return data.publicUrl;
  },
  getNonConformites: videoDataService.getNonConformitesByVideoId,
  getTranscriptions: videoDataService.getTranscriptionsByVideoId,
  updateStatutAnalyse: databaseOperations.updateStatutAnalyse,
  deleteVideo: async (videoId: string) => {
    const video = await videoDataService.getVideoById(videoId);
    if (video) {
      // Delete from storage first
      const fileName = video.chemin_video.split('/').pop();
      if (fileName) {
        await supabase.storage
          .from('video-inspections')
          .remove([fileName]);
      }
      
      // Delete from database
      const { error } = await (supabase as any)
        .from('video_inspections')
        .delete()
        .eq('id', videoId);
      
      if (error) {
        throw new Error(`Erreur suppression vidéo: ${error.message}`);
      }
    }
  }
};
