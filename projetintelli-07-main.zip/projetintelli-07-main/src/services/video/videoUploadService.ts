
import { VideoInspection } from './types';
import { videoValidation } from './videoValidation';
import { storageDiagnostic } from './storageDiagnostic';
import { storageUpload } from './storageUpload';
import { databaseOperations } from './databaseOperations';
import { analysisService } from './analysisService';

export const videoUploadService = {
  async uploadVideoFile(file: File, dateInspection: string): Promise<{ videoPath: string; videoInspection: VideoInspection }> {
    console.log('🎥 === DEBUT SERVICE uploadVideo ===');
    console.log('🎥 Paramètres:', {
      fileName: file.name,
      fileSize: file.size,
      fileType: file.type,
      dateInspection
    });

    try {
      // Validation fichier
      videoValidation.validateFile(file);

      // Upload vers le stockage
      const uploadData = await storageUpload.uploadToStorage(file);

      // Créer l'entrée en base de données
      const videoInspection = await databaseOperations.createVideoRecord(file, dateInspection, uploadData.path);

      // Démarrer l'analyse IA en arrière-plan
      analysisService.startAnalysisAsync(videoInspection.id);

      console.log('✅ Upload terminé avec succès');
      return { videoPath: uploadData.path, videoInspection };
      
    } catch (error) {
      console.error('❌ Erreur service upload:', error);
      throw error;
    }
  },

  // Export des sous-services pour compatibilité
  diagnosticSupabaseDetaille: storageDiagnostic.runDiagnostic,
  validateFile: videoValidation.validateFile,
  uploadToStorage: storageUpload.uploadToStorage,
  createVideoRecord: databaseOperations.createVideoRecord,
  startAnalysisAsync: analysisService.startAnalysisAsync,
  startAnalysis: analysisService.startAnalysis,
  updateStatutAnalyse: databaseOperations.updateStatutAnalyse
};
