export interface VideoInspection {
  id: string;
  nom_fichier: string;
  chemin_video: string;
  taille_fichier?: number;
  duree_video?: number;
  date_inspection: string;
  statut_analyse: 'en_attente' | 'en_cours' | 'terminee' | 'erreur';
  description_environnement?: string;
  created_at: string;
  updated_at: string;
}

export interface NonConformiteVideo {
  id: string;
  video_inspection_id: string;
  timestamp_video: number;
  type_non_conformite: string;
  description: string;
  niveau_gravite: 'faible' | 'moyen' | 'eleve' | 'critique';
  confiance_score?: number;
}

export interface TranscriptionAudio {
  id: string;
  video_inspection_id: string;
  timestamp_debut: number;
  timestamp_fin: number;
  texte_transcrit: string;
  locuteur?: string;
  mots_cles_securite?: string[];
}
