
export const videoValidation = {
  validateFile(file: File): void {
    if (!file || file.size === 0) {
      throw new Error('Fichier invalide ou vide');
    }

    // Limite configurée à 5GB comme dans Supabase
    const maxSize = 5 * 1024 * 1024 * 1024; // 5GB
    if (file.size > maxSize) {
      throw new Error(`Fichier trop volumineux: ${(file.size / (1024 * 1024 * 1024)).toFixed(2)}GB. Maximum configuré: 5GB`);
    }

    // Types MIME supportés - ajout de video/quicktime pour les fichiers .mov
    const allowedTypes = [
      'video/mp4', 
      'video/quicktime',  // Fichiers .mov
      'video/x-msvideo',  // Fichiers .avi
      'video/webm',
      'video/avi',
      'video/mkv',
      'video/3gp',
      'video/x-ms-wmv'
    ];
    
    if (!allowedTypes.includes(file.type) && !file.type.startsWith('video/')) {
      throw new Error(`Type de fichier non supporté: ${file.type}`);
    }
  }
};
