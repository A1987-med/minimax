
import { supabase } from "@/integrations/supabase/client";

export const storageDiagnostic = {
  async runDiagnostic(): Promise<void> {
    try {
      console.log('🔍 === DIAGNOSTIC DÉTAILLÉ BUCKET VIDEO-INSPECTIONS ===');
      
      // Test 1: Vérifier l'existence du bucket
      console.log('🪣 Test 1: Existence du bucket...');
      const { data: buckets, error: bucketsError } = await supabase.storage.listBuckets();
      
      if (bucketsError) {
        console.error('❌ Erreur listage buckets:', bucketsError);
        throw new Error(`Impossible de lister les buckets: ${bucketsError.message}`);
      }
      
      const videoBucket = buckets?.find(b => b.id === 'video-inspections');
      if (!videoBucket) {
        console.error('❌ Bucket video-inspections non trouvé');
        console.log('📋 Buckets disponibles:', buckets?.map(b => b.id));
        throw new Error('Bucket video-inspections n\'existe pas');
      }
      
      console.log('✅ Bucket trouvé:', videoBucket);
      
      // Test 2: Vérifier l'accès au bucket
      console.log('🔐 Test 2: Accès au bucket...');
      const { data: bucketInfo, error: bucketError } = await supabase.storage
        .from('video-inspections')
        .list('', { limit: 1 });
      
      if (bucketError) {
        console.error('❌ Erreur accès bucket:', bucketError);
        throw new Error(`Bucket inaccessible: ${bucketError.message}`);
      }
      
      console.log('✅ Bucket accessible, fichiers racine:', bucketInfo?.length || 0);
      
      // Test 3: Vérifier le dossier uploads/
      console.log('📁 Test 3: Dossier uploads/...');
      const { data: uploadFolders, error: folderError } = await supabase.storage
        .from('video-inspections')
        .list('uploads', { limit: 1 });
      
      if (folderError && !folderError.message.includes('not found')) {
        console.error('❌ Erreur dossier uploads:', folderError);
        throw new Error(`Problème dossier uploads: ${folderError.message}`);
      }
      
      if (folderError?.message.includes('not found')) {
        console.log('📁 Dossier uploads/ n\'existe pas encore, sera créé automatiquement');
      } else {
        console.log('✅ Dossier uploads/ accessible, fichiers:', uploadFolders?.length || 0);
      }
      
      // Test 4: Test upload réel (petit fichier)
      console.log('🧪 Test 4: Upload test...');
      const testContent = new Uint8Array([0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70]);
      const testBlob = new Blob([testContent], { type: 'video/mp4' });
      const testFileName = `uploads/test_${Date.now()}.mp4`;
      
      const { data: testUpload, error: testError } = await supabase.storage
        .from('video-inspections')
        .upload(testFileName, testBlob, {
          cacheControl: '3600',
          upsert: false
        });
      
      if (testError) {
        console.error('❌ Test upload échoué:', testError);
        throw new Error(`Test upload échoué: ${testError.message}`);
      }
      
      console.log('✅ Test upload réussi:', testUpload.path);
      
      // Nettoyer le fichier test
      await supabase.storage.from('video-inspections').remove([testUpload.path]);
      console.log('🗑️ Fichier test supprimé');
      
      console.log('✅ === DIAGNOSTIC TERMINÉ - BUCKET OPÉRATIONNEL ===');
      
    } catch (error) {
      console.error('❌ Diagnostic échoué:', error);
      throw error;
    }
  }
};
