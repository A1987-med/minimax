
import { supabase } from "@/integrations/supabase/client";
import { databaseOperations } from './databaseOperations';

export const analysisService = {
  startAnalysisAsync(videoId: string): void {
    analysisService.startAnalysis(videoId).catch(error => {
      console.error('⚠️ Erreur analyse IA (non bloquante):', error);
    });
  },

  async startAnalysis(videoId: string): Promise<void> {
    try {
      const { data, error } = await supabase.functions.invoke('analyze-video', {
        body: { videoId }
      });

      if (error) {
        console.error('❌ Erreur démarrage analyse:', error);
        await databaseOperations.updateStatutAnalyse(videoId, 'erreur');
      }
    } catch (error) {
      console.error('❌ Erreur lors du démarrage de l\'analyse:', error);
      await databaseOperations.updateStatutAnalyse(videoId, 'erreur');
    }
  }
};
