
import { supabase } from "@/integrations/supabase/client";
import { VideoInspection, NonConformiteVideo, TranscriptionAudio } from './types';

export const videoDataService = {
  async getAllVideos(): Promise<VideoInspection[]> {
    console.log('📊 Récupération de toutes les vidéos...');
    
    // Use type assertion to bypass missing type definitions
    const { data, error } = await (supabase as any)
      .from('video_inspections')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('❌ Erreur récupération vidéos:', error);
      throw error;
    }

    console.log('✅ Vidéos récupérées:', data?.length || 0);
    
    return (data || []).map((item: any) => ({
      id: item.id,
      nom_fichier: item.nom_fichier,
      chemin_video: item.chemin_video,
      taille_fichier: item.taille_fichier,
      duree_video: item.duree_video,
      date_inspection: item.date_inspection,
      statut_analyse: item.statut_analyse as "en_attente" | "en_cours" | "terminee" | "erreur",
      description_environnement: item.description_environnement,
      created_at: item.created_at,
      updated_at: item.updated_at
    }));
  },

  async getVideoById(videoId: string): Promise<VideoInspection | null> {
    console.log('🔍 Récupération vidéo par ID:', videoId);
    
    const { data, error } = await (supabase as any)
      .from('video_inspections')
      .select('*')
      .eq('id', videoId)
      .single();

    if (error) {
      console.error('❌ Erreur récupération vidéo:', error);
      return null;
    }

    return data ? {
      id: data.id,
      nom_fichier: data.nom_fichier,
      chemin_video: data.chemin_video,
      taille_fichier: data.taille_fichier,
      duree_video: data.duree_video,
      date_inspection: data.date_inspection,
      statut_analyse: data.statut_analyse as "en_attente" | "en_cours" | "terminee" | "erreur",
      description_environnement: data.description_environnement,
      created_at: data.created_at,
      updated_at: data.updated_at
    } : null;
  },

  async getNonConformitesByVideoId(videoId: string): Promise<NonConformiteVideo[]> {
    console.log('🔍 Récupération non-conformités pour vidéo:', videoId);
    
    const { data, error } = await (supabase as any)
      .from('non_conformites_video')
      .select('*')
      .eq('video_inspection_id', videoId)
      .order('timestamp_video');

    if (error) {
      console.error('❌ Erreur récupération non-conformités:', error);
      throw error;
    }

    return (data || []).map((item: any) => ({
      id: item.id,
      video_inspection_id: item.video_inspection_id,
      timestamp_video: item.timestamp_video,
      type_non_conformite: item.type_non_conformite,
      description: item.description,
      niveau_gravite: item.niveau_gravite as "faible" | "moyen" | "eleve" | "critique",
      confiance_score: item.confiance_score
    }));
  },

  async getTranscriptionsByVideoId(videoId: string): Promise<TranscriptionAudio[]> {
    console.log('🔍 Récupération transcriptions pour vidéo:', videoId);
    
    const { data, error } = await (supabase as any)
      .from('transcriptions_audio')
      .select('*')
      .eq('video_inspection_id', videoId)
      .order('timestamp_debut');

    if (error) {
      console.error('❌ Erreur récupération transcriptions:', error);
      throw error;
    }

    return (data || []).map((item: any) => ({
      id: item.id,
      video_inspection_id: item.video_inspection_id,
      timestamp_debut: item.timestamp_debut,
      timestamp_fin: item.timestamp_fin,
      texte_transcrit: item.texte_transcrit,
      locuteur: item.locuteur,
      mots_cles_securite: item.mots_cles_securite
    }));
  }
};
