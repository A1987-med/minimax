
import { supabase } from "@/integrations/supabase/client";
import { VideoInspection } from './types';

export const databaseOperations = {
  async createVideoRecord(file: File, dateInspection: string, videoPath: string): Promise<VideoInspection> {
    const videoData = {
      date_inspection: dateInspection,
      nom_fichier: file.name,
      chemin_video: videoPath,
      taille_fichier: file.size,
      statut_analyse: 'en_attente' as const
    };

    console.log('🎥 Insertion en DB...');
    
    // Use type assertion to bypass missing type definitions
    const { data, error } = await (supabase as any)
      .from('video_inspections')
      .insert([videoData])
      .select()
      .single();

    if (error) {
      console.error('❌ Erreur création vidéo inspection:', error);
      
      // Nettoyer le fichier uploadé
      await supabase.storage
        .from('video-inspections')
        .remove([videoPath]);
      
      throw new Error(`Erreur base de données: ${error.message}`);
    }

    return {
      id: data.id,
      nom_fichier: data.nom_fichier,
      chemin_video: data.chemin_video,
      taille_fichier: data.taille_fichier,
      duree_video: data.duree_video,
      date_inspection: data.date_inspection,
      statut_analyse: data.statut_analyse as "en_attente" | "en_cours" | "terminee" | "erreur",
      description_environnement: data.description_environnement,
      created_at: data.created_at,
      updated_at: data.updated_at
    };
  },

  async updateStatutAnalyse(videoId: string, statut: VideoInspection['statut_analyse']): Promise<void> {
    const { error } = await (supabase as any)
      .from('video_inspections')
      .update({ statut_analyse: statut, updated_at: new Date().toISOString() })
      .eq('id', videoId);

    if (error) {
      console.error('❌ Erreur mise à jour statut:', error);
      throw error;
    }
  }
};
