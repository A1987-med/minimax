
import { supabase } from "@/integrations/supabase/client";

export const storageUpload = {
  async uploadToStorage(file: File): Promise<{ path: string }> {
    const timestamp = Date.now();
    const fileName = `uploads/${timestamp}_${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
    
    console.log('🎥 Upload vers bucket video-inspections:', fileName, `Taille: ${(file.size / (1024 * 1024)).toFixed(1)}MB`);
    
    try {
      // Vérifier d'abord si le bucket est accessible
      console.log('🔍 Vérification de l\'accès au bucket...');
      const { data: bucketTest, error: bucketError } = await supabase.storage
        .from('video-inspections')
        .list('', { limit: 1 });
      
      if (bucketError) {
        console.error('❌ Bucket inaccessible:', bucketError);
        throw new Error(`Bucket video-inspections non accessible: ${bucketError.message}`);
      }
      
      console.log('✅ Bucket accessible, début upload...');
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('video-inspections')
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false,
          duplex: 'half'
        });

      if (uploadError) {
        console.error('❌ Erreur upload détaillée:', uploadError);
        
        // Messages d'erreur spécifiques améliorés
        if (uploadError.message?.includes('policy') || uploadError.message?.includes('RLS')) {
          throw new Error('Politiques RLS bloquent l\'upload. Vérifiez que le fichier va dans le dossier "uploads/".');
        } else if (uploadError.message?.includes('413') || uploadError.message?.includes('too large') || uploadError.message?.includes('exceeded') || uploadError.message?.includes('size limit')) {
          const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
          throw new Error(`Fichier trop volumineux: ${fileSizeMB}MB. Votre plan Supabase a une limite réelle plus basse que configurée. Essayez avec un fichier < 100MB.`);
        } else if (uploadError.message?.includes('bucket')) {
          throw new Error('Bucket video-inspections inaccessible. Vérifiez la configuration Supabase.');
        } else if (uploadError.message?.includes('Internal Server Error') || uploadError.message?.includes('500')) {
          const fileSizeMB = (file.size / (1024 * 1024)).toFixed(1);
          throw new Error(`Erreur serveur Supabase (500). Causes possibles:
- Limite de stockage atteinte sur votre plan Supabase (actuel: ${fileSizeMB}MB)
- Plan Supabase limitant les fichiers volumineux
- Problème temporaire Supabase
Recommandation: Essayez un fichier < 50MB`);
        } else {
          throw new Error(`Upload échoué: ${uploadError.message}`);
        }
      }

      if (!uploadData?.path) {
        throw new Error('Upload réussi mais aucun chemin retourné');
      }

      console.log('✅ Upload réussi:', uploadData.path);
      return uploadData;
      
    } catch (error) {
      console.error('❌ Erreur réseau upload:', error);
      
      // Si c'est déjà notre erreur formatée, la relancer
      if (error.message && !error.message.includes('NetworkError')) {
        throw error;
      }
      
      // Sinon, erreur réseau générique
      throw new Error(`Erreur de connexion durant l'upload. Vérifiez votre connexion internet et réessayez.`);
    }
  }
};
