
import { supabase } from '@/integrations/supabase/client';
import type { ChecklistPrevention, ChecklistItem, Inspection } from '@/types/prevention';

class ChecklistService {
  async getAll(): Promise<ChecklistPrevention[]> {
    try {
      const { data, error } = await supabase
        .from('checklists_prevention')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        typeChecklist: item.type_checklist,
        titre: item.titre,
        items: Array.isArray(item.items) ? item.items as unknown as ChecklistItem[] : [],
        completeePar: item.completee_par || '',
        dateCompletion: item.date_completion || '',
        statut: item.statut as "en_cours" | "complete" | "incomplete",
        observations: item.observations || '',
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));
    } catch (error) {
      console.error('Erreur lors de la récupération des checklists:', error);
      return [];
    }
  }

  async create(checklist: Omit<ChecklistPrevention, 'id' | 'createdAt' | 'updatedAt'>): Promise<ChecklistPrevention> {
    try {
      const { data, error } = await supabase
        .from('checklists_prevention')
        .insert({
          type_checklist: checklist.typeChecklist,
          titre: checklist.titre,
          items: checklist.items as any,
          completee_par: checklist.completeePar,
          date_completion: checklist.dateCompletion,
          statut: checklist.statut,
          observations: checklist.observations
        })
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        typeChecklist: data.type_checklist,
        titre: data.titre,
        items: Array.isArray(data.items) ? data.items as unknown as ChecklistItem[] : [],
        completeePar: data.completee_par || '',
        dateCompletion: data.date_completion || '',
        statut: data.statut as "en_cours" | "complete" | "incomplete",
        observations: data.observations || '',
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout de la checklist:', error);
      throw error;
    }
  }

  async update(id: string, updates: Partial<ChecklistPrevention>): Promise<ChecklistPrevention> {
    try {
      const updateData: any = {};
      if (updates.typeChecklist !== undefined) updateData.type_checklist = updates.typeChecklist;
      if (updates.titre !== undefined) updateData.titre = updates.titre;
      if (updates.items !== undefined) updateData.items = updates.items as any;
      if (updates.completeePar !== undefined) updateData.completee_par = updates.completeePar;
      if (updates.dateCompletion !== undefined) updateData.date_completion = updates.dateCompletion;
      if (updates.statut !== undefined) updateData.statut = updates.statut;
      if (updates.observations !== undefined) updateData.observations = updates.observations;

      const { data, error } = await supabase
        .from('checklists_prevention')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        typeChecklist: data.type_checklist,
        titre: data.titre,
        items: Array.isArray(data.items) ? data.items as unknown as ChecklistItem[] : [],
        completeePar: data.completee_par || '',
        dateCompletion: data.date_completion || '',
        statut: data.statut as "en_cours" | "complete" | "incomplete",
        observations: data.observations || '',
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de la mise à jour de la checklist:', error);
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('checklists_prevention')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Erreur lors de la suppression de la checklist:', error);
      throw error;
    }
  }
}

class InspectionService {
  async getAll(): Promise<Inspection[]> {
    try {
      const { data, error } = await supabase
        .from('inspections')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        typeInspection: item.type_inspection || item.titre || '',
        equipementZone: item.equipement_zone || item.description || '',
        inspecteur: item.inspecteur || '',
        dateInspection: item.date_prevue || '',
        heureInspection: item.heure_inspection || '09:00',
        resultats: (typeof item.resultats === 'object' && item.resultats !== null) ? item.resultats as Record<string, any> : {},
        conformite: item.conformite !== null ? item.conformite : true,
        actionsCorrectives: item.actions_correctives || '',
        dateProchaineInspection: item.date_prochaine_inspection || '',
        statut: (item.status as "planifiee" | "en_cours" | "complete" | "reportee") || 'planifiee',
        createdAt: item.created_at,
        updatedAt: item.updated_at
      }));
    } catch (error) {
      console.error('Erreur lors de la récupération des inspections:', error);
      return [];
    }
  }

  async create(inspection: Omit<Inspection, 'id' | 'createdAt' | 'updatedAt'>): Promise<Inspection> {
    try {
      const insertData: any = {
        // Map to both old and new column names for compatibility
        titre: inspection.typeInspection,
        type_inspection: inspection.typeInspection,
        description: inspection.equipementZone,
        equipement_zone: inspection.equipementZone,
        inspecteur: inspection.inspecteur,
        date_prevue: inspection.dateInspection,
        heure_inspection: inspection.heureInspection,
        resultats: inspection.resultats,
        conformite: inspection.conformite,
        actions_correctives: inspection.actionsCorrectives,
        date_prochaine_inspection: inspection.dateProchaineInspection,
        status: inspection.statut
      };

      const { data, error } = await supabase
        .from('inspections')
        .insert(insertData)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        typeInspection: data.type_inspection || data.titre,
        equipementZone: data.equipement_zone || data.description,
        inspecteur: data.inspecteur,
        dateInspection: data.date_prevue,
        heureInspection: data.heure_inspection || '09:00',
        resultats: (typeof data.resultats === 'object' && data.resultats !== null) ? data.resultats as Record<string, any> : {},
        conformite: data.conformite !== null ? data.conformite : true,
        actionsCorrectives: data.actions_correctives || '',
        dateProchaineInspection: data.date_prochaine_inspection || '',
        statut: data.status as "planifiee" | "en_cours" | "complete" | "reportee",
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout de l\'inspection:', error);
      throw error;
    }
  }

  async update(id: string, updates: Partial<Inspection>): Promise<Inspection> {
    try {
      const updateData: any = {};
      
      // Map to both old and new column names for compatibility
      if (updates.typeInspection !== undefined) {
        updateData.titre = updates.typeInspection;
        updateData.type_inspection = updates.typeInspection;
      }
      if (updates.equipementZone !== undefined) {
        updateData.description = updates.equipementZone;
        updateData.equipement_zone = updates.equipementZone;
      }
      if (updates.inspecteur !== undefined) updateData.inspecteur = updates.inspecteur;
      if (updates.dateInspection !== undefined) updateData.date_prevue = updates.dateInspection;
      if (updates.heureInspection !== undefined) updateData.heure_inspection = updates.heureInspection;
      if (updates.resultats !== undefined) updateData.resultats = updates.resultats;
      if (updates.conformite !== undefined) updateData.conformite = updates.conformite;
      if (updates.actionsCorrectives !== undefined) updateData.actions_correctives = updates.actionsCorrectives;
      if (updates.dateProchaineInspection !== undefined) updateData.date_prochaine_inspection = updates.dateProchaineInspection;
      if (updates.statut !== undefined) updateData.status = updates.statut;

      const { data, error } = await supabase
        .from('inspections')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        typeInspection: data.type_inspection || data.titre,
        equipementZone: data.equipement_zone || data.description,
        inspecteur: data.inspecteur,
        dateInspection: data.date_prevue,
        heureInspection: data.heure_inspection || '09:00',
        resultats: (typeof data.resultats === 'object' && data.resultats !== null) ? data.resultats as Record<string, any> : {},
        conformite: data.conformite !== null ? data.conformite : true,
        actionsCorrectives: data.actions_correctives || '',
        dateProchaineInspection: data.date_prochaine_inspection || '',
        statut: data.status as "planifiee" | "en_cours" | "complete" | "reportee",
        createdAt: data.created_at,
        updatedAt: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de la mise à jour de l\'inspection:', error);
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('inspections')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'inspection:', error);
      throw error;
    }
  }
}

export const checklistService = new ChecklistService();
export const inspectionService = new InspectionService();
