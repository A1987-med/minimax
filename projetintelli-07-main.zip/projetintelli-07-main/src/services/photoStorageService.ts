
// Service de stockage des photos utilisant exclusivement Supabase Storage
import { supabasePhotoStorageService } from './supabasePhotoStorageService';

interface AnalyzedPhoto {
  id: string;
  file: File;
  url: string;
  analysis?: any;
  analyzing: boolean;
  analysisStartTime?: number;
}

class PhotoStorageService {
  private isIpad = /iPad/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  private isSafari = /Safari/.test(navigator.userAgent) && !/Chrome/.test(navigator.userAgent);

  async init(): Promise<void> {
    console.log('🔧 [PhotoStorageService] INIT - Mode Supabase Storage uniquement');
    console.log('📱 Appareil détecté - iPad:', this.isIpad, 'Safari:', this.isSafari);
    console.log('✅ Supabase Storage prêt');
  }

  async uploadPhoto(file: File): Promise<{ url: string; photoInspection: any }> {
    console.log('📸 Upload photo via Supabase Storage');
    try {
      const result = await supabasePhotoStorageService.uploadPhoto(file);
      console.log('✅ Upload réussi via Supabase');
      return result;
    } catch (error) {
      console.error('❌ Erreur upload Supabase:', error);
      throw error;
    }
  }

  async savePhotos(photos: AnalyzedPhoto[]): Promise<void> {
    console.log('💾 [PhotoStorageService] Sauvegarde via Supabase (déjà fait lors de l\'upload)');
    // Les photos sont déjà sauvegardées individuellement lors de l'upload
    console.log('✅ Sauvegarde confirmée - Photos déjà en base Supabase');
  }

  async loadPhotos(): Promise<AnalyzedPhoto[]> {
    console.log('📂 [PhotoStorageService] Chargement via Supabase Storage');
    
    try {
      const photos = await supabasePhotoStorageService.getAllPhotos();
      
      // Convertir les données Supabase vers le format AnalyzedPhoto
      const analyzedPhotos: AnalyzedPhoto[] = [];
      
      for (const photo of photos) {
        try {
          // Créer un File fictif à partir de l'URL pour maintenir la compatibilité
          const response = await fetch(photo.image_url);
          const blob = await response.blob();
          const file = new File([blob], photo.file_name, { type: photo.file_type });
          
          const analyzedPhoto: AnalyzedPhoto = {
            id: photo.id,
            file: file,
            url: photo.image_url,
            analysis: photo.analysis,
            analyzing: photo.analyzing,
            analysisStartTime: photo.analysis_start_time
          };
          
          analyzedPhotos.push(analyzedPhoto);
        } catch (error) {
          console.error('❌ Erreur conversion photo:', photo.id, error);
          // Continuer avec les autres photos même si une échoue
        }
      }
      
      console.log('✅ Chargement Supabase réussi:', analyzedPhotos.length, 'photos');
      return analyzedPhotos;
    } catch (error) {
      console.error('❌ Erreur chargement Supabase:', error);
      throw error;
    }
  }

  async clearPhotos(): Promise<void> {
    console.log('🗑️ [PhotoStorageService] Suppression via Supabase Storage');
    
    try {
      const photos = await supabasePhotoStorageService.getAllPhotos();
      for (const photo of photos) {
        await supabasePhotoStorageService.deletePhoto(photo.id);
      }
      console.log('✅ Suppression Supabase réussie');
    } catch (error) {
      console.error('❌ Erreur suppression Supabase:', error);
      throw error;
    }
  }

  async debugStorage(): Promise<void> {
    console.log('🔍 [PhotoStorageService] Debug via Supabase Storage');
    
    try {
      const photos = await supabasePhotoStorageService.getAllPhotos();
      console.log('📊 Debug Storage - Photos trouvées:', photos.length);
      photos.forEach((photo, index) => {
        console.log(`📷 Photo ${index + 1}:`, {
          id: photo.id,
          fileName: photo.file_name,
          analyzing: photo.analyzing,
          hasAnalysis: !!photo.analysis
        });
      });
    } catch (error) {
      console.error('❌ Erreur debug Supabase:', error);
    }
  }
}

export const photoStorageService = new PhotoStorageService();
