
interface Position {
  latitude: number;
  longitude: number;
}

interface NavigationResult {
  distance: number;
  bearing: number;
  formattedDistance: string;
  formattedBearing: string;
}

export class NavigationService {
  
  // Calculer la distance entre deux points GPS (formule de Haversine)
  static calculateDistance(pos1: Position, pos2: Position): number {
    const R = 6371000; // Rayon de la Terre en mètres
    const φ1 = pos1.latitude * Math.PI / 180;
    const φ2 = pos2.latitude * Math.PI / 180;
    const Δφ = (pos2.latitude - pos1.latitude) * Math.PI / 180;
    const Δλ = (pos2.longitude - pos1.longitude) * Math.PI / 180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distance en mètres
  }

  // Calculer l'orientation (bearing) entre deux points
  static calculateBearing(pos1: Position, pos2: Position): number {
    const φ1 = pos1.latitude * Math.PI / 180;
    const φ2 = pos2.latitude * Math.PI / 180;
    const Δλ = (pos2.longitude - pos1.longitude) * Math.PI / 180;

    const y = Math.sin(Δλ) * Math.cos(φ2);
    const x = Math.cos(φ1) * Math.sin(φ2) - Math.sin(φ1) * Math.cos(φ2) * Math.cos(Δλ);

    const θ = Math.atan2(y, x);

    return (θ * 180 / Math.PI + 360) % 360; // Bearing en degrés
  }

  // Obtenir les informations de navigation complètes
  static getNavigationInfo(currentPos: Position, targetPos: Position): NavigationResult {
    const distance = this.calculateDistance(currentPos, targetPos);
    const bearing = this.calculateBearing(currentPos, targetPos);

    const formattedDistance = distance < 1000 
      ? `${Math.round(distance)} m`
      : `${(distance / 1000).toFixed(1)} km`;

    const directions = [
      'Nord', 'Nord-Est', 'Est', 'Sud-Est', 
      'Sud', 'Sud-Ouest', 'Ouest', 'Nord-Ouest'
    ];
    const directionIndex = Math.round(bearing / 45) % 8;
    const formattedBearing = directions[directionIndex];

    return {
      distance,
      bearing,
      formattedDistance,
      formattedBearing
    };
  }

  // Ouvrir l'application de navigation native
  static openInNativeMap(position: Position, label?: string) {
    const { latitude, longitude } = position;
    const labelParam = label ? encodeURIComponent(label) : '';
    
    // Détection de la plateforme
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/.test(navigator.userAgent);

    if (isIOS) {
      // Utiliser Apple Maps sur iOS
      const appleUrl = `maps://?q=${labelParam}&ll=${latitude},${longitude}`;
      window.open(appleUrl, '_system');
    } else if (isAndroid) {
      // Utiliser Google Maps sur Android
      const googleUrl = `geo:${latitude},${longitude}?q=${latitude},${longitude}(${labelParam})`;
      window.open(googleUrl, '_system');
    } else {
      // Fallback pour le web - Google Maps
      const webUrl = `https://www.google.com/maps?q=${latitude},${longitude}`;
      window.open(webUrl, '_blank');
    }
  }

  // Démarrer la navigation turn-by-turn
  static startNavigation(position: Position, label?: string) {
    const { latitude, longitude } = position;
    const labelParam = label ? encodeURIComponent(label) : '';
    
    // URL universelle pour démarrer la navigation
    const navigationUrl = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}&destination_place_id=${labelParam}`;
    window.open(navigationUrl, '_blank');
  }
}

export const navigationService = NavigationService;
