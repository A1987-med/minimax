
import { ASTData } from './astTypes';
import { astDataService } from './astDataService';
import jsPDF from 'jspdf';

export interface ExportOptions {
  format: 'json' | 'pdf' | 'excel';
  includeAllCorpsMetiers?: boolean;
  corpsMetiers?: string[];
}

class ASTExportService {
  
  // Export en JSON
  exportToJSON(options: ExportOptions): void {
    const data = options.includeAllCorpsMetiers 
      ? astDataService.getAllASTData()
      : options.corpsMetiers?.map(cm => astDataService.getASTData(cm)).filter(Boolean) || [];

    const exportData = {
      exportedAt: new Date().toISOString(),
      totalCorpsMetiers: data.length,
      data: data
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { 
      type: 'application/json' 
    });
    
    this.downloadFile(blob, `ast-export-${new Date().toISOString().split('T')[0]}.json`);
    console.log('✅ Export JSON terminé:', data.length, 'corps de métiers');
  }

  // Export en PDF
  exportToPDF(options: ExportOptions): void {
    const data = options.includeAllCorpsMetiers 
      ? astDataService.getAllASTData()
      : options.corpsMetiers?.map(cm => astDataService.getASTData(cm)).filter(Boolean) || [];

    const doc = new jsPDF();
    let yPosition = 20;

    // Titre
    doc.setFontSize(20);
    doc.setFont(undefined, 'bold');
    doc.text('RAPPORT AST - ANALYSE DE SÉCURITÉ DU TRAVAIL', 20, yPosition);
    yPosition += 20;

    // Date
    doc.setFontSize(12);
    doc.setFont(undefined, 'normal');
    doc.text(`Généré le: ${new Date().toLocaleDateString('fr-FR')}`, 20, yPosition);
    yPosition += 15;

    data.forEach((astData: ASTData) => {
      // Vérifier espace page
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }

      // Corps de métier
      doc.setFontSize(16);
      doc.setFont(undefined, 'bold');
      doc.text(`CORPS DE MÉTIER: ${astData.corpsMetier.toUpperCase()}`, 20, yPosition);
      yPosition += 15;

      astData.taches.forEach((tache, tIndex) => {
        if (yPosition > 240) {
          doc.addPage();
          yPosition = 20;
        }

        doc.setFontSize(14);
        doc.setFont(undefined, 'bold');
        doc.text(`${tIndex + 1}. ${tache.nom}`, 20, yPosition);
        yPosition += 10;

        tache.operations.forEach((operation, oIndex) => {
          if (yPosition > 250) {
            doc.addPage();
            yPosition = 20;
          }

          doc.setFontSize(12);
          doc.setFont(undefined, 'normal');
          doc.text(`  ${tIndex + 1}.${oIndex + 1} ${operation.nom}`, 25, yPosition);
          yPosition += 8;

          // Risques
          if (operation.risques.length > 0) {
            doc.setFontSize(10);
            doc.text(`    Risques: ${operation.risques.length}`, 30, yPosition);
            yPosition += 6;
          }
        });
        yPosition += 5;
      });
      yPosition += 10;
    });

    doc.save(`ast-rapport-${new Date().toISOString().split('T')[0]}.pdf`);
    console.log('✅ Export PDF terminé:', data.length, 'corps de métiers');
  }

  // Export en Excel (CSV)
  exportToExcel(options: ExportOptions): void {
    const data = options.includeAllCorpsMetiers 
      ? astDataService.getAllASTData()
      : options.corpsMetiers?.map(cm => astDataService.getASTData(cm)).filter(Boolean) || [];

    const headers = [
      'Corps de Métier',
      'Tâche',
      'Opération',
      'Sous-Opération',
      'Risque Description',
      'Niveau Risque',
      'Mesures Prévention',
      'Outils',
      'Matériaux'
    ];

    const rows: string[][] = [headers];

    data.forEach((astData: ASTData) => {
      astData.taches.forEach(tache => {
        tache.operations.forEach(operation => {
          // Si pas de sous-opérations, créer une ligne pour l'opération
          if (operation.sousOperations.length === 0) {
            const risquesText = operation.risques.map(r => r.description).join('; ');
            const niveauxText = operation.risques.map(r => r.niveau).join('; ');
            const preventionText = operation.risques.flatMap(r => r.mesuresPrevention).join('; ');
            const outilsText = operation.outils.map(o => o.nom).join('; ');
            const materiauxText = operation.materiaux.map(m => m.nom).join('; ');

            rows.push([
              astData.corpsMetier,
              tache.nom,
              operation.nom,
              '',
              risquesText,
              niveauxText,
              preventionText,
              outilsText,
              materiauxText
            ]);
          } else {
            // Créer une ligne pour chaque sous-opération
            operation.sousOperations.forEach(sousOp => {
              const risquesText = sousOp.risques.map(r => r.description).join('; ');
              const niveauxText = sousOp.risques.map(r => r.niveau).join('; ');
              const preventionText = sousOp.risques.flatMap(r => r.mesuresPrevention).join('; ');
              const outilsText = operation.outils.map(o => o.nom).join('; ');
              const materiauxText = operation.materiaux.map(m => m.nom).join('; ');

              rows.push([
                astData.corpsMetier,
                tache.nom,
                operation.nom,
                sousOp.nom,
                risquesText,
                niveauxText,
                preventionText,
                outilsText,
                materiauxText
              ]);
            });
          }
        });
      });
    });

    const csvContent = rows.map(row => 
      row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(',')
    ).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    this.downloadFile(blob, `ast-export-${new Date().toISOString().split('T')[0]}.csv`);
    console.log('✅ Export Excel terminé:', data.length, 'corps de métiers');
  }

  // Méthode utilitaire pour télécharger
  private downloadFile(blob: Blob, filename: string): void {
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    }
  }

  // Obtenir statistiques pour l'export
  getExportStats(): { totalCorpsMetiers: number; totalTaches: number; totalOperations: number } {
    const allData = astDataService.getAllASTData();
    
    return {
      totalCorpsMetiers: allData.length,
      totalTaches: allData.reduce((acc, data) => acc + data.taches.length, 0),
      totalOperations: allData.reduce((acc, data) => 
        acc + data.taches.reduce((subAcc, tache) => subAcc + tache.operations.length, 0), 0
      )
    };
  }
}

export const astExportService = new ASTExportService();
