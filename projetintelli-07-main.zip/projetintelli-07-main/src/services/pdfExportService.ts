import jsPDF from 'jspdf';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';
import { ExportFilters } from './pdf/pdfExportTypes';
import { defaultPDFConfig, PDFUtils } from './pdf/pdfUtils';
import { PDFSectionGenerators } from './pdf/pdfSectionGenerators';
import { PDFAnalysisGenerators } from './pdf/pdfAnalysisGenerators';

export type { ExportFilters } from './pdf/pdfExportTypes';

export class PDFExportService {
  private doc: jsPDF;
  private config = defaultPDFConfig;
  private utils: PDFUtils;
  private sectionGenerators: PDFSectionGenerators;
  private analysisGenerators: PDFAnalysisGenerators;

  constructor() {
    this.doc = new jsPDF();
    this.utils = new PDFUtils(this.doc, this.config);
    this.sectionGenerators = new PDFSectionGenerators(this.doc, this.config);
    this.analysisGenerators = new PDFAnalysisGenerators(this.doc, this.config);
  }

  async exportPhotoReport(photos: AnalyzedPhoto[], filters: ExportFilters): Promise<void> {
    console.log('PDF Generation du rapport PDF professionnel...');
    
    const filteredPhotos = this.filterPhotosByDate(photos, filters);
    
    if (filteredPhotos.length === 0) {
      throw new Error('Aucune photo trouvee pour la periode selectionnee');
    }

    this.doc = new jsPDF();
    this.utils = new PDFUtils(this.doc, this.config);
    this.sectionGenerators = new PDFSectionGenerators(this.doc, this.config);
    this.analysisGenerators = new PDFAnalysisGenerators(this.doc, this.config);
    
    let yPosition = 20;

    // Page de couverture
    yPosition = await this.sectionGenerators.addCoverPage(filteredPhotos, filters);
    
    // Nouvelle page pour le contenu
    this.doc.addPage();
    yPosition = 20;
    
    // Table des matières
    yPosition = this.sectionGenerators.addTableOfContents(filteredPhotos, yPosition);
    
    // Nouvelle page pour le résumé
    this.doc.addPage();
    yPosition = 20;
    
    // Résumé exécutif avec graphiques
    yPosition = this.analysisGenerators.addExecutiveSummary(filteredPhotos, yPosition);
    
    // Détails des photos
    for (let i = 0; i < filteredPhotos.length; i++) {
      const photo = filteredPhotos[i];
      
      // Nouvelle page pour chaque photo
      this.doc.addPage();
      yPosition = 20;
      
      yPosition = await this.analysisGenerators.addPhotoSection(photo, i + 1, yPosition, filters);
    }

    // Page de conclusion
    this.doc.addPage();
    this.sectionGenerators.addConclusionPage(filteredPhotos);

    // Numérotation des pages
    this.utils.addPageNumbers();

    const fileName = `rapport-inspection-photos-${new Date().toISOString().split('T')[0]}.pdf`;
    this.doc.save(fileName);
    
    console.log('Rapport PDF professionnel genere:', fileName);
  }

  private filterPhotosByDate(photos: AnalyzedPhoto[], filters: ExportFilters): AnalyzedPhoto[] {
    if (!filters.dateDebut && !filters.dateFin) {
      return photos;
    }

    return photos.filter(photo => {
      let photoDate: Date;
      
      if (photo.exifData?.dateTime) {
        photoDate = new Date(photo.exifData.dateTime);
      } else {
        photoDate = new Date(photo.file.lastModified || Date.now());
      }

      if (filters.dateDebut && photoDate < filters.dateDebut) {
        return false;
      }
      
      if (filters.dateFin && photoDate > filters.dateFin) {
        return false;
      }
      
      return true;
    });
  }
}

export const pdfExportService = new PDFExportService();
