
import jsPDF from 'jspdf';

interface FormData {
  date: string;
  heureDebut: string;
  heureFin: string;
  nomCoordonnateur: string;
  zoneInspectee: string;
  secteurChantier: string;
  nombreTravailleursPresents: number;
  detailsTravailleurs: any[];
  meteoData: any;
  derogations: any[];
  permis: any;
  autres: any;
  machinerie: any;
  conformiteProtocoles: string;
  portEPI: string;
  etatEquipements: string;
  respectProcedures: string;
  nonConformites: string;
  niveauGravite: string;
  actionsCorrectivesRequises: string;
  delaiCorrection: string;
  echafaudages: string;
  espacesClos: string;
  travailHauteur: string;
  matieresDangereuses: string;
  equipementsCollectifs: string;
  observationsPositives: string;
  observationsNegatives: string;
  risquesIdentifies: string;
  actionsImmediates: string;
  recommandationsAmelioration: string;
  suiviRequis: string;
  formationNecessaire: string;
  travailleursFormes: string;
  supervisionAdequate: string;
  communicationSecurite: string;
  evaluationGlobale: string;
  pointsAmeliorer: string;
  prochaineSuggestion: string;
  signature: string;
  dateSignature: string;
}

export class RapportInspectionPDFService {
  private doc: jsPDF;

  constructor() {
    this.doc = new jsPDF();
  }

  async exportRapportComplet(formData: FormData, projectInfo?: any): Promise<void> {
    console.log('Génération du rapport complet d\'inspection SST...');

    this.doc = new jsPDF();
    let yPosition = 20;

    // Page de couverture
    this.doc.setFillColor(59, 130, 246);
    this.doc.rect(0, 0, 210, 40, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(24);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('RAPPORT D\'INSPECTION SST', 105, 25, { align: 'center' });
    
    yPosition = 55;

    // Informations générales
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(16);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('INFORMATIONS GÉNÉRALES', 20, yPosition);
    yPosition += 15;

    // Boîte d'informations
    this.doc.setFillColor(248, 250, 252);
    this.doc.rect(15, yPosition - 5, 180, 80, 'F');
    this.doc.setDrawColor(59, 130, 246);
    this.doc.setLineWidth(1);
    this.doc.rect(15, yPosition - 5, 180, 80);

    this.doc.setFontSize(11);
    this.doc.setFont('helvetica', 'normal');
    
    if (projectInfo) {
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Projet:', 20, yPosition + 5);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(projectInfo.nomProjet, 60, yPosition + 5);
      yPosition += 8;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Numéro:', 20, yPosition + 5);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(projectInfo.numeroProjet, 60, yPosition + 5);
      yPosition += 8;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Adresse:', 20, yPosition + 5);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(projectInfo.adresseProjet, 60, yPosition + 5);
      yPosition += 8;
    }

    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Date d\'inspection:', 20, yPosition + 5);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(formData.date, 80, yPosition + 5);
    yPosition += 8;

    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Heure:', 20, yPosition + 5);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(`${formData.heureDebut} - ${formData.heureFin}`, 60, yPosition + 5);
    yPosition += 8;

    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Coordonnateur:', 20, yPosition + 5);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(formData.nomCoordonnateur, 80, yPosition + 5);
    yPosition += 8;

    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Zone inspectée:', 20, yPosition + 5);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(formData.zoneInspectee, 80, yPosition + 5);
    yPosition += 8;

    this.doc.setFont('helvetica', 'bold');
    this.doc.text('Travailleurs présents:', 20, yPosition + 5);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(formData.nombreTravailleursPresents.toString(), 90, yPosition + 5);

    yPosition += 25;

    // Nouvelle page pour les détails
    this.doc.addPage();
    yPosition = 20;

    // Section Conformité
    this.addSection('CONFORMITÉ ET OBSERVATIONS', [
      { label: 'Conformité protocoles', value: formData.conformiteProtocoles },
      { label: 'Port des EPI', value: formData.portEPI },
      { label: 'État des équipements', value: formData.etatEquipements },
      { label: 'Respect des procédures', value: formData.respectProcedures }
    ], yPosition);

    yPosition += 70;

    // Section Non-conformités
    if (yPosition > 220) {
      this.doc.addPage();
      yPosition = 20;
    }

    this.addSection('NON-CONFORMITÉS', [
      { label: 'Non-conformités identifiées', value: formData.nonConformites },
      { label: 'Niveau de gravité', value: formData.niveauGravite },
      { label: 'Actions correctives requises', value: formData.actionsCorrectivesRequises },
      { label: 'Délai de correction', value: formData.delaiCorrection }
    ], yPosition);

    yPosition += 70;

    // Section Inspections spécifiques
    if (yPosition > 220) {
      this.doc.addPage();
      yPosition = 20;
    }

    this.addSection('INSPECTIONS SPÉCIFIQUES', [
      { label: 'Échafaudages', value: formData.echafaudages },
      { label: 'Espaces clos', value: formData.espacesClos },
      { label: 'Travail en hauteur', value: formData.travailHauteur },
      { label: 'Matières dangereuses', value: formData.matieresDangereuses },
      { label: 'Équipements collectifs', value: formData.equipementsCollectifs }
    ], yPosition);

    yPosition += 90;

    // Section Évaluation globale
    if (yPosition > 220) {
      this.doc.addPage();
      yPosition = 20;
    }

    this.addSection('ÉVALUATION GLOBALE', [
      { label: 'Évaluation générale', value: formData.evaluationGlobale },
      { label: 'Points à améliorer', value: formData.pointsAmeliorer },
      { label: 'Recommandations', value: formData.recommandationsAmelioration }
    ], yPosition);

    // Signature
    if (yPosition > 220) {
      this.doc.addPage();
      yPosition = 20;
    } else {
      yPosition += 70;
    }

    this.doc.setFontSize(14);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('SIGNATURE', 20, yPosition);
    yPosition += 15;

    this.doc.setFontSize(11);
    this.doc.setFont('helvetica', 'normal');
    this.doc.text(`Inspecteur: ${formData.signature}`, 20, yPosition);
    yPosition += 8;
    this.doc.text(`Date: ${new Date(formData.dateSignature).toLocaleDateString('fr-CA')}`, 20, yPosition);

    // Numérotation des pages
    const pageCount = this.doc.internal.pages.length - 1;
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      this.doc.setFontSize(8);
      this.doc.setTextColor(128, 128, 128);
      this.doc.text(`Page ${i} sur ${pageCount}`, 105, 290, { align: 'center' });
    }

    const fileName = `rapport-inspection-sst-${formData.date}.pdf`;
    this.doc.save(fileName);
    
    console.log('Rapport complet d\'inspection SST généré:', fileName);
  }

  private addSection(title: string, items: { label: string; value: string }[], yPosition: number): void {
    // Titre de section
    this.doc.setFillColor(59, 130, 246);
    this.doc.rect(15, yPosition, 180, 12, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(12);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text(title, 20, yPosition + 8);
    
    yPosition += 20;

    // Contenu
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(10);
    
    items.forEach(item => {
      if (item.value && item.value.trim()) {
        this.doc.setFont('helvetica', 'bold');
        this.doc.text(`${item.label}:`, 20, yPosition);
        
        this.doc.setFont('helvetica', 'normal');
        const splitText = this.doc.splitTextToSize(item.value, 150);
        this.doc.text(splitText, 20, yPosition + 5);
        yPosition += Math.max(8, splitText.length * 4 + 3);
      }
    });
  }
}

export const rapportInspectionPDFService = new RapportInspectionPDFService();
