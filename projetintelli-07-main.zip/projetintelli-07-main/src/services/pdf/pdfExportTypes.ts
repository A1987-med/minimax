
export interface ExportFilters {
  dateDebut?: Date;
  dateFin?: Date;
  includeAnalyses?: boolean;
  includePhotos?: boolean;
  projectInfo?: {
    nomProjet?: string;
    numeroProjet?: string;
    adresseProjet?: string;
  };
}
