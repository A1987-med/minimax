
import jsPDF from 'jspdf';
import { PDFConfig, PDFUtils } from './pdfUtils';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';
import { ExportFilters } from './pdfExportTypes';

export class PDFAnalysisGenerators {
  private utils: PDFUtils;

  constructor(private doc: jsPDF, private config: PDFConfig) {
    this.utils = new PDFUtils(doc, config);
  }

  addExecutiveSummary(filteredPhotos: AnalyzedPhoto[], yPosition: number): number {
    // En-tête professionnel avec dégradé
    this.doc.setFillColor(41, 98, 255);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 20, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(18);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('RÉSUMÉ EXÉCUTIF', this.config.margin + 8, yPosition + 13);
    
    yPosition += 30;

    // Métriques dans un tableau compact
    const stats = [
      { label: 'Photos Total', value: filteredPhotos.length.toString(), color: [52, 152, 219] },
      { label: 'Analysees', value: filteredPhotos.filter(p => p.analysis).length.toString(), color: [46, 204, 113] },
      { label: 'Non-conformites', value: filteredPhotos.reduce((acc, p) => acc + (p.analysis?.nonConformites?.length || 0), 0).toString(), color: [231, 76, 60] },
      { label: 'Risques', value: filteredPhotos.reduce((acc, p) => acc + (p.analysis?.risques?.length || 0), 0).toString(), color: [230, 126, 34] }
    ];

    // Grille de métriques 2x2
    const boxWidth = (this.config.pageWidth - 2 * this.config.margin - 15) / 2;
    const boxHeight = 25;
    let xPos = this.config.margin;
    let yPos = yPosition;

    stats.forEach((stat, index) => {
      if (index === 2) {
        xPos = this.config.margin;
        yPos += boxHeight + 5;
      }

      // Bordure subtile
      this.doc.setDrawColor(220, 220, 220);
      this.doc.setLineWidth(0.5);
      this.doc.rect(xPos, yPos, boxWidth, boxHeight);
      
      // Accent coloré à gauche
      this.doc.setFillColor(stat.color[0], stat.color[1], stat.color[2]);
      this.doc.rect(xPos, yPos, 4, boxHeight, 'F');
      
      // Fond léger
      this.doc.setFillColor(248, 249, 250);
      this.doc.rect(xPos + 4, yPos, boxWidth - 4, boxHeight, 'F');
      
      // Valeur principale
      this.doc.setTextColor(stat.color[0], stat.color[1], stat.color[2]);
      this.doc.setFontSize(16);
      this.doc.setFont(undefined, 'bold');
      this.doc.text(stat.value, xPos + 12, yPos + 12);
      
      // Label
      this.doc.setTextColor(100, 100, 100);
      this.doc.setFontSize(10);
      this.doc.setFont(undefined, 'normal');
      this.doc.text(stat.label, xPos + 12, yPos + 20);
      
      if (index % 2 === 0) xPos += boxWidth + 7.5;
    });

    yPosition = yPos + boxHeight + 25;

    // Graphique des risques compact
    this.doc.setTextColor(51, 51, 51);
    this.doc.setFontSize(14);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('Repartition des Risques', this.config.margin, yPosition);
    yPosition += 15;

    const riskLevels = ['faible', 'moyen', 'eleve', 'critique'];
    const riskLabels = ['Faible', 'Moyen', 'Eleve', 'Critique'];
    const riskColors = [[46, 204, 113], [241, 196, 15], [230, 126, 34], [231, 76, 60]] as [number, number, number][];
    
    const riskCounts = riskLevels.map(level => 
      filteredPhotos.reduce((acc, p) => {
        if (!p.analysis?.risques) return acc;
        return acc + p.analysis.risques.filter((r: any) => {
          const riskLevel = r.niveau || r.impact || r.probabilite || 'faible';
          return riskLevel.toLowerCase() === level;
        }).length;
      }, 0)
    );

    const maxCount = Math.max(...riskCounts, 1);
    const chartWidth = this.config.pageWidth - 2 * this.config.margin - 50;

    riskLabels.forEach((label, index) => {
      const barWidth = Math.max((riskCounts[index] / maxCount) * chartWidth, 2);
      
      // Barre de fond
      this.doc.setFillColor(240, 240, 240);
      this.doc.rect(this.config.margin + 45, yPosition, chartWidth, 6, 'F');
      
      // Barre de données
      this.doc.setFillColor(riskColors[index][0], riskColors[index][1], riskColors[index][2]);
      this.doc.rect(this.config.margin + 45, yPosition, barWidth, 6, 'F');
      
      // Labels
      this.doc.setTextColor(70, 70, 70);
      this.doc.setFontSize(9);
      this.doc.text(label, this.config.margin, yPosition + 4);
      this.doc.text(riskCounts[index].toString(), this.config.margin + 45 + chartWidth + 3, yPosition + 4);
      
      yPosition += 12;
    });

    return yPosition + 10;
  }

  async addPhotoSection(photo: AnalyzedPhoto, index: number, yPosition: number, filters: ExportFilters): Promise<number> {
    const photoName = this.generatePhotoDisplayName(photo, index);
    
    // En-tête de photo moderne
    this.doc.setFillColor(52, 73, 94);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 18, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(14);
    this.doc.setFont(undefined, 'bold');
    this.doc.text(`INSPECTION ${index.toString().padStart(2, '0')} • ${photoName}`, this.config.margin + 8, yPosition + 12);
    
    yPosition += 25;

    // Photo avec cadre élégant
    if (filters.includePhotos) {
      try {
        const imgData = await this.utils.convertImageToBase64(photo.file);
        const imgWidth = 100;
        const imgHeight = 75;
        const centeredX = (this.config.pageWidth - imgWidth) / 2;
        
        // Ombre portée
        this.doc.setFillColor(0, 0, 0, 0.1);
        this.doc.rect(centeredX + 2, yPosition + 2, imgWidth, imgHeight, 'F');
        
        // Cadre principal
        this.doc.setFillColor(255, 255, 255);
        this.doc.rect(centeredX - 1, yPosition - 1, imgWidth + 2, imgHeight + 2, 'F');
        this.doc.setDrawColor(200, 200, 200);
        this.doc.setLineWidth(0.5);
        this.doc.rect(centeredX - 1, yPosition - 1, imgWidth + 2, imgHeight + 2);
        
        this.doc.addImage(imgData, 'JPEG', centeredX, yPosition, imgWidth, imgHeight);
        
        yPosition += imgHeight + 15;
        
        if (photo.exifData?.dateTime) {
          this.doc.setTextColor(120, 120, 120);
          this.doc.setFontSize(8);
          this.doc.setFont(undefined, 'normal');
          const dateText = `Prise le ${new Date(photo.exifData.dateTime).toLocaleDateString('fr-FR')} a ${new Date(photo.exifData.dateTime).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}`;
          this.doc.text(dateText, this.config.pageWidth / 2, yPosition, { align: 'center' });
          yPosition += 15;
        }
        
      } catch (error) {
        console.warn('Impossible d\'inclure l\'image:', error);
        this.doc.setTextColor(150, 150, 150);
        this.doc.setFontSize(10);
        this.doc.text('Image non disponible', this.config.pageWidth / 2, yPosition, { align: 'center' });
        yPosition += 20;
      }
    }

    // Analyse avec sections compactes
    if (filters.includeAnalyses && photo.analysis) {
      yPosition = this.utils.checkPageBreak(yPosition, 60);
      yPosition = this.addCompactAnalysisSection(photo.analysis, yPosition);
    }

    return yPosition;
  }

  private generatePhotoDisplayName(photo: AnalyzedPhoto, index: number): string {
    const originalName = photo.file.name;
    const baseName = originalName.split('.')[0];
    
    if (photo.exifData?.dateTime) {
      const date = new Date(photo.exifData.dateTime);
      return `Photo_${date.getDate().toString().padStart(2, '0')}-${(date.getMonth() + 1).toString().padStart(2, '0')}-${date.getFullYear()}_${date.getHours().toString().padStart(2, '0')}h${date.getMinutes().toString().padStart(2, '0')}`;
    }
    
    return baseName.length > 25 ? `${baseName.substring(0, 25)}...` : baseName;
  }

  private addCompactAnalysisSection(analysis: any, yPosition: number): number {
    // En-tête de l'analyse
    this.doc.setFillColor(236, 240, 241);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 15, 'F');
    this.doc.setDrawColor(189, 195, 199);
    this.doc.setLineWidth(0.3);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 15);
    
    this.doc.setTextColor(52, 73, 94);
    this.doc.setFontSize(12);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('ANALYSE INTELLIGENCE ARTIFICIELLE', this.config.margin + 6, yPosition + 10);
    
    yPosition += 20;

    // Score global avec barre de progression
    if (analysis.scoreGlobal !== undefined) {
      yPosition = this.addScoreSection(analysis.scoreGlobal, yPosition);
    }

    // Description environnement
    if (analysis.environmentDescription) {
      yPosition = this.addInfoBox('ENVIRONNEMENT', analysis.environmentDescription, [52, 152, 219], yPosition);
    }

    // Analyse détaillée
    if (analysis.environmentAnalysis) {
      yPosition = this.addEnvironmentBox(analysis.environmentAnalysis, yPosition);
    }

    // Non-conformités
    if (analysis.nonConformites && analysis.nonConformites.length > 0) {
      const items = analysis.nonConformites.map((nc: any, i: number) => 
        `${i + 1}. ${nc.type || 'Non defini'} - ${nc.description || 'Description non disponible'}${nc.gravite ? ` (${nc.gravite})` : ''}`
      );
      yPosition = this.addListBox('NON-CONFORMITES', items, [231, 76, 60], yPosition);
    }

    // Risques
    if (analysis.risques && analysis.risques.length > 0) {
      const items = analysis.risques.map((r: any, i: number) => {
        const niveau = r.niveau || r.probabilite || r.impact || '';
        return `${i + 1}. ${r.type || 'Non defini'}${niveau ? ` (${niveau})` : ''} - ${r.description || 'Description non disponible'}`;
      });
      yPosition = this.addListBox('RISQUES', items, [230, 126, 34], yPosition);
    }

    // Recommandations
    if (analysis.recommandations && analysis.recommandations.length > 0) {
      const items = analysis.recommandations.map((rec: string, i: number) => 
        `${i + 1}. ${rec || 'Recommandation non definie'}`
      );
      yPosition = this.addListBox('RECOMMANDATIONS', items, [155, 89, 182], yPosition);
    }

    return yPosition + 10;
  }

  private addScoreSection(score: number, yPosition: number): number {
    yPosition = this.utils.checkPageBreak(yPosition, 35);
    
    const boxHeight = 30;
    const boxWidth = this.config.pageWidth - 2 * this.config.margin;
    
    // Fond de la boîte
    this.doc.setFillColor(248, 249, 250);
    this.doc.rect(this.config.margin, yPosition, boxWidth, boxHeight, 'F');
    this.doc.setDrawColor(52, 152, 219);
    this.doc.setLineWidth(0.5);
    this.doc.rect(this.config.margin, yPosition, boxWidth, boxHeight);
    
    // Titre
    this.doc.setTextColor(52, 152, 219);
    this.doc.setFontSize(11);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('SCORE DE SECURITE', this.config.margin + 6, yPosition + 10);
    
    // Barre de progression
    const progressY = yPosition + 15;
    const progressWidth = boxWidth - 80;
    const scoreColor = score >= 80 ? [46, 204, 113] : score >= 60 ? [241, 196, 15] : [231, 76, 60];
    
    // Fond de la barre
    this.doc.setFillColor(230, 230, 230);
    this.doc.rect(this.config.margin + 6, progressY, progressWidth, 8, 'F');
    
    // Barre de score
    this.doc.setFillColor(scoreColor[0], scoreColor[1], scoreColor[2]);
    this.doc.rect(this.config.margin + 6, progressY, (score / 100) * progressWidth, 8, 'F');
    
    // Valeur du score
    this.doc.setTextColor(scoreColor[0], scoreColor[1], scoreColor[2]);
    this.doc.setFontSize(12);
    this.doc.setFont(undefined, 'bold');
    this.doc.text(`${score}%`, this.config.margin + progressWidth + 15, progressY + 6);
    
    return yPosition + boxHeight + 8;
  }

  private addInfoBox(title: string, content: string, color: [number, number, number], yPosition: number): number {
    const maxWidth = this.config.pageWidth - 2 * this.config.margin - 12;
    const lines = this.doc.splitTextToSize(content, maxWidth);
    const boxHeight = 18 + (lines.length * 6);
    
    yPosition = this.utils.checkPageBreak(yPosition, boxHeight);
    
    // Boîte principale
    this.doc.setFillColor(248, 249, 250);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, boxHeight, 'F');
    
    // Barre colorée à gauche
    this.doc.setFillColor(color[0], color[1], color[2]);
    this.doc.rect(this.config.margin, yPosition, 4, boxHeight, 'F');
    
    // Bordure
    this.doc.setDrawColor(220, 220, 220);
    this.doc.setLineWidth(0.3);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, boxHeight);
    
    // Titre
    this.doc.setTextColor(color[0], color[1], color[2]);
    this.doc.setFontSize(10);
    this.doc.setFont(undefined, 'bold');
    this.doc.text(title, this.config.margin + 8, yPosition + 10);
    
    // Contenu
    this.doc.setTextColor(70, 70, 70);
    this.doc.setFontSize(9);
    this.doc.setFont(undefined, 'normal');
    let textY = yPosition + 16;
    lines.forEach((line: string) => {
      this.doc.text(line, this.config.margin + 8, textY);
      textY += 6;
    });
    
    return yPosition + boxHeight + 6;
  }

  private addListBox(title: string, items: string[], color: [number, number, number], yPosition: number): number {
    if (items.length === 0) return yPosition;
    
    // Calculer la hauteur nécessaire
    let totalHeight = 15; // Header
    items.forEach(item => {
      const maxWidth = this.config.pageWidth - 2 * this.config.margin - 20;
      const lines = this.doc.splitTextToSize(item, maxWidth);
      totalHeight += lines.length * 5 + 3;
    });
    
    yPosition = this.utils.checkPageBreak(yPosition, totalHeight);
    const startY = yPosition;
    
    // En-tête
    this.doc.setFillColor(color[0], color[1], color[2]);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 12, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(10);
    this.doc.setFont(undefined, 'bold');
    this.doc.text(title, this.config.margin + 6, yPosition + 8);
    
    yPosition += 15;
    
    // Fond de la liste
    this.doc.setFillColor(248, 249, 250);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, totalHeight - 15, 'F');
    
    // Bordure
    this.doc.setDrawColor(color[0], color[1], color[2]);
    this.doc.setLineWidth(0.5);
    this.doc.rect(this.config.margin, startY, this.config.pageWidth - 2 * this.config.margin, totalHeight);
    
    // Éléments de la liste
    this.doc.setTextColor(70, 70, 70);
    this.doc.setFontSize(8);
    this.doc.setFont(undefined, 'normal');
    
    items.forEach(item => {
      const maxWidth = this.config.pageWidth - 2 * this.config.margin - 20;
      const lines = this.doc.splitTextToSize(item, maxWidth);
      
      lines.forEach((line: string) => {
        this.doc.text(line, this.config.margin + 8, yPosition);
        yPosition += 5;
      });
      yPosition += 3;
    });
    
    return startY + totalHeight + 8;
  }

  private addEnvironmentBox(envAnalysis: any, yPosition: number): number {
    // Traduction des clés anglaises vers le français
    const translations = {
      'humans': 'Humains',
      'safety': 'Securite',
      'materials': 'Materiaux',
      'hazards': 'Dangers',
      'infrastructure': 'Infrastructure',
      'detected': 'detecte',
      'count': 'nombre',
      'equipmentStatus': 'statut equipement',
      'activities': 'activites',
      'positions': 'positions',
      'safetyDistance': 'distance securite',
      'helmet': 'casque',
      'vest': 'gilet',
      'harness': 'harnais',
      'boots': 'chaussures',
      'badges': 'badges',
      'compliance': 'conformite',
      'construction': 'construction',
      'tools': 'outils',
      'storage': 'rangement',
      'vehicles': 'vehicules',
      'machinery': 'machinerie',
      'level': 'niveau',
      'zones': 'zones',
      'conditions': 'conditions',
      'signage': 'signalisation',
      'barriers': 'barrieres',
      'lighting': 'eclairage',
      'surfaces': 'surfaces',
      'access': 'acces',
      'weather': 'meteo',
      'organization': 'organisation'
    };

    const sections = [
      { title: 'Humains', data: envAnalysis.humans },
      { title: 'Securite', data: envAnalysis.safety },
      { title: 'Materiaux', data: envAnalysis.materials },
      { title: 'Dangers', data: envAnalysis.hazards },
      { title: 'Infrastructure', data: envAnalysis.infrastructure }
    ].filter(section => section.data && Object.keys(section.data).length > 0);
    
    if (sections.length === 0) return yPosition;
    
    // Calculer la hauteur totale
    let totalHeight = 15; // Header
    sections.forEach(section => {
      totalHeight += 12; // Sous-titre
      Object.entries(section.data).forEach(([key, value]) => {
        if (value) {
          const frenchKey = (translations as any)[key] || key;
          const displayValue = Array.isArray(value) ? value.join(', ') : value.toString();
          const text = `• ${frenchKey}: ${displayValue}`;
          const maxWidth = this.config.pageWidth - 2 * this.config.margin - 25;
          const lines = this.doc.splitTextToSize(text, maxWidth);
          totalHeight += lines.length * 5;
        }
      });
    });
    
    yPosition = this.utils.checkPageBreak(yPosition, totalHeight);
    const startY = yPosition;
    
    // En-tête
    this.doc.setFillColor(100, 149, 237);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 12, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(10);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('ANALYSE DETAILLEE', this.config.margin + 6, yPosition + 8);
    
    yPosition += 15;
    
    // Fond
    this.doc.setFillColor(248, 249, 250);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, totalHeight - 15, 'F');
    
    // Bordure
    this.doc.setDrawColor(100, 149, 237);
    this.doc.setLineWidth(0.5);
    this.doc.rect(this.config.margin, startY, this.config.pageWidth - 2 * this.config.margin, totalHeight);
    
    // Contenu
    this.doc.setFontSize(8);
    sections.forEach(section => {
      // Sous-titre
      this.doc.setTextColor(100, 149, 237);
      this.doc.setFont(undefined, 'bold');
      this.doc.text(`${section.title}:`, this.config.margin + 8, yPosition);
      yPosition += 10;
      
      // Détails
      this.doc.setTextColor(70, 70, 70);
      this.doc.setFont(undefined, 'normal');
      Object.entries(section.data).forEach(([key, value]) => {
        if (value) {
          const frenchKey = (translations as any)[key] || key;
          const displayValue = Array.isArray(value) ? value.join(', ') : value.toString();
          const text = `• ${frenchKey}: ${displayValue}`;
          const maxWidth = this.config.pageWidth - 2 * this.config.margin - 25;
          const lines = this.doc.splitTextToSize(text, maxWidth);
          
          lines.forEach((line: string) => {
            this.doc.text(line, this.config.margin + 12, yPosition);
            yPosition += 5;
          });
        }
      });
      yPosition += 2;
    });
    
    return startY + totalHeight + 8;
  }
}
