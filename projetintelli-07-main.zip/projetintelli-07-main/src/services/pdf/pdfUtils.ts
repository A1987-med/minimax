
import jsPDF from 'jspdf';

export interface PDFColors {
  primaryColor: [number, number, number];
  secondaryColor: [number, number, number];
  accentColor: [number, number, number];
  grayColor: [number, number, number];
}

export interface PDFConfig {
  pageWidth: number;
  pageHeight: number;
  margin: number;
  lineHeight: number;
  sectionSpacing: number;
  colors: PDFColors;
}

export const defaultPDFConfig: PDFConfig = {
  pageWidth: 210,
  pageHeight: 297,
  margin: 20,
  lineHeight: 8,
  sectionSpacing: 15,
  colors: {
    primaryColor: [59, 130, 246],
    secondaryColor: [16, 185, 129],
    accentColor: [239, 68, 68],
    grayColor: [107, 114, 128]
  }
};

export class PDFUtils {
  constructor(private doc: jsPDF, private config: PDFConfig) {}

  checkPageBreak(yPosition: number, requiredSpace: number = 30): number {
    if (yPosition + requiredSpace > this.config.pageHeight - this.config.margin) {
      this.doc.addPage();
      return this.config.margin;
    }
    return yPosition;
  }

  async convertImageToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        resolve(result);
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  addPageNumbers(): void {
    const pageCount = this.doc.getNumberOfPages();
    
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      
      this.doc.setDrawColor(this.config.colors.grayColor[0], this.config.colors.grayColor[1], this.config.colors.grayColor[2]);
      this.doc.line(this.config.margin, this.config.pageHeight - 25, this.config.pageWidth - this.config.margin, this.config.pageHeight - 25);
      
      this.doc.setTextColor(this.config.colors.grayColor[0], this.config.colors.grayColor[1], this.config.colors.grayColor[2]);
      this.doc.setFontSize(8);
      this.doc.setFont(undefined, 'normal');
      
      this.doc.text(`Page ${i} sur ${pageCount}`, this.config.pageWidth - this.config.margin - 20, this.config.pageHeight - 15);
      this.doc.text('Systeme SST - Photo Inspection IA', this.config.margin, this.config.pageHeight - 15);
      this.doc.text(new Date().toLocaleDateString('fr-FR'), this.config.pageWidth / 2, this.config.pageHeight - 15, { align: 'center' });
    }
  }
}
