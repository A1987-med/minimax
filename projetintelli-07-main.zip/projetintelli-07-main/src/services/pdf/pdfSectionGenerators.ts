
import jsPDF from 'jspdf';
import { PDFConfig, PDFUtils } from './pdfUtils';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';
import { ExportFilters } from './pdfExportTypes';

export class PDFSectionGenerators {
  private utils: PDFUtils;

  constructor(private doc: jsPDF, private config: PDFConfig) {
    this.utils = new PDFUtils(doc, config);
  }

  async addCoverPage(photos: AnalyzedPhoto[], filters: ExportFilters): Promise<number> {
    // Fond dégradé simulé avec rectangles
    this.doc.setFillColor(this.config.colors.primaryColor[0], this.config.colors.primaryColor[1], this.config.colors.primaryColor[2]);
    this.doc.rect(0, 0, this.config.pageWidth, 80, 'F');
    
    this.doc.setFillColor(59, 130, 246);
    this.doc.rect(0, 80, this.config.pageWidth, 40, 'F');
    
    this.doc.setFillColor(59, 130, 246);
    this.doc.rect(0, 120, this.config.pageWidth, 40, 'F');

    // Titre principal modifié
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(28);
    this.doc.setFont(undefined, 'bold');
    this.doc.text("RAPPORT D'INSPECTION JOURNALIER", this.config.pageWidth / 2, 65, { align: 'center' });
    
    // Date du rapport à la place de "PHOTO SST"
    this.doc.setFontSize(24);
    const dateRapport = new Date().toLocaleDateString('fr-FR', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    this.doc.text(dateRapport, this.config.pageWidth / 2, 90, { align: 'center' });

    // Informations de base
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(16);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('INFORMATIONS DU RAPPORT', this.config.margin, 180);

    // Boîte d'informations
    this.doc.setDrawColor(this.config.colors.primaryColor[0], this.config.colors.primaryColor[1], this.config.colors.primaryColor[2]);
    this.doc.setLineWidth(2);
    this.doc.rect(this.config.margin, 190, this.config.pageWidth - 2 * this.config.margin, 60);
    
    this.doc.setFillColor(248, 250, 252);
    this.doc.rect(this.config.margin + 1, 191, this.config.pageWidth - 2 * this.config.margin - 2, 58, 'F');

    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(12);
    this.doc.setFont(undefined, 'normal');
    
    let infoY = 205;
    
    // Ajouter le nom du projet s'il existe
    if (filters.projectInfo?.nomProjet) {
      this.doc.setFont(undefined, 'bold');
      this.doc.text(`Projet: ${filters.projectInfo.nomProjet}`, this.config.margin + 10, infoY);
      this.doc.setFont(undefined, 'normal');
      infoY += this.config.lineHeight + 2;
    }
    
    // Ajouter le numéro du projet s'il existe
    if (filters.projectInfo?.numeroProjet) {
      this.doc.setFont(undefined, 'bold');
      this.doc.text(`Numero: ${filters.projectInfo.numeroProjet}`, this.config.margin + 10, infoY);
      this.doc.setFont(undefined, 'normal');
      infoY += this.config.lineHeight + 2;
    }
    
    // Ajouter l'adresse du projet s'il existe
    if (filters.projectInfo?.adresseProjet) {
      this.doc.setFont(undefined, 'bold');
      this.doc.text(`Adresse: ${filters.projectInfo.adresseProjet}`, this.config.margin + 10, infoY);
      this.doc.setFont(undefined, 'normal');
      infoY += this.config.lineHeight + 2;
    }
    
    this.doc.text(`Periode: ${this.formatPeriode(filters)}`, this.config.margin + 10, infoY);
    infoY += this.config.lineHeight + 2;
    this.doc.text(`Nombre de photos: ${photos.length}`, this.config.margin + 10, infoY);
    infoY += this.config.lineHeight + 2;
    this.doc.text(`Photos analysees: ${photos.filter(p => p.analysis).length}`, this.config.margin + 10, infoY);
    infoY += this.config.lineHeight + 2;
    this.doc.text(`Genere le: ${new Date().toLocaleDateString('fr-FR')} a ${new Date().toLocaleTimeString('fr-FR')}`, this.config.margin + 10, infoY);

    return 270;
  }

  addTableOfContents(photos: AnalyzedPhoto[], yPosition: number): number {
    // Titre de la section
    this.doc.setFillColor(this.config.colors.primaryColor[0], this.config.colors.primaryColor[1], this.config.colors.primaryColor[2]);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 12, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(16);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('TABLE DES MATIERES', this.config.margin + 5, yPosition + 8);
    
    yPosition += 25;
    
    // Contenu de la table
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(12);
    this.doc.setFont(undefined, 'normal');
    
    const tableItems = [
      { title: '1. Resume Executif', page: '3' },
      { title: '2. Details des Inspections Photos', page: '4+' },
      { title: `3. Conclusions et Recommandations`, page: `${4 + photos.length}` }
    ];

    tableItems.forEach(item => {
      this.doc.text(item.title, this.config.margin + 5, yPosition);
      this.doc.text(item.page, this.config.pageWidth - this.config.margin - 20, yPosition);
      
      // Ligne pointillée
      this.doc.setDrawColor(this.config.colors.grayColor[0], this.config.colors.grayColor[1], this.config.colors.grayColor[2]);
      this.doc.setLineDashPattern([1, 1], 0);
      this.doc.line(this.config.margin + 80, yPosition - 2, this.config.pageWidth - this.config.margin - 25, yPosition - 2);
      this.doc.setLineDashPattern([], 0);
      
      yPosition += this.config.sectionSpacing;
    });

    return yPosition;
  }

  addConclusionPage(photos: AnalyzedPhoto[]): void {
    let yPosition = 30;
    
    // Titre de conclusion
    this.doc.setFillColor(this.config.colors.primaryColor[0], this.config.colors.primaryColor[1], this.config.colors.primaryColor[2]);
    this.doc.rect(this.config.margin, yPosition, this.config.pageWidth - 2 * this.config.margin, 15, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(16);
    this.doc.setFont(undefined, 'bold');
    this.doc.text('CONCLUSIONS ET RECOMMANDATIONS', this.config.margin + 5, yPosition + 10);
    
    yPosition += 35;

    // Synthèse générale
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(12);
    this.doc.setFont(undefined, 'normal');
    
    const totalNonConformites = photos.reduce((acc, p) => acc + (p.analysis?.nonConformites?.length || 0), 0);
    const totalRisques = photos.reduce((acc, p) => acc + (p.analysis?.risques?.length || 0), 0);
    
    const conclusionText = [
      `Cette inspection a porte sur ${photos.length} photos avec analyse IA.`,
      `Au total, ${totalNonConformites} non-conformites et ${totalRisques} risques ont ete identifies.`,
      '',
      'ACTIONS PRIORITAIRES RECOMMANDEES:',
      '• Traiter immediatement les risques critiques identifies',
      '• Planifier la correction des non-conformites majeures',
      '• Organiser une formation de sensibilisation si necessaire',
      '• Programmer un suivi dans les 30 jours',
      '',
      'Ce rapport a ete genere automatiquement par le systeme SST.',
      'Pour toute question, contactez le responsable securite.'
    ];

    conclusionText.forEach(line => {
      if (line.startsWith('ACTIONS PRIORITAIRES')) {
        this.doc.setFont(undefined, 'bold');
        this.doc.setFontSize(12);
      } else if (line.startsWith('•')) {
        this.doc.setFont(undefined, 'normal');
        this.doc.setFontSize(11);
      } else {
        this.doc.setFont(undefined, 'normal');
        this.doc.setFontSize(11);
      }
      
      this.doc.text(line, this.config.margin, yPosition);
      yPosition += line === '' ? this.config.lineHeight : this.config.lineHeight + 4;
    });
  }

  private formatPeriode(filters: ExportFilters): string {
    if (filters.dateDebut && filters.dateFin) {
      return `${filters.dateDebut.toLocaleDateString('fr-FR')} - ${filters.dateFin.toLocaleDateString('fr-FR')}`;
    } else if (filters.dateDebut) {
      return `A partir du ${filters.dateDebut.toLocaleDateString('fr-FR')}`;
    } else if (filters.dateFin) {
      return `Jusqu'au ${filters.dateFin.toLocaleDateString('fr-FR')}`;
    }
    return 'Toutes les photos';
  }
}
