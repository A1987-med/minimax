
// Service de validation et conversion des formats d'image pour Claude AI
export class ImageFormatService {
  private static readonly SUPPORTED_FORMATS = [
    'image/jpeg',
    'image/jpg', 
    'image/png',
    'image/webp',
    'image/gif'
  ];

  private static readonly UNSUPPORTED_FORMATS = [
    'image/x-adobe-dng',
    'image/dng',
    'image/tiff',
    'image/bmp',
    'image/svg+xml',
    'image/heic',
    'image/heif',
    'image/raw',
    'image/x-canon-cr2',
    'image/x-canon-crw',
    'image/x-nikon-nef',
    'image/x-sony-arw'
  ];

  private static readonly DNG_EXTENSIONS = ['.dng', '.cr2', '.crw', '.nef', '.arw', '.raw'];

  static isFormatSupported(mimeType: string): boolean {
    return this.SUPPORTED_FORMATS.includes(mimeType.toLowerCase());
  }

  static isFormatUnsupported(mimeType: string): boolean {
    return this.UNSUPPORTED_FORMATS.includes(mimeType.toLowerCase());
  }

  static isDngOrRawFile(fileName: string, mimeType: string): boolean {
    const lowerFileName = fileName.toLowerCase();
    const lowerMimeType = mimeType.toLowerCase();
    
    // Vérifier par extension
    const hasRawExtension = this.DNG_EXTENSIONS.some(ext => lowerFileName.endsWith(ext));
    
    // Vérifier par type MIME
    const isRawMimeType = this.UNSUPPORTED_FORMATS.includes(lowerMimeType) || 
                          lowerMimeType.includes('dng') || 
                          lowerMimeType.includes('raw') ||
                          lowerMimeType === 'application/octet-stream'; // DNG parfois détecté comme octet-stream
    
    return hasRawExtension || isRawMimeType;
  }

  static async convertToSupportedFormat(file: File): Promise<File> {
    console.log('🔄 Conversion du format:', file.type, 'vers JPEG');
    console.log('🔄 Fichier:', file.name, 'Taille:', file.size);
    
    return new Promise((resolve, reject) => {
      // Pour les fichiers DNG/RAW, conversion impossible dans le navigateur
      if (this.isDngOrRawFile(file.name, file.type)) {
        console.warn('⚠️ Fichier DNG/RAW détecté, conversion impossible dans le navigateur');
        reject(new Error('Les fichiers DNG/RAW ne peuvent pas être convertis automatiquement dans le navigateur. Veuillez convertir le fichier en JPEG avec un logiciel photo (Lightroom, Photoshop, etc.) avant de l\'importer.'));
        return;
      }

      // Créer une image pour les autres formats convertibles
      const img = new Image();
      
      img.onload = () => {
        try {
          // Créer un canvas pour la conversion
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          
          if (!ctx) {
            throw new Error('Impossible de créer le contexte canvas');
          }
          
          // Redimensionner si nécessaire (max 2048px)
          const maxSize = 2048;
          let { width, height } = img;
          
          if (width > maxSize || height > maxSize) {
            const ratio = Math.min(maxSize / width, maxSize / height);
            width = Math.round(width * ratio);
            height = Math.round(height * ratio);
          }
          
          canvas.width = width;
          canvas.height = height;
          
          // Dessiner l'image
          ctx.fillStyle = 'white'; // Fond blanc pour JPEG
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);
          
          // Convertir en blob JPEG
          canvas.toBlob(
            (blob) => {
              if (blob) {
                const convertedFile = new File(
                  [blob], 
                  file.name.replace(/\.[^/.]+$/, '.jpg'),
                  { type: 'image/jpeg' }
                );
                console.log('✅ Conversion réussie vers JPEG');
                resolve(convertedFile);
              } else {
                reject(new Error('Échec de la conversion'));
              }
            },
            'image/jpeg',
            0.9 // Qualité 90%
          );
          
        } catch (error) {
          reject(error);
        }
      };
      
      img.onerror = () => {
        reject(new Error('Impossible de charger l\'image pour conversion. Le format pourrait ne pas être supporté par le navigateur.'));
      };
      
      // Charger l'image
      try {
        img.src = URL.createObjectURL(file);
      } catch (error) {
        reject(new Error('Impossible de créer l\'aperçu du fichier'));
      }
    });
  }

  static getFormatErrorMessage(mimeType: string): string {
    if (this.isFormatUnsupported(mimeType)) {
      const formatName = mimeType.split('/')[1]?.toUpperCase() || 'inconnu';
      if (formatName.includes('DNG') || formatName.includes('RAW')) {
        return `Format ${formatName} (RAW) détecté. Les fichiers RAW/DNG ne peuvent pas être convertis dans le navigateur.`;
      }
      return `Format ${formatName} non supporté par l'IA Claude. Les formats supportés sont : JPEG, PNG, WebP, GIF.`;
    }
    return 'Format d\'image non reconnu ou corrompu.';
  }

  static getSupportedFormatsInfo(): string {
    return 'Formats supportés : JPEG, PNG, WebP, GIF. Pour les fichiers RAW/DNG : convertissez-les d\'abord en JPEG avec Lightroom, Photoshop ou un autre logiciel photo.';
  }
}

export const imageFormatService = new ImageFormatService();
