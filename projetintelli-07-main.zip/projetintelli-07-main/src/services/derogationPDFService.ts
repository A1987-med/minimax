
import jsPDF from 'jspdf';

interface Position {
  latitude: number;
  longitude: number;
}

interface Derogation {
  id: string;
  numero: string;
  soustraitant: string;
  derogation: string;
  referenceLegale: string;
  suivi: string;
  observations: string;
  echeancier: string;
  position?: Position;
  images: string[];
  photosDerogation: string[];
  photosCorrection: string[];
}

export class DerogationPDFService {
  private doc: jsPDF;

  constructor() {
    this.doc = new jsPDF();
  }

  private async addImageToPDF(imageUrl: string, x: number, y: number, width: number, height: number): Promise<number> {
    try {
      // Convertir l'image en base64 si nécessaire
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      
      return new Promise((resolve, reject) => {
        img.onload = () => {
          canvas.width = width;
          canvas.height = height;
          ctx?.drawImage(img, 0, 0, width, height);
          const dataURL = canvas.toDataURL('image/jpeg', 0.8);
          
          try {
            this.doc.addImage(dataURL, 'JPEG', x, y, width, height);
            resolve(y + height + 5);
          } catch (error) {
            console.error('Erreur lors de l\'ajout de l\'image au PDF:', error);
            resolve(y);
          }
        };
        
        img.onerror = () => {
          console.error('Erreur lors du chargement de l\'image:', imageUrl);
          resolve(y);
        };
        
        img.crossOrigin = 'anonymous';
        img.src = imageUrl;
      });
    } catch (error) {
      console.error('Erreur lors du traitement de l\'image:', error);
      return y;
    }
  }

  async exportDerogationsPDF(derogations: Derogation[], projectInfo?: any): Promise<void> {
    console.log('Génération du rapport PDF des dérogations...');
    
    if (derogations.length === 0) {
      throw new Error('Aucune dérogation à exporter');
    }

    this.doc = new jsPDF();
    let yPosition = 20;

    // En-tête
    this.doc.setFillColor(220, 38, 38);
    this.doc.rect(0, 0, 210, 25, 'F');
    
    this.doc.setTextColor(255, 255, 255);
    this.doc.setFontSize(20);
    this.doc.setFont('helvetica', 'bold');
    this.doc.text('RAPPORT DE DÉROGATIONS SST', 105, 16, { align: 'center' });
    
    yPosition = 35;

    // Informations du projet
    this.doc.setTextColor(0, 0, 0);
    this.doc.setFontSize(12);
    this.doc.setFont('helvetica', 'normal');
    
    if (projectInfo) {
      this.doc.text(`Projet: ${projectInfo.nomProjet}`, 20, yPosition);
      yPosition += 8;
      this.doc.text(`Numéro: ${projectInfo.numeroProjet}`, 20, yPosition);
      yPosition += 8;
      this.doc.text(`Adresse: ${projectInfo.adresseProjet}`, 20, yPosition);
      yPosition += 15;
    }

    // Date du rapport
    this.doc.text(`Date du rapport: ${new Date().toLocaleDateString('fr-CA')}`, 20, yPosition);
    yPosition += 20;

    // Pour chaque dérogation
    for (let i = 0; i < derogations.length; i++) {
      const derogation = derogations[i];
      
      // Vérifier si on a besoin d'une nouvelle page
      if (yPosition > 220) {
        this.doc.addPage();
        yPosition = 20;
      }

      // Titre de la dérogation avec fond coloré
      this.doc.setFillColor(254, 226, 226);
      this.doc.rect(15, yPosition - 5, 180, 12, 'F');
      
      this.doc.setFontSize(14);
      this.doc.setFont('helvetica', 'bold');
      this.doc.setTextColor(185, 28, 28);
      this.doc.text(`DÉROGATION #${derogation.numero}`, 20, yPosition + 3);
      yPosition += 15;

      // Détails de la dérogation
      this.doc.setFontSize(10);
      this.doc.setFont('helvetica', 'normal');
      this.doc.setTextColor(0, 0, 0);
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Sous-traitant:', 20, yPosition);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(derogation.soustraitant, 65, yPosition);
      yPosition += 6;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Article CSTC:', 20, yPosition);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(derogation.derogation, 65, yPosition);
      yPosition += 6;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Référence légale:', 20, yPosition);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(derogation.referenceLegale, 65, yPosition);
      yPosition += 6;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Statut:', 20, yPosition);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(derogation.suivi, 65, yPosition);
      yPosition += 6;
      
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Délai de correction:', 20, yPosition);
      this.doc.setFont('helvetica', 'normal');
      this.doc.text(derogation.echeancier, 65, yPosition);
      yPosition += 10;

      // Observations
      this.doc.setFont('helvetica', 'bold');
      this.doc.text('Observations:', 20, yPosition);
      yPosition += 6;
      
      this.doc.setFont('helvetica', 'normal');
      const splitObservations = this.doc.splitTextToSize(derogation.observations, 170);
      this.doc.text(splitObservations, 20, yPosition);
      yPosition += splitObservations.length * 4 + 10;

      // Position GPS si disponible
      if (derogation.position) {
        this.doc.setFont('helvetica', 'bold');
        this.doc.text('Position GPS:', 20, yPosition);
        yPosition += 6;
        
        this.doc.setFont('helvetica', 'normal');
        this.doc.text(`Latitude: ${derogation.position.latitude.toFixed(6)}`, 20, yPosition);
        yPosition += 4;
        this.doc.text(`Longitude: ${derogation.position.longitude.toFixed(6)}`, 20, yPosition);
        yPosition += 10;
      }

      // Photos de dérogation
      if (derogation.photosDerogation.length > 0) {
        this.doc.setFont('helvetica', 'bold');
        this.doc.setTextColor(220, 38, 38);
        this.doc.text(`Photos de dérogation (${derogation.photosDerogation.length}):`, 20, yPosition);
        yPosition += 8;
        
        for (let j = 0; j < derogation.photosDerogation.length; j++) {
          if (yPosition > 200) {
            this.doc.addPage();
            yPosition = 20;
          }
          
          try {
            yPosition = await this.addImageToPDF(derogation.photosDerogation[j], 20, yPosition, 80, 60);
          } catch (error) {
            console.error('Erreur lors de l\'ajout de la photo de dérogation:', error);
            yPosition += 8;
          }
        }
        yPosition += 5;
      }

      // Photos de correction
      if (derogation.photosCorrection.length > 0) {
        this.doc.setFont('helvetica', 'bold');
        this.doc.setTextColor(34, 197, 94);
        this.doc.text(`Photos de correction (${derogation.photosCorrection.length}):`, 20, yPosition);
        yPosition += 8;
        
        for (let j = 0; j < derogation.photosCorrection.length; j++) {
          if (yPosition > 200) {
            this.doc.addPage();
            yPosition = 20;
          }
          
          try {
            yPosition = await this.addImageToPDF(derogation.photosCorrection[j], 20, yPosition, 80, 60);
          } catch (error) {
            console.error('Erreur lors de l\'ajout de la photo de correction:', error);
            yPosition += 8;
          }
        }
        yPosition += 5;
      }

      // Ligne de séparation
      if (i < derogations.length - 1) {
        this.doc.setDrawColor(220, 38, 38);
        this.doc.setLineWidth(0.5);
        this.doc.line(20, yPosition, 190, yPosition);
        yPosition += 15;
      }
    }

    // Pied de page
    const pageCount = this.doc.internal.pages.length - 1;
    for (let i = 1; i <= pageCount; i++) {
      this.doc.setPage(i);
      this.doc.setFontSize(8);
      this.doc.setTextColor(128, 128, 128);
      this.doc.text(`Page ${i} sur ${pageCount}`, 105, 290, { align: 'center' });
      this.doc.text(`Généré le ${new Date().toLocaleDateString('fr-CA')} à ${new Date().toLocaleTimeString('fr-CA')}`, 105, 285, { align: 'center' });
    }

    const fileName = `rapport-derogations-${new Date().toISOString().split('T')[0]}.pdf`;
    this.doc.save(fileName);
    
    console.log('Rapport PDF des dérogations généré:', fileName);
  }
}

export const derogationPDFService = new DerogationPDFService();
