
import { entryService } from '@/services/accueilService';
import { occupations as staticOccupations } from '@/constants/occupations';

export interface OccupationData {
  nom: string;
  source: 'employees' | 'static';
  employeesCount: number;
}

class OccupationService {
  async getAllOccupations(): Promise<OccupationData[]> {
    try {
      // Récupérer les employés depuis Gestion RH
      const employees = await entryService.getAll();
      
      // Extraire les occupations des employés
      const employeeOccupations = new Map<string, number>();
      
      employees.forEach((emp: any) => {
        // Chercher dans le champ occupation (string)
        if (emp.occupation && typeof emp.occupation === 'string' && 
            emp.occupation.trim() && emp.occupation !== 'Non spécifié' && 
            emp.occupation !== 'Valide' && emp.occupation !== 'Échue') {
          const occupation = emp.occupation.trim();
          employeeOccupations.set(occupation, (employeeOccupations.get(occupation) || 0) + 1);
        }

        // Chercher dans le champ occupations (array)
        if (emp.occupations && Array.isArray(emp.occupations)) {
          emp.occupations.forEach(occ => {
            if (occ && typeof occ === 'string' && occ.trim() && 
                occ !== 'Non spécifié' && occ !== 'Valide' && occ !== 'Échue') {
              const occupation = occ.trim();
              employeeOccupations.set(occupation, (employeeOccupations.get(occupation) || 0) + 1);
            }
          });
        }
      });

      // Créer la liste unifiée
      const occupationsList: OccupationData[] = [];

      // Ajouter les occupations des employés
      employeeOccupations.forEach((count, nom) => {
        occupationsList.push({
          nom,
          source: 'employees',
          employeesCount: count
        });
      });

      // Ajouter les occupations statiques qui ne sont pas déjà présentes
      staticOccupations.forEach(staticOcc => {
        if (!employeeOccupations.has(staticOcc)) {
          occupationsList.push({
            nom: staticOcc,
            source: 'static',
            employeesCount: 0
          });
        }
      });

      // Trier par source (employés d'abord) puis par nom
      return occupationsList.sort((a, b) => {
        if (a.source !== b.source) {
          return a.source === 'employees' ? -1 : 1;
        }
        return a.nom.localeCompare(b.nom);
      });

    } catch (error) {
      console.error('Erreur lors de la récupération des occupations:', error);
      // Fallback sur les occupations statiques
      return staticOccupations.map(nom => ({
        nom,
        source: 'static' as const,
        employeesCount: 0
      }));
    }
  }

  async getEmployeeOccupations(): Promise<string[]> {
    try {
      const employees = await entryService.getAll();
      const occupationsSet = new Set<string>();
      
      employees.forEach((emp: any) => {
        // Chercher dans le champ occupation (string)
        if (emp.occupation && typeof emp.occupation === 'string' && 
            emp.occupation.trim() && emp.occupation !== 'Non spécifié' && 
            emp.occupation !== 'Valide' && emp.occupation !== 'Échue') {
          occupationsSet.add(emp.occupation.trim());
        }

        // Chercher dans le champ occupations (array)
        if (emp.occupations && Array.isArray(emp.occupations)) {
          emp.occupations.forEach(occ => {
            if (occ && typeof occ === 'string' && occ.trim() && 
                occ !== 'Non spécifié' && occ !== 'Valide' && occ !== 'Échue') {
              occupationsSet.add(occ.trim());
            }
          });
        }
      });

      return Array.from(occupationsSet).sort();
    } catch (error) {
      console.error('Erreur lors de la récupération des occupations des employés:', error);
      return [];
    }
  }
}

export const occupationService = new OccupationService();
