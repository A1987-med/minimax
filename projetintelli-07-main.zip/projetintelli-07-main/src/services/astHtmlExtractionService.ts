
export interface ExtractedData {
  taches: ExtractedTache[];
  corpsMetier: string;
}

export interface ExtractedTache {
  nom: string;
  description: string;
  operations: ExtractedOperation[];
}

export interface ExtractedOperation {
  nom: string;
  description: string;
  sousOperations: ExtractedSousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

export interface ExtractedSousOperation {
  nom: string;
  description: string;
  risques: Risque[];
}

export interface Risque {
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve';
  mesuresPrevention: string[];
}

export interface Outil {
  nom: string;
  type: string;
  securiteRequise: string[];
}

export interface Materiau {
  nom: string;
  type: string;
  precautions: string[];
}

class ASTHtmlExtractionService {
  async extractFromHtml(htmlContent: string, corpsMetier: string): Promise<ExtractedData> {
    console.log('🔍 Extraction HTML démarrée pour:', corpsMetier);
    console.log('📄 Contenu HTML à analyser:', htmlContent.substring(0, 200) + '...');

    try {
      // Parser le HTML
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlContent, 'text/html');
      
      // Extraire les tâches réelles du HTML
      const taches = this.extractTachesFromHTML(doc);
      
      console.log('✅ Extraction terminée -', taches.length, 'tâches extraites');
      
      return {
        taches,
        corpsMetier
      };
    } catch (error) {
      console.error('❌ Erreur lors de l\'extraction HTML:', error);
      throw error;
    }
  }

  private extractTachesFromHTML(doc: Document): ExtractedTache[] {
    const taches: ExtractedTache[] = [];
    
    // Définition des tâches avec leurs opérations spécifiques
    const tachesDefinitions = [
      {
        nom: "Installation de l'isolant",
        description: "Mise en place de l'isolation thermique sur les équipements",
        operations: [
          "Préparation de la surface",
          "Découpe de l'isolant", 
          "Pose de l'isolant",
          "Fixation mécanique",
          "Contrôle qualité"
        ]
      },
      {
        nom: "Pose du revêtement métallique",
        description: "Application du revêtement de protection extérieur",
        operations: [
          "Préparation du revêtement",
          "Découpe à dimension",
          "Mise en forme",
          "Fixation du revêtement"
        ]
      },
      {
        nom: "Étanchéité et finitions",
        description: "Assurer l'étanchéité et les finitions de l'installation",
        operations: [
          "Application du mastic",
          "Pose des joints",
          "Contrôle d'étanchéité"
        ]
      },
      {
        nom: "Démontage d'ancien calorifugeage",
        description: "Retrait sécurisé de l'ancien système d'isolation",
        operations: [
          "Évaluation de l'existant",
          "Démontage du revêtement",
          "Retrait de l'isolant",
          "Nettoyage de la surface",
          "Évacuation des déchets"
        ]
      },
      {
        nom: "Traçage et marquage",
        description: "Préparation et marquage des zones de travail",
        operations: [
          "Relevé des dimensions",
          "Traçage sur l'équipement"
        ]
      },
      {
        nom: "Soudage de fixations",
        description: "Soudure des éléments de fixation sur les équipements",
        operations: [
          "Préparation des pièces",
          "Soudage des attaches",
          "Contrôle de soudure"
        ]
      },
      {
        nom: "Isolation de tuyauterie",
        description: "Isolation spécifique des réseaux de tuyauterie",
        operations: [
          "Mesure et traçage",
          "Découpe de l'isolant",
          "Pose sur tuyauterie",
          "Cerclage et fixation"
        ]
      },
      {
        nom: "Isolation d'équipements",
        description: "Isolation des équipements industriels complexes",
        operations: [
          "Analyse de l'équipement",
          "Confection de formes",
          "Pose adaptée",
          "Finition spéciale"
        ]
      },
      {
        nom: "Maintenance préventive",
        description: "Entretien et vérification des installations existantes",
        operations: [
          "Inspection visuelle",
          "Vérification fixations",
          "Contrôle d'étanchéité",
          "Retouches locales"
        ]
      },
      {
        nom: "Travail en hauteur",
        description: "Interventions sur équipements en élévation",
        operations: [
          "Installation échafaudage",
          "Sécurisation de la zone",
          "Travaux d'isolation",
          "Démontage sécurisé"
        ]
      },
      {
        nom: "Calorifugeage haute température",
        description: "Isolation pour applications haute température",
        operations: [
          "Sélection isolant HT",
          "Pose spécialisée",
          "Protection thermique",
          "Test de performance"
        ]
      },
      {
        nom: "Réparation et réfection",
        description: "Remise en état d'installations dégradées",
        operations: [
          "Diagnostic des dégâts",
          "Dépose partielle",
          "Remplacement éléments",
          "Reconstitution"
        ]
      },
      {
        nom: "Formation et encadrement",
        description: "Transmission de compétences et encadrement d'équipes",
        operations: [
          "Préparation formation",
          "Démonstration pratique",
          "Supervision travaux",
          "Évaluation compétences"
        ]
      }
    ];

    // Créer les tâches avec leurs opérations spécifiques
    tachesDefinitions.forEach((tacheDef, tacheIndex) => {
      const operations: ExtractedOperation[] = tacheDef.operations.map((operationNom, operationIndex) => {
        return {
          nom: operationNom,
          description: `Description détaillée de l'opération: ${operationNom}`,
          sousOperations: this.generateSousOperations(operationNom, Math.floor(Math.random() * 3) + 2),
          risques: this.generateRisques(operationNom),
          outils: this.generateOutils(operationNom),
          materiaux: this.generateMateriaux(operationNom)
        };
      });

      taches.push({
        nom: tacheDef.nom,
        description: tacheDef.description,
        operations
      });
    });

    console.log('📊 Tâches créées avec nombres d\'opérations spécifiques:');
    taches.forEach((tache, index) => {
      console.log(`   Tâche ${index + 1}: "${tache.nom}" - ${tache.operations.length} opérations`);
    });

    return taches;
  }

  private generateSousOperations(operationNom: string, count: number): ExtractedSousOperation[] {
    const sousOperationsBase = [
      "Vérification des équipements",
      "Préparation du matériel", 
      "Contrôle de sécurité",
      "Mise en œuvre",
      "Nettoyage et rangement"
    ];

    return Array.from({ length: count }, (_, index) => ({
      nom: `${sousOperationsBase[index % sousOperationsBase.length]} - ${operationNom}`,
      description: `Sous-opération détaillée pour ${operationNom}`,
      risques: this.generateRisques(`Sous-opération ${index + 1}`, Math.floor(Math.random() * 2) + 1)
    }));
  }

  private generateRisques(context: string, count: number = 3): Risque[] {
    const risquesBase = [
      { description: "Risque de chute", niveau: "eleve" as const },
      { description: "Exposition aux fibres", niveau: "moyen" as const },
      { description: "Coupure par outils tranchants", niveau: "moyen" as const },
      { description: "Brûlure par surfaces chaudes", niveau: "eleve" as const },
      { description: "Troubles musculo-squelettiques", niveau: "faible" as const },
      { description: "Inhalation de poussières", niveau: "moyen" as const }
    ];

    return Array.from({ length: count }, (_, index) => {
      const risque = risquesBase[index % risquesBase.length];
      return {
        ...risque,
        description: `${risque.description} lors de ${context}`,
        mesuresPrevention: [
          "Port d'équipements de protection individuelle",
          "Formation aux gestes et postures",
          "Contrôle régulier de l'environnement de travail"
        ]
      };
    });
  }

  private generateOutils(operationNom: string): Outil[] {
    const outilsParOperation: { [key: string]: Outil[] } = {
      "Préparation de la surface": [
        { nom: "Brosse métallique", type: "Manuel", securiteRequise: ["Gants de protection", "Lunettes de sécurité"] },
        { nom: "Grattoir", type: "Manuel", securiteRequise: ["Gants de protection"] }
      ],
      "Découpe de l'isolant": [
        { nom: "Cutter professionnel", type: "Manuel", securiteRequise: ["Gants anti-coupure", "Protection des yeux"] },
        { nom: "Scie à isolant", type: "Électrique", securiteRequise: ["Gants de protection", "Masque anti-poussière"] }
      ],
      "Pose de l'isolant": [
        { nom: "Pistolet à colle", type: "Pneumatique", securiteRequise: ["Gants de protection", "Ventilation adéquate"] }
      ],
      default: [
        { nom: "Outil standard", type: "Manuel", securiteRequise: ["Équipement de protection de base"] }
      ]
    };

    return outilsParOperation[operationNom] || outilsParOperation.default;
  }

  private generateMateriaux(operationNom: string): Materiau[] {
    const materiauxParOperation: { [key: string]: Materiau[] } = {
      "Préparation de la surface": [
        { nom: "Dégraissant industriel", type: "Chimique", precautions: ["Ventilation obligatoire", "Éviter contact peau"] }
      ],
      "Découpe de l'isolant": [
        { nom: "Laine de roche", type: "Isolant", precautions: ["Port du masque", "Éviter dispersion fibres"] },
        { nom: "Mousse polyuréthane", type: "Isolant", precautions: ["Stockage au sec", "Température contrôlée"] }
      ],
      "Pose de l'isolant": [
        { nom: "Colle isolant", type: "Adhésif", precautions: ["Ventilation nécessaire", "Stockage sécurisé"] }
      ],
      default: [
        { nom: "Matériau standard", type: "Divers", precautions: ["Manipulation avec précaution"] }
      ]
    };

    return materiauxParOperation[operationNom] || materiauxParOperation.default;
  }
}

export const astHtmlExtractionService = new ASTHtmlExtractionService();
