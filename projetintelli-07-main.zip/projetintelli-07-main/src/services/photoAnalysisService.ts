
// src/services/photoAnalysisService.ts
import { supabase } from '@/integrations/supabase/client';

export type PhotoAnalysisResult = {
  nonConformites: Array<{
    type: string;
    description: string;
    gravite: 'faible' | 'moyen' | 'eleve' | 'critique';
    solution: string;
  }>;
  risques: Array<{
    type: string;
    description: string;
    probabilite: 'faible' | 'moyen' | 'eleve';
    impact: 'faible' | 'moyen' | 'eleve' | 'critique';
    prevention: string;
  }>;
  scoreGlobal: number;
  recommandations: string[];
  environmentAnalysis?: {
    humans: {
      detected: boolean;
      count: string;
      equipmentStatus: string;
      activities: string[];
      positions?: string;
      safetyDistance?: string;
    };
    safety: {
      helmet: string;
      vest: string;
      harness: string;
      boots: string;
      badges?: string;
      compliance?: string;
    };
    materials: {
      construction?: string[];
      tools?: string[];
      storage: string;
      vehicles?: string;
      machinery?: string;
    };
    hazards: {
      level: string;
      zones: string[];
      conditions: string;
      signage?: string;
      barriers?: string;
    };
    infrastructure: {
      lighting: string;
      surfaces: string;
      access: string;
      weather?: string;
      organization?: string;
    };
  };
  environmentDescription?: string;
};

// Fonction pour envoyer la photo à l'API Claude pour analyse
export const analyzePhoto = async (imageUrl: string): Promise<PhotoAnalysisResult> => {
  console.log('📸 [PhotoAnalysisService] Envoi de la photo à Claude pour analyse');
  
  try {
    const { data, error } = await supabase.functions.invoke('analyze-photo', {
      body: { imageUrl },
    });

    if (error) {
      console.error('❌ [PhotoAnalysisService] Erreur Edge Function:', error);
      throw new Error(`Erreur lors de l'analyse de l'image: ${error.message}`);
    }

    console.log('✅ [PhotoAnalysisService] Réponse reçue de Claude:', data.success ? 'Succès' : 'Échec');
    
    if (!data.success) {
      throw new Error(`Erreur lors de l'analyse: ${data.error}`);
    }

    return data.analysis;
  } catch (error) {
    console.error('❌ [PhotoAnalysisService] Exception:', error);
    throw error;
  }
};
