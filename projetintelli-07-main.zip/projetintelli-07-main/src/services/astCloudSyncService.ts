
import { supabase } from '@/integrations/supabase/client';
import { ASTData } from './astTypes';
import { astDataService } from './astDataService';

class ASTCloudSyncService {
  
  // Sauvegarder vers Supabase
  async saveToCloud(astData: ASTData): Promise<boolean> {
    try {
      console.log('🌐 Sauvegarde cloud pour:', astData.corpsMetier);
      
      const { error } = await supabase.from('ast_data').upsert({
        corps_metier: astData.corpsMetier,
        data: astData as any,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'corps_metier'
      });

      if (error) {
        console.error('❌ Erreur sauvegarde cloud:', error);
        return false;
      }

      console.log('✅ Sauvegarde cloud réussie pour:', astData.corpsMetier);
      return true;
    } catch (error) {
      console.error('❌ Erreur sauvegarde cloud:', error);
      return false;
    }
  }

  // Charger depuis Supabase
  async loadFromCloud(corpsMetier: string): Promise<ASTData | null> {
    try {
      console.log('🌐 Chargement cloud pour:', corpsMetier);
      
      const { data, error } = await supabase
        .from('ast_data')
        .select('data')
        .eq('corps_metier', corpsMetier)
        .single();

      if (error || !data) {
        console.log('ℹ️ Aucune donnée cloud pour:', corpsMetier);
        return null;
      }

      console.log('✅ Chargement cloud réussi pour:', corpsMetier);
      return data.data as unknown as ASTData;
    } catch (error) {
      console.error('❌ Erreur chargement cloud:', error);
      return null;
    }
  }

  // Synchroniser toutes les données
  async syncAllToCloud(): Promise<{ success: number; errors: number }> {
    const allData = astDataService.getAllASTData();
    let success = 0;
    let errors = 0;

    console.log('🔄 Synchronisation de', allData.length, 'corps de métiers...');

    for (const astData of allData) {
      const result = await this.saveToCloud(astData);
      if (result) {
        success++;
      } else {
        errors++;
      }
    }

    console.log(`✅ Synchronisation terminée: ${success} réussies, ${errors} erreurs`);
    return { success, errors };
  }

  // Charger toutes les données du cloud
  async loadAllFromCloud(): Promise<ASTData[]> {
    try {
      console.log('🌐 Chargement de toutes les données cloud...');
      
      const { data, error } = await supabase
        .from('ast_data')
        .select('data');

      if (error) {
        console.error('❌ Erreur chargement cloud:', error);
        return [];
      }

      const astDataArray = data?.map((item: any) => item.data as unknown as ASTData) || [];
      console.log('✅ Chargé', astDataArray.length, 'corps de métiers du cloud');
      return astDataArray;
    } catch (error) {
      console.error('❌ Erreur chargement cloud:', error);
      return [];
    }
  }

  // Supprimer du cloud
  async deleteFromCloud(corpsMetier: string): Promise<boolean> {
    try {
      console.log('🗑️ Suppression cloud pour:', corpsMetier);
      
      const { error } = await supabase
        .from('ast_data')
        .delete()
        .eq('corps_metier', corpsMetier);

      if (error) {
        console.error('❌ Erreur suppression cloud:', error);
        return false;
      }

      console.log('✅ Suppression cloud réussie pour:', corpsMetier);
      return true;
    } catch (error) {
      console.error('❌ Erreur suppression cloud:', error);
      return false;
    }
  }

  // Synchroniser depuis le cloud vers le local
  async syncFromCloud(): Promise<{ imported: number; errors: number }> {
    try {
      console.log('🔄 Synchronisation depuis le cloud...');
      
      const cloudData = await this.loadAllFromCloud();
      let imported = 0;
      let errors = 0;

      for (const astData of cloudData) {
        try {
          astDataService.saveASTData(astData);
          imported++;
          console.log('✅ Données importées pour:', astData.corpsMetier);
        } catch (error) {
          console.error('❌ Erreur import pour:', astData.corpsMetier, error);
          errors++;
        }
      }

      console.log(`✅ Import terminé: ${imported} réussies, ${errors} erreurs`);
      return { imported, errors };
    } catch (error) {
      console.error('❌ Erreur synchronisation depuis cloud:', error);
      return { imported: 0, errors: 1 };
    }
  }
}

export const astCloudSyncService = new ASTCloudSyncService();
