import { ASTData, ExtractedTache, ExtractedOperation } from './astTypes';
import { astHtmlExtractionService } from './astHtmlExtractionService';

export interface TextExtractionInput {
  corpsMetier: string;
  textContent: string;
}

class ASTTextExtractionService {
  
  async extractASTFromText(input: TextExtractionInput): Promise<ASTData> {
    console.log('🚀 === DÉBUT EXTRACTION AST DEPUIS TEXTE ===');
    console.log('📋 Corps de métier:', input.corpsMetier);
    console.log('📄 Longueur du texte:', input.textContent.length, 'caractères');
    
    const startTime = Date.now();
    
    try {
      // Vérifier si c'est du HTML pour le calorifugeur
      if (input.textContent.includes('<!DOCTYPE html') && 
          input.corpsMetier.toLowerCase().includes('calorifugeur')) {
        console.log('🔍 Contenu HTML détecté pour calorifugeur, utilisation de l\'extracteur HTML spécialisé');
        const extractedData = await astHtmlExtractionService.extractFromHtml(input.textContent, input.corpsMetier);
        return {
          corpsMetier: extractedData.corpsMetier,
          taches: extractedData.taches,
          extractedAt: new Date().toISOString()
        };
      }

      const astData = this.parseTextToAST(input);

      const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
      console.log(`🎉 === EXTRACTION TEXTE COMPLÈTE EN ${totalTime}s ===`);
      console.log('📋 Résultat:', astData.taches.length, 'tâches extraites du texte');

      return astData;
      
    } catch (error) {
      const totalTime = ((Date.now() - startTime) / 1000).toFixed(2);
      console.error(`❌ === ÉCHEC APRÈS ${totalTime}s ===`);
      console.error('💥 Erreur complète:', error);
      
      throw new Error(`Extraction AST depuis texte échouée: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
    }
  }

  private parseTextToAST(input: TextExtractionInput): ASTData {
    console.log('🔍 Parsing du texte pour extraction AST avec sous-opérations...');
    
    const lines = input.textContent.split('\n').map(line => line.trim()).filter(line => line.length > 0);
    
    const tachesMap = new Map<number, ExtractedTache>();
    let currentTache: ExtractedTache | null = null;
    let currentOperation: ExtractedOperation | null = null;
    
    for (const line of lines) {
      // Pattern pour les tâches principales (ex: "1. PRÉPARER LES TRAVAUX")
      const tacheMatch = line.match(/^(\d+)\.\s+(.+)$/);
      if (tacheMatch) {
        const numero = parseInt(tacheMatch[1]);
        const nom = tacheMatch[2].trim();
        
        currentTache = {
          nom,
          description: nom,
          operations: []
        };
        
        tachesMap.set(numero, currentTache);
        currentOperation = null;
        console.log(`✅ Tâche ${numero} extraite: "${nom}"`);
        continue;
      }
      
      // Pattern pour les opérations (ex: "1.1 Recevoir les consignes")
      const operationMatch = line.match(/^(\d+)\.(\d+)\s+(.+)$/);
      if (operationMatch && currentTache) {
        const tacheNum = parseInt(operationMatch[1]);
        const operationNum = parseInt(operationMatch[2]);
        const nom = operationMatch[3].trim();
        
        currentOperation = {
          nom,
          description: nom,
          sousOperations: [],
          risques: [
            {
              description: `Risques liés à: ${nom}`,
              niveau: 'moyen' as const,
              mesuresPrevention: [
                "Respecter les procédures de sécurité",
                "Porter les équipements de protection individuelle",
                "Vérifier l'état des équipements avant utilisation"
              ]
            }
          ],
          outils: [
            {
              nom: `Outils pour ${nom}`,
              type: "Équipement professionnel",
              securiteRequise: [
                "Vérification avant utilisation",
                "Formation sur l'utilisation",
                "Maintenance régulière"
              ]
            }
          ],
          materiaux: [
            {
              nom: `Matériaux pour ${nom}`,
              type: "Matériau spécialisé",
              precautions: [
                "Manipulation selon les fiches techniques",
                "Stockage approprié",
                "Respect des normes de sécurité"
              ]
            }
          ]
        };
        
        if (!currentTache.operations) {
          currentTache.operations = [];
        }
        currentTache.operations.push(currentOperation);
        console.log(`✅ Opération ${tacheNum}.${operationNum} extraite: "${nom}"`);
        continue;
      }
      
      // Pattern pour les sous-opérations (ex: "1.1.1 Se rendre sur les lieux des travaux")
      const sousOperationMatch = line.match(/^(\d+)\.(\d+)\.(\d+)\s+(.+)$/);
      if (sousOperationMatch && currentOperation) {
        const tacheNum = parseInt(sousOperationMatch[1]);
        const operationNum = parseInt(sousOperationMatch[2]);
        const sousOperationNum = parseInt(sousOperationMatch[3]);
        const nom = sousOperationMatch[4].trim();
        
        const sousOperation = {
          nom,
          description: nom,
          risques: [
            {
              description: `Risques spécifiques à: ${nom}`,
              niveau: 'faible' as const,
              mesuresPrevention: [
                "Suivre les procédures détaillées",
                "Utiliser les équipements de protection",
                "Signaler toute anomalie"
              ]
            }
          ]
        };
        
        if (!currentOperation.sousOperations) {
          currentOperation.sousOperations = [];
        }
        currentOperation.sousOperations.push(sousOperation);
        console.log(`✅ Sous-opération ${tacheNum}.${operationNum}.${sousOperationNum} extraite: "${nom}"`);
        continue;
      }
      
      // Ignorer les lignes qui ne correspondent à aucun pattern
      // (descriptions, notes, etc.)
    }
    
    const tachesArray = Array.from(tachesMap.values());
    
    // S'assurer que toutes les tâches ont operations initialisé
    tachesArray.forEach(tache => {
      if (!tache.operations) {
        tache.operations = [];
      }
      // S'assurer que toutes les opérations ont leurs propriétés initialisées
      tache.operations.forEach(operation => {
        if (!operation.sousOperations) operation.sousOperations = [];
        if (!operation.risques) operation.risques = [];
        if (!operation.outils) operation.outils = [];
        if (!operation.materiaux) operation.materiaux = [];
      });
    });
    
    const totalOperations = tachesArray.reduce((acc, t) => acc + (t.operations ? t.operations.length : 0), 0);
    const totalSousOperations = tachesArray.reduce((acc, t) => acc + (t.operations ? t.operations.reduce((subAcc, op) => subAcc + (op.sousOperations ? op.sousOperations.length : 0), 0) : 0), 0);
    
    console.log(`📊 Résultat final: ${tachesArray.length} tâches principales`);
    console.log(`📊 Total opérations: ${totalOperations}`);
    console.log(`📊 Total sous-opérations: ${totalSousOperations}`);
    
    return {
      corpsMetier: input.corpsMetier,
      taches: tachesArray,
      extractedAt: new Date().toISOString()
    };
  }
}

export const astTextExtractionService = new ASTTextExtractionService();
