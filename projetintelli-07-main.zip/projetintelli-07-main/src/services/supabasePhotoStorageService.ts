
import { supabase } from '@/integrations/supabase/client';

interface PhotoAnalysisResult {
  nonConformites: Array<{
    type: string;
    description: string;
    gravite: 'faible' | 'moyen' | 'eleve';
    solution: string;
  }>;
  risques: Array<{
    type: string;
    description: string;
    niveau: 'faible' | 'moyen' | 'eleve';
    prevention: string;
  }>;
  scoreGlobal: number;
  recommandations: string[];
}

interface PhotoInspection {
  id: string;
  file_name: string;
  file_size: number;
  file_type: string;
  image_url: string;
  analysis?: PhotoAnalysisResult;
  analyzing: boolean;
  timestamp: number;
  analysis_start_time?: number;
  created_at?: string;
  updated_at?: string;
}

export class SupabasePhotoStorageService {
  private bucket = 'photo-inspections';
  
  async uploadPhoto(file: File): Promise<{ url: string; photoInspection: PhotoInspection }> {
    try {
      console.log('📸 Début upload photo vers Supabase Storage...');
      console.log('📸 Fichier:', { name: file.name, size: file.size, type: file.type });

      // Générer un nom unique pour le fichier
      const timestamp = Date.now();
      const uniqueId = crypto.randomUUID();
      const fileExtension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
      const fileName = `inspection_${timestamp}_${uniqueId}.${fileExtension}`;
      
      console.log('📸 Nom fichier généré:', fileName);

      // Upload vers Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from(this.bucket)
        .upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) {
        console.error('❌ Erreur upload Supabase Storage:', uploadError);
        throw new Error(`Erreur upload: ${uploadError.message}`);
      }

      console.log('✅ Upload Supabase Storage réussi:', uploadData);

      // Obtenir l'URL publique
      const { data: urlData } = supabase.storage
        .from(this.bucket)
        .getPublicUrl(fileName);

      if (!urlData?.publicUrl) {
        throw new Error('Impossible d\'obtenir l\'URL publique');
      }

      console.log('🔗 URL publique obtenue:', urlData.publicUrl);

      // Créer l'enregistrement dans la table photo_inspections
      const photoInspectionData = {
        id: uniqueId,
        // Use both old and new column names for compatibility
        file_name: file.name,
        nom_fichier: file.name,
        file_size: file.size,
        taille_fichier: file.size,
        file_type: file.type,
        type_fichier: file.type,
        image_url: urlData.publicUrl,
        analysis: null as any,
        analysis_result: null as any,
        analyzing: false,
        analyzing_status: false,
        timestamp: timestamp,
        analysis_start_time: null
      };

      const { data: dbData, error: dbError } = await supabase
        .from('photo_inspections')
        .insert([photoInspectionData])
        .select()
        .single();

      if (dbError) {
        console.error('❌ Erreur insertion DB:', dbError);
        // Nettoyer le fichier uploadé en cas d'erreur DB
        await supabase.storage.from(this.bucket).remove([fileName]);
        throw new Error(`Erreur base de données: ${dbError.message}`);
      }

      console.log('✅ Enregistrement DB créé:', dbData);

      const photoInspection: PhotoInspection = {
        id: dbData.id,
        file_name: dbData.file_name || dbData.nom_fichier || '',
        file_size: dbData.file_size || dbData.taille_fichier || 0,
        file_type: dbData.file_type || dbData.type_fichier || '',
        image_url: dbData.image_url,
        analysis: this.parseAnalysisResult(dbData.analysis || dbData.analysis_result),
        analyzing: dbData.analyzing || dbData.analyzing_status || false,
        timestamp: dbData.timestamp || Date.now(),
        analysis_start_time: dbData.analysis_start_time,
        created_at: dbData.created_at,
        updated_at: dbData.updated_at
      };

      console.log('🎉 Upload photo complet - Service Supabase');
      return {
        url: urlData.publicUrl,
        photoInspection
      };

    } catch (error) {
      console.error('❌ Erreur complète upload photo:', error);
      throw error;
    }
  }

  private parseAnalysisResult(analysis: any): PhotoAnalysisResult | undefined {
    if (!analysis) return undefined;
    
    if (typeof analysis === 'object' && analysis.nonConformites && analysis.risques) {
      return analysis as PhotoAnalysisResult;
    }
    
    return undefined;
  }

  async updateAnalysis(photoId: string, analysis: PhotoAnalysisResult, analyzing: boolean = false): Promise<void> {
    try {
      console.log('🔄 Mise à jour analyse photo:', photoId);
      
      // Update both old and new column names for compatibility
      const updateData: any = {
        analysis: analysis as any,
        analysis_result: analysis as any,
        analyzing: analyzing,
        analyzing_status: analyzing,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('photo_inspections')
        .update(updateData)
        .eq('id', photoId);

      if (error) {
        console.error('❌ Erreur mise à jour analyse:', error);
        throw error;
      }

      console.log('✅ Analyse mise à jour avec succès');
    } catch (error) {
      console.error('❌ Erreur mise à jour analyse:', error);
      throw error;
    }
  }

  async markAsAnalyzing(photoId: string): Promise<void> {
    try {
      const updateData: any = {
        analyzing: true,
        analyzing_status: true,
        analysis_start_time: Date.now(),
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('photo_inspections')
        .update(updateData)
        .eq('id', photoId);

      if (error) throw error;
    } catch (error) {
      console.error('❌ Erreur marquage analyse en cours:', error);
      throw error;
    }
  }

  async getAllPhotos(): Promise<PhotoInspection[]> {
    try {
      const { data, error } = await supabase
        .from('photo_inspections')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        file_name: item.file_name || item.nom_fichier || '',
        file_size: item.file_size || item.taille_fichier || 0,
        file_type: item.file_type || item.type_fichier || '',
        image_url: item.image_url,
        analysis: this.parseAnalysisResult(item.analysis || item.analysis_result),
        analyzing: item.analyzing || item.analyzing_status || false,
        timestamp: item.timestamp || Date.parse(item.created_at),
        analysis_start_time: item.analysis_start_time,
        created_at: item.created_at,
        updated_at: item.updated_at
      }));
    } catch (error) {
      console.error('❌ Erreur récupération photos:', error);
      throw error;
    }
  }

  async deletePhoto(photoId: string): Promise<void> {
    try {
      // Récupérer les infos de la photo pour obtenir le nom du fichier
      const { data: photo, error: selectError } = await supabase
        .from('photo_inspections')
        .select('image_url')
        .eq('id', photoId)
        .single();

      if (selectError) throw selectError;

      // Extraire le nom du fichier de l'URL
      const fileName = photo.image_url.split('/').pop();
      
      if (fileName) {
        // Supprimer le fichier du storage
        const { error: storageError } = await supabase.storage
          .from(this.bucket)
          .remove([fileName]);

        if (storageError) {
          console.warn('⚠️ Erreur suppression fichier storage:', storageError);
        }
      }

      // Supprimer l'enregistrement de la DB
      const { error: dbError } = await supabase
        .from('photo_inspections')
        .delete()
        .eq('id', photoId);

      if (dbError) throw dbError;

      console.log('✅ Photo supprimée avec succès');
    } catch (error) {
      console.error('❌ Erreur suppression photo:', error);
      throw error;
    }
  }

  async getPhotoById(photoId: string): Promise<PhotoInspection | null> {
    try {
      const { data, error } = await supabase
        .from('photo_inspections')
        .select('*')
        .eq('id', photoId)
        .single();

      if (error) {
        console.error('❌ Erreur récupération photo:', error);
        return null;
      }

      return {
        id: data.id,
        file_name: data.file_name || data.nom_fichier || '',
        file_size: data.file_size || data.taille_fichier || 0,
        file_type: data.file_type || data.type_fichier || '',
        image_url: data.image_url,
        analysis: this.parseAnalysisResult(data.analysis || data.analysis_result),
        analyzing: data.analyzing || data.analyzing_status || false,
        timestamp: data.timestamp || Date.parse(data.created_at),
        analysis_start_time: data.analysis_start_time,
        created_at: data.created_at,
        updated_at: data.updated_at
      };
    } catch (error) {
      console.error('❌ Erreur récupération photo par ID:', error);
      return null;
    }
  }
}

export const supabasePhotoStorageService = new SupabasePhotoStorageService();
