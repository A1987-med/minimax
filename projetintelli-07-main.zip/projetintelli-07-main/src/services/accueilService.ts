import { supabase } from '@/integrations/supabase/client';
import type { Soustraitant, EntryData } from '@/types/accueil';

class SoustraitantService {
  async getAll(): Promise<Soustraitant[]> {
    try {
      const { data, error } = await supabase
        .from('soustraitants')
        .select('*')
        .eq('actif', true)
        .order('nom');

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        nom: item.nom,
        telephone: item.telephone || '',
        courriel: item.courriel || '',
        adresse: item.adresse || '',
        dateAjout: item.date_ajout,
        actif: item.actif
      }));
    } catch (error) {
      console.error('Erreur lors de la récupération des sous-traitants:', error);
      throw error;
    }
  }

  async create(soustraitant: Omit<Soustraitant, 'id'>): Promise<Soustraitant> {
    try {
      const { data, error } = await supabase
        .from('soustraitants')
        .insert({
          nom: soustraitant.nom,
          telephone: soustraitant.telephone,
          courriel: soustraitant.courriel,
          adresse: soustraitant.adresse,
          date_ajout: soustraitant.dateAjout,
          actif: soustraitant.actif
        })
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        nom: data.nom,
        telephone: data.telephone || '',
        courriel: data.courriel || '',
        adresse: data.adresse || '',
        dateAjout: data.date_ajout,
        actif: data.actif
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout du sous-traitant:', error);
      throw error;
    }
  }

  async update(id: string, updates: Partial<Soustraitant>): Promise<Soustraitant> {
    try {
      const updateData: any = {};
      if (updates.nom !== undefined) updateData.nom = updates.nom;
      if (updates.telephone !== undefined) updateData.telephone = updates.telephone;
      if (updates.courriel !== undefined) updateData.courriel = updates.courriel;
      if (updates.adresse !== undefined) updateData.adresse = updates.adresse;
      if (updates.actif !== undefined) updateData.actif = updates.actif;

      const { data, error } = await supabase
        .from('soustraitants')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        nom: data.nom,
        telephone: data.telephone || '',
        courriel: data.courriel || '',
        adresse: data.adresse || '',
        dateAjout: data.date_ajout,
        actif: data.actif
      };
    } catch (error) {
      console.error('Erreur lors de la mise à jour du sous-traitant:', error);
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('soustraitants')
        .update({ actif: false })
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Erreur lors de la suppression du sous-traitant:', error);
      throw error;
    }
  }
}

class EntryService {
  async getAll(): Promise<EntryData[]> {
    try {
      const { data, error } = await supabase
        .from('entries_accueil')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        prenom: item.prenom,
        nom: item.nom,
        nomEmploye: item.nom_employe,
        entreprise: item.entreprise,
        fonction: item.fonction || '',
        corpsMetier: item.corps_metier || '',
        occupation: (item as any).occupation || '',
        occupations: Array.isArray(item.occupations) ? item.occupations as string[] : [],
        numeroEtiquette: item.numero_etiquette || '',
        nomSousTraitant: item.nom_sous_traitant || '',
        telephone: item.telephone || '',
        courriel: item.courriel || '',
        dateEcheanceCarte: item.date_echeance_carte || '',
        etiquetteRecue: item.etiquette_recue || false,
        dateEntree: item.date_entree,
        heureEntree: item.heure_entree,
        dateAccueil: item.date_accueil || '',
        numeroClient: item.numero_client || '',
        numeroImmatriculation: item.numero_immatriculation || '',
        adresse: item.adresse || '',
        ville: item.ville || '',
        codePostal: item.code_postal || '',
        nomContactAccident: item.nom_contact_accident || '',
        cellulaireContact: item.cellulaire_contact || '',
        age: item.age || 0,
        estSousTraitant: item.est_sous_traitant || false,
        estCadre: item.est_cadre || false,
        dateAjout: item.date_ajout,
        selectedFormations: Array.isArray(item.selected_formations) ? item.selected_formations as string[] : [],
        cartesFormations: typeof item.cartes_formations === 'object' ? item.cartes_formations as Record<string, any> : {},
        carteASP: item.carte_asp || '',
        carteASPName: item.carte_asp_name || '',
        carteCCQ: item.carte_ccq || '',
        carteCCQName: item.carte_ccq_name || '',
        carteSIMDUT: item.carte_simdut || '',
        carteSIMDUTName: item.carte_simdut_name || '',
        carteSecouriste: item.carte_secouriste || '',
        carteSecouristeName: item.carte_secouriste_name || '',
        dateEcheancierSecouriste: item.date_echeancier_secouriste || '',
        logo: item.logo || '',
        soustraitant: item.soustraitant || '',
        allergie: item.allergie || '',
        maladie: item.maladie || '',
        estSecouriste: item.est_secouriste || false,
        estContremaitre: item.est_contremaitre || false
      }));
    } catch (error) {
      console.error('Erreur lors de la récupération des entrées:', error);
      throw error;
    }
  }

  async create(entry: Omit<EntryData, 'id'>): Promise<EntryData> {
    try {
      const insertData = {
        prenom: entry.prenom,
        nom: entry.nom,
        nom_employe: entry.nomEmploye,
        entreprise: entry.entreprise,
        fonction: entry.fonction,
        corps_metier: entry.corpsMetier,
        occupations: entry.occupations,
        numero_etiquette: entry.numeroEtiquette,
        nom_sous_traitant: entry.nomSousTraitant,
        telephone: entry.telephone,
        courriel: entry.courriel,
        date_echeance_carte: entry.dateEcheanceCarte,
        etiquette_recue: entry.etiquetteRecue,
        date_entree: entry.dateEntree,
        heure_entree: entry.heureEntree,
        date_accueil: entry.dateAccueil,
        numero_client: entry.numeroClient,
        numero_immatriculation: entry.numeroImmatriculation,
        adresse: entry.adresse,
        ville: entry.ville,
        code_postal: entry.codePostal,
        nom_contact_accident: entry.nomContactAccident,
        cellulaire_contact: entry.cellulaireContact,
        age: entry.age,
        est_sous_traitant: entry.estSousTraitant,
        est_cadre: entry.estCadre,
        date_ajout: entry.dateAjout,
        selected_formations: entry.selectedFormations,
        cartes_formations: entry.cartesFormations,
        carte_asp: entry.carteASP,
        carte_asp_name: entry.carteASPName,
        carte_ccq: entry.carteCCQ,
        carte_ccq_name: entry.carteCCQName,
        carte_simdut: entry.carteSIMDUT,
        carte_simdut_name: entry.carteSIMDUTName,
        carte_secouriste: entry.carteSecouriste,
        carte_secouriste_name: entry.carteSecouristeName,
        date_echeancier_secouriste: entry.dateEcheancierSecouriste,
        logo: entry.logo,
        soustraitant: entry.soustraitant,
        allergie: entry.allergie,
        maladie: entry.maladie,
        est_secouriste: entry.estSecouriste,
        est_contremaitre: entry.estContremaitre,
        ...(entry.occupation && { occupation: entry.occupation })
      };

      const { data, error } = await supabase
        .from('entries_accueil')
        .insert(insertData)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        prenom: data.prenom,
        nom: data.nom,
        nomEmploye: data.nom_employe,
        entreprise: data.entreprise,
        fonction: data.fonction || '',
        corpsMetier: data.corps_metier || '',
        occupation: (data as any).occupation || '',
        occupations: Array.isArray(data.occupations) ? data.occupations as string[] : [],
        numeroEtiquette: data.numero_etiquette || '',
        nomSousTraitant: data.nom_sous_traitant || '',
        telephone: data.telephone || '',
        courriel: data.courriel || '',
        dateEcheanceCarte: data.date_echeance_carte || '',
        etiquetteRecue: data.etiquette_recue || false,
        dateEntree: data.date_entree,
        heureEntree: data.heure_entree,
        dateAccueil: data.date_accueil || '',
        numeroClient: data.numero_client || '',
        numeroImmatriculation: data.numero_immatriculation || '',
        adresse: data.adresse || '',
        ville: data.ville || '',
        codePostal: data.code_postal || '',
        nomContactAccident: data.nom_contact_accident || '',
        cellulaireContact: data.cellulaire_contact || '',
        age: data.age || 0,
        estSousTraitant: data.est_sous_traitant || false,
        estCadre: data.est_cadre || false,
        dateAjout: data.date_ajout,
        selectedFormations: Array.isArray(data.selected_formations) ? data.selected_formations as string[] : [],
        cartesFormations: typeof data.cartes_formations === 'object' ? data.cartes_formations as Record<string, any> : {},
        carteASP: data.carte_asp || '',
        carteASPName: data.carte_asp_name || '',
        carteCCQ: data.carte_ccq || '',
        carteCCQName: data.carte_ccq_name || '',
        carteSIMDUT: data.carte_simdut || '',
        carteSIMDUTName: data.carte_simdut_name || '',
        carteSecouriste: data.carte_secouriste || '',
        carteSecouristeName: data.carte_secouriste_name || '',
        dateEcheancierSecouriste: data.date_echeancier_secouriste || '',
        logo: data.logo || '',
        soustraitant: data.soustraitant || '',
        allergie: data.allergie || '',
        maladie: data.maladie || '',
        estSecouriste: data.est_secouriste || false,
        estContremaitre: data.est_contremaitre || false
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout de l\'entrée:', error);
      throw error;
    }
  }

  async update(id: string, updates: Partial<EntryData>): Promise<EntryData> {
    try {
      console.log('🔄 SERVICE UPDATE - ID:', id);
      console.log('🔄 SERVICE UPDATE - Updates reçues:', updates);

      const updateData: any = {};
      
      // Mapper chaque propriété de manière explicite
      Object.keys(updates).forEach(key => {
        const value = updates[key as keyof EntryData];
        if (value !== undefined) {
          switch (key) {
            case 'prenom':
              updateData.prenom = value;
              break;
            case 'nom':
              updateData.nom = value;
              break;
            case 'nomEmploye':
              updateData.nom_employe = value;
              break;
            case 'entreprise':
              updateData.entreprise = value;
              break;
            case 'fonction':
              updateData.fonction = value;
              break;
            case 'corpsMetier':
              updateData.corps_metier = value;
              break;
            case 'occupations':
              updateData.occupations = value;
              // Également mettre à jour le corps de métier
              if (Array.isArray(value)) {
                updateData.corps_metier = value.join(', ');
              }
              break;
            case 'occupation':
              updateData.occupation = value;
              break;
            case 'numeroEtiquette':
              updateData.numero_etiquette = value;
              break;
            case 'nomSousTraitant':
              updateData.nom_sous_traitant = value;
              break;
            case 'telephone':
              updateData.telephone = value;
              break;
            case 'courriel':
              updateData.courriel = value;
              break;
            case 'adresse':
              updateData.adresse = value;
              break;
            case 'ville':
              updateData.ville = value;
              break;
            case 'codePostal':
              updateData.code_postal = value;
              break;
            case 'dateEcheanceCarte':
              updateData.date_echeance_carte = value;
              break;
            case 'etiquetteRecue':
              updateData.etiquette_recue = value;
              break;
            case 'dateEntree':
              updateData.date_entree = value;
              break;
            case 'heureEntree':
              updateData.heure_entree = value;
              break;
            case 'dateAccueil':
              updateData.date_accueil = value;
              break;
            case 'numeroClient':
              updateData.numero_client = value;
              break;
            case 'numeroImmatriculation':
              updateData.numero_immatriculation = value;
              break;
            case 'nomContactAccident':
              updateData.nom_contact_accident = value;
              break;
            case 'cellulaireContact':
              updateData.cellulaire_contact = value;
              break;
            case 'age':
              updateData.age = value;
              break;
            case 'estSousTraitant':
              updateData.est_sous_traitant = value;
              break;
            case 'estCadre':
              updateData.est_cadre = value;
              break;
            case 'selectedFormations':
              updateData.selected_formations = value;
              break;
            case 'cartesFormations':
              updateData.cartes_formations = value;
              break;
            case 'carteASP':
              updateData.carte_asp = value;
              break;
            case 'carteASPName':
              updateData.carte_asp_name = value;
              break;
            case 'carteCCQ':
              updateData.carte_ccq = value;
              break;
            case 'carteCCQName':
              updateData.carte_ccq_name = value;
              break;
            case 'carteSIMDUT':
              updateData.carte_simdut = value;
              break;
            case 'carteSIMDUTName':
              updateData.carte_simdut_name = value;
              break;
            case 'carteSecouriste':
              updateData.carte_secouriste = value;
              break;
            case 'carteSecouristeName':
              updateData.carte_secouriste_name = value;
              break;
            case 'dateEcheancierSecouriste':
              updateData.date_echeancier_secouriste = value;
              break;
            case 'estSecouriste':
              updateData.est_secouriste = value;
              break;
            case 'estContremaitre':
              updateData.est_contremaitre = value;
              break;
            case 'allergie':
              updateData.allergie = value;
              break;
            case 'maladie':
              updateData.maladie = value;
              break;
            default:
              console.log(`🟡 SERVICE UPDATE - Champ non mappé: ${key}`);
              break;
          }
        }
      });

      console.log('🔄 SERVICE UPDATE - Données à envoyer à Supabase:', updateData);

      const { data, error } = await supabase
        .from('entries_accueil')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('❌ SERVICE UPDATE - Erreur Supabase:', error);
        throw error;
      }

      console.log('✅ SERVICE UPDATE - Données mises à jour dans Supabase:', data);

      return {
        id: data.id,
        prenom: data.prenom,
        nom: data.nom,
        nomEmploye: data.nom_employe,
        entreprise: data.entreprise,
        fonction: data.fonction || '',
        corpsMetier: data.corps_metier || '',
        occupation: (data as any).occupation || '',
        occupations: Array.isArray(data.occupations) ? data.occupations as string[] : [],
        numeroEtiquette: data.numero_etiquette || '',
        nomSousTraitant: data.nom_sous_traitant || '',
        telephone: data.telephone || '',
        courriel: data.courriel || '',
        dateEcheanceCarte: data.date_echeance_carte || '',
        etiquetteRecue: data.etiquette_recue || false,
        dateEntree: data.date_entree,
        heureEntree: data.heure_entree,
        dateAccueil: data.date_accueil || '',
        numeroClient: data.numero_client || '',
        numeroImmatriculation: data.numero_immatriculation || '',
        adresse: data.adresse || '',
        ville: data.ville || '',
        codePostal: data.code_postal || '',
        nomContactAccident: data.nom_contact_accident || '',
        cellulaireContact: data.cellulaire_contact || '',
        age: data.age || 0,
        estSousTraitant: data.est_sous_traitant || false,
        estCadre: data.est_cadre || false,
        dateAjout: data.date_ajout,
        selectedFormations: Array.isArray(data.selected_formations) ? data.selected_formations as string[] : [],
        cartesFormations: typeof data.cartes_formations === 'object' ? data.cartes_formations as Record<string, any> : {},
        carteASP: data.carte_asp || '',
        carteASPName: data.carte_asp_name || '',
        carteCCQ: data.carte_ccq || '',
        carteCCQName: data.carte_ccq_name || '',
        carteSIMDUT: data.carte_simdut || '',
        carteSIMDUTName: data.carte_simdut_name || '',
        carteSecouriste: data.carte_secouriste || '',
        carteSecouristeName: data.carte_secouriste_name || '',
        dateEcheancierSecouriste: data.date_echeancier_secouriste || '',
        logo: data.logo || '',
        soustraitant: data.soustraitant || '',
        allergie: data.allergie || '',
        maladie: data.maladie || '',
        estSecouriste: data.est_secouriste || false,
        estContremaitre: data.est_contremaitre || false
      };
    } catch (error) {
      console.error('❌ SERVICE UPDATE - Erreur lors de la mise à jour de l\'entrée:', error);
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('entries_accueil')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Erreur lors de la suppression de l\'entrée:', error);
      throw error;
    }
  }
}

export const soustraitantService = new SoustraitantService();
export const entryService = new EntryService();
