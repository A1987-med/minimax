
import { supabase } from "@/integrations/supabase/client";
import type { ContactUrgence } from "@/types/urgences";

export const contactUrgenceService = {
  async getAll(): Promise<ContactUrgence[]> {
    console.log('📊 SERVICE - Récupération des contacts d\'urgence');
    
    // Use type assertion to bypass missing type definitions
    const { data, error } = await (supabase as any)
      .from('contacts_urgence')
      .select('*')
      .eq('actif', true)
      .order('ordre_priorite');
    
    if (error) {
      console.error('❌ SERVICE - Erreur récupération contacts:', error);
      throw error;
    }
    
    const transformed = (data || []).map((item: any) => ({
      id: item.id,
      nom: item.nom,
      fonction: item.fonction,
      telephone: item.telephone,
      telephoneSecondaire: item.telephone_secondaire || '',
      courriel: item.courriel || '',
      typeContact: item.type_contact as 'police' | 'pompiers' | 'ambulance' | 'securite' | 'direction' | 'autre',
      disponibilite: item.disponibilite || '',
      ordrePriorite: item.ordre_priorite,
      actif: item.actif,
      createdAt: item.created_at,
      updatedAt: item.updated_at
    }));
    
    console.log('✅ SERVICE - Contacts d\'urgence récupérés:', transformed.length);
    return transformed;
  },

  async create(contact: Omit<ContactUrgence, 'id' | 'createdAt' | 'updatedAt'>): Promise<ContactUrgence> {
    console.log('📝 SERVICE - Création contact d\'urgence:', contact);
    
    const { data, error } = await (supabase as any)
      .from('contacts_urgence')
      .insert({
        nom: contact.nom,
        fonction: contact.fonction,
        telephone: contact.telephone,
        telephone_secondaire: contact.telephoneSecondaire,
        courriel: contact.courriel,
        type_contact: contact.typeContact,
        disponibilite: contact.disponibilite,
        ordre_priorite: contact.ordrePriorite,
        actif: contact.actif
      })
      .select()
      .single();
    
    if (error) {
      console.error('❌ SERVICE - Erreur création contact:', error);
      throw error;
    }
    
    const transformed = {
      id: data.id,
      nom: data.nom,
      fonction: data.fonction,
      telephone: data.telephone,
      telephoneSecondaire: data.telephone_secondaire || '',
      courriel: data.courriel || '',
      typeContact: data.type_contact as 'police' | 'pompiers' | 'ambulance' | 'securite' | 'direction' | 'autre',
      disponibilite: data.disponibilite || '',
      ordrePriorite: data.ordre_priorite,
      actif: data.actif,
      createdAt: data.created_at,
      updatedAt: data.updated_at
    };
    
    console.log('✅ SERVICE - Contact d\'urgence créé:', transformed);
    return transformed;
  },

  async update(id: string, updates: Partial<ContactUrgence>): Promise<ContactUrgence> {
    console.log('📝 SERVICE - Mise à jour contact d\'urgence:', id, updates);
    
    const { data, error } = await (supabase as any)
      .from('contacts_urgence')
      .update({
        nom: updates.nom,
        fonction: updates.fonction,
        telephone: updates.telephone,
        telephone_secondaire: updates.telephoneSecondaire,
        courriel: updates.courriel,
        type_contact: updates.typeContact,
        disponibilite: updates.disponibilite,
        ordre_priorite: updates.ordrePriorite,
        actif: updates.actif
      })
      .eq('id', id)
      .select()
      .single();
    
    if (error) {
      console.error('❌ SERVICE - Erreur mise à jour contact:', error);
      throw error;
    }
    
    const transformed = {
      id: data.id,
      nom: data.nom,
      fonction: data.fonction,
      telephone: data.telephone,
      telephoneSecondaire: data.telephone_secondaire || '',
      courriel: data.courriel || '',
      typeContact: data.type_contact as 'police' | 'pompiers' | 'ambulance' | 'securite' | 'direction' | 'autre',
      disponibilite: data.disponibilite || '',
      ordrePriorite: data.ordre_priorite,
      actif: data.actif,
      createdAt: data.created_at,
      updatedAt: data.updated_at
    };
    
    console.log('✅ SERVICE - Contact d\'urgence mis à jour:', transformed);
    return transformed;
  },

  async delete(id: string): Promise<void> {
    console.log('🗑️ SERVICE - Suppression contact d\'urgence:', id);
    
    const { error } = await (supabase as any)
      .from('contacts_urgence')
      .delete()
      .eq('id', id);
    
    if (error) {
      console.error('❌ SERVICE - Erreur suppression contact:', error);
      throw error;
    }
    
    console.log('✅ SERVICE - Contact d\'urgence supprimé');
  }
};
