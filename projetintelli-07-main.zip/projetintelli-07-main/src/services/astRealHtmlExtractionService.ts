export interface ExtractedData {
  taches: ExtractedTache[];
  corpsMetier: string;
}

export interface ExtractedTache {
  nom: string;
  description: string;
  operations: ExtractedOperation[];
}

export interface ExtractedOperation {
  nom: string;
  description: string;
  sousOperations: ExtractedSousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

export interface ExtractedSousOperation {
  nom: string;
  description: string;
  risques: Risque[];
}

export interface Risque {
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve';
  mesuresPrevention: string[];
}

export interface Outil {
  nom: string;
  type: string;
  securiteRequise: string[];
}

export interface Materiau {
  nom: string;
  type: string;
  precautions: string[];
}

class ASTRealHtmlExtractionService {
  async extractFromHtml(htmlContent: string, corpsMetier: string): Promise<ExtractedData> {
    console.log('🔍 === DÉBUT EXTRACTION HTML STRUCTURE EXACTE ===');
    console.log('📄 Longueur du contenu HTML:', htmlContent.length);

    try {
      // Utiliser la structure exacte fournie
      const taches = this.parseExactStructure(htmlContent);
      
      console.log('✅ Extraction structure exacte terminée:', {
        nombreTaches: taches.length,
        nombreOperations: taches.reduce((acc, t) => acc + t.operations.length, 0),
        nombreSousOperations: taches.reduce((acc, t) => acc + t.operations.reduce((subAcc, op) => subAcc + op.sousOperations.length, 0), 0)
      });
      
      return {
        taches,
        corpsMetier
      };
    } catch (error) {
      console.error('❌ Erreur extraction structure exacte:', error);
      throw error;
    }
  }

  private parseExactStructure(content: string): ExtractedTache[] {
    const taches: ExtractedTache[] = [];
    
    // Structure exacte basée sur votre hiérarchie fournie
    const tachesData = [
      {
        nom: "Préparer les travaux",
        operations: [
          {
            nom: "Recevoir les consignes",
            sousOperations: [
              "Se rendre sur les lieux des travaux",
              "Vérifier les particularités du chantier",
              "Vérifier les conditions météorologiques (température, vent, pluie, etc.), s'il y a lieu"
            ]
          },
          {
            nom: "Mettre en place les mesures de sécurité nécessaires",
            sousOperations: [
              "Participer aux rencontres de sécurité",
              "Prendre connaissance des mesures de sécurité et de l'analyse de risque",
              "Vérifier les éléments de sécurité sur le permis de travail",
              "Vérifier les règles internes et particulières du client, en lien avec la santé et la sécurité",
              "Déterminer l'équipement de sécurité requis et s'assurer de sa disponibilité et de son bon état",
              "Vérifier les risques liés à la qualité de l'air, s'il y a lieu",
              "Lire les fiches signalétiques des produits à utiliser",
              "Établir le ou les périmètres de sécurité",
              "Installer des filets sous les échafaudages, empêchant la chute d'outils, de matériaux, etc.",
              "Cadenasser la machinerie, s'il y a lieu"
            ]
          },
          {
            nom: "Recevoir les matériaux et l'équipement",
            sousOperations: [
              "Vérifier l'état et les quantités de matériaux et d'équipement",
              "Prévoir un lieu d'entreposage"
            ]
          },
          {
            nom: "Préparer les matériaux, l'outillage et l'équipement",
            sousOperations: [
              "Disposer les matériaux, l'outillage et l'équipement aux bons endroits",
              "Organiser son aire de travail"
            ]
          },
          {
            nom: "Protéger les surfaces environnantes",
            sousOperations: [
              "Recouvrir les surfaces ou les objets à protéger (polythène, filet, etc.)",
              "Fabriquer des abris"
            ]
          }
        ]
      },
      {
        nom: "Ériger des échafaudages",
        operations: [
          {
            nom: "Faire l'inventaire des éléments",
            sousOperations: [
              "Prendre les mesures de l'échafaudage",
              "Identifier les obstacles pour l'installation",
              "Calculer le nombre d'éléments de l'échafaudage",
              "Procéder à l'inspection visuelle de l'équipement",
              "Détecter les bris",
              "Remplacer les éléments endommagés"
            ]
          },
          {
            nom: "Prendre connaissance du mode d'assemblage",
            sousOperations: []
          },
          {
            nom: "Asseoir la base",
            sousOperations: [
              "Vérifier la solidité du sol",
              "Installer les bases de bois avec les vérins à vis (screw jacks)",
              "Installer les plaques de base et les contreventements",
              "Vérifier le niveau de la base et le trait carré"
            ]
          },
          {
            nom: "Assembler les éléments",
            sousOperations: [
              "Installer les cadres",
              "Installer les contreventements",
              "Installer les croisillons",
              "Installer les plateformes",
              "Installer les échelles",
              "Installer les garde-corps",
              "Installer les ancrages",
              "Installer les plaques (coups-de-pied)"
            ]
          },
          {
            nom: "Assurer la stabilité de l'échafaudage",
            sousOperations: [
              "Déterminer les points d'ancrage",
              "Poser des ancrages",
              "Fixer l'échafaudage",
              "Procéder à une inspection finale",
              "Obtenir l'approbation de la personne responsable, s'il y a lieu"
            ]
          }
        ]
      },
      {
        nom: "Installer de l'isolant rigide ou semi-rigide sur de la tuyauterie",
        operations: [
          {
            nom: "Dégeler la tuyauterie, s'il y a lieu",
            sousOperations: [
              "S'assurer de la mise hors service",
              "Chauffer la tuyauterie (chalumeau)",
              "Utiliser un produit de déglaçage"
            ]
          },
          {
            nom: "Essuyer et nettoyer la tuyauterie, s'il y a lieu",
            sousOperations: [
              "Enlever toute trace d'eau, de poussière, de huile, de résidus, etc.",
              "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu"
            ]
          },
          {
            nom: "Appliquer l'apprêt, s'il y a lieu",
            sousOperations: []
          },
          {
            nom: "Mesurer et couper des sections d'isolant",
            sousOperations: [
              "Prendre les mesures de la tuyauterie",
              "Couper l'isolant pour coudes, supports, \"T\", \"Y\", etc."
            ]
          },
          {
            nom: "Poser des sections d'isolant",
            sousOperations: [
              "Positionner l'isolant",
              "Fixer à l'aide de fil de fer",
              "Couper les joints au besoin"
            ]
          },
          {
            nom: "Sceller les joints, s'il y a lieu",
            sousOperations: [
              "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)",
              "Respecter le délai de prise",
              "Réunir les deux côtés",
              "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)"
            ]
          },
          {
            nom: "Attacher les sections d'isolant",
            sousOperations: [
              "Installer un deuxième et un troisième fils de fer sur chaque section d'isolant",
              "Installer une bande d'acier inoxydable de ½ pouce (pour les tuyaux de plus de 300 mm)"
            ]
          },
          {
            nom: "Poser le coupe-vapeur, s'il y a lieu",
            sousOperations: [
              "Couper le coupe-vapeur",
              "Positionner le coupe-vapeur",
              "Fixer le coupe-vapeur à l'aide d'un ruban d'aluminium"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer de l'isolant rigide ou semi-rigide sur des appareils et des murs",
        operations: [
          {
            nom: "Dégeler l'appareil, s'il y a lieu",
            sousOperations: [
              "S'assurer de la mise hors service",
              "Chauffer l'appareil avec un chalumeau",
              "Utiliser un produit de déglaçage"
            ]
          },
          {
            nom: "Essuyer et nettoyer, s'il y a lieu",
            sousOperations: [
              "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.",
              "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu"
            ]
          },
          {
            nom: "Mesurer et couper l'isolant",
            sousOperations: [
              "Évaluer les quantités nécessaires",
              "Maximiser l'utilisation des matériaux",
              "Utiliser les données des fabricants d'isolant (chart) pour les mesures des segments de coude",
              "Préparer les patrons, s'il y a lieu"
            ]
          },
          {
            nom: "Préparer les ancrages ou les attaches",
            sousOperations: [
              "Vérifier les sortes d'ancrages",
              "Choisir l'outil approprié à l'ancrage",
              "Déterminer les points d'ancrage",
              "Fixer les ancrages avec ou sans colle, par soudage par points, s'il y a lieu"
            ]
          },
          {
            nom: "Poser l'isolant",
            sousOperations: [
              "Positionner l'isolant sur l'appareil ou le mur"
            ]
          },
          {
            nom: "Fixer l'isolant",
            sousOperations: []
          },
          {
            nom: "Sceller les joints, s'il y a lieu",
            sousOperations: [
              "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)",
              "Respecter le délai de prise",
              "Réunir les deux côtés",
              "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer de l'isolant rigide ou semi-rigide sur des conduits d'air",
        operations: [
          {
            nom: "Essuyer et nettoyer le conduit, s'il y a lieu",
            sousOperations: [
              "S'assurer que le conduit peut recevoir des ancrages ou de l'isolant",
              "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.",
              "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu"
            ]
          },
          {
            nom: "Fixer les ancrages",
            sousOperations: [
              "Localiser les points d'ancrage",
              "Selon le type et l'épaisseur de l'isolant, poser des ancrages avec ou sans colle, par soudage par points, s'il y a lieu",
              "Replier les ancrages, s'il y a lieu",
              "S'assurer de la solidité des ancrages"
            ]
          },
          {
            nom: "Mesurer et couper l'isolant",
            sousOperations: [
              "Évaluer les quantités nécessaires",
              "Décider de l'ordre à respecter",
              "Maximiser l'utilisation des matériaux",
              "Utiliser les données des fabricants d'isolant (chart) pour les mesures des segments de coude, s'il y a lieu",
              "Préparer les patrons, s'il y a lieu"
            ]
          },
          {
            nom: "Poser l'isolant",
            sousOperations: [
              "Placer les morceaux d'isolant prédécoupés",
              "Respecter la séquence de pose: côtés, dessous, dessus"
            ]
          },
          {
            nom: "Fixer les rondelles de retenue",
            sousOperations: []
          },
          {
            nom: "Couper l'excédent des ancrages",
            sousOperations: [
              "Appuyer les pinces coupantes sur la rondelle de retenue",
              "Couper l'ancrage",
              "Récupérer la partie coupée"
            ]
          },
          {
            nom: "Sceller les joints, s'il y a lieu",
            sousOperations: [
              "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)",
              "Respecter le délai de prise",
              "Réunir les deux côtés",
              "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Appliquer de l'isolant giclé et soufflé",
        operations: [
          {
            nom: "Dégeler la tuyauterie ou l'appareil, s'il y a lieu",
            sousOperations: [
              "S'assurer de la mise hors service",
              "Chauffer la tuyauterie (chalumeau)",
              "Utiliser un produit de déglaçage"
            ]
          },
          {
            nom: "Essuyer et nettoyer, s'il y a lieu",
            sousOperations: [
              "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.",
              "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu"
            ]
          },
          {
            nom: "Appliquer de l'apprêt, s'il y a lieu",
            sousOperations: [
              "Laver à l'essence minérale",
              "Laisser sécher",
              "Appliquer l'apprêt",
              "Ventiler, s'il y a lieu (endroits mal aérés)"
            ]
          },
          {
            nom: "Appliquer l'isolant",
            sousOperations: [
              "Pulvériser l'isolant sur le substrat"
            ]
          },
          {
            nom: "Uniformiser la surface d'isolant",
            sousOperations: [
              "Mesurer l'épaisseur de l'isolant appliqué (jauge d'épaisseur)",
              "Consulter les normes relatives aux épaisseurs minimale et maximale",
              "Ajouter de l'isolant ou retirer de l'isolant (outil tranchant)"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer des panneaux sandwichs isolants sur des appareils",
        operations: [
          {
            nom: "Essuyer et nettoyer l'appareil, s'il y a lieu",
            sousOperations: [
              "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.",
              "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu"
            ]
          },
          {
            nom: "Poser les ancrages et les fixations",
            sousOperations: [
              "Poser des ancrages sur les côtés et sur le dessus de l'appareil",
              "Poser des bandes d'acier inoxydable",
              "Calculer la distance entre chaque ancrage, selon les directives reçues"
            ]
          },
          {
            nom: "Poser les panneaux sandwichs isolants",
            sousOperations: []
          },
          {
            nom: "Serrer et sceller les joints",
            sousOperations: []
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer un fini protecteur souple",
        operations: [
          {
            nom: "Installer un treillis métallique, s'il y a lieu",
            sousOperations: []
          },
          {
            nom: "Poser des coins de fer, s'il y a lieu",
            sousOperations: []
          },
          {
            nom: "Cimenter, s'il y a lieu",
            sousOperations: []
          },
          {
            nom: "Mesurer et couper le fini protecteur",
            sousOperations: []
          },
          {
            nom: "Appliquer l'enduit",
            sousOperations: []
          },
          {
            nom: "Poser le fini protecteur",
            sousOperations: [
              "Poser le coton en l'étirant",
              "S'assurer de l'absence de plis"
            ]
          },
          {
            nom: "Réappliquer de l'enduit",
            sousOperations: []
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer des membranes d'étanchéité",
        operations: [
          {
            nom: "Mesurer et couper la membrane",
            sousOperations: [
              "Mesurer en tenant compte du chevauchement",
              "Couper la membrane selon la forme et les dimensions désirées"
            ]
          },
          {
            nom: "Poser la membrane",
            sousOperations: [
              "Vérifier les vents dominants",
              "Commencer la pose par le dessous",
              "Continuer la pose par les côtés",
              "Terminer la pose par le dessus"
            ]
          },
          {
            nom: "Chauffer les joints",
            sousOperations: []
          },
          {
            nom: "Poser des soupapes, s'il y a lieu",
            sousOperations: [
              "Pratiquer des ouvertures dans la membrane",
              "Insérer les soupapes dans les ouvertures",
              "Sceller le pourtour des soupapes"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Fabriquer des pièces de fini protecteur rigide ou semi-rigide",
        operations: [
          {
            nom: "Prendre les mesures requises",
            sousOperations: [
              "Déterminer les parties à fabriquer",
              "Noter la hauteur, la largeur, la profondeur, le diamètre et la circonférence"
            ]
          },
          {
            nom: "Faire un patron",
            sousOperations: [
              "Rapporter les mesures prises sur le revêtement",
              "Diviser les mesures au besoin pour faire un \"T\", un coude, un \"Y\", un bout de réservoir, etc."
            ]
          },
          {
            nom: "Tracer les pièces",
            sousOperations: [
              "Copier le patron",
              "Indiquer les points de repère, s'il y a lieu"
            ]
          },
          {
            nom: "Tailler les pièces",
            sousOperations: []
          },
          {
            nom: "Façonner les pièces",
            sousOperations: []
          },
          {
            nom: "Assembler les pièces",
            sousOperations: []
          },
          {
            nom: "Identifier les pièces",
            sousOperations: []
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer un fini protecteur rigide ou semi-rigide",
        operations: [
          {
            nom: "Mesurer et couper le fini protecteur",
            sousOperations: [
              "Prendre les mesures et les rapporter sur le fini",
              "Tracer le fini et le découper",
              "Ajuster les dimensions des pièces prédécoupées"
            ]
          },
          {
            nom: "Poser le fini protecteur",
            sousOperations: [
              "Positionner le fini protecteur"
            ]
          },
          {
            nom: "Fixer le fini protecteur (bandes et attaches, vis ou rivets, colle, etc.)",
            sousOperations: []
          },
          {
            nom: "Sceller les joints, s'il y a lieu",
            sousOperations: [
              "Appliquer de la silicone sur les joints longitudinaux, circulaires et autour des coupes"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Installer des systèmes coupe-feu",
        operations: [
          {
            nom: "Nettoyer l'ouverture",
            sousOperations: [
              "Vérifier s'il y a des déchets dans l'ouverture",
              "Retirer les déchets, s'il y a lieu"
            ]
          },
          {
            nom: "Poser, s'il y a lieu, des supports, rails, ancrages, etc.",
            sousOperations: []
          },
          {
            nom: "Mesurer et couper le système coupe-feu",
            sousOperations: [
              "Mesurer et couper le matériau selon le cadre déjà installé",
              "Faire les coupes nécessaires pour les fils et tuyaux qui passent au travers du système"
            ]
          },
          {
            nom: "Poser le système coupe-feu",
            sousOperations: [
              "Positionner le système coupe-feu",
              "Appliquer un scellant"
            ]
          },
          {
            nom: "Remplir une fiche signalétique, s'il y a lieu",
            sousOperations: [
              "Inscrire la date d'installation du système",
              "Inscrire le type de système installé"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux et l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      },
      {
        nom: "Enlever des matériaux d'isolation contenant de l'amiante ou des moisissures",
        operations: [
          {
            nom: "Construire les enceintes nécessaires",
            sousOperations: [
              "Installer les structures",
              "Poser un plastique de protection à l'intérieur de la structure (double couche sur le plancher)",
              "Installer les douches",
              "Calculer le volume d'air à traiter",
              "Installer un système de ventilation à pression négative, s'il y a lieu",
              "Poser les affiches relatives à l'amiante"
            ]
          },
          {
            nom: "Défaire les bandes, attaches, ancrages, etc.",
            sousOperations: [
              "Couper les attaches",
              "Mouiller les surfaces"
            ]
          },
          {
            nom: "Retirer le fini protecteur",
            sousOperations: [
              "Couper le fini",
              "Mouiller les surfaces",
              "Enlever le fini"
            ]
          },
          {
            nom: "Retirer l'isolant",
            sousOperations: [
              "Mouiller l'isolant sur toutes ses faces",
              "Enlever l'isolant graduellement, en continuant de le mouiller"
            ]
          },
          {
            nom: "Ramasser les débris",
            sousOperations: [
              "Ramasser les débris minutieusement",
              "Mouiller les débris"
            ]
          },
          {
            nom: "Déposer les débris dans les sacs recommandés",
            sousOperations: [
              "Placer les débris dans des sacs pré-identifiés",
              "Placer les sacs dans un autre sac du même type"
            ]
          },
          {
            nom: "Procéder au nettoyage final",
            sousOperations: [
              "Passer un aspirateur muni d'un filtre HEPA sur toutes les parois des enceintes"
            ]
          },
          {
            nom: "Appliquer un scellant",
            sousOperations: []
          },
          {
            nom: "Démanteler les enceintes",
            sousOperations: [
              "Enlever les toiles",
              "Désassembler les structures"
            ]
          },
          {
            nom: "Nettoyer l'aire de travail et ranger l'équipement",
            sousOperations: [
              "Ramasser les débris",
              "Ranger les matériaux",
              "Nettoyer et ranger l'équipement",
              "Ranger ses outils personnels"
            ]
          }
        ]
      }
    ];

    console.log('📋 Structure exacte chargée - Nombre de tâches:', tachesData.length);

    // Convertir la structure exacte en format d'extraction
    tachesData.forEach((tacheData, tacheIndex) => {
      console.log(`🎯 TÂCHE ${tacheIndex + 1}: "${tacheData.nom}"`);
      
      const tache: ExtractedTache = {
        nom: tacheData.nom,
        description: tacheData.nom,
        operations: []
      };

      tacheData.operations.forEach((operationData, operationIndex) => {
        console.log(`   ➕ OPÉRATION ${tacheIndex + 1}.${operationIndex + 1}: "${operationData.nom}"`);
        
        const operation: ExtractedOperation = {
          nom: operationData.nom,
          description: operationData.nom,
          sousOperations: [],
          risques: this.generateContextualRisks(operationData.nom),
          outils: this.generateContextualOutils(operationData.nom),
          materiaux: this.generateContextualMateriaux(operationData.nom)
        };

        operationData.sousOperations.forEach((sousOpNom, sousOpIndex) => {
          console.log(`      🔸 SOUS-OPÉRATION ${tacheIndex + 1}.${operationIndex + 1}.${sousOpIndex + 1}: "${sousOpNom}"`);
          
          const sousOperation: ExtractedSousOperation = {
            nom: sousOpNom,
            description: sousOpNom,
            risques: this.generateContextualRisks(sousOpNom)
          };
          
          operation.sousOperations.push(sousOperation);
        });

        tache.operations.push(operation);
      });

      taches.push(tache);
    });

    console.log('📊 Structure finale parsée:', {
      taches: taches.length,
      operationsTotal: taches.reduce((acc, t) => acc + t.operations.length, 0),
      sousOperationsTotal: taches.reduce((acc, t) => acc + t.operations.reduce((subAcc, op) => subAcc + op.sousOperations.length, 0), 0)
    });

    return taches;
  }

  private generateContextualRisks(text: string): Risque[] {
    const risques: Risque[] = [];
    const lowerText = text.toLowerCase();
    
    // Risques liés aux échafaudages et hauteur
    if (lowerText.includes('échafaud') || lowerText.includes('hauteur') || lowerText.includes('montage') || lowerText.includes('installer') && lowerText.includes('plateforme')) {
      risques.push({
        description: "Chute de hauteur",
        niveau: "eleve",
        mesuresPrevention: ["Port du harnais de sécurité", "Installation de garde-corps", "Vérification de la stabilité", "Formation travail en hauteur"]
      });
    }
    
    // Risques liés aux outils tranchants
    if (lowerText.includes('couper') || lowerText.includes('découper') || lowerText.includes('tailler') || lowerText.includes('cutter')) {
      risques.push({
        description: "Coupures par outils tranchants",
        niveau: "moyen",
        mesuresPrevention: ["Gants anti-coupure", "Formation utilisation outils", "Lames rétractables", "Rangement sécurisé"]
      });
    }
    
    // Risques liés à l'amiante
    if (lowerText.includes('amiante') || lowerText.includes('enlever') && lowerText.includes('isolant')) {
      risques.push({
        description: "Exposition aux fibres d'amiante",
        niveau: "eleve",
        mesuresPrevention: ["Masque FFP3", "Combinaison jetable", "Zone confinée", "Procédures décontamination", "Surveillance médicale"]
      });
    }
    
    // Risques chimiques
    if (lowerText.includes('produit') || lowerText.includes('enduit') || lowerText.includes('colle') || lowerText.includes('scellant')) {
      risques.push({
        description: "Contact avec produits chimiques",
        niveau: "moyen",
        mesuresPrevention: ["Gants de protection chimique", "Lunettes de sécurité", "Consultation fiches sécurité", "Ventilation adequête"]
      });
    }
    
    // Risques thermiques
    if (lowerText.includes('chauffer') || lowerText.includes('chalumeau') || lowerText.includes('chaud')) {
      risques.push({
        description: "Brûlures thermiques",
        niveau: "eleve",
        mesuresPrevention: ["Gants thermiques", "Vêtements ignifuges", "Formation chalumeau", "Périmètre de sécurité"]
      });
    }
    
    // Risques liés aux particules et fibres
    if (lowerText.includes('isolant') || lowerText.includes('fibre') || lowerText.includes('laine') || lowerText.includes('mouiller')) {
      risques.push({
        description: "Inhalation de particules et fibres",
        niveau: "moyen",
        mesuresPrevention: ["Masque de protection respiratoire", "Ventilation", "Humidification des matériaux", "Combinaison de protection"]
      });
    }
    
    // Risques mécaniques
    if (lowerText.includes('ancrage') || lowerText.includes('fixer') || lowerText.includes('serrer') || lowerText.includes('rivet')) {
      risques.push({
        description: "Blessures par outils mécaniques",
        niveau: "moyen",
        mesuresPrevention: ["Gants mécaniques", "Lunettes protection", "Vérification état outils", "Formation sécuritaire"]
      });
    }
    
    return risques;
  }

  private generateContextualOutils(text: string): Outil[] {
    const outils: Outil[] = [];
    const lowerText = text.toLowerCase();
    
    // Outils de mesure
    if (lowerText.includes('mesurer') || lowerText.includes('prendre les mesures')) {
      outils.push({
        nom: "Mètre ruban et règle",
        type: "Mesure",
        securiteRequise: ["Vérification avant usage", "Rangement sécurisé"]
      });
    }
    
    // Outils de découpe
    if (lowerText.includes('couper') || lowerText.includes('tailler') || lowerText.includes('découper')) {
      outils.push({
        nom: "Cutter professionnel",
        type: "Découpe",
        securiteRequise: ["Lame rétractable", "Gants obligatoires", "Changement lames régulier"]
      });
    }
    
    // Outils d'échafaudage
    if (lowerText.includes('échafaud') || lowerText.includes('assembler') || lowerText.includes('ancrage')) {
      outils.push({
        nom: "Clés d'échafaudage",
        type: "Assemblage",
        securiteRequise: ["Inspection avant usage", "Formation spécialisée", "Certification valide"]
      });
    }
    
    // Chalumeau
    if (lowerText.includes('chauffer') || lowerText.includes('chalumeau') || lowerText.includes('dégeler')) {
      outils.push({
        nom: "Chalumeau",
        type: "Thermique",
        securiteRequise: ["Permis de feu", "Extincteur à proximité", "Formation chalumeau", "Vérification étanchéité"]
      });
    }
    
    // Outils de fixation
    if (lowerText.includes('fixer') || lowerText.includes('attacher') || lowerText.includes('rivet')) {
      outils.push({
        nom: "Outils de fixation",
        type: "Assemblage",
        securiteRequise: ["Vérification couple serrage", "Gants mécaniques", "Protection auditive"]
      });
    }
    
    // Équipement de nettoyage
    if (lowerText.includes('nettoyer') || lowerText.includes('essuyer') || lowerText.includes('ramasser')) {
      outils.push({
        nom: "Équipement de nettoyage",
        type: "Entretien",
        securiteRequise: ["Gants protection", "Ventilation", "Tri des déchets"]
      });
    }
    
    return outils;
  }

  private generateContextualMateriaux(text: string): Materiau[] {
    const materiaux: Materiau[] = [];
    const lowerText = text.toLowerCase();
    
    // Isolants
    if (lowerText.includes('isolant')) {
      materiaux.push({
        nom: "Isolant calorifuge",
        type: "Isolation thermique",
        precautions: ["Stockage au sec", "Éviter compression", "Protection UV", "Manipulation avec EPI"]
      });
    }
    
    // Membranes et pare-vapeur
    if (lowerText.includes('membrane') || lowerText.includes('pare-vapeur') || lowerText.includes('coupe-vapeur')) {
      materiaux.push({
        nom: "Membrane pare-vapeur",
        type: "Étanchéité",
        precautions: ["Éviter perforations", "Stockage température contrôlée", "Manipulation soigneuse"]
      });
    }
    
    // Finis protecteurs
    if (lowerText.includes('fini') || lowerText.includes('protecteur') || lowerText.includes('revêtement')) {
      materiaux.push({
        nom: "Fini protecteur métallique",
        type: "Protection",
        precautions: ["Manipulation à deux personnes", "Gants anti-coupure", "Protection arêtes vives"]
      });
    }
    
    // Produits chimiques
    if (lowerText.includes('colle') || lowerText.includes('enduit') || lowerText.includes('scellant')) {
      materiaux.push({
        nom: "Produits chimiques (colles, enduits)",
        type: "Chimique",
        precautions: ["Ventilation nécessaire", "Éviter contact peau", "Respect temps séchage", "Fiches sécurité"]
      });
    }
    
    // Éléments d'échafaudage
    if (lowerText.includes('échafaud') || lowerText.includes('cadre') || lowerText.includes('plateforme')) {
      materiaux.push({
        nom: "Éléments d'échafaudage",
        type: "Structure",
        precautions: ["Inspection avant usage", "Stockage organisé", "Manutention sécuritaire", "Marquage défauts"]
      });
    }
    
    // Panneaux sandwich
    if (lowerText.includes('panneau') || lowerText.includes('sandwich')) {
      materiaux.push({
        nom: "Panneaux sandwich isolants",
        type: "Isolation préfabriquée",
        precautions: ["Manutention verticale", "Protection contre chocs", "Stockage sur support"]
      });
    }
    
    return materiaux;
  }
}

export const astRealHtmlExtractionService = new ASTRealHtmlExtractionService();
