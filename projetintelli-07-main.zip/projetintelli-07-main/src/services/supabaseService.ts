
// Re-export des services refactorisés
export { soustraitantService, entryService } from '@/services/accueilService';
export { signalementService } from '@/services/signalementService';
export { checklistService, inspectionService } from '@/services/preventionService';
export { contactUrgenceService } from '@/services/urgencesService';
