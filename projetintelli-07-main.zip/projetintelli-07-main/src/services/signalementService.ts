
import { supabase } from '@/integrations/supabase/client';
import type { Signalement } from '@/types/signalement';

class SignalementService {
  async getAll(): Promise<Signalement[]> {
    try {
      const { data, error } = await supabase
        .from('signalements')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      return (data || []).map(item => ({
        id: item.id,
        type_incident: item.type_incident || item.type,
        date_incident: item.date_incident || '',
        heure_incident: item.heure_incident || '',
        lieu: item.lieu || '',
        description: item.description,
        gravite: (item.gravite || 'faible') as "faible" | "moyenne" | "elevee" | "critique",
        rapporte_par: item.rapporte_par || '',
        temoin_nom: item.temoin_nom || '',
        temoin_contact: item.temoin_contact || '',
        mesures_prises: item.mesures_prises || '',
        statut: (item.statut || item.status || 'ouvert') as "ouvert" | "en_cours" | "ferme" | "resolu",
        created_at: item.created_at,
        updated_at: item.updated_at
      }));
    } catch (error) {
      console.error('Erreur lors de la récupération des signalements:', error);
      throw error;
    }
  }

  async create(signalement: Omit<Signalement, 'id' | 'created_at' | 'updated_at'>): Promise<Signalement> {
    try {
      // Use both old and new column names for compatibility
      const insertData: any = {
        type: signalement.type_incident,
        type_incident: signalement.type_incident,
        date_incident: signalement.date_incident,
        heure_incident: signalement.heure_incident,
        lieu: signalement.lieu,
        description: signalement.description,
        gravite: signalement.gravite,
        rapporte_par: signalement.rapporte_par,
        temoin_nom: signalement.temoin_nom,
        temoin_contact: signalement.temoin_contact,
        mesures_prises: signalement.mesures_prises,
        status: signalement.statut,
        statut: signalement.statut
      };

      const { data, error } = await supabase
        .from('signalements')
        .insert(insertData)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        type_incident: data.type_incident || data.type,
        date_incident: data.date_incident || '',
        heure_incident: data.heure_incident || '',
        lieu: data.lieu || '',
        description: data.description,
        gravite: (data.gravite || 'faible') as "faible" | "moyenne" | "elevee" | "critique",
        rapporte_par: data.rapporte_par || '',
        temoin_nom: data.temoin_nom || '',
        temoin_contact: data.temoin_contact || '',
        mesures_prises: data.mesures_prises || '',
        statut: (data.statut || data.status || 'ouvert') as "ouvert" | "en_cours" | "ferme" | "resolu",
        created_at: data.created_at,
        updated_at: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de l\'ajout du signalement:', error);
      throw error;
    }
  }

  async update(id: string, updates: Partial<Signalement>): Promise<Signalement> {
    try {
      const updateData: any = {};
      
      // Map to both old and new column names for compatibility
      if (updates.type_incident !== undefined) {
        updateData.type = updates.type_incident;
        updateData.type_incident = updates.type_incident;
      }
      if (updates.date_incident !== undefined) updateData.date_incident = updates.date_incident;
      if (updates.heure_incident !== undefined) updateData.heure_incident = updates.heure_incident;
      if (updates.lieu !== undefined) updateData.lieu = updates.lieu;
      if (updates.description !== undefined) updateData.description = updates.description;
      if (updates.gravite !== undefined) updateData.gravite = updates.gravite;
      if (updates.rapporte_par !== undefined) updateData.rapporte_par = updates.rapporte_par;
      if (updates.temoin_nom !== undefined) updateData.temoin_nom = updates.temoin_nom;
      if (updates.temoin_contact !== undefined) updateData.temoin_contact = updates.temoin_contact;
      if (updates.mesures_prises !== undefined) updateData.mesures_prises = updates.mesures_prises;
      if (updates.statut !== undefined) {
        updateData.status = updates.statut;
        updateData.statut = updates.statut;
      }

      const { data, error } = await supabase
        .from('signalements')
        .update(updateData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      return {
        id: data.id,
        type_incident: data.type_incident || data.type,
        date_incident: data.date_incident || '',
        heure_incident: data.heure_incident || '',
        lieu: data.lieu || '',
        description: data.description,
        gravite: (data.gravite || 'faible') as "faible" | "moyenne" | "elevee" | "critique",
        rapporte_par: data.rapporte_par || '',
        temoin_nom: data.temoin_nom || '',
        temoin_contact: data.temoin_contact || '',
        mesures_prises: data.mesures_prises || '',
        statut: (data.statut || data.status || 'ouvert') as "ouvert" | "en_cours" | "ferme" | "resolu",
        created_at: data.created_at,
        updated_at: data.updated_at
      };
    } catch (error) {
      console.error('Erreur lors de la mise à jour du signalement:', error);
      throw error;
    }
  }

  async delete(id: string): Promise<void> {
    try {
      const { error } = await supabase
        .from('signalements')
        .delete()
        .eq('id', id);

      if (error) throw error;
    } catch (error) {
      console.error('Erreur lors de la suppression du signalement:', error);
      throw error;
    }
  }
}

export const signalementService = new SignalementService();
