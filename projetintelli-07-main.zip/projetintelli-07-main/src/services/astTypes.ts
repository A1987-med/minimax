
export interface Risque {
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve';
  mesuresPrevention: string[];
}

export interface Outil {
  nom: string;
  type: string;
  securiteRequise: string[];
}

export interface Materiau {
  nom: string;
  type: string;
  precautions: string[];
}

export interface ExtractedSousOperation {
  nom: string;
  description: string;
  risques: Risque[];
}

export interface ExtractedOperation {
  nom: string;
  description: string;
  sousOperations: ExtractedSousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

export interface ExtractedTache {
  nom: string;
  description: string;
  operations: ExtractedOperation[];
}

export interface ASTData {
  corpsMetier: string;
  taches: ExtractedTache[];
  extractedAt: string;
}
