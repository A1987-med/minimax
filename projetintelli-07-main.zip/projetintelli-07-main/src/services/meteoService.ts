
export interface MeteoData {
  date: string;
  temperature: number;
  temperatureRessentie: number;
  vent: number;
  rafales: number;
  humidite: number;
  conditions: string;
  icone: string;
  location?: string; // Ajout pour afficher la localisation utilisée
  isRealData?: boolean; // Ajout pour savoir si c'est des vraies données
}

// Configuration par défaut pour Laval, Québec (fallback)
const LAVAL_LAT = 45.6066;
const LAVAL_LON = -73.7124;

// Fonction pour obtenir la position GPS actuelle
const getCurrentPosition = async (): Promise<{ lat: number; lon: number; location: string } | null> => {
  console.log('🌍 Tentative d\'obtention de la position GPS...');
  
  if (!navigator.geolocation) {
    console.warn('⚠️ Géolocalisation non supportée par le navigateur');
    return null;
  }

  try {
    const position = await new Promise<GeolocationPosition>((resolve, reject) => {
      navigator.geolocation.getCurrentPosition(
        resolve,
        reject,
        {
          enableHighAccuracy: true,
          timeout: 15000, // Augmenté pour iPad
          maximumAge: 300000 // 5 minutes
        }
      );
    });

    const lat = position.coords.latitude;
    const lon = position.coords.longitude;
    
    console.log('✅ Position GPS obtenue:', { lat, lon });
    return { 
      lat, 
      lon, 
      location: `GPS (${lat.toFixed(4)}°, ${lon.toFixed(4)}°)` 
    };
  } catch (error) {
    console.warn('⚠️ Erreur géolocalisation:', error);
    return null;
  }
};

// Fonction pour valider la clé API WeatherAPI
const isValidApiKey = (apiKey: string): boolean => {
  // Une clé API WeatherAPI est généralement une chaîne alphanumérique de 32 caractères
  const isValid = apiKey && 
         apiKey.trim().length >= 20 && // Plus flexible sur la longueur
         /^[a-zA-Z0-9]+$/.test(apiKey.trim()) &&
         !apiKey.includes('http') &&
         !apiKey.includes('{') &&
         !apiKey.includes('}');
  
  console.log('🔑 Validation clé API:', { 
    length: apiKey?.length, 
    isValid, 
    sample: apiKey?.substring(0, 8) + '...' 
  });
  
  return isValid;
};

import { 
  saveMeteoDataToSupabase, 
  getMeteoDataFromSupabase, 
  getMeteoHistoryFromSupabase,
  syncLocalStorageToSupabase 
} from './meteoSupabaseService';

// Fonction pour obtenir les données météo simulées réalistes pour Laval, Québec (fallback)
const getSimulatedMeteoData = async (date: string): Promise<MeteoData> => {
  // Simulation d'un délai d'API
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const currentDate = new Date(date);
  const month = currentDate.getMonth(); // 0-11
  
  // Températures moyennes mensuelles pour Laval, Québec (°C)
  const monthlyTemps = {
    0: -12,   // Janvier
    1: -10,   // Février  
    2: -3,    // Mars
    3: 6,     // Avril
    4: 14,    // Mai
    5: 19,    // Juin
    6: 22,    // Juillet
    7: 20,    // Août
    8: 15,    // Septembre
    9: 8,     // Octobre
    10: 1,    // Novembre
    11: -8    // Décembre
  };
  
  const baseTemp = monthlyTemps[month as keyof typeof monthlyTemps];
  
  // Variation quotidienne réaliste (-5 à +8°C de la moyenne)
  const tempVariation = (Math.random() * 13) - 5;
  const temperature = Math.round(baseTemp + tempVariation);
  
  // Humidité typique du Québec (plus élevée en été)
  const baseHumidity = month >= 5 && month <= 8 ? 70 : 65;
  const humidite = Math.round(baseHumidity + (Math.random() * 20) - 10);
  
  // Vent plus fort en hiver
  const baseWind = month >= 11 || month <= 2 ? 15 : 8;
  const vent = Math.round(baseWind + (Math.random() * 10));
  
  // Conditions météo saisonnières pour Laval, Québec
  let conditions: string;
  let icone: string;
  
  const random = Math.random();
  
  if (month >= 11 || month <= 2) { // Hiver
    if (random < 0.4) {
      conditions = 'Neigeux';
      icone = '❄️';
    } else if (random < 0.6) {
      conditions = 'Nuageux';
      icone = '☁️';
    } else if (random < 0.8) {
      conditions = 'Ensoleillé';
      icone = '☀️';
    } else {
      conditions = 'Tempête de neige';
      icone = '🌨️';
    }
  } else if (month >= 3 && month <= 5) { // Printemps
    if (random < 0.35) {
      conditions = 'Pluvieux';
      icone = '🌧️';
    } else if (random < 0.6) {
      conditions = 'Nuageux';
      icone = '☁️';
    } else if (random < 0.85) {
      conditions = 'Ensoleillé';
      icone = '☀️';
    } else {
      conditions = 'Brouillard';
      icone = '🌫️';
    }
  } else if (month >= 6 && month <= 8) { // Été
    if (random < 0.25) {
      conditions = 'Orageux';
      icone = '⛈️';
    } else if (random < 0.4) {
      conditions = 'Nuageux';
      icone = '☁️';
    } else if (random < 0.8) {
      conditions = 'Ensoleillé';
      icone = '☀️';
    } else {
      conditions = 'Pluvieux';
      icone = '🌧️';
    }
  } else { // Automne
    if (random < 0.4) {
      conditions = 'Pluvieux';
      icone = '🌧️';
    } else if (random < 0.6) {
      conditions = 'Nuageux';
      icone = '☁️';
    } else if (random < 0.8) {
      conditions = 'Ensoleillé';
      icone = '☀️';
    } else {
      conditions = 'Brouillard';
      icone = '🌫️';
    }
  }
  
  return {
    date,
    temperature,
    temperatureRessentie: Math.round(temperature - (vent * 0.3)),
    vent,
    rafales: Math.round(vent + Math.random() * 15),
    humidite: Math.max(30, Math.min(95, humidite)),
    conditions,
    icone,
    isRealData: false // Marquer comme données simulées
  };
};

// Fonction pour obtenir les données météo avec cache hybride localStorage + Supabase
export const getMeteoData = async (date: string, projetId?: string): Promise<MeteoData> => {
  console.log('🌤️ Début récupération données météo pour:', date);
  
  // Vérifier si on a une clé API WeatherAPI AVANT de vérifier les caches
  const apiKey = localStorage.getItem('weatherapi_key');
  const hasValidApiKey = apiKey && isValidApiKey(apiKey);
  
  console.log('🔑 Statut clé API:', { hasKey: !!apiKey, isValid: hasValidApiKey });

  // Si on a une clé API valide, essayer d'abord l'API pour les données fraîches
  if (hasValidApiKey) {
    console.log('🌐 Clé API valide détectée, récupération données fraîches...');
    
    try {
      const freshData = await fetchRealMeteoData(date, apiKey);
      if (freshData) {
        console.log('✅ Données météo fraîches récupérées de l\'API');
        // Sauvegarder immédiatement dans les deux caches
        await saveMeteoData(date, freshData, projetId);
        return freshData;
      }
    } catch (error) {
      console.warn('⚠️ Erreur lors de la récupération API, tentative de cache:', error);
    }
  }

  // 1. Vérifier le cache localStorage (rapide)
  const cachedData = getStoredMeteoHistory().find(data => data.date === date);
  if (cachedData && cachedData.isRealData) {
    console.log('⚡ Données météo réelles trouvées dans le cache localStorage');
    return cachedData;
  }

  // 2. Vérifier Supabase (persistant)
  const supabaseData = await getMeteoDataFromSupabase(date, projetId);
  if (supabaseData && supabaseData.isRealData) {
    console.log('☁️ Données météo réelles trouvées dans Supabase, mise en cache locale');
    saveMeteoDataToLocalStorage(date, supabaseData);
    return supabaseData;
  }

  // 3. Si pas de clé API ou échec, utiliser les données simulées
  console.log('🎲 Aucune donnée réelle disponible, génération de données simulées');
  const simulatedData = await getSimulatedMeteoData(date);
  await saveMeteoData(date, simulatedData, projetId);
  return simulatedData;
};

// Nouvelle fonction pour récupérer les données météo réelles de l'API
const fetchRealMeteoData = async (date: string, apiKey: string): Promise<MeteoData | null> => {
  try {
    // Tentative d'obtention de la position GPS
    const gpsPosition = await getCurrentPosition();
    
    let query: string, locationName: string;
    
    if (gpsPosition) {
      query = `${gpsPosition.lat},${gpsPosition.lon}`;
      locationName = gpsPosition.location;
      console.log('🌍 Utilisation de la position GPS pour la météo');
    } else {
      query = `${LAVAL_LAT},${LAVAL_LON}`;
      locationName = 'Laval, QC (par défaut)';
      console.log('📍 Utilisation de la position par défaut (Laval, QC) - Géolocalisation échouée');
    }

    // Données météo actuelles avec WeatherAPI
    const url = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${query}&lang=fr`;
    console.log('🌐 URL API:', url.replace(apiKey, 'API_KEY_HIDDEN'));

    const response = await fetch(url);
    
    console.log('📡 Réponse API:', { 
      status: response.status, 
      statusText: response.statusText,
      ok: response.ok 
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      console.error('❌ Erreur API WeatherAPI:', {
        status: response.status,
        statusText: response.statusText,
        error: errorData
      });
      
      if (response.status === 401 || response.status === 403) {
        console.error('🔑 Clé API invalide ou expirée. Suppression de la clé stockée.');
        localStorage.removeItem('weatherapi_key');
      }
      
      throw new Error(`Erreur API: ${response.status} - ${errorData?.error?.message || response.statusText}`);
    }

    const data = await response.json();
    console.log('✅ Données météo réelles récupérées avec succès:', data);
    
    // Convertir les données WeatherAPI vers notre format
    const current = data.current;
    const location = data.location;

    // Mapper les codes de condition WeatherAPI vers nos émojis
    const getWeatherIcon = (code: number, isDay: boolean): string => {
      const iconMap: { [key: number]: { day: string; night: string } } = {
        1000: { day: '☀️', night: '🌙' }, // Clear
        1003: { day: '⛅', night: '☁️' }, // Partly cloudy
        1006: { day: '☁️', night: '☁️' }, // Cloudy
        1009: { day: '☁️', night: '☁️' }, // Overcast
        1030: { day: '🌫️', night: '🌫️' }, // Mist
        1063: { day: '🌦️', night: '🌧️' }, // Patchy rain possible
        1066: { day: '🌨️', night: '❄️' }, // Patchy snow possible
        1069: { day: '🌨️', night: '❄️' }, // Patchy sleet possible
        1072: { day: '🌨️', night: '❄️' }, // Patchy freezing drizzle possible
        1087: { day: '⛈️', night: '⛈️' }, // Thundery outbreaks possible
        1114: { day: '❄️', night: '❄️' }, // Blowing snow
        1117: { day: '❄️', night: '❄️' }, // Blizzard
        1135: { day: '🌫️', night: '🌫️' }, // Fog
        1147: { day: '🌫️', night: '🌫️' }, // Freezing fog
        1150: { day: '🌦️', night: '🌧️' }, // Patchy light drizzle
        1153: { day: '🌦️', night: '🌧️' }, // Light drizzle
        1168: { day: '🌨️', night: '❄️' }, // Freezing drizzle
        1171: { day: '🌨️', night: '❄️' }, // Heavy freezing drizzle
        1180: { day: '🌦️', night: '🌧️' }, // Patchy light rain
        1183: { day: '🌧️', night: '🌧️' }, // Light rain
        1186: { day: '🌧️', night: '🌧️' }, // Moderate rain at times
        1189: { day: '🌧️', night: '🌧️' }, // Moderate rain
        1192: { day: '🌧️', night: '🌧️' }, // Heavy rain at times
        1195: { day: '🌧️', night: '🌧️' }, // Heavy rain
        1198: { day: '🌨️', night: '❄️' }, // Light freezing rain
        1201: { day: '🌨️', night: '❄️' }, // Moderate or heavy freezing rain
        1204: { day: '🌨️', night: '❄️' }, // Light sleet
        1207: { day: '🌨️', night: '❄️' }, // Moderate or heavy sleet
        1210: { day: '❄️', night: '❄️' }, // Patchy light snow
        1213: { day: '❄️', night: '❄️' }, // Light snow
        1216: { day: '❄️', night: '❄️' }, // Patchy moderate snow
        1219: { day: '❄️', night: '❄️' }, // Moderate snow
        1222: { day: '❄️', night: '❄️' }, // Patchy heavy snow
        1225: { day: '❄️', night: '❄️' }, // Heavy snow
        1237: { day: '🌨️', night: '❄️' }, // Ice pellets
        1240: { day: '🌦️', night: '🌧️' }, // Light rain shower
        1243: { day: '🌧️', night: '🌧️' }, // Moderate or heavy rain shower
        1246: { day: '🌧️', night: '🌧️' }, // Torrential rain shower
        1249: { day: '🌨️', night: '❄️' }, // Light sleet showers
        1252: { day: '🌨️', night: '❄️' }, // Moderate or heavy sleet showers
        1255: { day: '❄️', night: '❄️' }, // Light snow showers
        1258: { day: '❄️', night: '❄️' }, // Moderate or heavy snow showers
        1261: { day: '🌨️', night: '❄️' }, // Light showers of ice pellets
        1264: { day: '🌨️', night: '❄️' }, // Moderate or heavy showers of ice pellets
        1273: { day: '⛈️', night: '⛈️' }, // Patchy light rain with thunder
        1276: { day: '⛈️', night: '⛈️' }, // Moderate or heavy rain with thunder
        1279: { day: '⛈️', night: '⛈️' }, // Patchy light snow with thunder
        1282: { day: '⛈️', night: '⛈️' }, // Moderate or heavy snow with thunder
      };

      const mapping = iconMap[code];
      if (mapping) {
        return isDay ? mapping.day : mapping.night;
      }
      return isDay ? '☀️' : '🌙';
    };

    return {
      date,
      temperature: Math.round(current.temp_c),
      temperatureRessentie: Math.round(current.feelslike_c),
      vent: Math.round(current.wind_kph),
      rafales: Math.round(current.gust_kph || current.wind_kph),
      humidite: current.humidity,
      conditions: current.condition.text,
      icone: getWeatherIcon(current.condition.code, current.is_day === 1),
      location: `${location.name}, ${location.region}`,
      isRealData: true // Marquer comme données réelles
    };
  } catch (error) {
    console.error('❌ Erreur lors de la récupération des données météo réelles:', error);
    return null;
  }
};

// Fonction de sauvegarde hybride (localStorage + Supabase)
export const saveMeteoData = async (date: string, data: MeteoData, projetId?: string) => {
  // Sauvegarder dans localStorage (cache rapide)
  saveMeteoDataToLocalStorage(date, data);
  
  // Sauvegarder dans Supabase (persistance)
  await saveMeteoDataToSupabase(data, projetId);
};

// Fonction de sauvegarde localStorage (renommée pour clarté)
const saveMeteoDataToLocalStorage = (date: string, data: MeteoData) => {
  const existingData = JSON.parse(localStorage.getItem('meteo_history') || '[]');
  const newData = existingData.filter((item: MeteoData) => item.date !== date);
  newData.push(data);
  localStorage.setItem('meteo_history', JSON.stringify(newData));
};

// Fonction pour obtenir l'historique avec cache hybride
export const getMeteoHistory = async (days: number = 30, projetId?: string): Promise<MeteoData[]> => {
  console.log('📚 Récupération historique météo hybride...');
  
  // Essayer d'abord Supabase (source fiable)
  const supabaseHistory = await getMeteoHistoryFromSupabase(days, projetId);
  
  if (supabaseHistory.length > 0) {
    console.log('☁️ Historique récupéré depuis Supabase');
    // Mettre à jour le cache localStorage
    supabaseHistory.forEach(data => saveMeteoDataToLocalStorage(data.date, data));
    return supabaseHistory;
  }
  
  // Fallback sur localStorage
  const localHistory = getStoredMeteoHistory();
  
  if (localHistory.length > 0) {
    console.log('💾 Historique récupéré depuis localStorage');
    // Synchroniser vers Supabase en arrière-plan
    syncLocalStorageToSupabase(projetId);
    return localHistory.slice(-days);
  }
  
  // Si aucun historique, générer des données simulées
  console.log('🎲 Génération historique simulé');
  const history: MeteoData[] = [];
  const today = new Date();
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateString = date.toISOString().split('T')[0];
    
    const meteoData = await getSimulatedMeteoData(dateString);
    history.push(meteoData);
    await saveMeteoData(dateString, meteoData, projetId);
  }
  
  return history;
};

export const getStoredMeteoHistory = (): MeteoData[] => {
  return JSON.parse(localStorage.getItem('meteo_history') || '[]');
};

// Fonction pour configurer la clé API WeatherAPI
export const setWeatherApiKey = (apiKey: string) => {
  const cleanApiKey = apiKey.trim();
  
  if (!isValidApiKey(cleanApiKey)) {
    console.warn('⚠️ Format de clé API suspect:', cleanApiKey.substring(0, 20) + '...');
    console.warn('Une clé API WeatherAPI valide doit être une chaîne de caractères alphanumériques');
  }
  
  localStorage.setItem('weatherapi_key', cleanApiKey);
  console.log('✅ Clé API WeatherAPI sauvegardée');
};

export const getWeatherApiKey = (): string | null => {
  return localStorage.getItem('weatherapi_key');
};

export const removeWeatherApiKey = () => {
  localStorage.removeItem('weatherapi_key');
  console.log('🗑️ Clé API WeatherAPI supprimée');
};

// Fonction pour tester la validité de la clé API
export const testApiKey = async (apiKey: string): Promise<{ success: boolean; error?: string }> => {
  console.log('🧪 Test de la clé API en cours...');
  
  if (!isValidApiKey(apiKey)) {
    return { 
      success: false, 
      error: 'Format de clé API invalide. Une clé valide contient des caractères alphanumériques.' 
    };
  }

  try {
    const testUrl = `https://api.weatherapi.com/v1/current.json?key=${apiKey}&q=${LAVAL_LAT},${LAVAL_LON}`;
    console.log('🌐 Test URL:', testUrl.replace(apiKey, 'API_KEY_HIDDEN'));
    
    const response = await fetch(testUrl);
    
    console.log('📡 Test réponse:', { 
      status: response.status, 
      statusText: response.statusText,
      ok: response.ok 
    });
    
    if (response.ok) {
      const data = await response.json();
      console.log('✅ Test de clé API réussi:', data);
      return { success: true };
    } else {
      const errorData = await response.json().catch(() => null);
      console.error('❌ Test de clé API échoué:', response.status, errorData);
      return { 
        success: false, 
        error: `Erreur ${response.status}: ${errorData?.error?.message || response.statusText}` 
      };
    }
  } catch (error) {
    console.error('❌ Erreur lors du test de la clé API:', error);
    return { 
      success: false, 
      error: 'Erreur de connexion lors du test de la clé API' 
    };
  }
};
