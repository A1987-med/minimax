
import { ASTData } from './astTypes';
import { arpenteurASTData } from '../data/arpenteur';

class ASTDataService {
  private readonly STORAGE_KEY = 'ast_data';

  saveASTData(data: ASTData): void {
    try {
      const existingData = this.getAllASTData();
      const updatedData = existingData.filter(d => d.corpsMetier !== data.corpsMetier);
      updatedData.push(data);
      
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updatedData));
      console.log('Données AST sauvegardées pour:', data.corpsMetier);
    } catch (error) {
      console.error('Erreur sauvegarde AST:', error);
    }
  }

  getASTData(corpsMetier: string): ASTData | null {
    try {
      // Vérifier d'abord les données statiques pour Arpenteur
      if (corpsMetier === 'Arpenteur') {
        console.log('✅ Données statiques Arpenteur trouvées');
        return arpenteurASTData;
      }

      const allData = this.getAllASTData();
      const found = allData.find(d => d.corpsMetier === corpsMetier);
      console.log('Recherche AST pour:', corpsMetier, 'trouvé:', !!found);
      return found || null;
    } catch (error) {
      console.error('Erreur lecture AST:', error);
      return null;
    }
  }

  getAllASTData(): ASTData[] {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      return stored ? JSON.parse(stored) : [];
    } catch (error) {
      console.error('Erreur lecture données AST:', error);
      return [];
    }
  }

  deleteASTData(corpsMetier: string): void {
    try {
      const existingData = this.getAllASTData();
      const filteredData = existingData.filter(d => d.corpsMetier !== corpsMetier);
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(filteredData));
      console.log('Données AST supprimées pour:', corpsMetier);
    } catch (error) {
      console.error('Erreur suppression AST:', error);
    }
  }

  hasASTData(corpsMetier: string): boolean {
    // Toujours retourner true pour Arpenteur car on a les données statiques
    if (corpsMetier === 'Arpenteur') {
      return true;
    }
    return this.getASTData(corpsMetier) !== null;
  }
}

export const astDataService = new ASTDataService();
