
// Service pour gérer les informations du projet
class ProjectInfoService {
  private projectInfo = {
    nomProjet: '',
    numeroProjet: '',
    adresseProjet: '',
    logoMaitreOeuvre: ''
  };

  setProjectInfo(info: { nomProjet?: string; numeroProjet?: string; adresseProjet?: string; logoMaitreOeuvre?: string }) {
    this.projectInfo = { ...this.projectInfo, ...info };
    // Sauvegarder dans localStorage pour persistance
    localStorage.setItem('projectInfo', JSON.stringify(this.projectInfo));
  }

  getProjectInfo() {
    // Charger depuis localStorage si disponible
    const saved = localStorage.getItem('projectInfo');
    if (saved) {
      this.projectInfo = JSON.parse(saved);
    }
    
    // Tenter de récupérer le logo depuis la section Gestion si pas déjà défini
    if (!this.projectInfo.logoMaitreOeuvre) {
      const gestionData = localStorage.getItem('gestion_data');
      if (gestionData) {
        try {
          const parsed = JSON.parse(gestionData);
          if (parsed.logoMaitreOeuvre) {
            this.projectInfo.logoMaitreOeuvre = parsed.logoMaitreOeuvre;
            localStorage.setItem('projectInfo', JSON.stringify(this.projectInfo));
          }
        } catch (error) {
          console.log('Pas de données de gestion trouvées');
        }
      }
    }
    
    return this.projectInfo;
  }

  updateProjectField(field: 'nomProjet' | 'numeroProjet' | 'adresseProjet' | 'logoMaitreOeuvre', value: string) {
    this.projectInfo[field] = value;
    localStorage.setItem('projectInfo', JSON.stringify(this.projectInfo));
  }
}

export const projectInfoService = new ProjectInfoService();
