
import { supabase } from '@/integrations/supabase/client';
import { MeteoData } from './meteoService';

export interface MeteoDataDB {
  id: string;
  date: string;
  temperature: number;
  temperature_ressentie: number;
  vent: number;
  rafales: number;
  humidite: number;
  conditions: string;
  icone: string;
  location?: string;
  is_real_data: boolean;
  user_id?: string;
  projet_id?: string;
  created_at: string;
  updated_at: string;
}

// Convertir les données DB vers le format de l'interface MeteoData
const convertDBToMeteoData = (dbData: any): MeteoData => ({
  date: dbData.date,
  temperature: dbData.temperature,
  temperatureRessentie: dbData.temperature_ressentie,
  vent: dbData.vent,
  rafales: dbData.rafales,
  humidite: dbData.humidite,
  conditions: dbData.conditions,
  icone: dbData.icone,
  location: dbData.location,
  isRealData: dbData.is_real_data
});

// Convertir les données MeteoData vers le format DB
const convertMeteoDataToDB = (meteoData: MeteoData, projetId?: string): any => ({
  date: meteoData.date,
  temperature: meteoData.temperature,
  temperature_ressentie: meteoData.temperatureRessentie,
  vent: meteoData.vent,
  rafales: meteoData.rafales,
  humidite: meteoData.humidite,
  conditions: meteoData.conditions,
  icone: meteoData.icone,
  location: meteoData.location,
  is_real_data: meteoData.isRealData || false,
  projet_id: projetId
});

// Sauvegarder des données météo dans Supabase
export const saveMeteoDataToSupabase = async (meteoData: MeteoData, projetId?: string): Promise<boolean> => {
  try {
    console.log('💾 Sauvegarde données météo dans Supabase:', meteoData.date);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ Utilisateur non connecté, impossible de sauvegarder dans Supabase');
      return false;
    }

    const dbData = convertMeteoDataToDB(meteoData, projetId);
    
    // Utiliser upsert standard avec une clé composite
    const { error } = await supabase
      .from('meteo_data' as any)
      .upsert({
        ...dbData,
        user_id: user.id
      }, {
        onConflict: 'user_id,date'
      });

    if (error) {
      console.error('❌ Erreur lors de la sauvegarde dans Supabase:', error);
      return false;
    }

    console.log('✅ Données météo sauvegardées dans Supabase avec succès');
    return true;
  } catch (error) {
    console.error('❌ Erreur lors de la sauvegarde météo Supabase:', error);
    return false;
  }
};

// Récupérer des données météo depuis Supabase pour une date spécifique
export const getMeteoDataFromSupabase = async (date: string, projetId?: string): Promise<MeteoData | null> => {
  try {
    console.log('📖 Récupération données météo depuis Supabase:', date);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ Utilisateur non connecté, impossible de récupérer depuis Supabase');
      return null;
    }

    let query = supabase
      .from('meteo_data' as any)
      .select('*')
      .eq('user_id', user.id)
      .eq('date', date);

    if (projetId) {
      query = query.eq('projet_id', projetId);
    } else {
      query = query.is('projet_id', null);
    }

    const { data, error } = await query.single();

    if (error) {
      if (error.code === 'PGRST116') { // No rows found
        console.log('📭 Aucune donnée météo trouvée dans Supabase pour:', date);
        return null;
      }
      console.error('❌ Erreur lors de la récupération depuis Supabase:', error);
      return null;
    }

    const meteoData = convertDBToMeteoData(data);
    console.log('✅ Données météo récupérées depuis Supabase:', meteoData);
    return meteoData;
  } catch (error) {
    console.error('❌ Erreur lors de la récupération météo Supabase:', error);
    return null;
  }
};

// Récupérer l'historique météo depuis Supabase
export const getMeteoHistoryFromSupabase = async (days: number = 30, projetId?: string): Promise<MeteoData[]> => {
  try {
    console.log('📚 Récupération historique météo depuis Supabase:', days, 'jours');
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ Utilisateur non connecté, impossible de récupérer l\'historique depuis Supabase');
      return [];
    }

    const pastDate = new Date();
    pastDate.setDate(pastDate.getDate() - days);

    let query = supabase
      .from('meteo_data' as any)
      .select('*')
      .eq('user_id', user.id)
      .gte('date', pastDate.toISOString().split('T')[0])
      .order('date', { ascending: true });

    if (projetId) {
      query = query.eq('projet_id', projetId);
    } else {
      query = query.is('projet_id', null);
    }

    const { data, error } = await query;

    if (error) {
      console.error('❌ Erreur lors de la récupération de l\'historique depuis Supabase:', error);
      return [];
    }

    const meteoHistory = data.map(convertDBToMeteoData);
    console.log('✅ Historique météo récupéré depuis Supabase:', meteoHistory.length, 'entrées');
    return meteoHistory;
  } catch (error) {
    console.error('❌ Erreur lors de la récupération historique météo Supabase:', error);
    return [];
  }
};

// Supprimer des données météo de Supabase
export const deleteMeteoDataFromSupabase = async (date: string, projetId?: string): Promise<boolean> => {
  try {
    console.log('🗑️ Suppression données météo depuis Supabase:', date);
    
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ Utilisateur non connecté, impossible de supprimer depuis Supabase');
      return false;
    }

    let query = supabase
      .from('meteo_data' as any)
      .delete()
      .eq('user_id', user.id)
      .eq('date', date);

    if (projetId) {
      query = query.eq('projet_id', projetId);
    } else {
      query = query.is('projet_id', null);
    }

    const { error } = await query;

    if (error) {
      console.error('❌ Erreur lors de la suppression depuis Supabase:', error);
      return false;
    }

    console.log('✅ Données météo supprimées de Supabase avec succès');
    return true;
  } catch (error) {
    console.error('❌ Erreur lors de la suppression météo Supabase:', error);
    return false;
  }
};

// Synchroniser les données localStorage vers Supabase
export const syncLocalStorageToSupabase = async (projetId?: string): Promise<void> => {
  try {
    console.log('🔄 Synchronisation localStorage vers Supabase...');
    
    const localData = JSON.parse(localStorage.getItem('meteo_history') || '[]') as MeteoData[];
    
    if (localData.length === 0) {
      console.log('📭 Aucune donnée locale à synchroniser');
      return;
    }

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      console.warn('⚠️ Utilisateur non connecté, impossible de synchroniser');
      return;
    }

    console.log('📤 Synchronisation de', localData.length, 'entrées vers Supabase');
    
    for (const meteoData of localData) {
      await saveMeteoDataToSupabase(meteoData, projetId);
    }
    
    console.log('✅ Synchronisation terminée');
  } catch (error) {
    console.error('❌ Erreur lors de la synchronisation:', error);
  }
};
