
import { supabase } from '../integrations/supabase/client';

export interface PresenceJournaliere {
  id: string;
  date: string;
  sous_traitant: string;
  nombre_travailleurs: number;
  heure_saisie: string;
  created_at?: string;
  updated_at?: string;
}

export interface PresenceJournaliereInsert {
  date: string;
  sous_traitant: string;
  nombre_travailleurs: number;
  heure_saisie: string;
}

export interface SoustraitantPresence {
  id: string;
  nom: string;
  nombreTravailleurs: number;
  presenceIds?: string[];
}

class PresencesService {
  async savePresences(presences: PresenceJournaliereInsert[]) {
    // Pour l'instant, nous utilisons une table temporaire en localStorage
    // En attendant que la table presences_journalieres soit ajoutée à Supabase
    const existingPresences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    const newPresences = presences.map(p => ({
      ...p,
      id: Date.now().toString() + Math.random().toString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }));
    
    localStorage.setItem('presences_journalieres', JSON.stringify([...existingPresences, ...newPresences]));
    return newPresences;
  }

  async getPresencesByDate(date: string): Promise<PresenceJournaliere[]> {
    const presences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    return presences.filter((p: PresenceJournaliere) => p.date === date);
  }

  async getPresencesByDateRange(startDate: string, endDate: string): Promise<PresenceJournaliere[]> {
    const presences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    return presences.filter((p: PresenceJournaliere) => p.date >= startDate && p.date <= endDate);
  }

  async getPresencesGroupedBySoustraitant(date: string): Promise<SoustraitantPresence[]> {
    const presences = await this.getPresencesByDate(date);
    const grouped = presences.reduce((acc: Record<string, PresenceJournaliere[]>, presence) => {
      if (!acc[presence.sous_traitant]) {
        acc[presence.sous_traitant] = [];
      }
      acc[presence.sous_traitant].push(presence);
      return acc;
    }, {});

    return Object.entries(grouped).map(([nom, presencesList]) => ({
      id: nom,
      nom,
      nombreTravailleurs: presencesList.reduce((sum, p) => sum + p.nombre_travailleurs, 0),
      presenceIds: presencesList.map(p => p.id)
    }));
  }

  async deletePresence(id: string) {
    const presences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    const filtered = presences.filter((p: PresenceJournaliere) => p.id !== id);
    localStorage.setItem('presences_journalieres', JSON.stringify(filtered));
    return true;
  }

  async deleteSoustraitantPresences(soustraitant: string, date: string) {
    const presences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    const filtered = presences.filter((p: PresenceJournaliere) => 
      !(p.sous_traitant === soustraitant && p.date === date)
    );
    localStorage.setItem('presences_journalieres', JSON.stringify(filtered));
    return true;
  }

  async updatePresence(id: string, updates: Partial<PresenceJournaliereInsert>) {
    const presences = JSON.parse(localStorage.getItem('presences_journalieres') || '[]');
    const index = presences.findIndex((p: PresenceJournaliere) => p.id === id);
    if (index !== -1) {
      presences[index] = { ...presences[index], ...updates, updated_at: new Date().toISOString() };
      localStorage.setItem('presences_journalieres', JSON.stringify(presences));
      return presences[index];
    }
    throw new Error('Présence non trouvée');
  }
}

export const presencesService = new PresencesService();
