
import EXIF from 'exif-js';

export interface ExifData {
  dateTime?: string;
  cameraMake?: string;
  cameraModel?: string;
  gpsLatitude?: number;
  gpsLongitude?: number;
  orientation?: number;
}

export const extractExifData = (file: File): Promise<ExifData> => {
  return new Promise((resolve) => {
    try {
      console.log('🔍 === DÉBUT EXTRACTION EXIF DÉTAILLÉE ===');
      console.log('📸 Fichier:', {
        name: file.name,
        size: file.size,
        type: file.type,
        lastModified: new Date(file.lastModified).toISOString()
      });

      // Utiliser FileReader pour convertir le File en ArrayBuffer
      const reader = new FileReader();
      
      reader.onload = function(e) {
        try {
          const arrayBuffer = e.target?.result as ArrayBuffer;
          if (!arrayBuffer) {
            console.warn('⚠️ Pas de données ArrayBuffer');
            resolve({});
            return;
          }

          console.log('📂 ArrayBuffer récupéré, taille:', arrayBuffer.byteLength);
          
          // Utiliser EXIF.readFromBinaryFile pour extraire les données
          const exifData = EXIF.readFromBinaryFile(arrayBuffer);
          console.log('📊 EXIF.readFromBinaryFile résultat:', exifData);
          
          if (!exifData || Object.keys(exifData).length === 0) {
            console.warn('⚠️ Aucune donnée EXIF trouvée');
            resolve({});
            return;
          }

          // Chercher toutes les variantes de date
          const dateTime = exifData.DateTime || exifData.DateTimeOriginal || exifData.DateTimeDigitized || exifData.CreateDate;
          const cameraMake = exifData.Make;
          const cameraModel = exifData.Model;
          const orientation = exifData.Orientation;
          
          console.log('📅 Dates trouvées:', {
            DateTime: exifData.DateTime,
            DateTimeOriginal: exifData.DateTimeOriginal,
            DateTimeDigitized: exifData.DateTimeDigitized,
            CreateDate: exifData.CreateDate,
            finalDateTime: dateTime
          });

          console.log('📱 Appareil:', { Make: cameraMake, Model: cameraModel, Orientation: orientation });

          // Coordonnées GPS
          const gpsLat = exifData.GPSLatitude;
          const gpsLatRef = exifData.GPSLatitudeRef;
          const gpsLong = exifData.GPSLongitude;
          const gpsLongRef = exifData.GPSLongitudeRef;
          
          console.log('📍 GPS brut:', { gpsLat, gpsLatRef, gpsLong, gpsLongRef });

          let gpsLatitude, gpsLongitude;
          if (gpsLat && gpsLong) {
            gpsLatitude = convertDMSToDD(gpsLat, gpsLatRef);
            gpsLongitude = convertDMSToDD(gpsLong, gpsLongRef);
            console.log('📍 GPS converti:', { gpsLatitude, gpsLongitude });
          }

          const result = {
            dateTime,
            cameraMake,
            cameraModel,
            gpsLatitude,
            gpsLongitude,
            orientation
          };

          console.log('✅ Résultat final EXIF:', result);
          console.log('🔍 === FIN EXTRACTION EXIF ===');

          resolve(result);
          
        } catch (error) {
          console.error('❌ Erreur extraction EXIF:', error);
          resolve({});
        }
      };
      
      reader.onerror = function() {
        console.error('❌ Erreur lecture fichier');
        resolve({});
      };
      
      // Lire le fichier comme ArrayBuffer
      reader.readAsArrayBuffer(file);
      
    } catch (error) {
      console.error('❌ Erreur générale extraction EXIF:', error);
      resolve({});
    }
  });
};

// Fonction utilitaire pour convertir DMS (Degrees, Minutes, Seconds) en DD (Decimal Degrees)
function convertDMSToDD(dms: number[], ref: string): number {
  if (!dms || dms.length !== 3) return 0;
  
  let dd = dms[0] + dms[1]/60 + dms[2]/3600;
  if (ref === 'S' || ref === 'W') {
    dd = dd * -1;
  }
  return dd;
}

export const formatExifDate = (exifDate?: string): string => {
  if (!exifDate) return 'Date inconnue';
  
  try {
    console.log('📅 Formatage date EXIF:', exifDate);
    
    // Format EXIF: "YYYY:MM:DD HH:MM:SS"
    const [datePart, timePart] = exifDate.split(' ');
    if (!datePart) return exifDate;
    
    const [year, month, day] = datePart.split(':');
    if (!year || !month || !day) return exifDate;
    
    const date = new Date(`${year}-${month}-${day}${timePart ? `T${timePart}` : ''}`);
    
    if (isNaN(date.getTime())) {
      console.warn('⚠️ Date invalide:', exifDate);
      return exifDate;
    }
    
    const formatted = date.toLocaleString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    console.log('✅ Date formatée:', formatted);
    return formatted;
  } catch (error) {
    console.error('❌ Erreur formatage date EXIF:', error);
    return exifDate;
  }
};

// Export service instance
export const exifService = {
  extractExifData,
  formatExifDate
};
