
// Types pour la section Protocoles
export interface ProtocolePersonnalise {
  id: string;
  titre: string;
  typeActivite: string;
  regles: string[];
  equipementsRequis: string[];
  pointsControle: string[];
  creePar: string;
  actif: boolean;
  createdAt: string;
  updatedAt: string;
}
