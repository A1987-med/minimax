
// Types pour les formations et certifications
export interface FormationCertification {
  id: string;
  nomEmploye: string;
  entreprise: string;
  typeFormation: string;
  organisme?: string;
  dateObtention: string;
  dateExpiration?: string;
  numeroCertificat?: string;
  fichierUrl?: string;
  statut: 'valide' | 'expire' | 'en_attente' | 'suspendu';
  createdAt: string;
  updatedAt: string;
}
