
export interface CalorifugeurOutil {
  nom: string;
  type: string;
  securiteRequise: string[];
}

export interface CalorifugeurSousOperation {
  id: string;
  nom: string;
  description: string;
}

export interface CalorifugeurOperation {
  id: string;
  nom: string;
  description: string;
  outils?: CalorifugeurOutil[];
  sousOperations: CalorifugeurSousOperation[];
}

export interface CalorifugeurTache {
  id: string;
  numero: number;
  nom: string;
  description: string;
  operations: CalorifugeurOperation[];
}

export interface CalorifugeurAST {
  metier: string;
  taches: CalorifugeurTache[];
  createdAt: string;
}
