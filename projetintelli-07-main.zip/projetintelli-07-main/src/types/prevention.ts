
// Types pour la section Prévention
export interface ChecklistPrevention {
  id: string;
  typeChecklist: string;
  titre: string;
  items: ChecklistItem[];
  completeePar: string;
  dateCompletion: string;
  statut: 'en_cours' | 'complete' | 'incomplete';
  observations?: string;
  createdAt: string;
  updatedAt: string;
}

export interface ChecklistItem {
  id: string;
  description: string;
  verifie: boolean;
  commentaire?: string;
}

export interface Inspection {
  id: string;
  typeInspection: string;
  equipementZone: string;
  inspecteur: string;
  dateInspection: string;
  heureInspection: string;
  resultats: Record<string, any>;
  conformite: boolean;
  actionsCorrectives?: string;
  dateProchaineInspection?: string;
  statut: 'planifiee' | 'en_cours' | 'complete' | 'reportee';
  createdAt: string;
  updatedAt: string;
}
