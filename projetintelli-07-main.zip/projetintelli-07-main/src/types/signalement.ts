
// Types pour la section Signalement - utilisant les noms de colonnes Supabase
export interface Signalement {
  id: string;
  type_incident: string;
  description: string;
  lieu: string;
  date_incident: string;
  heure_incident: string;
  temoin_nom?: string;
  temoin_contact?: string;
  mesures_prises?: string;
  gravite: 'faible' | 'moyenne' | 'elevee' | 'critique';
  statut: 'ouvert' | 'en_cours' | 'ferme' | 'resolu';
  rapporte_par: string;
  created_at: string;
  updated_at: string;
}
