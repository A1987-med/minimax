
// Types pour la section Urgences
export interface ContactUrgence {
  id: string;
  nom: string;
  fonction: string;
  telephone: string;
  telephoneSecondaire?: string;
  courriel?: string;
  typeContact: 'police' | 'pompiers' | 'ambulance' | 'securite' | 'direction' | 'autre';
  disponibilite?: string;
  ordrePriorite: number;
  actif: boolean;
  createdAt: string;
  updatedAt: string;
}
