
// Types pour la section Accueil
export interface EntryData {
  id: string;
  prenom: string;
  nom: string;
  nomEmploye: string;
  entreprise: string;
  fonction: string;
  corpsMetier: string;
  occupation: string; // Champ occupation individual (string)
  occupations: string[]; // Champ occupations multiples (array)
  age: number;
  dateEntree: string;
  heureEntree: string;
  dateAjout: string;
  dateAccueil: string;
  etiquetteRecue: boolean;
  numeroEtiquette: string;
  estContremaitre: boolean;
  estSousTraitant: boolean;
  nomSousTraitant: string;
  telephone: string;
  courriel: string;
  adresse: string;
  ville: string;
  codePostal: string;
  numeroImmatriculation: string;
  nomContactAccident: string;
  cellulaireContact: string;
  estCadre: boolean;
  carteASP: string;
  carteASPName: string;
  carteCCQ: string;
  carteCCQName: string;
  numeroClient: string;
  dateEcheanceCarte: string;
  carteSIMDUT: string;
  carteSIMDUTName: string;
  selectedFormations: string[];
  cartesFormations: Record<string, { active: boolean; image?: string; imageName?: string; }>;
  estSecouriste: boolean;
  carteSecouriste: string;
  carteSecouristeName: string;
  dateEcheancierSecouriste: string;
  maladie: string;
  allergie: string;
  soustraitant: string;
  logo: string;
}

export interface Soustraitant {
  id: string;
  nom: string;
  adresse: string;
  telephone: string;
  courriel: string;
  actif: boolean;
  dateAjout: string;
}
