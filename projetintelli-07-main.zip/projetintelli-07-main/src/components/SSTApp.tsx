
import React, { useState, useRef, useEffect } from 'react';
import { SidebarProvider } from "@/components/ui/sidebar";
import { SSTSidebar } from "@/components/SSTSidebar";
import { SSTMainContent } from "@/components/SSTMainContent";

const SSTApp = () => {
  const [currentSection, setCurrentSection] = useState<string | null>(null);
  const astOperationLockRef = useRef(false);
  
  console.log('📱 iPad - SSTApp rendering with currentSection:', currentSection);
  
  // Fonction sécurisée pour changement de section avec correction iPad FINALE
  const handleSectionChange = (newSection: string | null) => {
    console.log('📱 iPad - SOLUTION FINALE - Demande changement section:', currentSection, '->', newSection);
    
    // Si on est en pleine opération AST sur iPad, bloquer les changements non autorisés
    if (astOperationLockRef.current && newSection !== 'ast' && newSection !== currentSection) {
      console.log('🔒 iPad AST - Changement de section bloqué pendant opération:', currentSection, '->', newSection);
      return;
    }
    
    console.log('✅ iPad - SOLUTION FINALE - Changement de section autorisé:', currentSection, '->', newSection);
    
    // Solution finale : forcer le changement d'état de manière synchrone ET asynchrone
    setCurrentSection(newSection);
    
    // Forcer un re-render multiple pour iPad avec différents délais
    setTimeout(() => {
      console.log('📱 iPad - SOLUTION FINALE - Force re-render 1 (50ms)');
      setCurrentSection(newSection);
    }, 50);
    
    setTimeout(() => {
      console.log('📱 iPad - SOLUTION FINALE - Force re-render 2 (150ms)');
      setCurrentSection(newSection);
    }, 150);
    
    // Forcer une mise à jour du DOM
    requestAnimationFrame(() => {
      console.log('📱 iPad - SOLUTION FINALE - Force re-render RAF');
      setCurrentSection(newSection);
    });
  };

  // Fonction pour verrouiller/déverrouiller la navigation pendant les opérations AST
  const setASTOperationLock = (locked: boolean) => {
    console.log('🔐 iPad AST - Verrouillage navigation:', locked);
    astOperationLockRef.current = locked;
  };
  
  // Solution finale : surveiller les changements d'état pour le debugging
  useEffect(() => {
    console.log('📱 iPad - SOLUTION FINALE - État changé vers:', currentSection);
  }, [currentSection]);
  
  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full relative overflow-hidden">
        {/* Fond moderne avec dégradé animé */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600 via-purple-700 via-indigo-800 to-slate-900"></div>
        
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-radial from-transparent via-blue-500/10 to-purple-900/20"></div>
          
          <div className="absolute inset-0 opacity-5" style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, white 1px, transparent 0)`,
            backgroundSize: '20px 20px'
          }}></div>
          
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-blue-400/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-400/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-3/4 left-1/2 w-64 h-64 bg-indigo-400/15 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        </div>
        
        <div className="absolute inset-0 bg-white/5 backdrop-blur-[0.5px]"></div>
        
        <SSTSidebar onSectionSelect={handleSectionChange} />
        <main className="flex-1 relative z-10">
          <SSTMainContent 
            currentSection={currentSection} 
            onSectionChange={handleSectionChange}
            setASTOperationLock={setASTOperationLock}
          />
        </main>
      </div>
    </SidebarProvider>
  );
};

export default SSTApp;
