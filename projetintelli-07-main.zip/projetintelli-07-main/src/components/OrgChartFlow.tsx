
import React, { useCallback, useState } from 'react';
import {
  ReactFlow,
  MiniMap,
  Controls,
  Background,
  useNodesState,
  useEdgesState,
  addEdge,
  Connection,
  BackgroundVariant,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';

import { EmployeeNode } from './nodes/EmployeeNode';
import { DepartmentNode } from './nodes/DepartmentNode';
import { ManagerNode } from './nodes/ManagerNode';
import { initialNodes, initialEdges } from './data/initialData';

const nodeTypes = {
  employee: EmployeeNode,
  department: DepartmentNode,
  manager: ManagerNode,
};

export function OrgChartFlow() {
  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  const onConnect = useCallback(
    (params: Connection) => setEdges((eds) => addEdge(params, eds)),
    [setEdges],
  );

  const nodeClassName = (node: any) => node.type;

  return (
    <div className="w-full h-screen relative">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        nodeTypes={nodeTypes}
        fitView
        className="bg-gradient-to-br from-blue-50 to-indigo-100"
        attributionPosition="bottom-left"
      >
        <Background 
          variant={BackgroundVariant.Dots} 
          gap={20} 
          size={1}
          color="#e0e7ff"
        />
        <Controls 
          className="bg-white/90 backdrop-blur-sm border border-indigo-200 rounded-lg shadow-lg"
        />
        <MiniMap 
          nodeClassName={nodeClassName}
          className="bg-white/90 backdrop-blur-sm border border-indigo-200 rounded-lg shadow-lg"
          pannable 
          zoomable
        />
      </ReactFlow>
    </div>
  );
}
