
import { Node, Edge } from '@xyflow/react';

export const initialNodes: Node[] = [
  {
    id: 'ceo',
    type: 'manager',
    position: { x: 400, y: 50 },
    data: {
      name: 'Marie Dubois',
      position: 'Directrice Générale',
      level: 'CEO',
      department: 'Direction'
    },
  },
  {
    id: 'it-director',
    type: 'manager',
    position: { x: 150, y: 200 },
    data: {
      name: 'Pierre Martin',
      position: 'Directeur IT',
      level: 'Director',
      department: 'Informatique'
    },
  },
  {
    id: 'hr-director',
    type: 'manager',
    position: { x: 650, y: 200 },
    data: {
      name: 'Sophie Leroy',
      position: 'Directrice RH',
      level: 'Director',
      department: 'Ressources Humaines'
    },
  },
  {
    id: 'it-dept',
    type: 'department',
    position: { x: 50, y: 350 },
    data: {
      name: 'IT',
      description: 'Département Informatique',
      employeeCount: 12,
      color: 'from-blue-400 to-blue-600'
    },
  },
  {
    id: 'hr-dept',
    type: 'department',
    position: { x: 550, y: 350 },
    data: {
      name: 'RH',
      description: 'Ressources Humaines',
      employeeCount: 8,
      color: 'from-green-400 to-green-600'
    },
  },
  {
    id: 'dev-manager',
    type: 'manager',
    position: { x: 50, y: 500 },
    data: {
      name: 'Thomas Bernard',
      position: 'Chef de Projet Dev',
      level: 'Manager',
      department: 'Développement'
    },
  },
  {
    id: 'dev1',
    type: 'employee',
    position: { x: -100, y: 650 },
    data: {
      name: 'Julie Petit',
      position: 'Développeuse Frontend',
      email: 'julie.petit@company.com'
    },
  },
  {
    id: 'dev2',
    type: 'employee',
    position: { x: 100, y: 650 },
    data: {
      name: 'Marc Rousseau',
      position: 'Développeur Backend',
      email: 'marc.rousseau@company.com'
    },
  },
  {
    id: 'hr1',
    type: 'employee',
    position: { x: 500, y: 500 },
    data: {
      name: 'Alice Moreau',
      position: 'Responsable Recrutement',
      email: 'alice.moreau@company.com',
      phone: '+33 1 23 45 67 89'
    },
  },
  {
    id: 'hr2',
    type: 'employee',
    position: { x: 700, y: 500 },
    data: {
      name: 'David Laurent',
      position: 'Gestionnaire RH',
      email: 'david.laurent@company.com'
    },
  },
];

export const initialEdges: Edge[] = [
  {
    id: 'ceo-it',
    source: 'ceo',
    target: 'it-director',
    type: 'smoothstep',
    style: { stroke: '#6366f1', strokeWidth: 2 },
  },
  {
    id: 'ceo-hr',
    source: 'ceo',
    target: 'hr-director',
    type: 'smoothstep',
    style: { stroke: '#6366f1', strokeWidth: 2 },
  },
  {
    id: 'it-director-dept',
    source: 'it-director',
    target: 'it-dept',
    type: 'smoothstep',
    style: { stroke: '#3b82f6', strokeWidth: 2 },
  },
  {
    id: 'hr-director-dept',
    source: 'hr-director',
    target: 'hr-dept',
    type: 'smoothstep',
    style: { stroke: '#10b981', strokeWidth: 2 },
  },
  {
    id: 'it-dept-manager',
    source: 'it-dept',
    target: 'dev-manager',
    type: 'smoothstep',
    style: { stroke: '#3b82f6', strokeWidth: 2 },
  },
  {
    id: 'manager-dev1',
    source: 'dev-manager',
    target: 'dev1',
    type: 'smoothstep',
    style: { stroke: '#3b82f6', strokeWidth: 1 },
  },
  {
    id: 'manager-dev2',
    source: 'dev-manager',
    target: 'dev2',
    type: 'smoothstep',
    style: { stroke: '#3b82f6', strokeWidth: 1 },
  },
  {
    id: 'hr-dept-hr1',
    source: 'hr-dept',
    target: 'hr1',
    type: 'smoothstep',
    style: { stroke: '#10b981', strokeWidth: 1 },
  },
  {
    id: 'hr-dept-hr2',
    source: 'hr-dept',
    target: 'hr2',
    type: 'smoothstep',
    style: { stroke: '#10b981', strokeWidth: 1 },
  },
];
