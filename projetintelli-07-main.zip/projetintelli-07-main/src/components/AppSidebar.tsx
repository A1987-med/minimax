
import React from 'react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { 
  Users, 
  Building2, 
  UserCheck, 
  Network, 
  Download,
  Upload,
  Palette,
  Settings
} from "lucide-react";

const tools = [
  {
    title: "Ajouter Employé",
    icon: Users,
    action: "add-employee"
  },
  {
    title: "Ajouter Département",
    icon: Building2,
    action: "add-department"
  },
  {
    title: "Ajouter Manager",
    icon: UserCheck,
    action: "add-manager"
  },
  {
    title: "Connecter",
    icon: Network,
    action: "connect"
  }
];

const actions = [
  {
    title: "Exporter",
    icon: Download,
    action: "export"
  },
  {
    title: "Importer",
    icon: Upload,
    action: "import"
  },
  {
    title: "Thèmes",
    icon: Palette,
    action: "themes"
  },
  {
    title: "Paramètres",
    icon: Settings,
    action: "settings"
  }
];

export function AppSidebar() {
  return (
    <Sidebar className="border-r-2 border-indigo-200/50">
      <SidebarHeader className="border-b border-indigo-200/50 p-4">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
            <Network className="w-5 h-5 text-white" />
          </div>
          <div>
            <h2 className="font-bold text-lg text-gray-800">OrgChart</h2>
            <p className="text-sm text-gray-600">Créateur d'organigramme</p>
          </div>
        </div>
        <SidebarTrigger className="ml-auto" />
      </SidebarHeader>
      
      <SidebarContent className="p-2">
        <SidebarGroup>
          <SidebarGroupLabel className="text-indigo-700 font-semibold">
            Outils
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {tools.map((tool) => (
                <SidebarMenuItem key={tool.title}>
                  <SidebarMenuButton 
                    className="hover:bg-indigo-100 hover:text-indigo-700 transition-colors rounded-lg"
                    onClick={() => console.log(`Action: ${tool.action}`)}
                  >
                    <tool.icon className="w-4 h-4" />
                    <span>{tool.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup>
          <SidebarGroupLabel className="text-purple-700 font-semibold">
            Actions
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {actions.map((action) => (
                <SidebarMenuItem key={action.title}>
                  <SidebarMenuButton 
                    className="hover:bg-purple-100 hover:text-purple-700 transition-colors rounded-lg"
                    onClick={() => console.log(`Action: ${action.action}`)}
                  >
                    <action.icon className="w-4 h-4" />
                    <span>{action.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
