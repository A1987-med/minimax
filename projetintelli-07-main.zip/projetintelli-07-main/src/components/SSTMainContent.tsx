
import React from 'react';
import { HomeSection } from "@/components/sections/HomeSection";
import { GestionSection } from "@/components/sections/GestionSection";
import { ProtocolesSection } from "@/components/sections/ProtocolesSection";
import { ProjetInformationsSection } from "@/components/sections/ProjetInformationsSection";
import { RapportJournalierSection } from "@/components/sections/RapportJournalierSection";

interface SSTMainContentProps {
  currentSection: string | null;
  onSectionChange: (section: string | null) => void;
  setASTOperationLock?: (locked: boolean) => void;
}

export function SSTMainContent({ currentSection, onSectionChange, setASTOperationLock }: SSTMainContentProps) {
  console.log('🔍 SSTMainContent rendering, currentSection:', currentSection);

  const handleBackToHome = () => {
    console.log('🏠 Retour à l\'accueil demandé');
    onSectionChange(null);
  };

  console.log('🎯 Rendering section:', currentSection);

  // Si aucune section n'est sélectionnée, afficher l'écran d'accueil principal avec les cartes
  if (currentSection === null) {
    console.log('📄 Affichage HomeSection (currentSection = null)');
    return <HomeSection onSectionSelect={onSectionChange} />;
  }

  // Gestion de la page de saisie de présence
  if (currentSection === 'saisie-presence') {
    console.log('📝 Chargement de la page Saisie Présence');
    const SaisiePresence = React.lazy(() => import('../pages/SaisiePresence'));
    return (
      <React.Suspense fallback={<div>Chargement...</div>}>
        <SaisiePresence />
      </React.Suspense>
    );
  }

  switch (currentSection) {
    case 'accueil':
      console.log('🏠 Chargement HomeSection');
      return <HomeSection onSectionSelect={onSectionChange} />;
    case 'gestion':
      console.log('📊 Chargement GestionSection');
      return <GestionSection onBack={handleBackToHome} />;
    case 'projet':
    case 'informations':
    case 'projet-informations':
      console.log('🏗️ Chargement ProjetInformationsSection');
      return <ProjetInformationsSection onBack={handleBackToHome} />;
    case 'rapport-journalier':
      console.log('📋 Chargement RapportJournalierSection');
      return <RapportJournalierSection onBack={handleBackToHome} />;
    case 'protocoles':
    case 'tolerances-zero':
    case 'signalement':
    case 'prevention':
    case 'prevention-generale':
    case 'ast':
    case 'photo-inspection':
    case 'video-inspection':
    case 'urgences':
      console.log('📋 Chargement ProtocolesSection avec onglet:', currentSection);
      return <ProtocolesSection onBack={handleBackToHome} setASTOperationLock={setASTOperationLock} />;
    default:
      console.log('❓ Section inconnue, retour à HomeSection:', currentSection);
      return <HomeSection onSectionSelect={onSectionChange} />;
  }
}
