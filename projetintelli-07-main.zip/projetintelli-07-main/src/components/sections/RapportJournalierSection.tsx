
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { RapportJournalierForm } from './rapport/RapportJournalierForm';
import { RapportJournaliersList } from './rapport/RapportJournaliersList';

interface RapportJournalierSectionProps {
  onBack?: () => void;
}

type ViewMode = 'list' | 'form' | 'view';

export const RapportJournalierSection = ({ onBack }: RapportJournalierSectionProps) => {
  const [currentView, setCurrentView] = useState<ViewMode>('list');
  const [selectedReport, setSelectedReport] = useState<any>(null);

  const handleNewReport = () => {
    setCurrentView('form');
  };

  const handleViewReport = (report: any) => {
    setSelectedReport(report);
    setCurrentView('view');
  };

  const handleFormSubmit = (data: any) => {
    console.log('Rapport d\'inspection soumis:', data);
    setCurrentView('list');
  };

  const handleBackToList = () => {
    setCurrentView('list');
    setSelectedReport(null);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto p-6">
        {/* En-tête avec bouton retour */}
        {onBack && currentView === 'list' && (
          <div className="mb-6">
            <Button
              onClick={onBack}
              variant="outline"
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Retour à l'accueil
            </Button>
          </div>
        )}

        {/* Contenu principal */}
        {currentView === 'list' && (
          <RapportJournaliersList
            onNewReport={handleNewReport}
            onViewReport={handleViewReport}
          />
        )}

        {currentView === 'form' && (
          <RapportJournalierForm
            onSubmit={handleFormSubmit}
            onBack={handleBackToList}
          />
        )}

        {currentView === 'view' && selectedReport && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Détails du rapport d'inspection</h2>
              <Button onClick={handleBackToList} variant="outline">
                Retour à la liste
              </Button>
            </div>
            {/* Ici on pourrait ajouter un composant de visualisation détaillée */}
            <div className="bg-white p-6 rounded-lg shadow">
              <pre className="whitespace-pre-wrap">
                {JSON.stringify(selectedReport, null, 2)}
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
