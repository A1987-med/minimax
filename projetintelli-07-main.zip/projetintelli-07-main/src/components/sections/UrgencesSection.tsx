import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowDown, AlertTriangle } from "lucide-react";
import { useNativeFeatures } from "@/hooks/useNativeFeatures";
import { toast } from "sonner";
import { FirstRespondersList } from "./urgences/FirstRespondersList";
import { EmergencyNumbers } from "./urgences/EmergencyNumbers";
import { SavedFacilities } from "./urgences/SavedFacilities";
import { FacilityLocator } from "./urgences/FacilityLocator";
import { EvacuationPlan } from "./urgences/EvacuationPlan";
import { EmergencyProcedures } from "./urgences/EmergencyProcedures";
import { getDefaultFacilities, processFacilities, calculateDistance, enrichFacilitiesWithExternalData } from "./urgences/urgencesUtils";
import { entryService } from "@/services/supabaseService";
import { EntryData } from "@/types/accueil";

interface Position {
  latitude: number;
  longitude: number;
}

interface MedicalFacility {
  name: string;
  address: string;
  phone?: string;
  distance?: number;
  type: 'hospital' | 'clinic';
}

interface SavedFacilitiesData {
  hospitals: MedicalFacility[];
  clinics: MedicalFacility[];
  position: Position;
  timestamp: string;
}

interface UrgencesSectionProps {
  onBack: () => void;
}

export const UrgencesSection = ({ onBack }: UrgencesSectionProps) => {
  const { makePhoneCall, getCurrentPosition } = useNativeFeatures();
  const [userPosition, setUserPosition] = useState<Position | null>(null);
  const [isLoadingPosition, setIsLoadingPosition] = useState(false);
  const [isLoadingFacilities, setIsLoadingFacilities] = useState(false);
  const [nearestHospitals, setNearestHospitals] = useState<MedicalFacility[]>([]);
  const [nearestClinics, setNearestClinics] = useState<MedicalFacility[]>([]);
  const [cossStatus, setCossStatus] = useState<string>("Disponible");
  const [savedData, setSavedData] = useState<SavedFacilitiesData | null>(null);
  const [entries, setEntries] = useState<EntryData[]>([]);
  const [isLoadingEntries, setIsLoadingEntries] = useState(true);

  // Charger les données d'accueil au montage du composant
  useEffect(() => {
    const loadEntries = async () => {
      try {
        console.log('🔄 URGENCES - Chargement des données d\'accueil...');
        const entriesData = await entryService.getAll();
        setEntries(entriesData);
        console.log('✅ URGENCES - Données d\'accueil chargées:', entriesData.length, 'entrées');
      } catch (error) {
        console.error('❌ URGENCES - Erreur chargement données d\'accueil:', error);
        toast.error('Erreur lors du chargement des données d\'accueil');
      } finally {
        setIsLoadingEntries(false);
      }
    };

    loadEntries();
  }, []);

  // Charger les données depuis le localStorage au montage du composant
  useEffect(() => {
    const savedHospitals = localStorage.getItem('urgences_hospitals');
    const savedClinics = localStorage.getItem('urgences_clinics');
    const savedPosition = localStorage.getItem('urgences_position');
    const savedTimestamp = localStorage.getItem('urgences_timestamp');
    const savedCossStatus = localStorage.getItem('urgences_coss_status');

    // Charger les données sauvegardées si elles existent
    if (savedHospitals && savedClinics && savedPosition && savedTimestamp) {
      try {
        const hospitals = JSON.parse(savedHospitals);
        const clinics = JSON.parse(savedClinics);
        const position = JSON.parse(savedPosition);
        
        setSavedData({
          hospitals,
          clinics,
          position,
          timestamp: savedTimestamp
        });
        
        // Charger aussi dans les états actuels
        setNearestHospitals(hospitals);
        setNearestClinics(clinics);
        setUserPosition(position);
      } catch (error) {
        console.error('Erreur lors du chargement des données sauvegardées:', error);
      }
    }

    if (savedCossStatus) {
      setCossStatus(savedCossStatus);
    }
  }, []);

  // Sauvegarder les données avec timestamp
  const saveDataWithTimestamp = (hospitals: MedicalFacility[], clinics: MedicalFacility[], position: Position) => {
    const timestamp = new Date().toISOString();
    
    localStorage.setItem('urgences_hospitals', JSON.stringify(hospitals));
    localStorage.setItem('urgences_clinics', JSON.stringify(clinics));
    localStorage.setItem('urgences_position', JSON.stringify(position));
    localStorage.setItem('urgences_timestamp', timestamp);
    
    setSavedData({
      hospitals,
      clinics,
      position,
      timestamp
    });
  };

  // Supprimer toutes les données sauvegardées
  const clearSavedData = () => {
    localStorage.removeItem('urgences_hospitals');
    localStorage.removeItem('urgences_clinics');
    localStorage.removeItem('urgences_position');
    localStorage.removeItem('urgences_timestamp');
    
    setSavedData(null);
    toast.success('Liste des établissements sauvegardés supprimée');
  };

  // Sauvegarder le statut CoSS dans le localStorage
  useEffect(() => {
    localStorage.setItem('urgences_coss_status', cossStatus);
  }, [cossStatus]);

  const handleCall = (number: string) => {
    makePhoneCall(number);
  };

  const handleUpdateEntry = async (id: string, updatedData: Partial<EntryData>) => {
    try {
      console.log('🔄 URGENCES - Mise à jour de l\'entrée:', id, updatedData);
      await entryService.update(id, updatedData);
      
      // Mettre à jour l'état local
      setEntries(prevEntries => 
        prevEntries.map(entry => 
          entry.id === id ? { ...entry, ...updatedData } : entry
        )
      );
      
      toast.success('Informations mises à jour');
      console.log('✅ URGENCES - Entrée mise à jour avec succès');
    } catch (error) {
      console.error('❌ URGENCES - Erreur mise à jour entrée:', error);
      toast.error('Erreur lors de la mise à jour');
    }
  };

  const openInGoogleMaps = (address: string, name: string) => {
    const query = encodeURIComponent(`${name}, ${address}`);
    const url = `https://www.google.com/maps/search/?api=1&query=${query}`;
    window.open(url, '_blank');
  };

  const findNearestFacilities = async (position: Position): Promise<{ hospitals: MedicalFacility[], clinics: MedicalFacility[] }> => {
    try {
      const radius = 15000; // 15km de rayon pour avoir plus de résultats
      
      // Recherche des hôpitaux
      const hospitalQuery = `
        [out:json][timeout:25];
        (
          node["amenity"="hospital"](around:${radius},${position.latitude},${position.longitude});
          way["amenity"="hospital"](around:${radius},${position.latitude},${position.longitude});
          relation["amenity"="hospital"](around:${radius},${position.latitude},${position.longitude});
        );
        out center;
      `;

      // Recherche des cliniques
      const clinicQuery = `
        [out:json][timeout:25];
        (
          node["amenity"="clinic"](around:${radius},${position.latitude},${position.longitude});
          way["amenity"="clinic"](around:${radius},${position.latitude},${position.longitude});
          relation["amenity"="clinic"](around:${radius},${position.latitude},${position.longitude});
          node["healthcare"="clinic"](around:${radius},${position.latitude},${position.longitude});
          way["healthcare"="clinic"](around:${radius},${position.latitude},${position.longitude});
        );
        out center;
      `;

      const [hospitalResponse, clinicResponse] = await Promise.all([
        fetch('https://overpass-api.de/api/interpreter', {
          method: 'POST',
          body: hospitalQuery,
          headers: { 'Content-Type': 'text/plain' }
        }),
        fetch('https://overpass-api.de/api/interpreter', {
          method: 'POST',
          body: clinicQuery,
          headers: { 'Content-Type': 'text/plain' }
        })
      ]);

      const [hospitalData, clinicData] = await Promise.all([
        hospitalResponse.json(),
        clinicResponse.json()
      ]);

      // Traitement des hôpitaux
      let hospitals = processFacilities(hospitalData.elements, position, 'hospital');
      
      // Traitement des cliniques
      let clinics = processFacilities(clinicData.elements, position, 'clinic');

      // Compléter avec les établissements par défaut si nécessaire
      const defaultHospitals = getDefaultFacilities('hospital');
      const defaultClinics = getDefaultFacilities('clinic');

      // Ajouter les hôpitaux par défaut s'il n'y en a pas assez
      while (hospitals.length < 3) {
        const defaultHospital = defaultHospitals[hospitals.length];
        if (defaultHospital) {
          hospitals.push({
            ...defaultHospital,
            distance: calculateDistance(
              position.latitude,
              position.longitude,
              45.5017, // Coordonnées approximatives de Montréal
              -73.5673
            )
          });
        } else {
          break;
        }
      }

      // Ajouter les cliniques par défaut s'il n'y en a pas assez
      while (clinics.length < 3) {
        const defaultClinic = defaultClinics[clinics.length];
        if (defaultClinic) {
          clinics.push({
            ...defaultClinic,
            distance: calculateDistance(
              position.latitude,
              position.longitude,
              45.5017, // Coordonnées approximatives de Montréal
              -73.5673
            )
          });
        } else {
          break;
        }
      }

      // Limiter à 3 de chaque
      hospitals = hospitals.slice(0, 3);
      clinics = clinics.slice(0, 3);

      // Enrichir les données avec des informations supplémentaires (notamment téléphones)
      const enrichedHospitals = await enrichFacilitiesWithExternalData(hospitals);
      const enrichedClinics = await enrichFacilitiesWithExternalData(clinics);

      console.log('Établissements enrichis:', { hospitals: enrichedHospitals, clinics: enrichedClinics });

      return { hospitals: enrichedHospitals, clinics: enrichedClinics };

    } catch (error) {
      console.error('Erreur lors de la recherche d\'établissements:', error);
      
      // Retourner des établissements par défaut en cas d'erreur
      return {
        hospitals: getDefaultFacilities('hospital'),
        clinics: getDefaultFacilities('clinic')
      };
    }
  };

  const handleGetLocation = async () => {
    setIsLoadingPosition(true);
    setIsLoadingFacilities(true);
    try {
      const position = await getCurrentPosition();
      if (position) {
        console.log('Position actuelle:', position);
        setUserPosition(position);
        
        // Rechercher les établissements les plus proches
        const { hospitals, clinics } = await findNearestFacilities(position);
        setNearestHospitals(hospitals);
        setNearestClinics(clinics);
        
        // Sauvegarder avec timestamp
        saveDataWithTimestamp(hospitals, clinics, position);
        
        toast.success('Établissements médicaux mis à jour et sauvegardés');
      }
    } catch (error) {
      console.error('Erreur lors de l\'obtention de la position:', error);
      toast.error('Erreur lors de la géolocalisation');
    } finally {
      setIsLoadingPosition(false);
      setIsLoadingFacilities(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-red-600">Urgences</h1>
      </div>

      {/* Alerte urgence */}
      <Alert className="border-red-200 bg-red-50">
        <AlertTriangle className="h-4 w-4 text-red-600" />
        <AlertDescription className="text-red-800 font-medium">
          En cas d'urgence vitale, composez immédiatement le 911
        </AlertDescription>
      </Alert>

      {/* Liste des secouristes disponibles */}
      {!isLoadingEntries && (
        <FirstRespondersList 
          entries={entries}
          onCall={handleCall}
          onUpdate={handleUpdateEntry}
        />
      )}

      {/* Numéros d'urgence */}
      <EmergencyNumbers 
        onCall={handleCall}
        cossStatus={cossStatus}
        onCossStatusChange={setCossStatus}
      />

      {/* Section des établissements sauvegardés */}
      <SavedFacilities 
        savedData={savedData}
        onClearSavedData={clearSavedData}
        onCall={handleCall}
        onOpenMaps={openInGoogleMaps}
      />

      {/* Établissements médicaux les plus proches */}
      <FacilityLocator 
        userPosition={userPosition}
        isLoadingPosition={isLoadingPosition}
        isLoadingFacilities={isLoadingFacilities}
        nearestHospitals={nearestHospitals}
        nearestClinics={nearestClinics}
        savedData={savedData}
        onGetLocation={handleGetLocation}
        onCall={handleCall}
        onOpenMaps={openInGoogleMaps}
      />

      {/* Plan d'évacuation avec carte interactive */}
      <EvacuationPlan 
        userPosition={userPosition}
        isLoadingPosition={isLoadingPosition}
        onGetLocation={handleGetLocation}
      />

      {/* Premiers secours */}
      <EmergencyProcedures />
    </div>
  );
};
