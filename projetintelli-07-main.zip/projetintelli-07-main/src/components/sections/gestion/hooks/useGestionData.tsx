
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { soustraitantService, entryService } from "@/services/accueilService";
import type { EntryData } from "@/types/accueil";
import { toast } from "sonner";

export const useGestionData = () => {
  const queryClient = useQueryClient();

  // Récupération des sous-traitants
  const { data: soustraitants = [], isLoading: isLoadingSoustraitants, refetch: refetchSoustraitants } = useQuery({
    queryKey: ['soustraitants'],
    queryFn: () => soustraitantService.getAll(),
  });

  // Récupération des entrées
  const { data: entries = [], isLoading: isLoadingEntries } = useQuery({
    queryKey: ['entries'],
    queryFn: () => entryService.getAll(),
  });

  console.log('🏗️ GESTION SECTION - Soustraitants chargés:', soustraitants.length);
  console.log('🏗️ GESTION SECTION - Entrées chargées:', entries.length);

  const handleSubmitEntry = async (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => {
    try {
      const now = new Date();
      const entryData = {
        ...data,
        dateEntree: now.toLocaleDateString('fr-CA'),
        heureEntree: now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })
      };

      await entryService.create(entryData);
      queryClient.invalidateQueries({ queryKey: ['entries'] });
      toast.success('Employé enregistré avec succès!');
    } catch (error) {
      console.error('Erreur lors de l\'enregistrement:', error);
      toast.error('Erreur lors de l\'enregistrement');
    }
  };

  const handleUpdateEntry = async (id: string, updates: Partial<EntryData>): Promise<void> => {
    try {
      console.log('🔄 GESTION DATA - Début mise à jour entrée:', id);
      console.log('🔄 GESTION DATA - Updates:', updates);
      
      await entryService.update(id, updates);
      
      console.log('🔄 GESTION DATA - Mise à jour terminée');
      
      // Invalider les queries pour forcer le rechargement
      await queryClient.invalidateQueries({ queryKey: ['entries'] });
      
      console.log('✅ GESTION DATA - Cache invalidé, mise à jour réussie');
      toast.success('Employé modifié avec succès!');
    } catch (error) {
      console.error('❌ GESTION DATA - Erreur lors de la modification:', error);
      toast.error('Erreur lors de la modification');
      throw error;
    }
  };

  const handleDeleteEntry = async (id: string) => {
    try {
      await entryService.delete(id);
      queryClient.invalidateQueries({ queryKey: ['entries'] });
      toast.success('Employé supprimé avec succès!');
    } catch (error) {
      console.error('Erreur lors de la suppression:', error);
      toast.error('Erreur lors de la suppression');
    }
  };

  const handleSoustraitantsChange = () => {
    console.log('🔄 GESTION SECTION - Invalidation des sous-traitants');
    queryClient.invalidateQueries({ queryKey: ['soustraitants'] });
    refetchSoustraitants();
  };

  return {
    soustraitants,
    entries,
    isLoadingSoustraitants,
    isLoadingEntries,
    handleSubmitEntry,
    handleUpdateEntry,
    handleDeleteEntry,
    handleSoustraitantsChange
  };
};
