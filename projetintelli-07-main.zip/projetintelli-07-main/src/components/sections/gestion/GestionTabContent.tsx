import React from 'react';
import { TabsContent } from "@/components/ui/tabs";
import { UserPlus, Users, Building2, QrCodeIcon } from "lucide-react";
import { WorkerFormWrapperWithManager } from "../accueil/WorkerFormWrapperWithManager";
import { EntriesTable } from "../accueil/EntriesTable";
import { SoustraitantManager } from "../accueil/SoustraitantManager";
import { QRCodeManager } from "../rapport/QRCodeManager";
import type { Soustraitant, EntryData } from "@/types/accueil";

interface GestionTabContentProps {
  activeTab: string;
  soustraitants: Soustraitant[];
  entries: EntryData[];
  onSubmitEntry: (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => Promise<void>;
  onUpdateEntry: (id: string, updates: Partial<EntryData>) => Promise<void>;
  onDeleteEntry: (id: string) => Promise<void>;
  onSoustraitantsChange: () => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const GestionTabContent = ({
  activeTab,
  soustraitants,
  entries,
  onSubmitEntry,
  onUpdateEntry,
  onDeleteEntry,
  onSoustraitantsChange,
  onASTNavigation
}: GestionTabContentProps) => {
  console.log('📋 GESTION TAB CONTENT - Debug:', { 
    activeTab, 
    entriesCount: entries.length,
    soustraitantsCount: soustraitants.length 
  });

  return (
    <>
      <TabsContent value="accueil-employes" className="mt-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-blue-500 rounded-lg flex items-center justify-center">
              <UserPlus className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Accueil des Nouveaux Employés</h3>
              <p className="text-sm text-gray-600">Enregistrement et formation des nouveaux arrivants</p>
            </div>
          </div>
          <WorkerFormWrapperWithManager 
            soustraitants={soustraitants}
            onSubmit={onSubmitEntry}
            onASTNavigation={onASTNavigation}
          />
        </div>
      </TabsContent>

      <TabsContent value="gestion-employes" className="mt-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-green-500 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Gestion des Employés</h3>
              <p className="text-sm text-gray-600">Liste, modification et suivi des employés enregistrés</p>
            </div>
          </div>
          <div className="p-1">
            <EntriesTable 
              entries={entries}
              onUpdateEntry={onUpdateEntry}
              onDeleteEntry={onDeleteEntry}
            />
          </div>
        </div>
      </TabsContent>

      <TabsContent value="sous-traitants" className="mt-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-purple-500 rounded-lg flex items-center justify-center">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Gestion des Sous-traitants</h3>
              <p className="text-sm text-gray-600">Administration des entreprises sous-traitantes</p>
            </div>
          </div>
          <SoustraitantManager 
            soustraitants={soustraitants}
            onSoustraitantsChange={onSoustraitantsChange}
            entries={entries}
          />
        </div>
      </TabsContent>

      <TabsContent value="codes-qr" className="mt-6">
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
              <QrCodeIcon className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">Codes QR pour Contremaîtres</h3>
              <p className="text-sm text-gray-600">Génération de codes QR pour la saisie rapide des présences</p>
            </div>
          </div>
          <QRCodeManager />
        </div>
      </TabsContent>
    </>
  );
};
