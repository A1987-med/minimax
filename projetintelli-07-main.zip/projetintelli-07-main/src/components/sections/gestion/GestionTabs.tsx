
import React from 'react';
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserPlus, Users, Building2, QrCodeIcon } from "lucide-react";

interface GestionTabsProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  children: React.ReactNode;
}

export const GestionTabs = ({ activeTab, setActiveTab, children }: GestionTabsProps) => {
  console.log('🎯 GESTION TABS - Debug:', { activeTab });

  return (
    <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
      <TabsList className="grid w-full grid-cols-4 bg-gray-100">
        <TabsTrigger 
          value="accueil-employes" 
          className="flex items-center gap-2 data-[state=active]:bg-blue-500 data-[state=active]:text-white"
        >
          <UserPlus className="w-4 h-4" />
          Accueil Employés
        </TabsTrigger>
        <TabsTrigger 
          value="gestion-employes" 
          className="flex items-center gap-2 data-[state=active]:bg-green-500 data-[state=active]:text-white"
        >
          <Users className="w-4 h-4" />
          Gestion Employés
        </TabsTrigger>
        <TabsTrigger 
          value="sous-traitants" 
          className="flex items-center gap-2 data-[state=active]:bg-purple-500 data-[state=active]:text-white"
        >
          <Building2 className="w-4 h-4" />
          Sous-traitants
        </TabsTrigger>
        <TabsTrigger 
          value="codes-qr" 
          className="flex items-center gap-2 data-[state=active]:bg-orange-500 data-[state=active]:text-white"
        >
          <QrCodeIcon className="w-4 h-4" />
          Codes QR
        </TabsTrigger>
      </TabsList>
      {children}
    </Tabs>
  );
};
