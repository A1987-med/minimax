
import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2 } from "lucide-react";

interface GestionHeaderProps {
  onBack: () => void;
}

export const GestionHeader = ({ onBack }: GestionHeaderProps) => {
  return (
    <div className="flex items-center gap-4 mb-6">
      <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
        ← Retour
      </Button>
      <h1 className="text-3xl font-bold text-gray-800">Gestion Administrative</h1>
      <Badge variant="outline" className="text-blue-600 border-blue-200">
        📋 Administration
      </Badge>
    </div>
  );
};
