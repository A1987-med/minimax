
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Search } from "lucide-react";

export const GlossaireTab = () => {
  const glossaire = [
    { terme: 'EPI', definition: 'Équipement de Protection Individuelle - Dispositif destiné à être porté par une personne pour la protéger des risques' },
    { terme: 'Harnais', definition: 'Équipement de protection contre les chutes, composé de sangles et de boucles' },
    { terme: 'Point d\'ancrage', definition: 'Point de fixation capable de supporter les efforts engendrés par l\'arrêt d\'une chute' },
    { terme: 'Signalisation temporaire', definition: 'Ensemble des dispositifs destinés à informer les usagers d\'une modification temporaire' },
    { terme: 'Zone de danger', definition: 'Espace où un travailleur peut être exposé à un risque pour sa sécurité ou sa santé' }
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">Glossaire des termes de sécurité</h2>
      
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-2 mb-4">
            <Search className="w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un terme..."
              className="flex-1 p-2 border border-gray-200 rounded-lg"
            />
          </div>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {glossaire.map((item, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <h3 className="font-semibold text-purple-600 mb-2">{item.terme}</h3>
              <p className="text-gray-700">{item.definition}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
