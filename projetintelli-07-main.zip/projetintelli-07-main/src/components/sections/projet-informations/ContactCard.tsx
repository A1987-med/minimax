
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { User, Phone, Mail } from "lucide-react";

interface ContactCardProps {
  name: string;
  title: string;
  phone: string;
  email: string;
  isSelected: boolean;
  onToggle: () => void;
  onCall: (phone: string) => void;
  onEmail: (email: string) => void;
  colorScheme: 'purple' | 'emerald';
}

export const ContactCard = ({ 
  name, 
  title, 
  phone, 
  email, 
  isSelected, 
  onToggle, 
  onCall, 
  onEmail, 
  colorScheme 
}: ContactCardProps) => {
  const colors = {
    purple: {
      bg: 'from-purple-500/5 to-violet-500/5',
      bgHover: 'group-hover:from-purple-500/10 group-hover:to-violet-500/10',
      iconBg: 'from-purple-500 to-violet-600',
      textTitle: 'text-purple-700',
      textSubtitle: 'text-purple-600',
      border: 'border-purple-200'
    },
    emerald: {
      bg: 'from-emerald-500/5 to-green-500/5',
      bgHover: 'group-hover:from-emerald-500/10 group-hover:to-green-500/10',
      iconBg: 'from-emerald-500 to-green-600',
      textTitle: 'text-emerald-700',
      textSubtitle: 'text-emerald-600',
      border: 'border-emerald-200'
    }
  };

  const color = colors[colorScheme];

  return (
    <Card 
      className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group cursor-pointer h-80" 
      onClick={onToggle}
    >
      <CardContent className="p-12 text-center relative overflow-hidden h-full flex flex-col justify-center">
        <div className={`absolute inset-0 bg-gradient-to-br ${color.bg} ${color.bgHover} transition-all duration-300`}></div>
        <div className="relative z-10">
          <div className={`w-20 h-20 bg-gradient-to-br ${color.iconBg} rounded-xl flex items-center justify-center mx-auto mb-6 shadow-lg`}>
            <User className="w-10 h-10 text-white" />
          </div>
          <div className={`text-2xl font-bold ${color.textTitle} mb-4`}>{name}</div>
          <div className={`text-lg ${color.textSubtitle} font-medium mb-6`}>{title}</div>
          
          {isSelected && (
            <div className={`mt-6 space-y-4 border-t ${color.border} pt-6`}>
              <Button
                variant="outline"
                size="lg"
                onClick={(e) => {
                  e.stopPropagation();
                  onCall(phone);
                }}
                className="w-full bg-green-50 hover:bg-green-100 text-green-700 border-green-200 flex items-center gap-3 py-4 text-lg"
              >
                <Phone className="w-6 h-6" />
                {phone}
              </Button>
              
              <Button
                variant="outline"
                size="lg"
                onClick={(e) => {
                  e.stopPropagation();
                  onEmail(email);
                }}
                className="w-full bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200 flex items-center gap-3 py-4 text-lg"
              >
                <Mail className="w-6 h-6" />
                {email}
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
