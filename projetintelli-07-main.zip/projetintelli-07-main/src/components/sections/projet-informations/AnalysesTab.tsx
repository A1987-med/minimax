
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

export const AnalysesTab = () => {
  const documents = [
    'Analyse risques - Travaux en hauteur',
    'Analyse risques - Manipulation d\'engins',
    'Analyse risques - Soudage et découpe',
    'Analyse risques - Installation électrique',
    'Plan de prévention général',
    'Évaluation environnementale'
  ];

  return (
    <div className="space-y-4">
      <h2 className="text-xl font-semibold text-gray-800">Documents d'analyse des risques</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documents.map((doc, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <span className="text-red-600 font-bold text-sm">PDF</span>
                </div>
                <div className="flex-1">
                  <h3 className="font-medium">{doc}</h3>
                  <p className="text-sm text-gray-500">Dernière mise à jour : {new Date().toLocaleDateString()}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};
