
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Building2, Hash, MapPin, Save, Clock, CheckCircle, Calendar } from "lucide-react";

interface ProjectConfigurationTabProps {
  nomProjet: string;
  numeroProjet: string;
  adresseProjet: string;
  hasChanges: boolean;
  onNomProjetChange: (value: string) => void;
  onNumeroProjetChange: (value: string) => void;
  onAdresseProjetChange: (value: string) => void;
  onSave: () => void;
}

export const ProjectConfigurationTab = ({
  nomProjet,
  numeroProjet,
  adresseProjet,
  hasChanges,
  onNomProjetChange,
  onNumeroProjetChange,
  onAdresseProjetChange,
  onSave
}: ProjectConfigurationTabProps) => {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Configuration du projet */}
      <div className="lg:col-span-2">
        <Card className="border-2 border-blue-200 bg-gradient-to-br from-blue-50 to-blue-100">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-3 text-blue-700">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg flex items-center justify-center">
                <Building2 className="w-5 h-5 text-white" />
              </div>
              Informations du Projet
            </CardTitle>
            <CardDescription>
              Configurez les détails principaux de votre projet de construction
            </CardDescription>
          </CardHeader>
          <CardContent className="bg-white rounded-lg p-6 shadow-sm border border-white/50">
            <div className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="nomProjet" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Building2 className="w-4 h-4 text-blue-600" />
                    Nom du projet
                  </Label>
                  <Input
                    id="nomProjet"
                    value={nomProjet}
                    onChange={(e) => onNomProjetChange(e.target.value)}
                    placeholder="Entrer le nom du projet"
                    className="text-sm"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="numeroProjet" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <Hash className="w-4 h-4 text-green-600" />
                    Numéro du projet
                  </Label>
                  <Input
                    id="numeroProjet"
                    value={numeroProjet}
                    onChange={(e) => onNumeroProjetChange(e.target.value)}
                    placeholder="Entrer le numéro du projet"
                    className="text-sm"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="adresseProjet" className="text-sm font-medium text-gray-700 flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-red-600" />
                    Adresse du projet
                  </Label>
                  <Input
                    id="adresseProjet"
                    value={adresseProjet}
                    onChange={(e) => onAdresseProjetChange(e.target.value)}
                    placeholder="Entrer l'adresse complète du projet"
                    className="text-sm"
                  />
                </div>
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-600">
                  {hasChanges ? (
                    <span className="text-orange-600 flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Modifications non sauvegardées
                    </span>
                  ) : (
                    <span className="text-green-600 flex items-center gap-1">
                      <CheckCircle className="w-4 h-4" />
                      Toutes les modifications sont sauvegardées
                    </span>
                  )}
                </div>
                
                <Button
                  onClick={onSave}
                  disabled={!hasChanges}
                  className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Sauvegarder
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Aperçu du projet */}
      <div className="lg:col-span-1">
        <Card className="border-2 border-green-200 bg-gradient-to-br from-green-50 to-green-100">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2 text-green-700">
              <CheckCircle className="w-5 h-5" />
              Aperçu du Projet
            </CardTitle>
          </CardHeader>
          <CardContent className="bg-white rounded-lg p-4 shadow-sm border border-white/50">
            <div className="space-y-4">
              <div>
                <div className="text-xs text-gray-500 uppercase tracking-wide">Nom</div>
                <div className="text-sm font-medium text-gray-800">
                  {nomProjet || "Non défini"}
                </div>
              </div>
              
              <div>
                <div className="text-xs text-gray-500 uppercase tracking-wide">Numéro</div>
                <div className="text-sm font-medium text-gray-800">
                  {numeroProjet || "Non défini"}
                </div>
              </div>
              
              <div>
                <div className="text-xs text-gray-500 uppercase tracking-wide">Adresse</div>
                <div className="text-sm font-medium text-gray-800">
                  {adresseProjet || "Non définie"}
                </div>
              </div>

              <Separator />

              <div className="text-center p-3 bg-green-50 rounded-lg">
                <Calendar className="w-6 h-6 mx-auto text-green-600 mb-1" />
                <div className="text-xs text-green-700">
                  Projet configuré le
                </div>
                <div className="text-sm font-medium text-green-800">
                  {new Date().toLocaleDateString('fr-FR')}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
