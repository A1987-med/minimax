
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Plus, Calendar, Trash2, Clock, Navigation, ExternalLink } from "lucide-react";

interface Inspection {
  id: string;
  date: string;
  type: string;
  zone: string;
  statut: 'Programmée' | 'Réalisé';
}

interface CalendarTabProps {
  inspections: Inspection[];
  newInspection: {
    date: string;
    type: string;
    zone: string;
    statut: 'Programmée' | 'Réalisé';
  };
  isCapturingLocation: boolean;
  onNewInspectionChange: (field: string, value: string) => void;
  onAddInspection: () => void;
  onDeleteInspection: (id: string) => void;
  onCaptureGPS: () => void;
  onSyncCalendar: () => void;
}

export const CalendarTab = ({
  inspections,
  newInspection,
  isCapturingLocation,
  onNewInspectionChange,
  onAddInspection,
  onDeleteInspection,
  onCaptureGPS,
  onSyncCalendar
}: CalendarTabProps) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-gray-800">Calendrier des inspections et vérifications</h2>
        <Button onClick={onSyncCalendar} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
          <ExternalLink className="w-4 h-4" />
          Ouvrir dans mon calendrier
        </Button>
      </div>

      {/* Formulaire d'ajout d'inspection */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="text-green-800 flex items-center gap-2">
            <Plus className="w-5 h-5" />
            Ajouter une inspection
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="newDate">Date</Label>
              <Input
                id="newDate"
                type="date"
                value={newInspection.date}
                onChange={(e) => onNewInspectionChange('date', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="newType">Type d'inspection</Label>
              <Input
                id="newType"
                placeholder="Ex: Échafaudages, Engins de chantier..."
                value={newInspection.type}
                onChange={(e) => onNewInspectionChange('type', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="newZone">Zone</Label>
              <div className="flex gap-2">
                <Input
                  id="newZone"
                  placeholder="Ex: Bâtiment A"
                  value={newInspection.zone}
                  onChange={(e) => onNewInspectionChange('zone', e.target.value)}
                  className="flex-1"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={onCaptureGPS}
                  disabled={isCapturingLocation}
                  className="shrink-0"
                >
                  {isCapturingLocation ? (
                    <Clock className="w-4 h-4 animate-spin" />
                  ) : (
                    <Navigation className="w-4 h-4" />
                  )}
                </Button>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Cliquez sur l'icône GPS pour ajouter votre position
              </p>
            </div>
            <div className="flex items-end">
              <Button onClick={onAddInspection} className="w-full bg-green-600 hover:bg-green-700">
                <Plus className="w-4 h-4 mr-2" />
                Ajouter
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Liste des inspections */}
      <div className="space-y-3">
        {inspections.map((inspection) => (
          <Card key={inspection.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3">
                    <Calendar className="w-5 h-5 text-blue-600" />
                    <div>
                      <h3 className="font-semibold">{inspection.type}</h3>
                      <p className="text-sm text-gray-600">{inspection.zone}</p>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <p className="font-medium">{inspection.date}</p>
                    <Badge 
                      variant={inspection.statut === 'Réalisé' ? 'default' : 'secondary'}
                      className={inspection.statut === 'Réalisé' ? 'bg-green-500' : 'bg-blue-500'}
                    >
                      {inspection.statut}
                    </Badge>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => onDeleteInspection(inspection.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <h3 className="font-semibold text-blue-800 mb-2">📅 Synchronisation automatique</h3>
          <p className="text-sm text-blue-700 mb-3">
            Le bouton "Ouvrir dans mon calendrier" lance automatiquement votre application de calendrier avec les inspections programmées pré-remplis.
          </p>
          <div className="space-y-2">
            <p className="text-xs text-blue-600">
              📱 <strong>Sur mobile :</strong> Ouvre l'application Calendrier native
            </p>
            <p className="text-xs text-blue-600">
              💻 <strong>Sur desktop :</strong> Ouvre Google Calendar dans un nouvel onglet
            </p>
            <p className="text-xs text-blue-600">
              🔄 <strong>Automatique :</strong> Pas besoin de télécharger ou importer manuellement
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
