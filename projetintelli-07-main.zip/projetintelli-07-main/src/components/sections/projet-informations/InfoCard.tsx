
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface InfoCardProps {
  title: string;
  subtitle: string;
  icon: LucideIcon;
  colorScheme: 'blue' | 'orange';
  children?: React.ReactNode;
}

export const InfoCard = ({ title, subtitle, icon: Icon, colorScheme, children }: InfoCardProps) => {
  const colors = {
    blue: {
      bg: 'from-blue-500/5 to-indigo-500/5',
      bgHover: 'group-hover:from-blue-500/10 group-hover:to-indigo-500/10',
      iconBg: 'from-blue-500 to-indigo-600',
      textTitle: 'text-blue-700',
      textSubtitle: 'text-blue-600'
    },
    orange: {
      bg: 'from-orange-500/5 to-red-500/5',
      bgHover: 'group-hover:from-orange-500/10 group-hover:to-red-500/10',
      iconBg: 'from-orange-500 to-red-600',
      textTitle: 'text-orange-700',
      textSubtitle: 'text-orange-600'
    }
  };

  const color = colors[colorScheme];

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 group cursor-pointer h-80">
      <CardContent className="p-12 text-center relative overflow-hidden h-full flex flex-col justify-center">
        <div className={`absolute inset-0 bg-gradient-to-br ${color.bg} ${color.bgHover} transition-all duration-300`}></div>
        <div className="relative z-10">
          <div className={`w-20 h-20 bg-gradient-to-br ${color.iconBg} rounded-xl flex items-center justify-center mx-auto mb-6 shadow-lg`}>
            <Icon className="w-10 h-10 text-white" />
          </div>
          <div className={`text-2xl font-bold ${color.textTitle} mb-4`}>{title}</div>
          <div className={`text-lg ${color.textSubtitle} font-medium mb-6`}>{subtitle}</div>
          {children && (
            <div className="mt-4 text-base text-gray-600 space-y-2">
              {children}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
