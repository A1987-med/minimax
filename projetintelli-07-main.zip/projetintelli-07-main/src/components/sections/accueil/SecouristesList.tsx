
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Building2 } from "lucide-react";
import { EntryData } from './types';

interface SecouristesListProps {
  entries: EntryData[];
}

// Fonction pour nettoyer le corps de métier
const cleanCorpsMetier = (corpsMetier: string): string => {
  // Liste des valeurs incorrectes à filtrer
  const invalidValues = [
    'Formule: Valide',
    'Formule: Échue',
    'Valide',
    'Échue'
  ];
  
  if (!corpsMetier || invalidValues.includes(corpsMetier)) {
    return 'Non spécifié';
  }
  
  return corpsMetier;
};

export const SecouristesList = ({ entries }: SecouristesListProps) => {
  console.log('SecouristesList rendering - Total entries:', entries.length);
  
  // Filtrer les secouristes (tous ceux qui ont coché estSecouriste)
  const secouristes = entries.filter(entry => entry.estSecouriste);
  
  console.log('Filtered secouristes:', secouristes.length);
  
  // Grouper par sous-traitant
  const secouristesParSoustraitant = secouristes.reduce((acc, entry) => {
    const soustraitant = entry.soustraitant;
    if (!acc[soustraitant]) {
      acc[soustraitant] = [];
    }
    acc[soustraitant].push(entry);
    return acc;
  }, {} as Record<string, EntryData[]>);

  // Trier les entreprises par ordre alphabétique
  const sortedEntreprises = Object.entries(secouristesParSoustraitant).sort(([a], [b]) => a.localeCompare(b));

  // Fonction pour vérifier si le secouriste a une formation/carte valide
  const hasValidFirstAidTraining = (worker: EntryData): boolean => {
    // Vérifier la carte de secouriste spécifique
    if (worker.carteSecouriste) {
      return true;
    }
    
    // Vérifier si une date d'échéancier est présente (indique une qualification)
    if (worker.dateEcheancierSecouriste) {
      return true;
    }
    
    // Vérifier si une formation de secourisme est sélectionnée
    if (worker.selectedFormations && worker.selectedFormations.some(formation => 
      formation.toLowerCase().includes('secour') || 
      formation.toLowerCase().includes('premiers soins') ||
      formation.toLowerCase().includes('rcp') ||
      formation.toLowerCase().includes('dea')
    )) {
      return true;
    }
    
    return false;
  };

  // Calculer le nombre de cartes reçues
  const cartesRecues = secouristes.filter(secouriste => hasValidFirstAidTraining(secouriste)).length;

  if (secouristes.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-red-600" />
            Secouristes sur le chantier (0)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Aucun secouriste déclaré</p>
            <p className="text-sm">Ajoutez des travailleurs avec la qualification secouriste</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-600" />
          Secouristes sur le chantier ({secouristes.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {sortedEntreprises.map(([soustraitant, workers]) => (
          <div key={soustraitant} className="border rounded-lg p-4 bg-gradient-to-r from-red-50 to-pink-50">
            <div className="flex items-center gap-2 mb-3">
              <Building2 className="w-4 h-4 text-red-600" />
              <h3 className="font-semibold text-red-800">{soustraitant}</h3>
              <Badge variant="outline" className="text-red-700 border-red-300">
                {workers.length} secouriste{workers.length > 1 ? 's' : ''}
              </Badge>
            </div>
            <div className="space-y-2">
              {workers.map((worker) => {
                const hasCard = hasValidFirstAidTraining(worker);
                
                return (
                  <div key={worker.id} className="flex items-center justify-between bg-white rounded p-3 shadow-sm">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center">
                        <Heart className="w-4 h-4 text-red-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{worker.nomEmploye}</p>
                        <p className="text-sm text-gray-600">{cleanCorpsMetier(worker.corpsMetier)}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {hasCard ? (
                        <Badge className="bg-green-100 text-green-800 border-green-300">
                          Carte reçue
                        </Badge>
                      ) : (
                        <Badge variant="destructive" className="bg-red-100 text-red-800 border-red-300">
                          Carte non reçue
                        </Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
        
        {/* Résumé avec nombre de cartes reçues */}
        <div className="mt-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-lg border border-green-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Heart className="w-5 h-5 text-green-600" />
              <span className="font-semibold text-green-800">Résumé secouristes</span>
            </div>
            <div className="text-right">
              <p className="text-lg font-bold text-green-800">{secouristes.length} total</p>
              <p className="text-sm text-green-600">
                {sortedEntreprises.length} entreprise{sortedEntreprises.length > 1 ? 's' : ''}
              </p>
              <p className="text-sm text-green-600 font-medium">
                {cartesRecues} carte{cartesRecues > 1 ? 's' : ''} reçue{cartesRecues > 1 ? 's' : ''}
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
