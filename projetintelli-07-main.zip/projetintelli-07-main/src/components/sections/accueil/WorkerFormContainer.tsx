import React, { useState } from 'react';
import { WorkerForm } from "./WorkerForm";
import type { EntryData } from "./types";

interface AvisVerbal {
  date: string;
  nature: string;
}

interface AvisEcrit {
  date: string;
  nature: string;
}

interface AccidentData {
  aAccident: boolean;
  dateAccident: string;
  typeBlessure: string;
  partieCorpsAtteinte: string;
  natureAccident: string;
  joursPermis: string;
  naturePerte: string;
  abandonTravail: boolean;
  joursAbsence: string;
  consultationMedecin: boolean;
  transportHopital: boolean;
  temoin1: string;
  temoin2: string;
  observations: string;
}

interface WorkerFormContainerProps {
  onSubmit: (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => void;
  logo: string;
  soustraitant: string;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const WorkerFormContainer = ({ 
  onSubmit, 
  logo, 
  soustraitant, 
  onASTNavigation 
}: WorkerFormContainerProps) => {
  const [prenom, setPrenom] = useState('');
  const [nom, setNom] = useState('');
  const [selectedOccupations, setSelectedOccupations] = useState<string[]>([]);
  const [dateNaissance, setDateNaissance] = useState<Date | undefined>();
  const [dateAccueil, setDateAccueil] = useState<Date | undefined>();
  const [etiquetteRecue, setEtiquetteRecue] = useState(false);
  const [numeroEtiquette, setNumeroEtiquette] = useState('');
  const [estContremaitre, setEstContremaitre] = useState(false);
  const [estSousTraitant, setEstSousTraitant] = useState(false);
  const [nomSousTraitant, setNomSousTraitant] = useState('');
  const [cellulaireTravailleur, setCellulaireTravailleur] = useState('');
  const [numeroImmatriculation, setNumeroImmatriculation] = useState('');
  const [nomContactAccident, setNomContactAccident] = useState('');
  const [cellulaireContact, setCellulaireContact] = useState('');
  const [estCadre, setEstCadre] = useState(false);
  const [carteASP, setCarteASP] = useState('');
  const [carteASPName, setCarteASPName] = useState('');
  const [carteCCQ, setCarteCCQ] = useState('');
  const [carteCCQName, setCarteCCQName] = useState('');
  const [numeroClient, setNumeroClient] = useState('');
  const [dateEcheanceCarte, setDateEcheanceCarte] = useState<Date | undefined>();
  const [carteSIMDUT, setCarteSIMDUT] = useState('');
  const [carteSIMDUTName, setCarteSIMDUTName] = useState('');
  const [selectedFormations, setSelectedFormations] = useState<string[]>([]);
  const [cartesFormations, setCartesFormations] = useState<Record<string, { active: boolean; image?: string; imageName?: string; }>>({});
  const [estSecouriste, setEstSecouriste] = useState(false);
  const [carteSecouriste, setCarteSecouriste] = useState('');
  const [carteSecouristeName, setCarteSecouristeName] = useState('');
  const [dateEcheancierSecouriste, setDateEcheancierSecouriste] = useState<Date | undefined>();
  const [maladie, setMaladie] = useState('');
  const [allergie, setAllergie] = useState('');

  // États pour les sanctions
  const [avisVerbaux, setAvisVerbaux] = useState<AvisVerbal[]>([]);
  const [avisEcrits, setAvisEcrits] = useState<AvisEcrit[]>([]);
  const [dateExpulsionTemporaire, setDateExpulsionTemporaire] = useState<string>('');
  const [dateExpulsionDefinitive, setDateExpulsionDefinitive] = useState<string>('');

  // État pour les accidents
  const [accidentData, setAccidentData] = useState<AccidentData>({
    aAccident: false,
    dateAccident: '',
    typeBlessure: '',
    partieCorpsAtteinte: '',
    natureAccident: '',
    joursPermis: '',
    naturePerte: '',
    abandonTravail: false,
    joursAbsence: '',
    consultationMedecin: false,
    transportHopital: false,
    temoin1: '',
    temoin2: '',
    observations: ''
  });

  const resetForm = () => {
    console.log('🧹 CONTAINER - Réinitialisation du formulaire');
    
    setPrenom('');
    setNom('');
    setSelectedOccupations([]);
    setDateNaissance(undefined);
    setDateAccueil(undefined);
    setEtiquetteRecue(false);
    setNumeroEtiquette('');
    setEstContremaitre(false);
    setEstSousTraitant(false);
    setNomSousTraitant('');
    setCellulaireTravailleur('');
    setNumeroImmatriculation('');
    setNomContactAccident('');
    setCellulaireContact('');
    setEstCadre(false);
    setCarteASP('');
    setCarteASPName('');
    setCarteCCQ('');
    setCarteCCQName('');
    setNumeroClient('');
    setDateEcheanceCarte(undefined);
    setCarteSIMDUT('');
    setCarteSIMDUTName('');
    setSelectedFormations([]);
    setCartesFormations({});
    setEstSecouriste(false);
    setCarteSecouriste('');
    setCarteSecouristeName('');
    setDateEcheancierSecouriste(undefined);
    setMaladie('');
    setAllergie('');
    
    // Réinitialiser les sanctions
    setAvisVerbaux([]);
    setAvisEcrits([]);
    setDateExpulsionTemporaire('');
    setDateExpulsionDefinitive('');
    
    // Réinitialiser les accidents
    setAccidentData({
      aAccident: false,
      dateAccident: '',
      typeBlessure: '',
      partieCorpsAtteinte: '',
      natureAccident: '',
      joursPermis: '',
      naturePerte: '',
      abandonTravail: false,
      joursAbsence: '',
      consultationMedecin: false,
      transportHopital: false,
      temoin1: '',
      temoin2: '',
      observations: ''
    });
    
    console.log('✨ CONTAINER - Formulaire réinitialisé');
  };

  const handleSubmit = (e: React.FormEvent) => {
    console.log('🚀 CONTAINER - Début de la soumission');
    e.preventDefault();
    
    // Validation des champs obligatoires - SEULEMENT prénom, nom et sous-traitant
    if (!prenom || !nom || !soustraitant) {
      console.log('🚨 CONTAINER - Validation échouée');
      alert('Veuillez remplir tous les champs obligatoires : Prénom, Nom et Sous-traitant');
      return;
    }

    console.log('✅ CONTAINER - Validation réussie');

    const age = dateNaissance ? new Date().getFullYear() - dateNaissance.getFullYear() : 0;

    const formData: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'> = {
      prenom,
      nom,
      nomEmploye: `${prenom} ${nom}`,
      entreprise: soustraitant || 'Non spécifié',
      fonction: selectedOccupations[0] || 'Non spécifié',
      corpsMetier: selectedOccupations.join(', '),
      occupation: selectedOccupations[0] || '', // Ajout du champ occupation manquant
      occupations: selectedOccupations,
      age,
      dateAjout: new Date().toLocaleDateString('fr-CA'),
      dateAccueil: dateAccueil?.toLocaleDateString('fr-CA') || '',
      etiquetteRecue,
      numeroEtiquette,
      estContremaitre,
      estSousTraitant,
      nomSousTraitant,
      telephone: cellulaireTravailleur,
      courriel: '',
      adresse: '',
      ville: '',
      codePostal: '',
      numeroImmatriculation,
      nomContactAccident,
      cellulaireContact,
      estCadre,
      carteASP,
      carteASPName,
      carteCCQ,
      carteCCQName,
      numeroClient,
      dateEcheanceCarte: dateEcheanceCarte?.toLocaleDateString('fr-CA') || '',
      carteSIMDUT,
      carteSIMDUTName,
      selectedFormations,
      cartesFormations,
      estSecouriste,
      carteSecouriste,
      carteSecouristeName,
      dateEcheancierSecouriste: dateEcheancierSecouriste?.toLocaleDateString('fr-CA') || '',
      maladie,
      allergie,
      soustraitant,
      logo
    };

    console.log('📦 CONTAINER - Données complètes préparées:', JSON.stringify(formData, null, 2));
    console.log('🎯 CONTAINER - Type de onSubmit:', typeof onSubmit);
    console.log('🎯 CONTAINER - onSubmit function:', onSubmit);
    
    try {
      // Appel de la fonction onSubmit du parent
      console.log('🔄 CONTAINER - Appel de onSubmit...');
      onSubmit(formData);
      console.log('✅ CONTAINER - onSubmit appelé avec succès');
      
      // Réinitialiser le formulaire seulement après succès
      console.log('🔄 CONTAINER - Réinitialisation...');
      resetForm();
      console.log('✨ CONTAINER - Processus terminé avec succès');
      
    } catch (error) {
      console.error('❌ CONTAINER - Erreur lors de onSubmit:', error);
    }
  };

  const handleDateNaissanceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setDateNaissance(value ? new Date(value) : undefined);
  };

  const handleOccupationToggle = (occupation: string) => {
    setSelectedOccupations(prev => 
      prev.includes(occupation) 
        ? prev.filter(o => o !== occupation)
        : [...prev, occupation]
    );
  };

  const handleCarteASPChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCarteASPName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setCarteASP(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCarteCCQChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCarteCCQName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setCarteCCQ(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleCarteSIMDUTChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCarteSIMDUTName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setCarteSIMDUT(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleFormationToggle = (formation: string) => {
    console.log('Formation toggled:', formation);
    setSelectedFormations(prev => {
      const newFormations = prev.includes(formation) 
        ? prev.filter(f => f !== formation)
        : [...prev, formation];
      console.log('New selectedFormations:', newFormations);
      return newFormations;
    });
  };

  const handleCarteFormationToggle = (formation: string, active: boolean) => {
    setCartesFormations(prev => ({
      ...prev,
      [formation]: { ...prev[formation], active }
    }));
  };

  const handleCarteFormationImageChange = (formation: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setCartesFormations(prev => ({
          ...prev,
          [formation]: { 
            ...prev[formation], 
            image: e.target?.result as string,
            imageName: file.name
          }
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCarteFormationImageRemove = (formation: string) => {
    setCartesFormations(prev => ({
      ...prev,
      [formation]: { 
        ...prev[formation], 
        image: undefined,
        imageName: undefined
      }
    }));
  };

  const handleCarteSecouristeChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setCarteSecouristeName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setCarteSecouriste(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <WorkerForm
      prenom={prenom}
      nom={nom}
      dateNaissance={dateNaissance}
      selectedOccupations={selectedOccupations}
      dateAccueil={dateAccueil}
      etiquetteRecue={etiquetteRecue}
      numeroEtiquette={numeroEtiquette}
      estContremaitre={estContremaitre}
      estSousTraitant={estSousTraitant}
      nomSousTraitant={nomSousTraitant}
      cellulaireTravailleur={cellulaireTravailleur}
      numeroImmatriculation={numeroImmatriculation}
      nomContactAccident={nomContactAccident}
      cellulaireContact={cellulaireContact}
      estCadre={estCadre}
      carteASP={carteASP}
      carteASPName={carteASPName}
      carteCCQ={carteCCQ}
      carteCCQName={carteCCQName}
      numeroClient={numeroClient}
      dateEcheanceCarte={dateEcheanceCarte}
      carteSIMDUT={carteSIMDUT}
      carteSIMDUTName={carteSIMDUTName}
      selectedFormations={selectedFormations}
      cartesFormations={cartesFormations}
      estSecouriste={estSecouriste}
      carteSecouriste={carteSecouriste}
      carteSecouristeName={carteSecouristeName}
      dateEcheancierSecouriste={dateEcheancierSecouriste}
      maladie={maladie}
      allergie={allergie}
      avisVerbaux={avisVerbaux}
      avisEcrits={avisEcrits}
      dateExpulsionTemporaire={dateExpulsionTemporaire}
      dateExpulsionDefinitive={dateExpulsionDefinitive}
      accidentData={accidentData}
      onPrenomChange={setPrenom}
      onNomChange={setNom}
      onDateNaissanceChange={handleDateNaissanceChange}
      onOccupationToggle={handleOccupationToggle}
      onDateAccueilChange={setDateAccueil}
      onEtiquetteRecueChange={setEtiquetteRecue}
      onNumeroEtiquetteChange={setNumeroEtiquette}
      onEstContremaitreChange={setEstContremaitre}
      onEstSousTraitantChange={setEstSousTraitant}
      onNomSousTraitantChange={setNomSousTraitant}
      onCellulaireTravailleurChange={setCellulaireTravailleur}
      onNumeroImmatriculationChange={setNumeroImmatriculation}
      onNomContactAccidentChange={setNomContactAccident}
      onCellulaireContactChange={setCellulaireContact}
      onEstCadreChange={setEstCadre}
      onCarteASPChange={handleCarteASPChange}
      onCarteCCQChange={handleCarteCCQChange}
      onNumeroClientChange={setNumeroClient}
      onDateEcheangeCarteChange={setDateEcheanceCarte}
      onCarteASPRemove={() => { setCarteASP(''); setCarteASPName(''); }}
      onCarteCCQRemove={() => { setCarteCCQ(''); setCarteCCQName(''); }}
      onCarteSIMDUTChange={handleCarteSIMDUTChange}
      onCarteSIMDUTRemove={() => { setCarteSIMDUT(''); setCarteSIMDUTName(''); }}
      onFormationToggle={handleFormationToggle}
      onCarteFormationToggle={handleCarteFormationToggle}
      onCarteFormationImageChange={handleCarteFormationImageChange}
      onCarteFormationImageRemove={handleCarteFormationImageRemove}
      onEstSecouristeChange={setEstSecouriste}
      onCarteSecouristeChange={handleCarteSecouristeChange}
      onCarteSecouristeRemove={() => { setCarteSecouriste(''); setCarteSecouristeName(''); }}
      onDateEcheancierSecouristeChange={setDateEcheancierSecouriste}
      onMaladieChange={setMaladie}
      onAllergieChange={setAllergie}
      onAvisVerbauxChange={setAvisVerbaux}
      onAvisEcritsChange={setAvisEcrits}
      onDateExpulsionTemporaireChange={setDateExpulsionTemporaire}
      onDateExpulsionDefinitiveChange={setDateExpulsionDefinitive}
      onAccidentDataChange={setAccidentData}
      onSubmit={handleSubmit}
      onASTNavigation={onASTNavigation}
    />
  );
};
