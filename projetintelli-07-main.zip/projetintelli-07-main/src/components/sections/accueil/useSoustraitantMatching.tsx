
// Hook pour la logique de correspondance flexible entre sous-traitants et entrées
export const useSoustraitantMatching = () => {
  // Fonction pour normaliser les noms d'entreprise - Version améliorée
  const normalizeCompanyName = (name: string): string => {
    if (!name || name.trim() === '') return '';
    
    return name
      .toLowerCase()
      .trim()
      // Supprimer la ponctuation et espaces
      .replace(/[.,\-_\s()]/g, '')
      // Supprimer les suffixes d'entreprise courants
      .replace(/\b(inc|ltee|ltd|limited|corporation|corp|sa|sas|sarl|llc|co|company|construction|electricite|plomberie|toiture|excavation|soudure|charpenterie|isolation|beton|menuiserie|maconnerie|quebec|canada)\b/g, '');
  };

  // Fonction pour calculer la correspondance flexible
  const isFlexibleMatch = (soustraitantNom: string, entryName: string): boolean => {
    // Ne pas faire de correspondance avec des chaînes vides
    if (!entryName || entryName.trim() === '') {
      return false;
    }
    
    const normalized1 = normalizeCompanyName(soustraitantNom);
    const normalized2 = normalizeCompanyName(entryName);
    
    console.log(`🔍 CORRESPONDANCE FLEXIBLE - "${soustraitantNom}" vs "${entryName}"`);
    console.log(`🔍 Normalisés: "${normalized1}" vs "${normalized2}"`);
    
    // Ne pas traiter les chaînes vides après normalisation
    if (normalized1 === '' || normalized2 === '') {
      console.log(`🔍 ❌ Chaîne vide après normalisation`);
      return false;
    }
    
    // 1. Correspondance exacte après normalisation
    if (normalized1 === normalized2) {
      console.log(`🔍 ✅ CORRESPONDANCE EXACTE après normalisation`);
      return true;
    }
    
    // 2. Correspondance par inclusion (l'un contient l'autre) - minimum 3 caractères
    if (normalized1.length >= 3 && normalized2.length >= 3) {
      if (normalized1.includes(normalized2) || normalized2.includes(normalized1)) {
        console.log(`🔍 ✅ CORRESPONDANCE PAR INCLUSION`);
        return true;
      }
    }
    
    // 3. Correspondance par mots-clés principaux (pour les acronymes)
    const words1 = normalized1.split(/[^a-z0-9]/).filter(w => w.length > 0);
    const words2 = normalized2.split(/[^a-z0-9]/).filter(w => w.length > 0);
    
    // Si l'un des noms est un acronyme court, vérifier s'il correspond au début des mots de l'autre
    if (words1.length === 1 && words1[0].length <= 5 && words2.length >= 2) {
      const acronym = words1[0];
      const firstLetters = words2.map(w => w[0]).join('');
      if (acronym === firstLetters) {
        console.log(`🔍 ✅ CORRESPONDANCE PAR ACRONYME (${acronym} = ${firstLetters})`);
        return true;
      }
    }
    
    if (words2.length === 1 && words2[0].length <= 5 && words1.length >= 2) {
      const acronym = words2[0];
      const firstLetters = words1.map(w => w[0]).join('');
      if (acronym === firstLetters) {
        console.log(`🔍 ✅ CORRESPONDANCE PAR ACRONYME (${acronym} = ${firstLetters})`);
        return true;
      }
    }
    
    // 4. Correspondance exacte des noms d'origine (sans normalisation)
    if (soustraitantNom.toLowerCase().trim() === entryName.toLowerCase().trim()) {
      console.log(`🔍 ✅ CORRESPONDANCE ORIGINALE`);
      return true;
    }
    
    console.log(`🔍 ❌ Aucune correspondance trouvée`);
    return false;
  };

  return {
    isFlexibleMatch
  };
};
