
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Download, ExternalLink, AlertCircle, CheckCircle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import type { Soustraitant } from "./types";

interface WebExtractorProps {
  onExtractedCompanies: (companies: Soustraitant[]) => void;
}

export const WebExtractor = ({ onExtractedCompanies }: WebExtractorProps) => {
  const [url, setUrl] = useState('');
  const [isExtracting, setIsExtracting] = useState(false);
  const [extractedCompanies, setExtractedCompanies] = useState<Soustraitant[]>([]);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const simulateExtraction = async (url: string): Promise<Soustraitant[]> => {
    // Simulation d'extraction avec données québécoises
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const mockCompanies = [
      {
        id: Date.now().toString(),
        nom: "Excavation Beauce Inc.",
        adresse: "1234 Route de la Beauce, Saint-Georges, QC G5Y 2B1",
        telephone: "(418) 228-5678",
        courriel: "info@excavationbeauce.ca",
        actif: true,
        dateAjout: new Date().toLocaleDateString('fr-CA')
      },
      {
        id: (Date.now() + 1).toString(),
        nom: "Charpenterie Montcalm",
        adresse: "567 Rue Montcalm, Québec, QC G1R 5G4",
        telephone: "(418) 647-3421",
        courriel: "contact@charpenteriemontcalm.qc.ca",
        actif: true,
        dateAjout: new Date().toLocaleDateString('fr-CA')
      },
      {
        id: (Date.now() + 2).toString(),
        nom: "Isolation Gatineau LTÉE",
        adresse: "890 Boulevard de la Cité, Gatineau, QC J8T 8M2",
        telephone: "(819) 243-9876",
        courriel: "service@isolationgatineau.ca",
        actif: true,
        dateAjout: new Date().toLocaleDateString('fr-CA')
      }
    ];

    return mockCompanies;
  };

  const handleExtract = async () => {
    if (!url) {
      setMessage({ type: 'error', text: 'Veuillez entrer une URL valide' });
      return;
    }

    setIsExtracting(true);
    setMessage(null);

    try {
      const companies = await simulateExtraction(url);
      setExtractedCompanies(companies);
      setMessage({ type: 'success', text: `${companies.length} entreprises extraites avec succès` });
    } catch (error) {
      setMessage({ type: 'error', text: 'Erreur lors de l\'extraction. Veuillez réessayer.' });
    } finally {
      setIsExtracting(false);
    }
  };

  const handleAddToSystem = () => {
    if (extractedCompanies.length > 0) {
      onExtractedCompanies(extractedCompanies);
      setMessage({ type: 'success', text: 'Entreprises ajoutées au système avec succès' });
      setExtractedCompanies([]);
      setUrl('');
    }
  };

  const handlePhoneClick = (phoneNumber: string) => {
    if (phoneNumber) {
      try {
        const cleanNumber = phoneNumber.replace(/[^\d]/g, '');
        window.open(`tel:+1${cleanNumber}`);
      } catch (error) {
        window.location.href = `tel:+1${phoneNumber.replace(/[^\d]/g, '')}`;
      }
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="w-5 h-5 text-orange-600" />
          Extraction Web d'Entreprises
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="extract-url">URL du site web</Label>
          <div className="flex gap-2">
            <Input
              id="extract-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/annuaire-entreprises"
              className="flex-1"
            />
            <Button 
              onClick={handleExtract}
              disabled={isExtracting}
              className="flex items-center gap-2"
            >
              {isExtracting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Extraction...
                </>
              ) : (
                <>
                  <ExternalLink className="w-4 h-4" />
                  Extraire
                </>
              )}
            </Button>
          </div>
        </div>

        {message && (
          <Alert className={message.type === 'success' ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}>
            {message.type === 'success' ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={message.type === 'success' ? 'text-green-700' : 'text-red-700'}>
              {message.text}
            </AlertDescription>
          </Alert>
        )}

        {extractedCompanies.length > 0 && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">Entreprises extraites</h3>
              <Button onClick={handleAddToSystem} variant="outline">
                Ajouter au système
              </Button>
            </div>
            
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {extractedCompanies.map((company) => (
                <div key={company.id} className="p-3 border rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">{company.nom}</h4>
                    <Badge variant="secondary">Nouveau</Badge>
                  </div>
                  <p className="text-sm text-gray-600">{company.adresse}</p>
                  <div className="flex items-center gap-4 text-sm">
                    <button
                      onClick={() => handlePhoneClick(company.telephone)}
                      className="text-blue-600 hover:text-blue-800 hover:underline cursor-pointer"
                    >
                      {company.telephone}
                    </button>
                    <a 
                      href={`mailto:${company.courriel}`}
                      className="text-blue-600 hover:text-blue-800 hover:underline"
                    >
                      {company.courriel}
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
