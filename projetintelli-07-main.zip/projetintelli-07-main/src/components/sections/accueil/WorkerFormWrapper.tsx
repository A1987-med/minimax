import React, { useState } from 'react';
import { WorkerFormContainer } from "./WorkerFormContainer";
import { EnterpriseForm } from "./EnterpriseForm";
import type { EntryData } from "./types";
import { soustraitants, soustraitantCorpsEtatMap } from '@/constants/soustraitants';

interface WorkerFormWrapperProps {
  onSubmit: (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const WorkerFormWrapper = ({ onSubmit, onASTNavigation }: WorkerFormWrapperProps) => {
  const [logo, setLogo] = useState('');
  const [logoName, setLogoName] = useState('');
  const [soustraitant, setSoustraitant] = useState('');
  const [corpsMetier, setCorpsMetier] = useState('');

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogoName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setLogo(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSoustraitantChange = (value: string) => {
    console.log('🏢 WRAPPER - Sous-traitant sélectionné:', value);
    setSoustraitant(value);
    
    // Mapping automatique vers le corps d'état avec gestion des variations de casse
    let correspondingCorpsEtat = soustraitantCorpsEtatMap[value];
    
    // Si pas trouvé, essayer avec différentes variantes de casse
    if (!correspondingCorpsEtat) {
      // Essayer avec la première lettre en majuscule de chaque mot
      const titleCase = value.split(/[-\s]/).map(word => 
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      ).join('-');
      correspondingCorpsEtat = soustraitantCorpsEtatMap[titleCase];
      
      // Essayer en majuscules
      if (!correspondingCorpsEtat) {
        correspondingCorpsEtat = soustraitantCorpsEtatMap[value.toUpperCase()];
      }
      
      // Essayer en minuscules
      if (!correspondingCorpsEtat) {
        correspondingCorpsEtat = soustraitantCorpsEtatMap[value.toLowerCase()];
      }
    }
    
    if (correspondingCorpsEtat) {
      console.log('🎯 WRAPPER - Corps d\'état mappé automatiquement:', correspondingCorpsEtat);
      setCorpsMetier(correspondingCorpsEtat);
    } else {
      console.log('⚠️ WRAPPER - Aucun mapping trouvé pour:', value);
      setCorpsMetier('');
    }
  };

  const handleCorpsMetierChange = (value: string) => {
    console.log('🔧 WRAPPER - Corps métier sélectionné manuellement:', value);
    setCorpsMetier(value);
  };

  const resetEnterpriseForm = () => {
    console.log('🧹 WRAPPER - Réinitialisation du formulaire entreprise');
    setSoustraitant('');
    setCorpsMetier('');
    setLogo('');
    setLogoName('');
  };

  const handleSubmit = (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => {
    console.log('📋 WRAPPER - Données avant soumission:', {
      ...data,
      soustraitant,
      corpsMetier,
      logo
    });

    const finalData = {
      ...data,
      soustraitant,
      corpsMetier,
      logo
    };

    try {
      onSubmit(finalData);
      // Réinitialiser le formulaire entreprise après soumission réussie
      resetEnterpriseForm();
      console.log('✨ WRAPPER - Formulaire entreprise réinitialisé');
    } catch (error) {
      console.error('❌ WRAPPER - Erreur lors de la soumission:', error);
    }
  };

  return (
    <div className="space-y-6">
      <EnterpriseForm
        logo={logo}
        logoName={logoName}
        soustraitant={soustraitant}
        corpsMetier={corpsMetier}
        onLogoChange={handleLogoChange}
        onSoustraitantChange={handleSoustraitantChange}
        onCorpsMetierChange={handleCorpsMetierChange}
      />
      
      <WorkerFormContainer
        onSubmit={handleSubmit}
        logo={logo}
        soustraitant={soustraitant}
        onASTNavigation={onASTNavigation}
      />
    </div>
  );
};
