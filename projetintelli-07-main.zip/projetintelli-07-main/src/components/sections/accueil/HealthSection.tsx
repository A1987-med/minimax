
import React from 'react';
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Heart } from "lucide-react";

interface HealthSectionProps {
  maladie: string;
  allergie: string;
  onMaladieChange: (value: string) => void;
  onAllergieChange: (value: string) => void;
}

export const HealthSection = ({
  maladie,
  allergie,
  onMaladieChange,
  onAllergieChange
}: HealthSectionProps) => {
  return (
    <div className="space-y-4 p-3 bg-red-50 rounded-lg border border-red-200">
      <div className="flex items-center gap-2">
        <Heart className="w-5 h-5 text-red-600" />
        <h4 className="text-sm font-semibold text-red-700">Maladies et allergies</h4>
      </div>

      <div className="space-y-3">
        <div className="space-y-2">
          <Label htmlFor="maladie">Maladie</Label>
          <Textarea
            id="maladie"
            value={maladie}
            onChange={(e) => onMaladieChange(e.target.value)}
            placeholder="Décrire les maladies existantes..."
            className="min-h-[100px]"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="allergie">Allergie</Label>
          <Textarea
            id="allergie"
            value={allergie}
            onChange={(e) => onAllergieChange(e.target.value)}
            placeholder="Décrire les allergies connues..."
            className="min-h-[100px]"
          />
        </div>
      </div>
    </div>
  );
};
