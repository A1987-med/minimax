
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangle } from "lucide-react";

interface AccidentData {
  aAccident: boolean;
  dateAccident: string;
  typeBlessure: string;
  partieCorpsAtteinte: string;
  natureAccident: string;
  joursPermis: string;
  naturePerte: string;
  abandonTravail: boolean;
  joursAbsence: string;
  consultationMedecin: boolean;
  transportHopital: boolean;
  temoin1: string;
  temoin2: string;
  observations: string;
}

interface AccidentsSectionProps {
  accidentData: AccidentData;
  nomContactAccident: string;
  cellulaireContact: string;
  onAccidentDataChange: (data: AccidentData) => void;
}

export const AccidentsSection = ({
  accidentData,
  nomContactAccident,
  cellulaireContact,
  onAccidentDataChange
}: AccidentsSectionProps) => {
  
  const handleFieldChange = (field: keyof AccidentData, value: any) => {
    onAccidentDataChange({
      ...accidentData,
      [field]: value
    });
  };

  const naturesAccident = [
    "Accident avec perte de temps",
    "Accident sans perte de temps", 
    "Dommage matériel",
    "Quasi-accident",
    "Perte matérielle"
  ];

  return (
    <div className="space-y-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-orange-600" />
        <h4 className="text-sm font-semibold text-orange-700">Accidents de travail</h4>
      </div>

      <div className="space-y-4">
        {/* Commutateur principal */}
        <div className="flex items-center space-x-2">
          <Switch
            id="accident-switch"
            checked={accidentData.aAccident}
            onCheckedChange={(checked) => handleFieldChange('aAccident', checked)}
          />
          <Label htmlFor="accident-switch" className="text-sm font-medium">
            Accident de travail
          </Label>
        </div>

        {/* Champs conditionnels */}
        {accidentData.aAccident && (
          <div className="space-y-4 p-4 bg-white rounded-lg border border-orange-200">
            
            {/* Date de l'accident */}
            <div className="space-y-2">
              <Label htmlFor="date-accident">Date de l'accident</Label>
              <Input
                id="date-accident"
                type="date"
                value={accidentData.dateAccident}
                onChange={(e) => handleFieldChange('dateAccident', e.target.value)}
              />
            </div>

            {/* Type de blessure */}
            <div className="space-y-2">
              <Label htmlFor="type-blessure">Type de blessure</Label>
              <Input
                id="type-blessure"
                value={accidentData.typeBlessure}
                onChange={(e) => handleFieldChange('typeBlessure', e.target.value)}
                placeholder="Décrire le type de blessure..."
              />
            </div>

            {/* Partie du corps atteinte */}
            <div className="space-y-2">
              <Label htmlFor="partie-corps">Partie du corps atteinte</Label>
              <Input
                id="partie-corps"
                value={accidentData.partieCorpsAtteinte}
                onChange={(e) => handleFieldChange('partieCorpsAtteinte', e.target.value)}
                placeholder="Partie du corps touchée..."
              />
            </div>

            {/* Nature de l'accident */}
            <div className="space-y-2">
              <Label htmlFor="nature-accident">Nature de l'accident</Label>
              <Select 
                value={accidentData.natureAccident} 
                onValueChange={(value) => handleFieldChange('natureAccident', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Sélectionner la nature de l'accident" />
                </SelectTrigger>
                <SelectContent>
                  {naturesAccident.map((nature) => (
                    <SelectItem key={nature} value={nature}>
                      {nature}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Champs conditionnels selon la nature */}
            {accidentData.natureAccident === "Accident avec perte de temps" && (
              <div className="space-y-2">
                <Label htmlFor="jours-perdus">Nombre de jours perdus</Label>
                <Input
                  id="jours-perdus"
                  type="number"
                  value={accidentData.joursPermis}
                  onChange={(e) => handleFieldChange('joursPermis', e.target.value)}
                  placeholder="Nombre de jours..."
                />
              </div>
            )}

            {accidentData.natureAccident === "Dommage matériel" && (
              <div className="space-y-2">
                <Label htmlFor="nature-perte">Nature de la perte</Label>
                <Input
                  id="nature-perte"
                  value={accidentData.naturePerte}
                  onChange={(e) => handleFieldChange('naturePerte', e.target.value)}
                  placeholder="Décrire la nature de la perte..."
                />
              </div>
            )}

            {/* Questions Oui/Non */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  id="abandon-travail"
                  checked={accidentData.abandonTravail}
                  onCheckedChange={(checked) => handleFieldChange('abandonTravail', checked)}
                />
                <Label htmlFor="abandon-travail" className="text-sm">
                  Abandon de travail ?
                </Label>
              </div>

              {/* Champ conditionnel pour les jours d'absence */}
              {accidentData.abandonTravail && (
                <div className="space-y-2 ml-6">
                  <Label htmlFor="jours-absence">Nombre de jours absentés</Label>
                  <Input
                    id="jours-absence"
                    type="number"
                    value={accidentData.joursAbsence}
                    onChange={(e) => handleFieldChange('joursAbsence', e.target.value)}
                    placeholder="Nombre de jours d'absence..."
                    className="max-w-xs"
                  />
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="consultation-medecin"
                    checked={accidentData.consultationMedecin}
                    onCheckedChange={(checked) => handleFieldChange('consultationMedecin', checked)}
                  />
                  <Label htmlFor="consultation-medecin" className="text-sm">
                    Consultation d'un médecin ?
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="transport-hopital"
                    checked={accidentData.transportHopital}
                    onCheckedChange={(checked) => handleFieldChange('transportHopital', checked)}
                  />
                  <Label htmlFor="transport-hopital" className="text-sm">
                    Transport vers l'hôpital ?
                  </Label>
                </div>
              </div>
            </div>

            {/* Témoins */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="temoin1">Témoin Nº1</Label>
                <Input
                  id="temoin1"
                  value={accidentData.temoin1}
                  onChange={(e) => handleFieldChange('temoin1', e.target.value)}
                  placeholder="Nom du premier témoin..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="temoin2">Témoin Nº2</Label>
                <Input
                  id="temoin2"
                  value={accidentData.temoin2}
                  onChange={(e) => handleFieldChange('temoin2', e.target.value)}
                  placeholder="Nom du deuxième témoin..."
                />
              </div>
            </div>

            {/* Personne contact (automatique) */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Personne contact</Label>
                <Input
                  value={nomContactAccident || 'Non spécifié'}
                  disabled
                  className="bg-gray-100"
                />
              </div>

              <div className="space-y-2">
                <Label>Cellulaire du contact</Label>
                <Input
                  value={cellulaireContact || 'Non spécifié'}
                  disabled
                  className="bg-gray-100"
                />
              </div>
            </div>

            {/* Observations */}
            <div className="space-y-2">
              <Label htmlFor="observations-accident">Observations</Label>
              <Textarea
                id="observations-accident"
                value={accidentData.observations}
                onChange={(e) => handleFieldChange('observations', e.target.value)}
                placeholder="Observations concernant l'accident..."
                className="min-h-[100px]"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
