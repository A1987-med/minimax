
// Re-export des types depuis les nouveaux fichiers organisés
export type { EntryData, Soustraitant } from '@/types/accueil';
export type { Signalement } from '@/types/signalement';
export type { ChecklistPrevention, ChecklistItem, Inspection } from '@/types/prevention';
export type { ProtocolePersonnalise } from '@/types/protocoles';
export type { FormationCertification } from '@/types/formations';
export type { ContactUrgence } from '@/types/urgences';

// Re-export des constantes
export { occupations } from '@/constants/occupations';
export { formations } from '@/constants/formations';
export { soustraitants, corpsEtat, soustraitantCorpsEtatMap } from '@/constants/soustraitants';
