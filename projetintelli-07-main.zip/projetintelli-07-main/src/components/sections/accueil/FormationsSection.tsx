
import React from 'react';
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { GraduationCap, FileImage, ChevronDown, Upload, X } from "lucide-react";
import { formations } from './types';

interface FormationsSectionProps {
  selectedFormations: string[];
  cartesFormations: Record<string, { active: boolean; image?: string; imageName?: string; }>;
  onFormationToggle: (formation: string) => void;
  onCarteFormationToggle: (formation: string, active: boolean) => void;
  onCarteFormationImageChange: (formation: string, event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteFormationImageRemove: (formation: string) => void;
}

export const FormationsSection = ({
  selectedFormations,
  cartesFormations,
  onFormationToggle,
  onCarteFormationToggle,
  onCarteFormationImageChange,
  onCarteFormationImageRemove
}: FormationsSectionProps) => {
  return (
    <div className="space-y-4">
      {/* Section Formations Travailleur */}
      <div className="space-y-4 p-3 bg-green-50 rounded-lg border border-green-200">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-green-600" />
          <h4 className="text-sm font-semibold text-green-700">Formations Travailleur</h4>
        </div>

        <div className="space-y-2">
          <Label htmlFor="formations">Formations</Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                type="button"
                variant="outline"
                className="w-full justify-between"
              >
                {selectedFormations.length > 0 
                  ? `${selectedFormations.length} formation(s) sélectionnée(s)`
                  : "Sélectionner les formations"
                }
                <ChevronDown className="w-4 h-4 opacity-50" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-full max-w-md p-0 bg-white border border-gray-200 shadow-lg z-50">
              <div className="max-h-60 overflow-y-auto p-4 space-y-2">
                {formations.map((formation) => (
                  <div key={formation} className="flex items-center space-x-2">
                    <Checkbox
                      id={formation}
                      checked={selectedFormations.includes(formation)}
                      onCheckedChange={() => onFormationToggle(formation)}
                    />
                    <Label 
                      htmlFor={formation}
                      className="text-sm font-normal cursor-pointer"
                    >
                      {formation}
                    </Label>
                  </div>
                ))}
              </div>
            </PopoverContent>
          </Popover>
          {selectedFormations.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {selectedFormations.map((formation) => (
                <span 
                  key={formation}
                  className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800"
                >
                  {formation}
                  <button
                    type="button"
                    onClick={() => onFormationToggle(formation)}
                    className="ml-1 text-green-600 hover:text-green-800"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Section Cartes reçues */}
      <div className="space-y-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
        <div className="flex items-center gap-2">
          <FileImage className="w-5 h-5 text-orange-600" />
          <h4 className="text-sm font-semibold text-orange-700">Cartes reçues</h4>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="space-y-2">
            <Label>Formule (Formations sélectionnées)</Label>
            <div className="p-2 bg-white rounded-md border border-orange-200 min-h-[40px] text-sm">
              {selectedFormations.length > 0 ? selectedFormations.join(', ') : 'Aucune formation sélectionnée'}
            </div>
          </div>
          <div className="space-y-2">
            <Label>Nombre de formations</Label>
            <div className="p-2 bg-white rounded-md border border-orange-200 text-center font-medium">
              {selectedFormations.length}
            </div>
          </div>
        </div>

        {selectedFormations.length > 0 ? (
          <div className="space-y-4">
            {selectedFormations.map((formation) => {
              const carteFormation = cartesFormations[formation] || { active: false };
              
              return (
                <div key={formation} className="space-y-3 p-3 bg-white rounded-lg border border-orange-100">
                  <div className="flex items-center justify-between">
                    <Label className="text-sm font-medium">{formation}</Label>
                    <div className="flex items-center space-x-2">
                      <Label htmlFor={`switch-${formation}`} className="text-sm">
                        {carteFormation.active ? "Oui" : "Non"}
                      </Label>
                      <Switch
                        id={`switch-${formation}`}
                        checked={carteFormation.active}
                        onCheckedChange={(checked) => onCarteFormationToggle(formation, checked)}
                      />
                    </div>
                  </div>

                  {carteFormation.active && (
                    <div className="space-y-2">
                      <Label htmlFor={`carte-${formation}`}>Photo de la carte</Label>
                      <div className="space-y-2">
                        <div className="relative">
                          <Input
                            id={`carte-${formation}`}
                            type="file"
                            accept="image/*"
                            onChange={(e) => onCarteFormationImageChange(formation, e)}
                            className="hidden"
                          />
                          <Button
                            type="button"
                            variant="outline"
                            onClick={() => document.getElementById(`carte-${formation}`)?.click()}
                            className="flex items-center gap-2"
                          >
                            <Upload className="w-4 h-4" />
                            Choisir une image
                          </Button>
                        </div>
                        {carteFormation.image && (
                          <div className="flex items-center gap-2">
                            <div className="w-20 h-20 border border-gray-300 rounded-lg overflow-hidden">
                              <img
                                src={carteFormation.image}
                                alt={`Carte ${formation}`}
                                className="w-full h-full object-contain"
                              />
                            </div>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => onCarteFormationImageRemove(formation)}
                              className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                              title="Supprimer l'image"
                            >
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                        {carteFormation.imageName && (
                          <p className="text-sm text-gray-500">{carteFormation.imageName}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-4 text-center text-gray-500 bg-white rounded-lg border border-orange-100">
            Sélectionnez d'abord des formations pour pouvoir gérer les cartes correspondantes.
          </div>
        )}
      </div>
    </div>
  );
};
