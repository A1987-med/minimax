
import { useState } from 'react';
import { soustraitantService } from "@/services/accueilService";
import { useToast } from "@/hooks/use-toast";

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

export const useSoustraitantOperations = (
  soustraitants: Soustraitant[],
  onSoustraitantsChange: (soustraitants: Soustraitant[]) => void
) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingSoustraitant, setEditingSoustraitant] = useState<Soustraitant | null>(null);
  const [newSoustraitant, setNewSoustraitant] = useState({ nom: '' });
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleAddSoustraitant = async () => {
    console.log('🔄 Ajout nouveau sous-traitant:', newSoustraitant.nom);
    
    if (!newSoustraitant.nom.trim()) {
      toast({
        title: "Erreur",
        description: "Le nom du sous-traitant est requis",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const nouveauSoustraitant = await soustraitantService.create({
        nom: newSoustraitant.nom.trim(),
        adresse: '',
        telephone: '',
        courriel: '',
        actif: true,
        dateAjout: new Date().toISOString().split('T')[0]
      });

      console.log('✅ Sous-traitant créé:', nouveauSoustraitant);
      onSoustraitantsChange([...soustraitants, nouveauSoustraitant]);
      setNewSoustraitant({ nom: '' });
      setIsDialogOpen(false);

      toast({
        title: "Sous-traitant ajouté",
        description: `${nouveauSoustraitant.nom} a été ajouté avec succès`,
        variant: "default"
      });

    } catch (error) {
      console.error('❌ Erreur création sous-traitant:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le sous-traitant",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditSoustraitant = (soustraitant: Soustraitant) => {
    setEditingSoustraitant(soustraitant);
    setNewSoustraitant({ nom: soustraitant.nom });
    setIsDialogOpen(true);
  };

  const handleUpdateSoustraitant = async () => {
    if (!editingSoustraitant || !newSoustraitant.nom.trim()) {
      toast({
        title: "Erreur",
        description: "Le nom du sous-traitant est requis",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);
    try {
      const updatedSoustraitant = await soustraitantService.update(editingSoustraitant.id, {
        nom: newSoustraitant.nom.trim()
      });

      const updatedList = soustraitants.map(s =>
        s.id === editingSoustraitant.id ? updatedSoustraitant : s
      );
      
      onSoustraitantsChange(updatedList);
      setEditingSoustraitant(null);
      setNewSoustraitant({ nom: '' });
      setIsDialogOpen(false);

      toast({
        title: "Sous-traitant modifié",
        description: `${updatedSoustraitant.nom} a été modifié avec succès`,
        variant: "default"
      });

    } catch (error) {
      console.error('Erreur modification sous-traitant:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modifier le sous-traitant",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteSoustraitant = async (id: string) => {
    const soustraitant = soustraitants.find(s => s.id === id);
    if (!soustraitant) return;

    if (!confirm(`Êtes-vous sûr de vouloir supprimer "${soustraitant.nom}" ?`)) {
      return;
    }

    setIsLoading(true);
    try {
      await soustraitantService.delete(id);
      const updatedList = soustraitants.filter(s => s.id !== id);
      onSoustraitantsChange(updatedList);

      toast({
        title: "Sous-traitant supprimé",
        description: `${soustraitant.nom} a été supprimé avec succès`,
        variant: "default"
      });

    } catch (error) {
      console.error('Erreur suppression sous-traitant:', error);
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le sous-traitant",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggleActif = async (id: string) => {
    const soustraitant = soustraitants.find(s => s.id === id);
    if (!soustraitant) return;

    setIsLoading(true);
    try {
      const updatedSoustraitant = await soustraitantService.update(id, {
        actif: !soustraitant.actif
      });

      const updatedList = soustraitants.map(s =>
        s.id === id ? updatedSoustraitant : s
      );
      
      onSoustraitantsChange(updatedList);

      toast({
        title: "Statut modifié",
        description: `${updatedSoustraitant.nom} est maintenant ${updatedSoustraitant.actif ? 'actif' : 'inactif'}`,
        variant: "default"
      });

    } catch (error) {
      console.error('Erreur modification statut:', error);
      toast({
        title: "Erreur",
        description: "Impossible de modifier le statut",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleExport = () => {
    const dataStr = JSON.stringify(soustraitants, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'soustraitants.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const importedData = JSON.parse(e.target?.result as string);
          if (Array.isArray(importedData)) {
            onSoustraitantsChange(importedData);
          }
        } catch (error) {
          console.error('Erreur lors de l\'import:', error);
        }
      };
      reader.readAsText(file);
    }
  };

  const resetDialog = () => {
    setEditingSoustraitant(null);
    setNewSoustraitant({ nom: '' });
    setIsDialogOpen(false);
  };

  return {
    isDialogOpen,
    setIsDialogOpen,
    editingSoustraitant,
    newSoustraitant,
    setNewSoustraitant,
    isLoading,
    handleAddSoustraitant,
    handleEditSoustraitant,
    handleUpdateSoustraitant,
    handleDeleteSoustraitant,
    handleToggleActif,
    handleExport,
    handleImport,
    resetDialog
  };
};
