
import React, { useState } from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { CreditCard, Upload, X, CalendarIcon, ZoomIn, CheckCircle, XCircle } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { ImageModal } from "@/components/ui/image-modal";

interface SecouristeSectionProps {
  estSecouriste: boolean;
  carteSecouriste: string;
  carteSecouristeName: string;
  dateEcheancierSecouriste?: Date;
  dateAccueil?: Date;
  onEstSecouristeChange: (checked: boolean) => void;
  onCarteSecouristeChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteSecouristeRemove?: () => void;
  onDateEcheancierSecouristeChange: (date?: Date) => void;
}

export const SecouristeSection = ({
  estSecouriste,
  carteSecouriste,
  carteSecouristeName,
  dateEcheancierSecouriste,
  dateAccueil,
  onEstSecouristeChange,
  onCarteSecouristeChange,
  onCarteSecouristeRemove,
  onDateEcheancierSecouristeChange
}: SecouristeSectionProps) => {
  const [modalImage, setModalImage] = useState<{ url: string; title: string } | null>(null);

  const calculateDaysBeforeExpirationSecouriste = (): number | null => {
    console.log('SecouristeSection - calculateDaysBeforeExpirationSecouriste called');
    console.log('SecouristeSection - dateAccueil:', dateAccueil);
    console.log('SecouristeSection - dateEcheancierSecouriste:', dateEcheancierSecouriste);
    
    if (!dateAccueil || !dateEcheancierSecouriste) {
      console.log('SecouristeSection - Missing dates, returning null');
      return null;
    }
    const timeDiff = dateEcheancierSecouriste.getTime() - dateAccueil.getTime();
    const days = Math.ceil(timeDiff / (1000 * 3600 * 24));
    console.log('SecouristeSection - Days calculated:', days);
    return days;
  };

  const getSecouristeValidityStatus = () => {
    console.log('SecouristeSection - getSecouristeValidityStatus called');
    const daysLeft = calculateDaysBeforeExpirationSecouriste();
    console.log('SecouristeSection - daysLeft:', daysLeft);
    
    if (daysLeft === null) {
      console.log('SecouristeSection - daysLeft is null, returning null');
      return null;
    }
    
    if (daysLeft >= 0) {
      console.log('SecouristeSection - Status: Valide');
      return { text: "Valide", bgColor: "bg-green-500" };
    } else {
      console.log('SecouristeSection - Status: Échue');
      return { text: "Échue", bgColor: "bg-red-500" };
    }
  };

  const secouristeValidityStatus = getSecouristeValidityStatus();
  
  console.log('SecouristeSection - Component render');
  console.log('SecouristeSection - estSecouriste:', estSecouriste);
  console.log('SecouristeSection - carteSecouriste:', !!carteSecouriste);
  console.log('SecouristeSection - dateEcheancierSecouriste:', dateEcheancierSecouriste);
  console.log('SecouristeSection - dateAccueil:', dateAccueil);
  console.log('SecouristeSection - secouristeValidityStatus:', secouristeValidityStatus);

  const openImageModal = (imageUrl: string, title: string) => {
    setModalImage({ url: imageUrl, title });
  };

  const closeImageModal = () => {
    setModalImage(null);
  };

  return (
    <div className="space-y-4 p-3 bg-pink-50 rounded-lg border border-pink-200">
      <div className="flex items-center gap-2">
        <CreditCard className="w-5 h-5 text-pink-600" />
        <h4 className="text-sm font-semibold text-pink-700">Secouriste</h4>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-2">
          <Checkbox
            id="secouriste"
            checked={estSecouriste}
            onCheckedChange={(checked) => onEstSecouristeChange(!!checked)}
          />
          <Label htmlFor="secouriste">Secouriste</Label>
        </div>

        {estSecouriste && (
          <div className="ml-6 space-y-3">
            <div className="space-y-2">
              <Label htmlFor="carteSecouriste">Carte de secouriste</Label>
              <div className="space-y-2">
                <div className="relative">
                  <Input
                    id="carteSecouriste"
                    type="file"
                    accept="image/*"
                    onChange={onCarteSecouristeChange}
                    className="hidden"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById('carteSecouriste')?.click()}
                    className="flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    Choisir une image
                  </Button>
                </div>
                {carteSecouriste && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div 
                        className="relative w-20 h-20 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                        onClick={() => openImageModal(carteSecouriste, "Carte de secouriste")}
                      >
                        <img
                          src={carteSecouriste}
                          alt="Carte de secouriste"
                          className="w-full h-full object-contain transition-transform group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                          <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={onCarteSecouristeRemove}
                        className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        title="Supprimer l'image"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                    
                    {/* Indicateur de statut */}
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="outline" 
                        className="flex items-center gap-1 text-green-600 border-green-300 bg-green-50"
                      >
                        <CheckCircle className="w-3 h-3" />
                        Carte reçue
                      </Badge>
                    </div>
                  </div>
                )}
                {!carteSecouriste && (
                  <div className="flex items-center gap-2">
                    <Badge 
                      variant="outline" 
                      className="flex items-center gap-1 text-red-600 border-red-300 bg-red-50"
                    >
                      <XCircle className="w-3 h-3" />
                      Carte non reçue
                    </Badge>
                  </div>
                )}
                {carteSecouristeName && (
                  <p className="text-sm text-gray-500">{carteSecouristeName}</p>
                )}
              </div>
            </div>

            {carteSecouriste && (
              <div className="space-y-2">
                <Label htmlFor="dateEcheancierSecouriste">Échéancier</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !dateEcheancierSecouriste && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateEcheancierSecouriste ? format(dateEcheancierSecouriste, "dd/MM/yyyy") : "Sélectionner une date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 min-w-[320px]" align="start">
                    <Calendar
                      mode="single"
                      selected={dateEcheancierSecouriste}
                      onSelect={onDateEcheancierSecouristeChange}
                      className="pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
              </div>
            )}

            {carteSecouriste && dateEcheancierSecouriste && dateAccueil && secouristeValidityStatus && (
              <div className="space-y-2">
                <Label>Preuve (Validité)</Label>
                <div className={cn(
                  "p-2 rounded-md text-white text-center font-medium",
                  secouristeValidityStatus.bgColor
                )}>
                  {secouristeValidityStatus.text}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal pour agrandir l'image */}
      {modalImage && (
        <ImageModal
          isOpen={true}
          onClose={closeImageModal}
          imageUrl={modalImage.url}
          title={modalImage.title}
        />
      )}
    </div>
  );
};
