import React, { useState } from 'react';
import { WorkerFormContainer } from "./WorkerFormContainer";
import { EnterpriseFormWithManager } from "./EnterpriseFormWithManager";
import type { EntryData } from "./types";
import { soustraitantCorpsEtatMap } from '@/constants/soustraitants';

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

interface WorkerFormWrapperWithManagerProps {
  soustraitants: Soustraitant[];
  onSubmit: (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const WorkerFormWrapperWithManager = ({ 
  soustraitants, 
  onSubmit, 
  onASTNavigation 
}: WorkerFormWrapperWithManagerProps) => {
  const [logo, setLogo] = useState('');
  const [logoName, setLogoName] = useState('');
  const [soustraitant, setSoustraitant] = useState('');
  const [corpsMetier, setCorpsMetier] = useState('');

  const handleLogoChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setLogoName(file.name);
      const reader = new FileReader();
      reader.onload = (e) => setLogo(e.target?.result as string);
      reader.readAsDataURL(file);
    } else {
      // Si aucun fichier (suppression), vider les états
      setLogo('');
      setLogoName('');
    }
  };

  const handleSoustraitantChange = (value: string) => {
    console.log('🏢 WRAPPER - Sous-traitant sélectionné:', value);
    setSoustraitant(value);
  };

  const handleCorpsMetierChange = (value: string) => {
    console.log('🔧 WRAPPER - Corps métier sélectionné:', value);
    setCorpsMetier(value);
  };

  const resetEnterpriseForm = () => {
    console.log('🧹 WRAPPER - Réinitialisation du formulaire entreprise');
    setSoustraitant('');
    setCorpsMetier('');
    setLogo('');
    setLogoName('');
  };

  const handleSubmit = (data: Omit<EntryData, 'id' | 'dateEntree' | 'heureEntree'>) => {
    console.log('📋 WRAPPER - Données avant soumission:', {
      ...data,
      soustraitant,
      corpsMetier,
      logo
    });

    const finalData = {
      ...data,
      soustraitant,
      corpsMetier,
      logo
    };

    try {
      onSubmit(finalData);
      // Réinitialiser le formulaire entreprise après soumission réussie
      resetEnterpriseForm();
      console.log('✨ WRAPPER - Formulaire entreprise réinitialisé');
    } catch (error) {
      console.error('❌ WRAPPER - Erreur lors de la soumission:', error);
    }
  };

  return (
    <div className="space-y-6">
      <EnterpriseFormWithManager
        logo={logo}
        logoName={logoName}
        soustraitant={soustraitant}
        soustraitants={soustraitants}
        onLogoChange={handleLogoChange}
        onSoustraitantChange={handleSoustraitantChange}
        onCorpsMetierChange={handleCorpsMetierChange}
      />
      
      <WorkerFormContainer
        onSubmit={handleSubmit}
        logo={logo}
        soustraitant={soustraitant}
        onASTNavigation={onASTNavigation}
      />
    </div>
  );
};
