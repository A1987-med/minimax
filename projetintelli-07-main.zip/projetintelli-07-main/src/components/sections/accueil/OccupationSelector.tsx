import React, { useState } from 'react';
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { ChevronDown, Mail, TreePine, Users, Building } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { occupationService, type OccupationData } from "@/services/occupationService";

interface OccupationSelectorProps {
  selectedOccupations: string[];
  onOccupationToggle: (occupation: string) => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const OccupationSelector = ({
  selectedOccupations,
  onOccupationToggle,
  onASTNavigation
}: OccupationSelectorProps) => {
  const [contremaitreEmail, setContremaitreEmail] = useState('');

  // Charger toutes les occupations (employés + statiques)
  const { data: occupations = [], isLoading } = useQuery({
    queryKey: ['all-occupations'],
    queryFn: () => occupationService.getAllOccupations(),
  });

  const isContremaitreSelected = selectedOccupations.includes('Contremaître');

  const handleEmailClick = () => {
    if (contremaitreEmail) {
      try {
        const mailtoLink = `mailto:${contremaitreEmail}`;
        window.open(mailtoLink);
      } catch (error) {
        window.location.href = `mailto:${contremaitreEmail}`;
      }
    }
  };

  const handleASTClick = (occupation: string) => {
    if (onASTNavigation) {
      onASTNavigation(occupation);
    }
  };

  // Grouper les occupations par source
  const occupationsEmployes = occupations.filter(occ => occ.source === 'employees');
  const occupationsStatiques = occupations.filter(occ => occ.source === 'static');

  return (
    <div className="space-y-2">
      <Label htmlFor="occupations" className="ml-4">Occupation *</Label>
      <Popover>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="outline"
            className="w-full justify-between"
            disabled={isLoading}
          >
            {isLoading ? 'Chargement...' : 
              selectedOccupations.length > 0 
                ? `${selectedOccupations.length} occupation(s) sélectionnée(s)`
                : "Sélectionner les occupations"
            }
            <ChevronDown className="w-4 h-4 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-full max-w-md p-0 bg-white border border-gray-200 shadow-lg z-50">
          <div className="max-h-60 overflow-y-auto p-4 space-y-2">
            {/* Section: Occupations des employés */}
            {occupationsEmployes.length > 0 && (
              <>
                <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-green-50 rounded">
                  <div className="flex items-center gap-1">
                    <Users className="w-3 h-3" />
                    Occupations de vos employés ({occupationsEmployes.length})
                  </div>
                </div>
                {occupationsEmployes.map((occupation) => (
                  <div key={occupation.nom} className="flex items-center justify-between space-x-2">
                    <div className="flex items-center space-x-2 flex-1">
                      <Checkbox
                        id={occupation.nom}
                        checked={selectedOccupations.includes(occupation.nom)}
                        onCheckedChange={() => onOccupationToggle(occupation.nom)}
                      />
                      <Label 
                        htmlFor={occupation.nom}
                        className="text-sm font-normal cursor-pointer flex-1"
                      >
                        {occupation.nom}
                      </Label>
                      <Badge variant="outline" className="text-xs bg-green-100 text-green-700 border-green-300">
                        {occupation.employeesCount}
                      </Badge>
                    </div>
                    {onASTNavigation && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleASTClick(occupation.nom)}
                        className="flex items-center gap-1 text-xs px-2 py-1 h-6 bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
                      >
                        <TreePine className="w-3 h-3" />
                        AST
                      </Button>
                    )}
                  </div>
                ))}
              </>
            )}
            
            {/* Séparateur si on a les deux sections */}
            {occupationsEmployes.length > 0 && occupationsStatiques.length > 0 && (
              <div className="h-px bg-border mx-2 my-2"></div>
            )}
            
            {/* Section: Occupations du catalogue */}
            {occupationsStatiques.length > 0 && (
              <>
                <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-blue-50 rounded">
                  <div className="flex items-center gap-1">
                    <Building className="w-3 h-3" />
                    Catalogue d'occupations ({occupationsStatiques.length})
                  </div>
                </div>
                {occupationsStatiques.map((occupation) => (
                  <div key={occupation.nom} className="flex items-center justify-between space-x-2">
                    <div className="flex items-center space-x-2 flex-1">
                      <Checkbox
                        id={occupation.nom}
                        checked={selectedOccupations.includes(occupation.nom)}
                        onCheckedChange={() => onOccupationToggle(occupation.nom)}
                      />
                      <Label 
                        htmlFor={occupation.nom}
                        className="text-sm font-normal cursor-pointer flex-1"
                      >
                        {occupation.nom}
                      </Label>
                    </div>
                    {onASTNavigation && (
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleASTClick(occupation.nom)}
                        className="flex items-center gap-1 text-xs px-2 py-1 h-6 bg-amber-50 hover:bg-amber-100 text-amber-700 border-amber-200"
                      >
                        <TreePine className="w-3 h-3" />
                        AST
                      </Button>
                    )}
                  </div>
                ))}
              </>
            )}
          </div>
        </PopoverContent>
      </Popover>
      
      {selectedOccupations.length > 0 && (
        <div className="flex flex-wrap gap-1 mt-2">
          {selectedOccupations.map((occupation) => {
            const occupationData = occupations.find(occ => occ.nom === occupation);
            return (
              <span 
                key={occupation}
                className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
              >
                {occupation}
                {occupationData?.source === 'employees' && (
                  <Badge variant="outline" className="ml-1 text-xs bg-green-100 text-green-700 border-green-300">
                    {occupationData.employeesCount}
                  </Badge>
                )}
                <button
                  type="button"
                  onClick={() => onOccupationToggle(occupation)}
                  className="ml-1 text-blue-600 hover:text-blue-800"
                >
                  ×
                </button>
              </span>
            );
          })}
        </div>
      )}

      {isContremaitreSelected && (
        <div className="mt-4 space-y-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <Label htmlFor="contremaitre-email">Email du contremaître</Label>
          <div className="flex gap-2">
            <Input
              id="contremaitre-email"
              type="email"
              placeholder="email@example.com"
              value={contremaitreEmail}
              onChange={(e) => setContremaitreEmail(e.target.value)}
              className="flex-1"
            />
            {contremaitreEmail && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleEmailClick}
                className="flex items-center gap-2 px-3 py-2 text-sm bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
              >
                <Mail className="w-4 h-4" />
                Contacter
              </Button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
