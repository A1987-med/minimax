
import React from 'react';
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Plus, Trash2 } from "lucide-react";

interface AvisVerbal {
  date: string;
  nature: string;
}

interface AvisEcrit {
  date: string;
  nature: string;
}

interface SanctionsSectionProps {
  avisVerbaux: AvisVerbal[];
  avisEcrits: AvisEcrit[];
  dateExpulsionTemporaire?: string;
  dateExpulsionDefinitive?: string;
  onAvisVerbauxChange: (avis: AvisVerbal[]) => void;
  onAvisEcritsChange: (avis: AvisEcrit[]) => void;
  onDateExpulsionTemporaireChange: (date: string) => void;
  onDateExpulsionDefinitiveChange: (date: string) => void;
}

export const SanctionsSection = ({
  avisVerbaux,
  avisEcrits,
  dateExpulsionTemporaire,
  dateExpulsionDefinitive,
  onAvisVerbauxChange,
  onAvisEcritsChange,
  onDateExpulsionTemporaireChange,
  onDateExpulsionDefinitiveChange
}: SanctionsSectionProps) => {
  
  const addAvisVerbal = () => {
    if (avisVerbaux.length < 3) {
      onAvisVerbauxChange([...avisVerbaux, { date: '', nature: '' }]);
    }
  };

  const removeAvisVerbal = (index: number) => {
    onAvisVerbauxChange(avisVerbaux.filter((_, i) => i !== index));
  };

  const updateAvisVerbal = (index: number, field: 'date' | 'nature', value: string) => {
    const updated = [...avisVerbaux];
    updated[index] = { ...updated[index], [field]: value };
    onAvisVerbauxChange(updated);
  };

  const addAvisEcrit = () => {
    if (avisEcrits.length < 3) {
      onAvisEcritsChange([...avisEcrits, { date: '', nature: '' }]);
    }
  };

  const removeAvisEcrit = (index: number) => {
    onAvisEcritsChange(avisEcrits.filter((_, i) => i !== index));
  };

  const updateAvisEcrit = (index: number, field: 'date' | 'nature', value: string) => {
    const updated = [...avisEcrits];
    updated[index] = { ...updated[index], [field]: value };
    onAvisEcritsChange(updated);
  };

  // Calcul automatique des sanctions selon les règles
  const shouldShowExpulsionTemporaire = avisEcrits.length >= 2;
  const shouldShowExpulsionDefinitive = avisEcrits.length >= 3;

  return (
    <div className="space-y-4 p-3 bg-orange-50 rounded-lg border border-orange-200">
      <div className="flex items-center gap-2">
        <AlertTriangle className="w-5 h-5 text-orange-600" />
        <h4 className="text-sm font-semibold text-orange-700">Sanctions disciplinaires</h4>
      </div>

      <div className="space-y-4">
        {/* Avis verbaux */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-orange-700 font-medium">Avis verbaux (max 3)</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addAvisVerbal}
              disabled={avisVerbaux.length >= 3}
              className="text-orange-600 border-orange-200 hover:bg-orange-100"
            >
              <Plus className="w-4 h-4 mr-1" />
              Ajouter
            </Button>
          </div>
          
          {avisVerbaux.map((avis, index) => (
            <div key={index} className="flex gap-2 items-start p-3 bg-yellow-50 rounded border border-yellow-200">
              <div className="flex-1 space-y-2">
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Label className="text-xs text-yellow-700">Date</Label>
                    <Input
                      type="date"
                      value={avis.date}
                      onChange={(e) => updateAvisVerbal(index, 'date', e.target.value)}
                      className="border-yellow-300"
                    />
                  </div>
                  <Badge variant="outline" className="text-yellow-700 border-yellow-300 mt-5">
                    Avis #{index + 1}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-yellow-700">Nature de l'avis</Label>
                  <Textarea
                    value={avis.nature}
                    onChange={(e) => updateAvisVerbal(index, 'nature', e.target.value)}
                    placeholder="Décrire la nature de l'avis verbal..."
                    className="min-h-[60px] border-yellow-300"
                  />
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => removeAvisVerbal(index)}
                className="text-red-500 hover:text-red-700 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>

        {/* Avis écrits */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <Label className="text-orange-700 font-medium">Avis écrits (max 3)</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={addAvisEcrit}
              disabled={avisEcrits.length >= 3}
              className="text-orange-600 border-orange-200 hover:bg-orange-100"
            >
              <Plus className="w-4 h-4 mr-1" />
              Ajouter
            </Button>
          </div>
          
          {avisEcrits.map((avis, index) => (
            <div key={index} className="flex gap-2 items-start p-3 bg-red-50 rounded border border-red-200">
              <div className="flex-1 space-y-2">
                <div className="flex gap-2">
                  <div className="flex-1">
                    <Label className="text-xs text-red-700">Date</Label>
                    <Input
                      type="date"
                      value={avis.date}
                      onChange={(e) => updateAvisEcrit(index, 'date', e.target.value)}
                      className="border-red-300"
                    />
                  </div>
                  <Badge variant="destructive" className="mt-5">
                    Avis écrit #{index + 1}
                  </Badge>
                </div>
                <div>
                  <Label className="text-xs text-red-700">Nature de l'avis</Label>
                  <Textarea
                    value={avis.nature}
                    onChange={(e) => updateAvisEcrit(index, 'nature', e.target.value)}
                    placeholder="Décrire la nature de l'avis écrit..."
                    className="min-h-[60px] border-red-300"
                  />
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => removeAvisEcrit(index)}
                className="text-red-500 hover:text-red-700 border-red-200 hover:bg-red-50"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>

        {/* Expulsion temporaire (2e avis écrit) */}
        {shouldShowExpulsionTemporaire && (
          <div className="p-3 bg-red-100 rounded border border-red-300">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-700" />
              <Label className="text-red-700 font-medium">Expulsion temporaire (3 jours)</Label>
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-red-700">Date d'expulsion</Label>
              <Input
                type="date"
                value={dateExpulsionTemporaire || ''}
                onChange={(e) => onDateExpulsionTemporaireChange(e.target.value)}
                className="border-red-300"
              />
            </div>
            <p className="text-xs text-red-600 mt-2">
              ⚠️ Déclenchée automatiquement au 2e avis écrit
            </p>
          </div>
        )}

        {/* Expulsion définitive (3e avis écrit) */}
        {shouldShowExpulsionDefinitive && (
          <div className="p-3 bg-red-200 rounded border border-red-400">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="w-4 h-4 text-red-800" />
              <Label className="text-red-800 font-medium">Expulsion définitive</Label>
            </div>
            <div className="space-y-2">
              <Label className="text-xs text-red-800">Date d'expulsion définitive</Label>
              <Input
                type="date"
                value={dateExpulsionDefinitive || ''}
                onChange={(e) => onDateExpulsionDefinitiveChange(e.target.value)}
                className="border-red-400"
              />
            </div>
            <p className="text-xs text-red-700 mt-2">
              🚫 Déclenchée automatiquement au 3e avis écrit - Interdiction permanente du chantier
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
