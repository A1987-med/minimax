
import React, { useState } from 'react';
import { ImageModal } from "@/components/ui/image-modal";
import { SIMDUTCard } from './cards/SIMDUTCard';
import { CarteInfoSection } from './cards/CarteInfoSection';

interface CardsSectionProps {
  carteSIMDUT: string;
  carteSIMDUTName: string;
  estCadre: boolean;
  carteASP: string;
  carteASPName: string;
  carteCCQ: string;
  carteCCQName: string;
  numeroClient: string;
  dateEcheanceCarte?: Date;
  dateAccueil?: Date;
  onCarteSIMDUTChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteSIMDUTRemove?: () => void;
  onEstCadreChange: (checked: boolean) => void;
  onCarteASPChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteASPRemove?: () => void;
  onCarteCCQChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteCCQRemove?: () => void;
  onNumeroClientChange: (value: string) => void;
  onDateEcheangeCarteChange: (date?: Date) => void;
}

export const CardsSection = ({
  carteSIMDUT,
  carteSIMDUTName,
  estCadre,
  carteASP,
  carteASPName,
  carteCCQ,
  carteCCQName,
  numeroClient,
  dateEcheanceCarte,
  dateAccueil,
  onCarteSIMDUTChange,
  onCarteSIMDUTRemove,
  onEstCadreChange,
  onCarteASPChange,
  onCarteASPRemove,
  onCarteCCQChange,
  onCarteCCQRemove,
  onNumeroClientChange,
  onDateEcheangeCarteChange
}: CardsSectionProps) => {
  const [modalImage, setModalImage] = useState<{ url: string; title: string } | null>(null);

  const openImageModal = (imageUrl: string, title: string) => {
    setModalImage({ url: imageUrl, title });
  };

  const closeImageModal = () => {
    setModalImage(null);
  };

  return (
    <div className="space-y-4">
      <SIMDUTCard
        carteSIMDUT={carteSIMDUT}
        carteSIMDUTName={carteSIMDUTName}
        onCarteSIMDUTChange={onCarteSIMDUTChange}
        onCarteSIMDUTRemove={onCarteSIMDUTRemove}
        onImageClick={openImageModal}
      />

      <CarteInfoSection
        estCadre={estCadre}
        carteASP={carteASP}
        carteASPName={carteASPName}
        carteCCQ={carteCCQ}
        carteCCQName={carteCCQName}
        numeroClient={numeroClient}
        dateEcheanceCarte={dateEcheanceCarte}
        dateAccueil={dateAccueil}
        onEstCadreChange={onEstCadreChange}
        onCarteASPChange={onCarteASPChange}
        onCarteASPRemove={onCarteASPRemove}
        onCarteCCQChange={onCarteCCQChange}
        onCarteCCQRemove={onCarteCCQRemove}
        onNumeroClientChange={onNumeroClientChange}
        onDateEcheangeCarteChange={onDateEcheangeCarteChange}
        onImageClick={openImageModal}
      />

      {modalImage && (
        <ImageModal
          isOpen={true}
          onClose={closeImageModal}
          imageUrl={modalImage.url}
          title={modalImage.title}
        />
      )}
    </div>
  );
};
