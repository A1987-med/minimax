import React from 'react';
import { PersonalInfoSection } from './PersonalInfoSection';
import { OccupationSelector } from './OccupationSelector';
import { ContactInfoSection } from './ContactInfoSection';
import { CardsSection } from './CardsSection';
import { FormationsSection } from './FormationsSection';
import { SecouristeSection } from './SecouristeSection';
import { HealthSection } from './HealthSection';
import { AccidentsSection } from './AccidentsSection';
import { SanctionsSection } from './SanctionsSection';
import { Button } from "@/components/ui/button";
import { UserPlus } from "lucide-react";

interface AvisVerbal {
  date: string;
  nature: string;
}

interface AvisEcrit {
  date: string;
  nature: string;
}

interface AccidentData {
  aAccident: boolean;
  dateAccident: string;
  typeBlessure: string;
  partieCorpsAtteinte: string;
  natureAccident: string;
  joursPermis: string;
  naturePerte: string;
  abandonTravail: boolean;
  joursAbsence: string;
  consultationMedecin: boolean;
  transportHopital: boolean;
  temoin1: string;
  temoin2: string;
  observations: string;
}

interface WorkerFormProps {
  prenom: string;
  nom: string;
  dateNaissance?: Date;
  selectedOccupations: string[];
  dateAccueil?: Date;
  etiquetteRecue: boolean;
  numeroEtiquette: string;
  estContremaitre: boolean;
  estSousTraitant: boolean;
  nomSousTraitant: string;
  cellulaireTravailleur: string;
  numeroImmatriculation: string;
  nomContactAccident: string;
  cellulaireContact: string;
  estCadre: boolean;
  carteASP: string;
  carteASPName: string;
  carteCCQ: string;
  carteCCQName: string;
  numeroClient: string;
  dateEcheanceCarte?: Date;
  carteSIMDUT: string;
  carteSIMDUTName: string;
  selectedFormations: string[];
  cartesFormations: Record<string, { active: boolean; image?: string; imageName?: string; }>;
  estSecouriste: boolean;
  carteSecouriste: string;
  carteSecouristeName: string;
  dateEcheancierSecouriste?: Date;
  maladie: string;
  allergie: string;
  avisVerbaux: AvisVerbal[];
  avisEcrits: AvisEcrit[];
  dateExpulsionTemporaire?: string;
  dateExpulsionDefinitive?: string;
  accidentData: AccidentData;
  onPrenomChange: (value: string) => void;
  onNomChange: (value: string) => void;
  onDateNaissanceChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onOccupationToggle: (occupation: string) => void;
  onDateAccueilChange: (date?: Date) => void;
  onEtiquetteRecueChange: (checked: boolean) => void;
  onNumeroEtiquetteChange: (value: string) => void;
  onEstContremaitreChange: (checked: boolean) => void;
  onEstSousTraitantChange: (checked: boolean) => void;
  onNomSousTraitantChange: (value: string) => void;
  onCellulaireTravailleurChange: (value: string) => void;
  onNumeroImmatriculationChange: (value: string) => void;
  onNomContactAccidentChange: (value: string) => void;
  onCellulaireContactChange: (value: string) => void;
  onEstCadreChange: (checked: boolean) => void;
  onCarteASPChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteCCQChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onNumeroClientChange: (value: string) => void;
  onDateEcheangeCarteChange: (date?: Date) => void;
  onCarteASPRemove?: () => void;
  onCarteCCQRemove?: () => void;
  onCarteSIMDUTChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteSIMDUTRemove?: () => void;
  onFormationToggle: (formation: string) => void;
  onCarteFormationToggle: (formation: string, active: boolean) => void;
  onCarteFormationImageChange: (formation: string, event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteFormationImageRemove: (formation: string) => void;
  onEstSecouristeChange: (checked: boolean) => void;
  onCarteSecouristeChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteSecouristeRemove?: () => void;
  onDateEcheancierSecouristeChange: (date?: Date) => void;
  onMaladieChange: (value: string) => void;
  onAllergieChange: (value: string) => void;
  onAvisVerbauxChange: (avis: AvisVerbal[]) => void;
  onAvisEcritsChange: (avis: AvisEcrit[]) => void;
  onDateExpulsionTemporaireChange: (date: string) => void;
  onDateExpulsionDefinitiveChange: (date: string) => void;
  onAccidentDataChange: (data: AccidentData) => void;
  onSubmit: (e: React.FormEvent) => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const WorkerForm = ({
  prenom,
  nom,
  dateNaissance,
  selectedOccupations,
  dateAccueil,
  etiquetteRecue,
  numeroEtiquette,
  estContremaitre,
  estSousTraitant,
  nomSousTraitant,
  cellulaireTravailleur,
  numeroImmatriculation,
  nomContactAccident,
  cellulaireContact,
  estCadre,
  carteASP,
  carteASPName,
  carteCCQ,
  carteCCQName,
  numeroClient,
  dateEcheanceCarte,
  carteSIMDUT,
  carteSIMDUTName,
  selectedFormations,
  cartesFormations,
  estSecouriste,
  carteSecouriste,
  carteSecouristeName,
  dateEcheancierSecouriste,
  maladie,
  allergie,
  avisVerbaux,
  avisEcrits,
  dateExpulsionTemporaire,
  dateExpulsionDefinitive,
  accidentData,
  onPrenomChange,
  onNomChange,
  onDateNaissanceChange,
  onOccupationToggle,
  onDateAccueilChange,
  onEtiquetteRecueChange,
  onNumeroEtiquetteChange,
  onEstContremaitreChange,
  onEstSousTraitantChange,
  onNomSousTraitantChange,
  onCellulaireTravailleurChange,
  onNumeroImmatriculationChange,
  onNomContactAccidentChange,
  onCellulaireContactChange,
  onEstCadreChange,
  onCarteASPChange,
  onCarteCCQChange,
  onNumeroClientChange,
  onDateEcheangeCarteChange,
  onCarteASPRemove,
  onCarteCCQRemove,
  onCarteSIMDUTChange,
  onCarteSIMDUTRemove,
  onFormationToggle,
  onCarteFormationToggle,
  onCarteFormationImageChange,
  onCarteFormationImageRemove,
  onEstSecouristeChange,
  onCarteSecouristeChange,
  onCarteSecouristeRemove,
  onDateEcheancierSecouristeChange,
  onMaladieChange,
  onAllergieChange,
  onAvisVerbauxChange,
  onAvisEcritsChange,
  onDateExpulsionTemporaireChange,
  onDateExpulsionDefinitiveChange,
  onAccidentDataChange,
  onSubmit,
  onASTNavigation
}: WorkerFormProps) => {

  console.log('🎨 WORKER FORM - Rendu du composant');
  console.log('🎨 WORKER FORM - selectedFormations:', selectedFormations);
  console.log('🎨 WORKER FORM - estSecouriste:', estSecouriste);
  console.log('🎨 WORKER FORM - avisVerbaux:', avisVerbaux);
  console.log('🎨 WORKER FORM - accidentData:', accidentData);

  return (
    <div className="space-y-6">
      <form onSubmit={onSubmit} className="space-y-6">
        <PersonalInfoSection
          prenom={prenom}
          nom={nom}
          dateNaissance={dateNaissance}
          dateAccueil={dateAccueil}
          onPrenomChange={onPrenomChange}
          onNomChange={onNomChange}
          onDateNaissanceChange={onDateNaissanceChange}
          onDateAccueilChange={onDateAccueilChange}
        />

        <OccupationSelector
          selectedOccupations={selectedOccupations}
          onOccupationToggle={onOccupationToggle}
          onASTNavigation={onASTNavigation}
        />

        <ContactInfoSection
          etiquetteRecue={etiquetteRecue}
          numeroEtiquette={numeroEtiquette}
          estContremaitre={estContremaitre}
          estSousTraitant={estSousTraitant}
          nomSousTraitant={nomSousTraitant}
          cellulaireTravailleur={cellulaireTravailleur}
          numeroImmatriculation={numeroImmatriculation}
          nomContactAccident={nomContactAccident}
          cellulaireContact={cellulaireContact}
          onEtiquetteRecueChange={onEtiquetteRecueChange}
          onNumeroEtiquetteChange={onNumeroEtiquetteChange}
          onEstContremaitreChange={onEstContremaitreChange}
          onEstSousTraitantChange={onEstSousTraitantChange}
          onNomSousTraitantChange={onNomSousTraitantChange}
          onCellulaireTravailleurChange={onCellulaireTravailleurChange}
          onNumeroImmatriculationChange={onNumeroImmatriculationChange}
          onNomContactAccidentChange={onNomContactAccidentChange}
          onCellulaireContactChange={onCellulaireContactChange}
        />

        <CardsSection
          carteSIMDUT={carteSIMDUT}
          carteSIMDUTName={carteSIMDUTName}
          estCadre={estCadre}
          carteASP={carteASP}
          carteASPName={carteASPName}
          carteCCQ={carteCCQ}
          carteCCQName={carteCCQName}
          numeroClient={numeroClient}
          dateEcheanceCarte={dateEcheanceCarte}
          dateAccueil={dateAccueil}
          onCarteSIMDUTChange={onCarteSIMDUTChange}
          onCarteSIMDUTRemove={onCarteSIMDUTRemove}
          onEstCadreChange={onEstCadreChange}
          onCarteASPChange={onCarteASPChange}
          onCarteASPRemove={onCarteASPRemove}
          onCarteCCQChange={onCarteCCQChange}
          onCarteCCQRemove={onCarteCCQRemove}
          onNumeroClientChange={onNumeroClientChange}
          onDateEcheangeCarteChange={onDateEcheangeCarteChange}
        />

        <FormationsSection
          selectedFormations={selectedFormations}
          cartesFormations={cartesFormations}
          onFormationToggle={onFormationToggle}
          onCarteFormationToggle={onCarteFormationToggle}
          onCarteFormationImageChange={onCarteFormationImageChange}
          onCarteFormationImageRemove={onCarteFormationImageRemove}
        />

        <SecouristeSection
          estSecouriste={estSecouriste}
          carteSecouriste={carteSecouriste}
          carteSecouristeName={carteSecouristeName}
          dateEcheancierSecouriste={dateEcheancierSecouriste}
          dateAccueil={dateAccueil}
          onEstSecouristeChange={onEstSecouristeChange}
          onCarteSecouristeChange={onCarteSecouristeChange}
          onCarteSecouristeRemove={onCarteSecouristeRemove}
          onDateEcheancierSecouristeChange={onDateEcheancierSecouristeChange}
        />

        <HealthSection
          maladie={maladie}
          allergie={allergie}
          onMaladieChange={onMaladieChange}
          onAllergieChange={onAllergieChange}
        />

        <AccidentsSection
          accidentData={accidentData}
          nomContactAccident={nomContactAccident}
          cellulaireContact={cellulaireContact}
          onAccidentDataChange={onAccidentDataChange}
        />

        <SanctionsSection
          avisVerbaux={avisVerbaux}
          avisEcrits={avisEcrits}
          dateExpulsionTemporaire={dateExpulsionTemporaire}
          dateExpulsionDefinitive={dateExpulsionDefinitive}
          onAvisVerbauxChange={onAvisVerbauxChange}
          onAvisEcritsChange={onAvisEcritsChange}
          onDateExpulsionTemporaireChange={onDateExpulsionTemporaireChange}
          onDateExpulsionDefinitiveChange={onDateExpulsionDefinitiveChange}
        />
      </form>

      {/* Bouton d'enregistrement - TOUJOURS VISIBLE EN DEHORS DU FORM */}
      <div className="flex justify-center pt-6 border-t border-gray-200 bg-white sticky bottom-0 z-10 pb-4">
        <Button 
          onClick={onSubmit}
          type="button"
          size="lg"
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-semibold shadow-lg"
        >
          <UserPlus className="w-5 h-5" />
          Enregistrer l'entrée
        </Button>
      </div>
    </div>
  );
};
