
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Upload, Building2 } from "lucide-react";
import { soustraitants, corpsEtat } from '@/constants/soustraitants';

interface EnterpriseFormProps {
  logo: string;
  logoName: string;
  soustraitant: string;
  corpsMetier: string;
  onLogoChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onSoustraitantChange: (value: string) => void;
  onCorpsMetierChange: (value: string) => void;
}

export const EnterpriseForm = ({
  logo,
  logoName,
  soustraitant,
  corpsMetier,
  onLogoChange,
  onSoustraitantChange,
  onCorpsMetierChange
}: EnterpriseFormProps) => {
  const handleSoustraitantChange = (value: string) => {
    onSoustraitantChange(value);
  };

  const handleCorpsMetierChange = (value: string) => {
    onCorpsMetierChange(value);
  };

  return (
    <div className="space-y-4 p-4 bg-orange-50 dark:bg-orange-950/20 rounded-lg border border-orange-200 dark:border-orange-800/30">
      <div className="flex items-center gap-2 mb-4">
        <Building2 className="w-5 h-5 text-orange-600 dark:text-orange-400" />
        <h3 className="text-lg font-semibold text-orange-700 dark:text-orange-300">Informations Entreprise</h3>
      </div>

      {/* Logo de l'entreprise */}
      <div className="space-y-2">
        <Label htmlFor="logo">Logo de l'entreprise</Label>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Input
              id="logo"
              type="file"
              accept="image/*"
              onChange={onLogoChange}
              className="hidden"
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => document.getElementById('logo')?.click()}
              className="flex items-center gap-2"
            >
              <Upload className="w-4 h-4" />
              Choisir une image
            </Button>
          </div>
          {logo && (
            <div className="w-20 h-20 border border-border rounded-lg overflow-hidden">
              <img
                src={logo}
                alt="Logo entreprise"
                className="w-full h-full object-contain"
              />
            </div>
          )}
        </div>
      </div>

      {/* Sous-traitants et Corps d'état */}
      <div className="grid grid-cols-1 gap-4">
        <div className="space-y-2">
          <Label htmlFor="soustraitant">Sous-traitants *</Label>
          <Select value={soustraitant} onValueChange={handleSoustraitantChange}>
            <SelectTrigger>
              <SelectValue placeholder="Sélectionner un sous-traitant" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50">
              {soustraitants.map((item) => (
                <SelectItem key={item} value={item}>
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="corps-etat">Corps d'état *</Label>
          <Select value={corpsMetier} onValueChange={handleCorpsMetierChange}>
            <SelectTrigger>
              <SelectValue placeholder="Sélectionner un corps d'état" />
            </SelectTrigger>
            <SelectContent className="bg-popover border border-border shadow-lg z-50 max-h-60">
              {corpsEtat.map((item) => (
                <SelectItem key={item} value={item}>
                  {item}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
};
