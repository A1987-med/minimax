
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { User, CalendarIcon } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface PersonalInfoSectionProps {
  prenom: string;
  nom: string;
  dateNaissance?: Date;
  dateAccueil?: Date;
  onPrenomChange: (value: string) => void;
  onNomChange: (value: string) => void;
  onDateNaissanceChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onDateAccueilChange: (date?: Date) => void;
}

export const PersonalInfoSection = ({
  prenom,
  nom,
  dateNaissance,
  dateAccueil,
  onPrenomChange,
  onNomChange,
  onDateNaissanceChange,
  onDateAccueilChange
}: PersonalInfoSectionProps) => {
  const calculateAge = (birthDate: Date): number => {
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  return (
    <div className="space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
      {/* Header avec titre et date d'accueil en haut à droite */}
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-2">
          <User className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-blue-700">Informations Personnelles</h3>
        </div>
        
        {/* Date d'accueil - centrée avec son champ */}
        <div className="flex flex-col items-center space-y-2 min-w-[160px]">
          <Label htmlFor="dateAccueil" className="text-sm font-medium text-blue-700 text-center">
            Date d'accueil
          </Label>
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className={cn(
                  "w-full h-9 text-sm justify-start text-left font-normal border-blue-300 hover:border-blue-500",
                  !dateAccueil && "text-muted-foreground"
                )}
              >
                <CalendarIcon className="mr-2 h-4 w-4 text-blue-600" />
                {dateAccueil ? format(dateAccueil, "dd/MM/yyyy") : "Sélectionner"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0 z-[100]" align="end" side="bottom">
              <Calendar
                mode="single"
                selected={dateAccueil}
                onSelect={onDateAccueilChange}
                className="pointer-events-auto rounded-md border bg-white shadow-lg"
              />
            </PopoverContent>
          </Popover>
        </div>
      </div>

      {/* Informations personnelles */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="prenom">Prénom *</Label>
          <Input
            id="prenom"
            value={prenom}
            onChange={(e) => onPrenomChange(e.target.value)}
            placeholder="Prénom du travailleur"
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="nom">Nom *</Label>
          <Input
            id="nom"
            value={nom}
            onChange={(e) => onNomChange(e.target.value)}
            placeholder="Nom du travailleur"
            required
          />
        </div>
      </div>

      {/* Nom complet (automatique) */}
      {(prenom || nom) && (
        <div className="space-y-2">
          <Label>Nom de l'employé</Label>
          <div className="p-2 bg-gray-50 rounded-md text-gray-700">
            {`${prenom} ${nom}`.trim()}
          </div>
        </div>
      )}

      {/* Date de naissance et âge */}
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="dateNaissance">Date de naissance</Label>
          <Input
            id="dateNaissance"
            type="date"
            value={dateNaissance ? format(dateNaissance, "yyyy-MM-dd") : ""}
            onChange={onDateNaissanceChange}
            max={format(new Date(), "yyyy-MM-dd")}
            min="1900-01-01"
            className="w-40"
          />
        </div>
        <div className="space-y-2">
          <Label>Âge (ans)</Label>
          <div className="p-2 bg-gray-50 rounded-md text-gray-700">
            {dateNaissance ? `${calculateAge(dateNaissance)} ans` : '-'}
          </div>
        </div>
      </div>
    </div>
  );
};
