import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Users, Mail, Phone } from "lucide-react";

interface ContactInfoSectionProps {
  etiquetteRecue: boolean;
  numeroEtiquette: string;
  estContremaitre: boolean;
  estSousTraitant: boolean;
  nomSousTraitant: string;
  cellulaireTravailleur: string;
  numeroImmatriculation: string;
  nomContactAccident: string;
  cellulaireContact: string;
  onEtiquetteRecueChange: (checked: boolean) => void;
  onNumeroEtiquetteChange: (value: string) => void;
  onEstContremaitreChange: (checked: boolean) => void;
  onEstSousTraitantChange: (checked: boolean) => void;
  onNomSousTraitantChange: (value: string) => void;
  onCellulaireTravailleurChange: (value: string) => void;
  onNumeroImmatriculationChange: (value: string) => void;
  onNomContactAccidentChange: (value: string) => void;
  onCellulaireContactChange: (value: string) => void;
}

export const ContactInfoSection = ({
  etiquetteRecue,
  numeroEtiquette,
  estContremaitre,
  estSousTraitant,
  nomSousTraitant,
  cellulaireTravailleur,
  numeroImmatriculation,
  nomContactAccident,
  cellulaireContact,
  onEtiquetteRecueChange,
  onNumeroEtiquetteChange,
  onEstContremaitreChange,
  onEstSousTraitantChange,
  onNomSousTraitantChange,
  onCellulaireTravailleurChange,
  onNumeroImmatriculationChange,
  onNomContactAccidentChange,
  onCellulaireContactChange
}: ContactInfoSectionProps) => {
  const [contremaitreEmail, setContremaitreEmail] = React.useState('');

  const handleEmailClick = () => {
    if (contremaitreEmail) {
      try {
        const mailtoLink = `mailto:${contremaitreEmail}`;
        window.open(mailtoLink);
      } catch (error) {
        window.location.href = `mailto:${contremaitreEmail}`;
      }
    }
  };

  const handlePhoneClick = (phoneNumber: string) => {
    if (phoneNumber) {
      try {
        // Nettoyer le numéro pour l'appel
        const cleanNumber = phoneNumber.replace(/[^\d]/g, '');
        window.open(`tel:+1${cleanNumber}`);
      } catch (error) {
        window.location.href = `tel:+1${phoneNumber.replace(/[^\d]/g, '')}`;
      }
    }
  };

  const formatCanadianPhone = (value: string) => {
    // Enlever tous les caractères non numériques
    const numbers = value.replace(/[^\d]/g, '');
    
    // Limiter à 10 chiffres
    const limited = numbers.slice(0, 10);
    
    // Formater selon le pattern canadien (XXX) XXX-XXXX
    if (limited.length >= 6) {
      return `(${limited.slice(0, 3)}) ${limited.slice(3, 6)}-${limited.slice(6)}`;
    } else if (limited.length >= 3) {
      return `(${limited.slice(0, 3)}) ${limited.slice(3)}`;
    } else {
      return limited;
    }
  };

  const handleCellulaireTravailleurChange = (value: string) => {
    const formatted = formatCanadianPhone(value);
    onCellulaireTravailleurChange(formatted);
  };

  const handleCellulaireContactChange = (value: string) => {
    const formatted = formatCanadianPhone(value);
    onCellulaireContactChange(formatted);
  };

  console.log('ContactInfoSection - estContremaitre:', estContremaitre);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          Informations de Contact
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Étiquette reçue */}
        <div className="flex items-center space-x-2">
          <Checkbox
            id="etiquette-recue"
            checked={etiquetteRecue}
            onCheckedChange={onEtiquetteRecueChange}
          />
          <Label htmlFor="etiquette-recue">Étiquette reçue</Label>
        </div>

        {etiquetteRecue && (
          <div className="space-y-2">
            <Label htmlFor="numero-etiquette">Numéro d'étiquette</Label>
            <Input
              id="numero-etiquette"
              value={numeroEtiquette}
              onChange={(e) => onNumeroEtiquetteChange(e.target.value)}
              placeholder="Numéro d'étiquette"
            />
          </div>
        )}

        {/* Contremaître */}
        <div className="flex items-center space-x-2">
          <Checkbox
            id="est-contremaitre"
            checked={estContremaitre}
            onCheckedChange={onEstContremaitreChange}
          />
          <Label htmlFor="est-contremaitre">Contremaître</Label>
        </div>

        {/* Champ email pour contremaître */}
        {estContremaitre && (
          <div className="mt-4 space-y-2 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <Label htmlFor="contremaitre-email">Email du contremaître</Label>
            <div className="flex gap-2">
              <Input
                id="contremaitre-email"
                type="email"
                placeholder="email@example.com"
                value={contremaitreEmail}
                onChange={(e) => setContremaitreEmail(e.target.value)}
                className="flex-1"
              />
              {contremaitreEmail && (
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={handleEmailClick}
                  className="flex items-center gap-2 px-3 py-2 text-sm bg-blue-50 hover:bg-blue-100 text-blue-700 border-blue-200"
                >
                  <Mail className="w-4 h-4" />
                  Contacter
                </Button>
              )}
            </div>
          </div>
        )}

        {/* Sous-traitant */}
        <div className="flex items-center space-x-2">
          <Checkbox
            id="est-sous-traitant"
            checked={estSousTraitant}
            onCheckedChange={onEstSousTraitantChange}
          />
          <Label htmlFor="est-sous-traitant">Sous-traitant</Label>
        </div>

        {estSousTraitant && (
          <div className="space-y-2">
            <Label htmlFor="nom-sous-traitant">Nom du sous-traitant</Label>
            <Input
              id="nom-sous-traitant"
              value={nomSousTraitant}
              onChange={(e) => onNomSousTraitantChange(e.target.value)}
              placeholder="Nom du sous-traitant"
            />
          </div>
        )}

        {/* Cellulaire du travailleur */}
        <div className="space-y-2">
          <Label htmlFor="cellulaire-travailleur">Téléphone du travailleur</Label>
          <div className="flex gap-2">
            <Input
              id="cellulaire-travailleur"
              value={cellulaireTravailleur}
              onChange={(e) => handleCellulaireTravailleurChange(e.target.value)}
              placeholder="(XXX) XXX-XXXX"
              className="flex-1"
            />
            {cellulaireTravailleur && cellulaireTravailleur.replace(/[^\d]/g, '').length === 10 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handlePhoneClick(cellulaireTravailleur)}
                className="flex items-center gap-2 px-3 py-2 text-sm bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
              >
                <Phone className="w-4 h-4" />
                Appeler
              </Button>
            )}
          </div>
        </div>

        {/* Numéro d'immatriculation du véhicule */}
        <div className="space-y-2">
          <Label htmlFor="numero-immatriculation">Numéro d'immatriculation du véhicule</Label>
          <Input
            id="numero-immatriculation"
            value={numeroImmatriculation}
            onChange={(e) => onNumeroImmatriculationChange(e.target.value)}
            placeholder="Numéro d'immatriculation du véhicule"
          />
        </div>

        {/* Contact en cas d'accident */}
        <div className="space-y-2">
          <Label htmlFor="nom-contact-accident">Nom du contact en cas d'accident</Label>
          <Input
            id="nom-contact-accident"
            value={nomContactAccident}
            onChange={(e) => onNomContactAccidentChange(e.target.value)}
            placeholder="Nom du contact"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="cellulaire-contact">Téléphone du contact</Label>
          <div className="flex gap-2">
            <Input
              id="cellulaire-contact"
              value={cellulaireContact}
              onChange={(e) => handleCellulaireContactChange(e.target.value)}
              placeholder="(XXX) XXX-XXXX"
              className="flex-1"
            />
            {cellulaireContact && cellulaireContact.replace(/[^\d]/g, '').length === 10 && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => handlePhoneClick(cellulaireContact)}
                className="flex items-center gap-2 px-3 py-2 text-sm bg-green-50 hover:bg-green-100 text-green-700 border-green-200"
              >
                <Phone className="w-4 h-4" />
                Appeler
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
