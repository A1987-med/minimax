
import React from 'react';
import { Button } from "@/components/ui/button";
import { Edit, Trash2, Building2 } from "lucide-react";

interface EnrichedSoustraitant {
  id: string;
  nom: string;
  actif: boolean;
  logo?: string | null;
  corpsMetiers?: string[];
  nombreEmployes?: number;
}

interface SoustraitantCardProps {
  soustraitant: EnrichedSoustraitant;
  onEdit: (soustraitant: EnrichedSoustraitant) => void;
  onDelete: (id: string) => void;
  onToggleActif: (id: string) => void;
  isLoading: boolean;
}

export const SoustraitantCard = ({ 
  soustraitant, 
  onEdit, 
  onDelete, 
  onToggleActif, 
  isLoading 
}: SoustraitantCardProps) => {
  return (
    <div
      className={`flex items-center justify-between p-4 rounded-lg border ${
        soustraitant.actif ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'
      }`}
    >
      <div className="flex items-center gap-4 flex-1">
        {/* Logo de l'entreprise */}
        <div className="w-12 h-12 flex-shrink-0">
          {soustraitant.logo ? (
            <img 
              src={soustraitant.logo} 
              alt={`Logo ${soustraitant.nom}`}
              className="w-12 h-12 object-cover rounded-lg border border-gray-200"
              onError={(e) => {
                e.currentTarget.style.display = 'none';
                const nextElement = e.currentTarget.nextElementSibling as HTMLElement;
                if (nextElement) {
                  nextElement.style.display = 'flex';
                }
              }}
            />
          ) : null}
          {/* Fallback en cas d'erreur ou absence de logo */}
          <div 
            className="w-12 h-12 bg-gray-200 rounded-lg flex items-center justify-center" 
            style={{ display: soustraitant.logo ? 'none' : 'flex' }}
          >
            <Building2 className="w-6 h-6 text-gray-400" />
          </div>
        </div>
        
        {/* Informations du sous-traitant */}
        <div className="flex-1 min-w-0">
          <div className="font-medium text-gray-900 truncate">{soustraitant.nom}</div>
          
          {/* Corps d'état */}
          {soustraitant.corpsMetiers && soustraitant.corpsMetiers.length > 0 && (
            <div className="mt-1">
              <div className="flex flex-wrap gap-1">
                {soustraitant.corpsMetiers.map((corps: string, index: number) => (
                  <span 
                    key={index}
                    className="inline-block px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded-md"
                  >
                    {corps}
                  </span>
                ))}
              </div>
            </div>
          )}
          
          {/* Nombre d'employés si disponible */}
          {soustraitant.nombreEmployes && soustraitant.nombreEmployes > 0 && (
            <div className="mt-1 text-xs text-gray-500">
              {soustraitant.nombreEmployes} employé{soustraitant.nombreEmployes > 1 ? 's' : ''} sur site
            </div>
          )}
        </div>
      </div>
      
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onToggleActif(soustraitant.id)}
          className={soustraitant.actif ? 'text-green-600' : 'text-gray-600'}
          disabled={isLoading}
        >
          {soustraitant.actif ? 'Actif' : 'Inactif'}
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onEdit(soustraitant)}
          disabled={isLoading}
        >
          <Edit className="w-4 h-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => onDelete(soustraitant.id)}
          className="text-red-600 hover:text-red-800"
          disabled={isLoading}
        >
          <Trash2 className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};
