
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Building2, X, Upload, Camera } from "lucide-react";
import { soustraitantCorpsEtatMap } from '@/constants/soustraitants';

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

interface EnterpriseFormWithManagerProps {
  logo: string;
  logoName: string;
  soustraitant: string;
  soustraitants: Soustraitant[];
  onLogoChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onSoustraitantChange: (value: string) => void;
  onCorpsMetierChange?: (value: string) => void;
}

export const EnterpriseFormWithManager = ({
  logo,
  logoName,
  soustraitant,
  soustraitants,
  onLogoChange,
  onSoustraitantChange,
  onCorpsMetierChange
}: EnterpriseFormWithManagerProps) => {
  const handleLogoRemove = () => {
    // Reset file input
    const fileInput = document.getElementById('logo-upload') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
    
    // Trigger onLogoChange with empty event to clear the logo
    const fakeEvent = {
      target: {
        files: null
      }
    } as React.ChangeEvent<HTMLInputElement>;
    onLogoChange(fakeEvent);
  };

  const handleImageClick = () => {
    const fileInput = document.getElementById('logo-upload') as HTMLInputElement;
    if (fileInput) {
      fileInput.click();
    }
  };

  const handleSoustraitantChange = (value: string) => {
    console.log('🏢 FORM - Sous-traitant sélectionné:', value);
    onSoustraitantChange(value);
    
    // Auto-mapping du corps d'état si la fonction est fournie
    if (onCorpsMetierChange) {
      const correspondingCorpsEtat = soustraitantCorpsEtatMap[value];
      if (correspondingCorpsEtat) {
        console.log('🎯 FORM - Corps d\'état mappé automatiquement:', correspondingCorpsEtat);
        onCorpsMetierChange(correspondingCorpsEtat);
      } else {
        console.log('⚠️ FORM - Aucun mapping trouvé pour:', value);
        onCorpsMetierChange('');
      }
    }
  };

  const activeSoustraitants = soustraitants.filter(s => s.actif);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-blue-600" />
          Informations Entreprise
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="logo-upload">Logo de l'entreprise</Label>
          <div className="mt-1">
            {/* Input caché */}
            <Input
              id="logo-upload"
              type="file"
              accept="image/*"
              onChange={onLogoChange}
              className="hidden"
            />
          </div>
        </div>

        <div className="flex items-start gap-4">
          {/* Zone d'image cliquable à gauche */}
          <div className="flex-shrink-0">
            {logo && logoName ? (
              <div className="relative">
                <div 
                  className="w-20 h-20 cursor-pointer rounded-lg border border-gray-200 shadow-sm overflow-hidden group hover:shadow-md transition-shadow"
                  onClick={handleImageClick}
                  title="Cliquer pour changer l'image"
                >
                  <img 
                    src={logo} 
                    alt="Logo entreprise" 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform" 
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                    <Camera className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={handleLogoRemove}
                  className="absolute -top-2 -right-2 h-6 w-6 p-0 bg-red-100 hover:bg-red-200 text-red-600 hover:text-red-800 rounded-full border border-red-300"
                >
                  <X className="w-3 h-3" />
                </Button>
              </div>
            ) : (
              <div 
                className="w-20 h-20 bg-gray-100 rounded-lg flex items-center justify-center border border-gray-200 cursor-pointer hover:bg-gray-150 hover:border-gray-300 transition-colors group"
                onClick={handleImageClick}
                title="Cliquer pour ajouter une image"
              >
                <div className="flex flex-col items-center gap-1">
                  <Upload className="w-6 h-6 text-gray-400 group-hover:text-gray-600 transition-colors" />
                  <span className="text-xs text-gray-400 group-hover:text-gray-600 transition-colors">Ajouter</span>
                </div>
              </div>
            )}
          </div>

          {/* Champ sous-traitant à droite */}
          <div className="flex-1">
            <Label htmlFor="soustraitant">Sous-traitant *</Label>
            <Select value={soustraitant} onValueChange={handleSoustraitantChange}>
              <SelectTrigger>
                <SelectValue placeholder="Sélectionner un sous-traitant" />
              </SelectTrigger>
              <SelectContent className="bg-popover border border-border shadow-lg z-50">
                {activeSoustraitants.length > 0 ? (
                  activeSoustraitants.map((st) => (
                    <SelectItem key={st.id} value={st.nom}>
                      {st.nom}
                    </SelectItem>
                  ))
                ) : (
                  <SelectItem value="no-data" disabled>
                    Aucun sous-traitant disponible
                  </SelectItem>
                )}
              </SelectContent>
            </Select>
            {activeSoustraitants.length === 0 && (
              <p className="text-sm text-amber-600 mt-1">
                💡 Ajoutez des sous-traitants dans la section "Gestion des sous-traitants"
              </p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
