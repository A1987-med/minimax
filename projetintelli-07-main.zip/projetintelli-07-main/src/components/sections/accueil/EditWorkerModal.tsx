import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar, CalendarIcon, X, Upload, ZoomIn } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import type { EntryData } from "./types";
import { formations } from "@/constants/formations";
import { occupations } from "@/constants/occupations";
import { ImageModal } from "@/components/ui/image-modal";

interface EditWorkerModalProps {
  entry: EntryData;
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<EntryData>) => void;
}

export const EditWorkerModal = ({ entry, isOpen, onClose, onSave }: EditWorkerModalProps) => {
  const [formData, setFormData] = useState<Partial<EntryData>>({});
  const [dateNaissance, setDateNaissance] = useState<Date | undefined>();
  const [dateAccueil, setDateAccueil] = useState<Date | undefined>();
  const [dateEcheancierSecouriste, setDateEcheancierSecouriste] = useState<Date | undefined>();
  const [dateEcheanceCarte, setDateEcheanceCarte] = useState<Date | undefined>();
  const [modalImage, setModalImage] = useState<{ url: string; title: string } | null>(null);

  useEffect(() => {
    if (entry) {
      setFormData({
        prenom: entry.prenom,
        nom: entry.nom,
        nomEmploye: entry.nomEmploye,
        entreprise: entry.entreprise,
        fonction: entry.fonction,
        corpsMetier: entry.corpsMetier,
        occupations: entry.occupations || [],
        age: entry.age,
        telephone: entry.telephone || '',
        courriel: entry.courriel || '',
        adresse: entry.adresse || '',
        ville: entry.ville || '',
        codePostal: entry.codePostal || '',
        numeroImmatriculation: entry.numeroImmatriculation || '',
        nomContactAccident: entry.nomContactAccident || '',
        cellulaireContact: entry.cellulaireContact || '',
        etiquetteRecue: entry.etiquetteRecue || false,
        numeroEtiquette: entry.numeroEtiquette || '',
        estContremaitre: entry.estContremaitre || false,
        estSousTraitant: entry.estSousTraitant || false,
        nomSousTraitant: entry.nomSousTraitant || '',
        estCadre: entry.estCadre || false,
        estSecouriste: entry.estSecouriste || false,
        selectedFormations: entry.selectedFormations || [],
        cartesFormations: entry.cartesFormations || {},
        carteSIMDUT: entry.carteSIMDUT || '',
        carteSIMDUTName: entry.carteSIMDUTName || '',
        carteASP: entry.carteASP || '',
        carteASPName: entry.carteASPName || '',
        carteCCQ: entry.carteCCQ || '',
        carteCCQName: entry.carteCCQName || '',
        numeroClient: entry.numeroClient || '',
        carteSecouriste: entry.carteSecouriste || '',
        carteSecouristeName: entry.carteSecouristeName || '',
        maladie: entry.maladie || '',
        allergie: entry.allergie || ''
      });

      // Parse dates
      if (entry.dateAccueil) {
        setDateAccueil(new Date(entry.dateAccueil));
      }
      if (entry.dateEcheancierSecouriste) {
        setDateEcheancierSecouriste(new Date(entry.dateEcheancierSecouriste));
      }
      if (entry.dateEcheanceCarte) {
        setDateEcheanceCarte(new Date(entry.dateEcheanceCarte));
      }
      // Calculer la date de naissance à partir de l'âge (approximatif)
      if (entry.age && entry.age > 0) {
        const currentYear = new Date().getFullYear();
        const birthYear = currentYear - entry.age;
        setDateNaissance(new Date(birthYear, 0, 1));
      }
    }
  }, [entry]);

  const handleInputChange = (field: keyof EntryData, value: any) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      // Mettre à jour nomEmploye quand prénom ou nom change
      ...(field === 'prenom' || field === 'nom' ? {
        nomEmploye: field === 'prenom' 
          ? `${value} ${formData.nom || ''}`.trim()
          : `${formData.prenom || ''} ${value}`.trim()
      } : {})
    }));
  };

  const handleFileUpload = (field: string, nameField: string, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        handleInputChange(field as keyof EntryData, e.target?.result as string);
        handleInputChange(nameField as keyof EntryData, file.name);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleImageRemove = (field: string, nameField: string) => {
    handleInputChange(field as keyof EntryData, '');
    handleInputChange(nameField as keyof EntryData, '');
  };

  const openImageModal = (imageUrl: string, title: string) => {
    setModalImage({ url: imageUrl, title });
  };

  const closeImageModal = () => {
    setModalImage(null);
  };

  const handleFormationToggle = (formation: string) => {
    const currentFormations = formData.selectedFormations || [];
    const newFormations = currentFormations.includes(formation)
      ? currentFormations.filter(f => f !== formation)
      : [...currentFormations, formation];
    
    handleInputChange('selectedFormations', newFormations);
  };

  const handleOccupationToggle = (occupation: string) => {
    const currentOccupations = formData.occupations || [];
    const newOccupations = currentOccupations.includes(occupation)
      ? currentOccupations.filter(o => o !== occupation)
      : [...currentOccupations, occupation];
    
    handleInputChange('occupations', newOccupations);
    handleInputChange('corpsMetier', newOccupations.join(', '));
  };

  const handleDateNaissanceChange = (date: Date | undefined) => {
    setDateNaissance(date);
    if (date) {
      const age = new Date().getFullYear() - date.getFullYear();
      handleInputChange('age', age);
    }
  };

  const handleSave = async () => {
    console.log('🔄 EDIT MODAL - Début de la sauvegarde');
    console.log('📦 EDIT MODAL - Données du formulaire:', formData);
    
    const updatedData = {
      ...formData,
      dateAccueil: dateAccueil?.toLocaleDateString('fr-CA') || '',
      dateEcheancierSecouriste: dateEcheancierSecouriste?.toLocaleDateString('fr-CA') || '',
      dateEcheanceCarte: dateEcheanceCarte?.toLocaleDateString('fr-CA') || ''
    };
    
    console.log('✅ EDIT MODAL - Données finales à sauvegarder:', updatedData);
    
    try {
      await onSave(updatedData);
      console.log('✅ EDIT MODAL - Sauvegarde réussie');
      onClose();
    } catch (error) {
      console.error('❌ EDIT MODAL - Erreur lors de la sauvegarde:', error);
    }
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Modifier le travailleur - {entry.nomEmploye}</DialogTitle>
          </DialogHeader>

          <div className="space-y-6">
            {/* Informations personnelles */}
            <div className="space-y-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
              <h3 className="text-lg font-semibold text-blue-700">Informations personnelles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="prenom">Prénom *</Label>
                  <Input
                    id="prenom"
                    value={formData.prenom || ''}
                    onChange={(e) => handleInputChange('prenom', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="nom">Nom *</Label>
                  <Input
                    id="nom"
                    value={formData.nom || ''}
                    onChange={(e) => handleInputChange('nom', e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Date de naissance</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateNaissance ? format(dateNaissance, "dd MMMM yyyy", { locale: fr }) : "Sélectionner une date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={dateNaissance}
                        onSelect={handleDateNaissanceChange}
                        locale={fr}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <Label htmlFor="age">Âge</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age || ''}
                    onChange={(e) => handleInputChange('age', parseInt(e.target.value) || 0)}
                  />
                </div>
              </div>
              <div>
                <Label>Date d'accueil</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateAccueil ? format(dateAccueil, "dd MMMM yyyy", { locale: fr }) : "Sélectionner une date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0">
                    <CalendarComponent
                      mode="single"
                      selected={dateAccueil}
                      onSelect={setDateAccueil}
                      locale={fr}
                    />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            {/* Corps de métier */}
            <div className="space-y-4 p-4 bg-green-50 rounded-lg border border-green-200">
              <h3 className="text-lg font-semibold text-green-700">Corps de métier</h3>
              <div className="flex flex-wrap gap-2">
                {occupations.map((occupation) => (
                  <Badge
                    key={occupation}
                    variant={formData.occupations?.includes(occupation) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => handleOccupationToggle(occupation)}
                  >
                    {occupation}
                    {formData.occupations?.includes(occupation) && (
                      <X className="ml-1 h-3 w-3" />
                    )}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Contact et informations professionnelles */}
            <div className="space-y-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
              <h3 className="text-lg font-semibold text-yellow-700">Contact et informations professionnelles</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="telephone">Téléphone</Label>
                  <Input
                    id="telephone"
                    value={formData.telephone || ''}
                    onChange={(e) => handleInputChange('telephone', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="courriel">Courriel</Label>
                  <Input
                    id="courriel"
                    type="email"
                    value={formData.courriel || ''}
                    onChange={(e) => handleInputChange('courriel', e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="adresse">Adresse</Label>
                  <Input
                    id="adresse"
                    value={formData.adresse || ''}
                    onChange={(e) => handleInputChange('adresse', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="ville">Ville</Label>
                  <Input
                    id="ville"
                    value={formData.ville || ''}
                    onChange={(e) => handleInputChange('ville', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="codePostal">Code postal</Label>
                  <Input
                    id="codePostal"
                    value={formData.codePostal || ''}
                    onChange={(e) => handleInputChange('codePostal', e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="numeroImmatriculation">Numéro d'immatriculation</Label>
                  <Input
                    id="numeroImmatriculation"
                    value={formData.numeroImmatriculation || ''}
                    onChange={(e) => handleInputChange('numeroImmatriculation', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="numeroEtiquette">Numéro d'étiquette</Label>
                  <Input
                    id="numeroEtiquette"
                    value={formData.numeroEtiquette || ''}
                    onChange={(e) => handleInputChange('numeroEtiquette', e.target.value)}
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="nomContactAccident">Nom contact d'urgence</Label>
                  <Input
                    id="nomContactAccident"
                    value={formData.nomContactAccident || ''}
                    onChange={(e) => handleInputChange('nomContactAccident', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="cellulaireContact">Cellulaire contact</Label>
                  <Input
                    id="cellulaireContact"
                    value={formData.cellulaireContact || ''}
                    onChange={(e) => handleInputChange('cellulaireContact', e.target.value)}
                  />
                </div>
              </div>
            </div>

            {/* Qualifications et statuts */}
            <div className="space-y-4 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <h3 className="text-lg font-semibold text-indigo-700">Qualifications et statuts</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="etiquetteRecue"
                    checked={formData.etiquetteRecue || false}
                    onCheckedChange={(checked) => handleInputChange('etiquetteRecue', checked)}
                  />
                  <Label htmlFor="etiquetteRecue">Étiquette reçue</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="estContremaitre"
                    checked={formData.estContremaitre || false}
                    onCheckedChange={(checked) => handleInputChange('estContremaitre', checked)}
                  />
                  <Label htmlFor="estContremaitre">Est contremaître</Label>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="estSousTraitant"
                    checked={formData.estSousTraitant || false}
                    onCheckedChange={(checked) => handleInputChange('estSousTraitant', checked)}
                  />
                  <Label htmlFor="estSousTraitant">Est sous-traitant</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="estCadre"
                    checked={formData.estCadre || false}
                    onCheckedChange={(checked) => handleInputChange('estCadre', checked)}
                  />
                  <Label htmlFor="estCadre">Est cadre</Label>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="estSecouriste"
                  checked={formData.estSecouriste || false}
                  onCheckedChange={(checked) => handleInputChange('estSecouriste', checked)}
                />
                <Label htmlFor="estSecouriste">Est secouriste</Label>
              </div>
              {formData.estSousTraitant && (
                <div>
                  <Label htmlFor="nomSousTraitant">Nom du sous-traitant</Label>
                  <Input
                    id="nomSousTraitant"
                    value={formData.nomSousTraitant || ''}
                    onChange={(e) => handleInputChange('nomSousTraitant', e.target.value)}
                  />
                </div>
              )}
            </div>

            {/* Section Cartes Professionnelles */}
            <div className="space-y-4 p-4 bg-purple-50 rounded-lg border border-purple-200">
              <h3 className="text-lg font-semibold text-purple-700">Cartes Professionnelles</h3>
              
              {/* Carte SIMDUT */}
              <div className="space-y-2">
                <Label>Carte SIMDUT 2015</Label>
                <div className="flex items-center gap-4">
                  <Input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleFileUpload('carteSIMDUT', 'carteSIMDUTName', e)}
                    className="hidden"
                    id="carteSIMDUT"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById('carteSIMDUT')?.click()}
                    className="flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    Choisir une image
                  </Button>
                  {formData.carteSIMDUT && (
                    <div className="flex items-center gap-2">
                      <div 
                        className="relative w-16 h-16 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                        onClick={() => openImageModal(formData.carteSIMDUT!, "Carte SIMDUT")}
                      >
                        <img
                          src={formData.carteSIMDUT}
                          alt="Carte SIMDUT"
                          className="w-full h-full object-contain transition-transform group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                          <ZoomIn className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      </div>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => handleImageRemove('carteSIMDUT', 'carteSIMDUTName')}
                        className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                </div>
                {formData.carteSIMDUTName && (
                  <p className="text-sm text-gray-500">{formData.carteSIMDUTName}</p>
                )}
              </div>

              {/* Carte ASP - visible seulement si cadre */}
              {formData.estCadre && (
                <div className="space-y-2 ml-6">
                  <Label>Carte ASP</Label>
                  <div className="flex items-center gap-4">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload('carteASP', 'carteASPName', e)}
                      className="hidden"
                      id="carteASP"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('carteASP')?.click()}
                      className="flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      Choisir une image
                    </Button>
                    {formData.carteASP && (
                      <div className="flex items-center gap-2">
                        <div 
                          className="relative w-16 h-16 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                          onClick={() => openImageModal(formData.carteASP!, "Carte ASP")}
                        >
                          <img
                            src={formData.carteASP}
                            alt="Carte ASP"
                            className="w-full h-full object-contain transition-transform group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                            <ZoomIn className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleImageRemove('carteASP', 'carteASPName')}
                          className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                  {formData.carteASPName && (
                    <p className="text-sm text-gray-500">{formData.carteASPName}</p>
                  )}
                </div>
              )}

              {/* Carte CCQ - visible seulement si non-cadre */}
              {!formData.estCadre && (
                <div className="space-y-3 ml-6">
                  <Label>Carte CCQ</Label>
                  <div className="flex items-center gap-4">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload('carteCCQ', 'carteCCQName', e)}
                      className="hidden"
                      id="carteCCQ"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('carteCCQ')?.click()}
                      className="flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      Choisir une image
                    </Button>
                    {formData.carteCCQ && (
                      <div className="flex items-center gap-2">
                        <div 
                          className="relative w-16 h-16 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                          onClick={() => openImageModal(formData.carteCCQ!, "Carte CCQ")}
                        >
                          <img
                            src={formData.carteCCQ}
                            alt="Carte CCQ"
                            className="w-full h-full object-contain transition-transform group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                            <ZoomIn className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleImageRemove('carteCCQ', 'carteCCQName')}
                          className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                  {formData.carteCCQName && (
                    <p className="text-sm text-gray-500">{formData.carteCCQName}</p>
                  )}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="numeroClient">Numéro client</Label>
                      <Input
                        id="numeroClient"
                        value={formData.numeroClient || ''}
                        onChange={(e) => handleInputChange('numeroClient', e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Date d'échéance carte</Label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="outline" className="w-full justify-start text-left">
                            <CalendarIcon className="mr-2 h-4 w-4" />
                            {dateEcheanceCarte ? format(dateEcheanceCarte, "dd MMMM yyyy", { locale: fr }) : "Sélectionner une date"}
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0">
                          <CalendarComponent
                            mode="single"
                            selected={dateEcheanceCarte}
                            onSelect={setDateEcheanceCarte}
                            locale={fr}
                          />
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Formations */}
            <div className="space-y-4 p-4 bg-orange-50 rounded-lg border border-orange-200">
              <h3 className="text-lg font-semibold text-orange-700">Formations</h3>
              <div className="flex flex-wrap gap-2">
                {formations.map((formation) => (
                  <Badge
                    key={formation}
                    variant={formData.selectedFormations?.includes(formation) ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => handleFormationToggle(formation)}
                  >
                    {formation}
                    {formData.selectedFormations?.includes(formation) && (
                      <X className="ml-1 h-3 w-3" />
                    )}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Section Secouriste */}
            {formData.estSecouriste && (
              <div className="space-y-4 p-4 bg-red-50 rounded-lg border border-red-200">
                <h3 className="text-lg font-semibold text-red-700">Secouriste</h3>
                <div className="space-y-2">
                  <Label>Carte Secouriste</Label>
                  <div className="flex items-center gap-4">
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleFileUpload('carteSecouriste', 'carteSecouristeName', e)}
                      className="hidden"
                      id="carteSecouriste"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => document.getElementById('carteSecouriste')?.click()}
                      className="flex items-center gap-2"
                    >
                      <Upload className="w-4 h-4" />
                      Choisir une image
                    </Button>
                    {formData.carteSecouriste && (
                      <div className="flex items-center gap-2">
                        <div 
                          className="relative w-16 h-16 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                          onClick={() => openImageModal(formData.carteSecouriste!, "Carte Secouriste")}
                        >
                          <img
                            src={formData.carteSecouriste}
                            alt="Carte Secouriste"
                            className="w-full h-full object-contain transition-transform group-hover:scale-105"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                            <ZoomIn className="w-4 h-4 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => handleImageRemove('carteSecouriste', 'carteSecouristeName')}
                          className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    )}
                  </div>
                  {formData.carteSecouristeName && (
                    <p className="text-sm text-gray-500">{formData.carteSecouristeName}</p>
                  )}
                </div>
                <div>
                  <Label>Date échéancier secouriste</Label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start text-left">
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {dateEcheancierSecouriste ? format(dateEcheancierSecouriste, "dd MMMM yyyy", { locale: fr }) : "Sélectionner une date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <CalendarComponent
                        mode="single"
                        selected={dateEcheancierSecouriste}
                        onSelect={setDateEcheancierSecouriste}
                        locale={fr}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
            )}

            {/* Santé */}
            <div className="space-y-4 p-4 bg-pink-50 rounded-lg border border-pink-200">
              <h3 className="text-lg font-semibold text-pink-700">Santé</h3>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="maladie">Maladie</Label>
                  <Textarea
                    id="maladie"
                    value={formData.maladie || ''}
                    onChange={(e) => handleInputChange('maladie', e.target.value)}
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="allergie">Allergie</Label>
                  <Textarea
                    id="allergie"
                    value={formData.allergie || ''}
                    onChange={(e) => handleInputChange('allergie', e.target.value)}
                    rows={3}
                  />
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex justify-end gap-2 pt-4 border-t">
              <Button variant="outline" onClick={onClose} type="button">
                Annuler
              </Button>
              <Button 
                onClick={handleSave}
                type="button"
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                Sauvegarder
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {modalImage && (
        <ImageModal
          isOpen={true}
          onClose={closeImageModal}
          imageUrl={modalImage.url}
          title={modalImage.title}
        />
      )}
    </>
  );
};
