
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Users, BarChart3 } from "lucide-react";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer } from "recharts";
import type { EntryData } from "./types";

interface FormationsListProps {
  entries: EntryData[];
}

export const FormationsList = ({ entries }: FormationsListProps) => {
  console.log('🎓 FORMATIONS LIST - Données reçues:', entries.length, 'entrées');

  // Collecter toutes les formations et calculer les statistiques
  const formationsStats = React.useMemo(() => {
    const formationsMap = new Map<string, number>();
    let totalWorkers = 0;
    let workersWithFormations = 0;

    entries.forEach(entry => {
      if (entry.selectedFormations && entry.selectedFormations.length > 0) {
        workersWithFormations++;
        entry.selectedFormations.forEach(formation => {
          formationsMap.set(formation, (formationsMap.get(formation) || 0) + 1);
        });
      }
      totalWorkers++;
    });

    // Convertir en tableau trié par nombre d'occurrences
    const formationsArray = Array.from(formationsMap.entries())
      .map(([formation, count]) => ({ formation, count }))
      .sort((a, b) => b.count - a.count);

    return {
      formationsArray,
      totalWorkers,
      workersWithFormations,
      totalFormationsCount: formationsArray.reduce((sum, item) => sum + item.count, 0)
    };
  }, [entries]);

  // Données pour le graphique principal - nombre de formations par travailleur
  const chartDataWorkers = React.useMemo(() => {
    return entries
      .map(entry => {
        const nomComplet = entry.nomEmploye.length > 15 ? entry.nomEmploye.substring(0, 15) + '...' : entry.nomEmploye;
        const entrepriseCourte = entry.entreprise.length > 15 ? entry.entreprise.substring(0, 15) + '...' : entry.entreprise;
        
        return {
          nom: nomComplet,
          entreprise: entrepriseCourte,
          nomAvecEntreprise: `${nomComplet}\n(${entrepriseCourte})`,
          fullNom: entry.nomEmploye,
          fullEntreprise: entry.entreprise,
          formations: entry.selectedFormations?.length || 0
        };
      })
      .sort((a, b) => b.formations - a.formations);
  }, [entries]);

  // Données pour le nouveau graphique - répartition par type de formation
  const chartDataFormations = React.useMemo(() => {
    return formationsStats.formationsArray.map(({ formation, count }) => ({
      formation: formation.length > 20 ? formation.substring(0, 20) + '...' : formation,
      fullFormation: formation,
      count
    }));
  }, [formationsStats.formationsArray]);

  const chartConfig = {
    formations: {
      label: "Formations",
    },
    count: {
      label: "Nombre",
    }
  };

  console.log('📊 FORMATIONS STATS:', formationsStats);
  console.log('📊 CHART DATA WORKERS:', chartDataWorkers);
  console.log('📊 CHART DATA FORMATIONS:', chartDataFormations);

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
          <GraduationCap className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Formations des travailleurs</h2>
          <p className="text-gray-600">Comparaison du nombre de formations par travailleur</p>
        </div>
      </div>

      {/* Statistiques générales */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{formationsStats.totalWorkers}</div>
            <div className="text-sm text-blue-700">Travailleurs total</div>
          </CardContent>
        </Card>
        
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{formationsStats.workersWithFormations}</div>
            <div className="text-sm text-green-700">Avec formations</div>
          </CardContent>
        </Card>
        
        <Card className="bg-purple-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{formationsStats.formationsArray.length}</div>
            <div className="text-sm text-purple-700">Types de formations</div>
          </CardContent>
        </Card>
        
        <Card className="bg-orange-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{formationsStats.totalFormationsCount}</div>
            <div className="text-sm text-orange-700">Total formations</div>
          </CardContent>
        </Card>
      </div>

      {/* Graphique principal - Nombre de formations par travailleur */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-blue-600" />
            Nombre de formations par travailleur
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-96">
            <BarChart data={chartDataWorkers} margin={{ bottom: 130, left: 20, right: 20, top: 20 }}>
              <XAxis 
                dataKey="nomAvecEntreprise"
                angle={-45}
                textAnchor="end"
                height={130}
                fontSize={10}
                interval={0}
                tick={{ fill: '#374151', fontSize: 10 }}
              />
              <YAxis 
                label={{ value: 'Nombre de formations', angle: -90, position: 'insideLeft' }}
              />
              <ChartTooltip 
                content={<ChartTooltipContent />}
                formatter={(value, name, props) => [
                  `${Number(value)} formation${Number(value) > 1 ? 's' : ''}`,
                  `${props.payload?.fullNom} - ${props.payload?.fullEntreprise}`
                ]}
              />
              <Bar dataKey="formations" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Nouveau graphique - Répartition par type de formation */}
      {chartDataFormations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-green-600" />
              Répartition par type de formation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-96">
              <BarChart data={chartDataFormations} margin={{ bottom: 100, left: 20, right: 20, top: 20 }}>
                <XAxis 
                  dataKey="formation" 
                  angle={-45}
                  textAnchor="end"
                  height={100}
                  fontSize={10}
                />
                <YAxis 
                  label={{ value: 'Nombre de formations', angle: -90, position: 'insideLeft' }}
                />
                <ChartTooltip 
                  content={<ChartTooltipContent />}
                  formatter={(value, name, props) => [
                    `${Number(value)} formation${Number(value) > 1 ? 's' : ''}`,
                    props.payload?.fullFormation
                  ]}
                />
                <Bar dataKey="count" fill="#10B981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
      )}

      {/* Liste des formations */}
      {formationsStats.formationsArray.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-blue-600" />
              Répartition des formations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {formationsStats.formationsArray.map(({ formation, count }) => (
                <div key={formation} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-800">{formation}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <Users className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">
                        {count} travailleur{count > 1 ? 's' : ''}
                      </span>
                    </div>
                  </div>
                  <Badge variant="outline" className="ml-4">
                    {count}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Liste détaillée par travailleur */}
      {formationsStats.workersWithFormations > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-green-600" />
              Détail par travailleur ({formationsStats.workersWithFormations})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {entries
                .filter(entry => entry.selectedFormations && entry.selectedFormations.length > 0)
                .map((entry) => (
                  <div key={entry.id} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-800">{entry.nomEmploye}</h4>
                        <p className="text-sm text-gray-600">{entry.entreprise}</p>
                        <div className="mt-2">
                          <span className="text-sm font-medium text-gray-700">Formations: </span>
                          <span className="text-sm text-gray-600">
                            {entry.selectedFormations?.join(', ') || 'Aucune'}
                          </span>
                        </div>
                      </div>
                      <Badge variant="secondary">
                        {entry.selectedFormations?.length || 0} formation{(entry.selectedFormations?.length || 0) > 1 ? 's' : ''}
                      </Badge>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Message si aucune formation */}
      {entries.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <GraduationCap className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">Aucune formation déclarée</h3>
            <p className="text-gray-500">
              Les formations des travailleurs apparaîtront ici une fois qu'elles seront renseignées dans leurs fiches d'accueil.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
