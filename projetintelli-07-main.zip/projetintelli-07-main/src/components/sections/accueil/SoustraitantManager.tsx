
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Settings, Search, Filter, Loader2, Upload, Download } from "lucide-react";
import { SoustraitantsList } from './SoustraitantsList';
import { SoustraitantDialog } from './SoustraitantDialog';
import { SoustraitantFilters } from './SoustraitantFilters';
import { useSoustraitantManager } from './useSoustraitantManager';
import type { EntryData } from "./types";

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

interface SoustraitantManagerProps {
  soustraitants: Soustraitant[];
  onSoustraitantsChange: (soustraitants: Soustraitant[]) => void;
  entries?: EntryData[];
}

export const SoustraitantManager = ({ soustraitants, onSoustraitantsChange, entries = [] }: SoustraitantManagerProps) => {
  const {
    isDialogOpen,
    setIsDialogOpen,
    editingSoustraitant,
    newSoustraitant,
    setNewSoustraitant,
    isLoading,
    searchTerm,
    setSearchTerm,
    filterStatut,
    setFilterStatut,
    filteredSoustraitants,
    handleAddSoustraitant,
    handleEditSoustraitant,
    handleUpdateSoustraitant,
    handleDeleteSoustraitant,
    handleToggleActif,
    handleExport,
    handleImport,
    resetDialog,
    clearFilters,
  } = useSoustraitantManager(soustraitants, onSoustraitantsChange, entries);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Settings className="w-5 h-5 text-blue-600" />
            Gestion des sous-traitants
            {isLoading && <Loader2 className="w-4 h-4 animate-spin" />}
          </div>
          <div className="flex gap-2">
            <input
              type="file"
              accept=".json"
              onChange={handleImport}
              className="hidden"
              id="import-file"
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => document.getElementById('import-file')?.click()}
              disabled={isLoading}
            >
              <Upload className="w-4 h-4 mr-1" />
              Importer
            </Button>
            <Button variant="outline" size="sm" onClick={handleExport} disabled={isLoading}>
              <Download className="w-4 h-4 mr-1" />
              Exporter
            </Button>
            
            <SoustraitantDialog 
              isOpen={isDialogOpen}
              onOpenChange={setIsDialogOpen}
              editingSoustraitant={editingSoustraitant}
              newSoustraitant={newSoustraitant}
              onNewSoustraitantChange={setNewSoustraitant}
              onAdd={handleAddSoustraitant}
              onUpdate={handleUpdateSoustraitant}
              onReset={resetDialog}
              isLoading={isLoading}
            />
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="list" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="list" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Liste
            </TabsTrigger>
            <TabsTrigger value="search" className="flex items-center gap-2">
              <Search className="w-4 h-4" />
              Recherche
            </TabsTrigger>
          </TabsList>

          <TabsContent value="list" className="mt-4">
            <SoustraitantsList 
              soustraitants={filteredSoustraitants} 
              onEdit={handleEditSoustraitant}
              onDelete={handleDeleteSoustraitant}
              onToggleActif={handleToggleActif}
              isLoading={isLoading}
            />
          </TabsContent>

          <TabsContent value="search" className="mt-4 space-y-4">
            <SoustraitantFilters 
              searchTerm={searchTerm}
              onSearchTermChange={setSearchTerm}
              filterStatut={filterStatut}
              onFilterStatutChange={setFilterStatut}
              onClearFilters={clearFilters}
              resultsCount={filteredSoustraitants.length}
              totalCount={soustraitants.length}
            />

            <SoustraitantsList 
              soustraitants={filteredSoustraitants}
              onEdit={handleEditSoustraitant}
              onDelete={handleDeleteSoustraitant}
              onToggleActif={handleToggleActif}
              isLoading={isLoading}
            />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};
