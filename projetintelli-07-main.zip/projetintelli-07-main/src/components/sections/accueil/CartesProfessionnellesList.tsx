
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CreditCard, AlertTriangle, CheckCircle, XCircle, Clock } from "lucide-react";
import type { EntryData } from "./types";

interface CartesProfessionnellesListProps {
  entries: EntryData[];
}

export const CartesProfessionnellesList = ({ entries }: CartesProfessionnellesListProps) => {
  console.log('💳 CARTES PROFESSIONNELLES - Données reçues:', entries.length, 'entrées');

  // Analyser l'état des cartes ASP
  const aspStats = React.useMemo(() => {
    let avecCarte = 0;
    let sansCarte = 0;
    let expirees = 0;

    entries.forEach(entry => {
      if (entry.carteASP && entry.carteASP.trim() !== '') {
        // Vérifier si la carte est expirée
        if (entry.dateEcheanceCarte) {
          const dateEcheance = new Date(entry.dateEcheanceCarte);
          const maintenant = new Date();
          if (dateEcheance < maintenant) {
            expirees++;
          } else {
            avecCarte++;
          }
        } else {
          avecCarte++;
        }
      } else {
        sansCarte++;
      }
    });

    return { avecCarte, sansCarte, expirees };
  }, [entries]);

  // Analyser l'état des cartes CCQ
  const ccqStats = React.useMemo(() => {
    let avecCarte = 0;
    let sansCarte = 0;

    entries.forEach(entry => {
      if (entry.carteCCQ && entry.carteCCQ.trim() !== '') {
        avecCarte++;
      } else {
        sansCarte++;
      }
    });

    return { avecCarte, sansCarte };
  }, [entries]);

  // Analyser l'état des cartes SIMDUT
  const simdutStats = React.useMemo(() => {
    let avecCarte = 0;
    let sansCarte = 0;

    entries.forEach(entry => {
      if (entry.carteSIMDUT && entry.carteSIMDUT.trim() !== '') {
        avecCarte++;
      } else {
        sansCarte++;
      }
    });

    return { avecCarte, sansCarte };
  }, [entries]);

  const getStatusBadge = (count: number, total: number, type: 'success' | 'warning' | 'danger') => {
    const percentage = total > 0 ? Math.round((count / total) * 100) : 0;
    let variant: "default" | "secondary" | "destructive" | "outline" = "outline";
    let className = "";

    switch (type) {
      case 'success':
        variant = "default";
        className = "bg-green-100 text-green-800 border-green-200";
        break;
      case 'warning':
        variant = "outline";
        className = "bg-orange-100 text-orange-800 border-orange-200";
        break;
      case 'danger':
        variant = "destructive";
        className = "bg-red-100 text-red-800 border-red-200";
        break;
    }

    return (
      <Badge variant={variant} className={className}>
        {count} ({percentage}%)
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
          <CreditCard className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Cartes professionnelles</h2>
          <p className="text-gray-600">État des cartes ASP, CCQ et SIMDUT 2015</p>
        </div>
      </div>

      {/* Vue d'ensemble */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{entries.length}</div>
            <div className="text-sm text-blue-700">Total travailleurs</div>
          </CardContent>
        </Card>
        
        <Card className="bg-green-50 border-green-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">
              {aspStats.avecCarte + ccqStats.avecCarte + simdutStats.avecCarte}
            </div>
            <div className="text-sm text-green-700">Cartes valides</div>
          </CardContent>
        </Card>
        
        <Card className="bg-red-50 border-red-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-red-600">
              {aspStats.sansCarte + ccqStats.sansCarte + simdutStats.sansCarte + aspStats.expirees}
            </div>
            <div className="text-sm text-red-700">Manquantes/Expirées</div>
          </CardContent>
        </Card>
      </div>

      {/* Section 1: État des cartes ASP */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-600" />
            État des cartes ASP
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-medium text-green-800">Cartes valides</span>
              </div>
              {getStatusBadge(aspStats.avecCarte, entries.length, 'success')}
            </div>
            
            <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                <span className="font-medium text-orange-800">Cartes expirées</span>
              </div>
              {getStatusBadge(aspStats.expirees, entries.length, 'warning')}
            </div>
            
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-800">Sans carte</span>
              </div>
              {getStatusBadge(aspStats.sansCarte, entries.length, 'danger')}
            </div>
          </div>

          {/* Détail des travailleurs sans carte ASP */}
          {aspStats.sansCarte > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-gray-800 mb-2">Travailleurs sans carte ASP:</h4>
              <div className="space-y-2">
                {entries
                  .filter(entry => !entry.carteASP || entry.carteASP.trim() === '')
                  .map(entry => (
                    <div key={entry.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div>
                        <span className="font-medium text-gray-800">{entry.nomEmploye}</span>
                        <span className="text-sm text-gray-600 ml-2">({entry.entreprise})</span>
                      </div>
                      <Badge variant="destructive">Manquante</Badge>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Section 2: État des cartes CCQ */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-600" />
            État des cartes CCQ
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-medium text-green-800">Avec carte</span>
              </div>
              {getStatusBadge(ccqStats.avecCarte, entries.length, 'success')}
            </div>
            
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-800">Sans carte</span>
              </div>
              {getStatusBadge(ccqStats.sansCarte, entries.length, 'danger')}
            </div>
          </div>

          {/* Détail des travailleurs sans carte CCQ */}
          {ccqStats.sansCarte > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-gray-800 mb-2">Travailleurs sans carte CCQ:</h4>
              <div className="space-y-2">
                {entries
                  .filter(entry => !entry.carteCCQ || entry.carteCCQ.trim() === '')
                  .map(entry => (
                    <div key={entry.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div>
                        <span className="font-medium text-gray-800">{entry.nomEmploye}</span>
                        <span className="text-sm text-gray-600 ml-2">({entry.entreprise})</span>
                      </div>
                      <Badge variant="destructive">Manquante</Badge>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Section 3: État des cartes SIMDUT 2015 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CheckCircle className="w-5 h-5 text-blue-600" />
            État des cartes SIMDUT 2015
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="font-medium text-green-800">Avec carte</span>
              </div>
              {getStatusBadge(simdutStats.avecCarte, entries.length, 'success')}
            </div>
            
            <div className="flex items-center justify-between p-4 bg-red-50 rounded-lg">
              <div className="flex items-center gap-2">
                <XCircle className="w-5 h-5 text-red-600" />
                <span className="font-medium text-red-800">Sans carte</span>
              </div>
              {getStatusBadge(simdutStats.sansCarte, entries.length, 'danger')}
            </div>
          </div>

          {/* Détail des travailleurs sans carte SIMDUT */}
          {simdutStats.sansCarte > 0 && (
            <div className="mt-4">
              <h4 className="font-medium text-gray-800 mb-2">Travailleurs sans carte SIMDUT 2015:</h4>
              <div className="space-y-2">
                {entries
                  .filter(entry => !entry.carteSIMDUT || entry.carteSIMDUT.trim() === '')
                  .map(entry => (
                    <div key={entry.id} className="flex items-center justify-between p-3 bg-red-50 rounded-lg">
                      <div>
                        <span className="font-medium text-gray-800">{entry.nomEmploye}</span>
                        <span className="text-sm text-gray-600 ml-2">({entry.entreprise})</span>
                      </div>
                      <Badge variant="destructive">Manquante</Badge>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Message si aucune donnée */}
      {entries.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <CreditCard className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-600 mb-2">Aucune donnée disponible</h3>
            <p className="text-gray-500">
              Les informations sur les cartes professionnelles apparaîtront ici une fois que les travailleurs seront enregistrés.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
