
import React from 'react';
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";

interface SoustraitantFiltersProps {
  searchTerm: string;
  onSearchTermChange: (value: string) => void;
  filterStatut: string;
  onFilterStatutChange: (value: string) => void;
  onClearFilters: () => void;
  resultsCount: number;
  totalCount: number;
}

export const SoustraitantFilters = ({
  searchTerm,
  onSearchTermChange,
  filterStatut,
  onFilterStatutChange,
  onClearFilters,
  resultsCount,
  totalCount
}: SoustraitantFiltersProps) => {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 rounded-lg">
        <div>
          <Label htmlFor="search">Rechercher</Label>
          <Input
            id="search"
            placeholder="Nom du sous-traitant..."
            value={searchTerm}
            onChange={(e) => onSearchTermChange(e.target.value)}
            className="bg-white"
          />
        </div>

        <div>
          <Label htmlFor="filter-statut">Statut</Label>
          <select
            id="filter-statut"
            value={filterStatut}
            onChange={(e) => onFilterStatutChange(e.target.value)}
            className="w-full h-10 px-3 py-2 bg-white border border-gray-300 rounded-md text-sm"
          >
            <option value="all">Tous</option>
            <option value="actif">Actif</option>
            <option value="inactif">Inactif</option>
          </select>
        </div>

        <div className="flex items-end">
          <Button 
            variant="outline" 
            onClick={onClearFilters}
            className="w-full"
          >
            <Filter className="w-4 h-4 mr-1" />
            Effacer
          </Button>
        </div>
      </div>

      <div className="text-sm text-gray-600 mb-2">
        {resultsCount} résultat(s) sur {totalCount} sous-traitant(s)
      </div>
    </div>
  );
};
