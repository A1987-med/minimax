
import { useMemo } from 'react';
import { soustraitantCorpsEtatMap } from "@/constants/soustraitants";
import { useSoustraitantMatching } from './useSoustraitantMatching';
import type { EntryData } from "./types";

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

interface EnrichedSoustraitant extends Soustraitant {
  logo?: string | null;
  corpsMetiers?: string[];
  nombreEmployes?: number;
}

export const useSoustraitantEnrichment = (
  soustraitants: Soustraitant[],
  entries: EntryData[] = []
) => {
  const { isFlexibleMatch } = useSoustraitantMatching();

  // Enrichir les sous-traitants avec les données des entrées
  const enrichedSoustraitants = useMemo(() => {
    console.log('📊 ENRICHISSEMENT FLEXIBLE - Début...');
    console.log('📊 ENRICHISSEMENT FLEXIBLE - Entries:', entries.length);
    console.log('📊 ENRICHISSEMENT FLEXIBLE - Soustraitants:', soustraitants.length);
    
    return soustraitants.map(soustraitant => {
      console.log(`📊 ENRICHISSEMENT FLEXIBLE - Traitement: "${soustraitant.nom}"`);
      
      // Chercher les entrées correspondantes avec logique flexible
      const soustraitantEntries = entries.filter(entry => {
        const matchEntreprise = isFlexibleMatch(soustraitant.nom, entry.entreprise || '');
        const matchSoustraitant = isFlexibleMatch(soustraitant.nom, entry.soustraitant || '');
        const matchNomSousTraitant = isFlexibleMatch(soustraitant.nom, entry.nomSousTraitant || '');
        
        const isMatch = matchEntreprise || matchSoustraitant || matchNomSousTraitant;
        
        if (isMatch) {
          console.log(`📊 ENRICHISSEMENT FLEXIBLE - ✅ MATCH pour "${soustraitant.nom}":`, {
            entry: {
              entreprise: entry.entreprise,
              soustraitant: entry.soustraitant,
              nomSousTraitant: entry.nomSousTraitant,
              logo: entry.logo ? 'LOGO PRÉSENT' : 'AUCUN LOGO'
            },
            matches: { matchEntreprise, matchSoustraitant, matchNomSousTraitant }
          });
        }
        
        return isMatch;
      });
      
      console.log(`📊 ENRICHISSEMENT FLEXIBLE - "${soustraitant.nom}" -> ${soustraitantEntries.length} entrées trouvées`);
      
      // Obtenir le logo le plus récent
      const latestEntry = soustraitantEntries.sort((a, b) => {
        const dateA = new Date(`${a.dateEntree} ${a.heureEntree}`);
        const dateB = new Date(`${b.dateEntree} ${b.heureEntree}`);
        return dateB.getTime() - dateA.getTime();
      })[0];
      
      // Utiliser le mapping fixe pour obtenir le corps d'état
      const corpsEtatFromMapping = soustraitantCorpsEtatMap[soustraitant.nom];
      const corpsMetiers = corpsEtatFromMapping ? [corpsEtatFromMapping] : [];
      
      const enriched = {
        ...soustraitant,
        logo: latestEntry?.logo || null,
        corpsMetiers: corpsMetiers,
        nombreEmployes: soustraitantEntries.length
      };
      
      if (soustraitantEntries.length > 0) {
        console.log(`📊 ENRICHISSEMENT FLEXIBLE - ✅ "${soustraitant.nom}" enrichi avec succès:`, {
          logo: !!latestEntry?.logo,
          logoUrl: latestEntry?.logo ? latestEntry.logo.substring(0, 50) + '...' : 'AUCUN',
          corpsMetiers: corpsMetiers,
          nombreEmployes: soustraitantEntries.length,
          corpsEtatFromMapping: corpsEtatFromMapping
        });
      } else {
        console.log(`📊 ENRICHISSEMENT FLEXIBLE - ❌ "${soustraitant.nom}" aucune correspondance trouvée mais mapping existe:`, {
          corpsEtatFromMapping: corpsEtatFromMapping
        });
      }
      
      return enriched;
    });
  }, [soustraitants, entries, isFlexibleMatch]);

  return {
    enrichedSoustraitants
  };
};
