
import React from 'react';
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Upload, X, CalendarIcon, ZoomIn } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

interface CCQCardProps {
  carteCCQ: string;
  carteCCQName: string;
  numeroClient: string;
  dateEcheanceCarte?: Date;
  dateAccueil?: Date;
  onCarteCCQChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteCCQRemove?: () => void;
  onNumeroClientChange: (value: string) => void;
  onDateEcheangeCarteChange: (date?: Date) => void;
  onImageClick: (imageUrl: string, title: string) => void;
}

export const CCQCard = ({
  carteCCQ,
  carteCCQName,
  numeroClient,
  dateEcheanceCarte,
  dateAccueil,
  onCarteCCQChange,
  onCarteCCQRemove,
  onNumeroClientChange,
  onDateEcheangeCarteChange,
  onImageClick
}: CCQCardProps) => {
  const formatNumeroClient = (value: string): string => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length >= 4) {
      return `${numbers.slice(0, 4)}-${numbers.slice(4, 8)}`;
    }
    return numbers;
  };

  const handleNumeroClientChange = (value: string) => {
    const formatted = formatNumeroClient(value);
    onNumeroClientChange(formatted);
  };

  const calculateDaysBeforeExpiration = (): number | null => {
    if (!dateAccueil || !dateEcheanceCarte) return null;
    const timeDiff = dateEcheanceCarte.getTime() - dateAccueil.getTime();
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
  };

  const getValidityStatus = () => {
    if (!carteCCQ) {
      return { text: "Carte non délivrée", bgColor: "bg-red-500" };
    }
    
    const daysLeft = calculateDaysBeforeExpiration();
    if (daysLeft === null) return null;
    
    if (daysLeft >= 0) {
      return { text: "Valide", bgColor: "bg-green-500" };
    } else {
      return { text: "Périmée", bgColor: "bg-yellow-500" };
    }
  };

  const validityStatus = getValidityStatus();
  const daysLeft = calculateDaysBeforeExpiration();

  return (
    <div className="ml-6 space-y-3">
      <div className="space-y-2">
        <Label htmlFor="carteCCQ">Carte CCQ</Label>
        <div className="space-y-2">
          {!carteCCQ && (
            <div className="relative">
              <Input
                id="carteCCQ"
                type="file"
                accept="image/*"
                onChange={onCarteCCQChange}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('carteCCQ')?.click()}
                className="flex items-center gap-2"
              >
                <Upload className="w-4 h-4" />
                Choisir une image
              </Button>
            </div>
          )}
          {carteCCQ && (
            <div className="flex items-center gap-2">
              <div 
                className="relative w-20 h-20 border border-gray-300 rounded-lg overflow-hidden cursor-pointer group"
                onClick={() => onImageClick(carteCCQ, "Carte CCQ")}
              >
                <img
                  src={carteCCQ}
                  alt="Carte CCQ"
                  className="w-full h-full object-contain transition-transform group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                  <ZoomIn className="w-6 h-6 text-white opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={onCarteCCQRemove}
                className="px-2 py-2 text-red-600 hover:text-red-700 hover:bg-red-50"
                title="Supprimer l'image"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          )}
          {carteCCQName && (
            <p className="text-sm text-gray-500">{carteCCQName}</p>
          )}
        </div>
      </div>

      {carteCCQ && (
        <>
          <div className="space-y-2">
            <Label htmlFor="numeroClient">Numéro client</Label>
            <Input
              id="numeroClient"
              value={numeroClient}
              onChange={(e) => handleNumeroClientChange(e.target.value)}
              placeholder="XXXX-XXXX"
              maxLength={9}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="dateEcheanceCarte">Date d'échéance de la carte</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-full justify-start text-left font-normal",
                    !dateEcheanceCarte && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateEcheanceCarte ? format(dateEcheanceCarte, "dd/MM/yyyy") : "Sélectionner une date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={dateEcheanceCarte}
                  onSelect={onDateEcheangeCarteChange}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
          </div>

          {(dateAccueil && dateEcheanceCarte) && (
            <div className="space-y-2">
              <Label>Durée avant expiration</Label>
              <div className="p-2 bg-gray-50 rounded-md text-gray-700 font-medium">
                {daysLeft !== null && daysLeft >= 0 
                  ? `${daysLeft} jours restants` 
                  : daysLeft !== null 
                  ? `Expirée depuis ${Math.abs(daysLeft)} jours`
                  : 'Calcul impossible'
                }
              </div>
            </div>
          )}

          {carteCCQ && (!dateAccueil || !dateEcheanceCarte) && (
            <div className="space-y-2">
              <Label>Durée avant expiration</Label>
              <div className="p-2 bg-yellow-50 rounded-md text-yellow-700 text-sm">
                {!dateAccueil && !dateEcheanceCarte 
                  ? "Veuillez sélectionner la date d'accueil et la date d'échéance pour calculer la durée"
                  : !dateAccueil 
                  ? "Veuillez sélectionner la date d'accueil pour calculer la durée"
                  : "Veuillez sélectionner la date d'échéance pour calculer la durée"
                }
              </div>
            </div>
          )}

          <div className="space-y-2">
            <Label>Validité</Label>
            <div className={cn(
              "p-2 rounded-md text-white text-center font-medium",
              validityStatus?.bgColor || "bg-gray-300"
            )}>
              {validityStatus?.text || "En attente"}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
