
import React from 'react';
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { CreditCard } from "lucide-react";
import { ASPCard } from './ASPCard';
import { CCQCard } from './CCQCard';

interface CarteInfoSectionProps {
  estCadre: boolean;
  carteASP: string;
  carteASPName: string;
  carteCCQ: string;
  carteCCQName: string;
  numeroClient: string;
  dateEcheanceCarte?: Date;
  dateAccueil?: Date;
  onEstCadreChange: (checked: boolean) => void;
  onCarteASPChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteASPRemove?: () => void;
  onCarteCCQChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onCarteCCQRemove?: () => void;
  onNumeroClientChange: (value: string) => void;
  onDateEcheangeCarteChange: (date?: Date) => void;
  onImageClick: (imageUrl: string, title: string) => void;
}

export const CarteInfoSection = ({
  estCadre,
  carteASP,
  carteASPName,
  carteCCQ,
  carteCCQName,
  numeroClient,
  dateEcheanceCarte,
  dateAccueil,
  onEstCadreChange,
  onCarteASPChange,
  onCarteASPRemove,
  onCarteCCQChange,
  onCarteCCQRemove,
  onNumeroClientChange,
  onDateEcheangeCarteChange,
  onImageClick
}: CarteInfoSectionProps) => {
  return (
    <div className="space-y-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
      <div className="flex items-center gap-2">
        <CreditCard className="w-5 h-5 text-purple-600" />
        <h4 className="text-sm font-semibold text-purple-700">Informations Carte</h4>
      </div>

      <div className="space-y-3">
        <div className="flex items-center space-x-2 p-2 bg-white rounded-md border border-purple-100">
          <Checkbox
            id="cadre"
            checked={estCadre}
            onCheckedChange={(checked) => {
              console.log('Checkbox cadre clicked, checked:', checked);
              onEstCadreChange(!!checked);
            }}
            className="data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
          />
          <Label htmlFor="cadre" className="text-sm font-medium cursor-pointer">
            Cadre
          </Label>
        </div>

        {estCadre && (
          <ASPCard
            carteASP={carteASP}
            carteASPName={carteASPName}
            onCarteASPChange={onCarteASPChange}
            onCarteASPRemove={onCarteASPRemove}
            onImageClick={onImageClick}
          />
        )}

        {!estCadre && (
          <CCQCard
            carteCCQ={carteCCQ}
            carteCCQName={carteCCQName}
            numeroClient={numeroClient}
            dateEcheanceCarte={dateEcheanceCarte}
            dateAccueil={dateAccueil}
            onCarteCCQChange={onCarteCCQChange}
            onCarteCCQRemove={onCarteCCQRemove}
            onNumeroClientChange={onNumeroClientChange}
            onDateEcheangeCarteChange={onDateEcheangeCarteChange}
            onImageClick={onImageClick}
          />
        )}
      </div>
    </div>
  );
};
