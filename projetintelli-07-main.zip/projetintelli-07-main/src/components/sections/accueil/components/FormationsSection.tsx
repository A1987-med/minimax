
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Building2 } from "lucide-react";
import type { EntryData } from "../types";

interface FormationsSectionProps {
  entries: EntryData[];
}

export const FormationsSection = ({ entries }: FormationsSectionProps) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-blue-600" />
          Formations par travailleur ({entries.length} travailleur{entries.length !== 1 ? 's' : ''})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {entries.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <GraduationCap className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Aucun travailleur enregistré</p>
            <p className="text-sm">Les travailleurs ajoutés apparaîtront ici avec leurs formations</p>
          </div>
        ) : (
          <div className="space-y-3">
            {entries.map((entry, index) => {
              const formationsCount = entry.selectedFormations?.length || 0;
              console.log('📋 FORMATION DEBUG - Entrée', entry.nomEmploye, 'formations:', entry.selectedFormations);
              console.log('📋 FORMATION DEBUG - Données complètes pour', entry.nomEmploye, ':', JSON.stringify(entry, null, 2));
              
              return (
                <div key={entry.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 font-semibold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{entry.prenom} {entry.nom}</p>
                      <div className="flex items-center gap-1">
                        <Building2 className="w-4 h-4 text-gray-500" />
                        <span className="text-sm text-gray-600">{entry.soustraitant}</span>
                      </div>
                      {/* Affichage des formations */}
                      {entry.selectedFormations && entry.selectedFormations.length > 0 && (
                        <div className="mt-1">
                          <div className="flex flex-wrap gap-1">
                            {entry.selectedFormations.map((formation, i) => {
                              console.log('🎯 FORMATION BADGE DEBUG - Formation:', formation, 'pour', entry.nomEmploye);
                              return (
                                <Badge key={i} variant="outline" className="text-xs bg-blue-50 text-blue-700">
                                  {formation}
                                </Badge>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={`${formationsCount > 0 ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-600'}`}>
                      {formationsCount} formation{formationsCount !== 1 ? 's' : ''}
                    </Badge>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
