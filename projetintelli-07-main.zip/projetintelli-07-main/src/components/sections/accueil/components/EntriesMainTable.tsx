
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Trash2, Download, Eye, EyeOff, Heart, Edit2 } from "lucide-react";
import type { EntryData } from "../types";
import { cleanOccupation } from "../utils/occupationUtils";
import { EditWorkerModal } from "../EditWorkerModal";

interface EntriesMainTableProps {
  entries: EntryData[];
  onDeleteEntry: (id: string) => void;
  onUpdateEntry?: (id: string, data: Partial<EntryData>) => void;
}

export const EntriesMainTable = ({ entries, onDeleteEntry, onUpdateEntry }: EntriesMainTableProps) => {
  const [selectedEntries, setSelectedEntries] = useState<string[]>([]);
  const [showAllColumns, setShowAllColumns] = useState(false);
  const [editingEntry, setEditingEntry] = useState<EntryData | null>(null);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedEntries(entries.map(entry => entry.id));
    } else {
      setSelectedEntries([]);
    }
  };

  const handleSelectEntry = (entryId: string, checked: boolean) => {
    if (checked) {
      setSelectedEntries(prev => [...prev, entryId]);
    } else {
      setSelectedEntries(prev => prev.filter(id => id !== entryId));
    }
  };

  const handleDeleteSelected = () => {
    selectedEntries.forEach(id => onDeleteEntry(id));
    setSelectedEntries([]);
  };

  const handleEditEntry = (entry: EntryData) => {
    setEditingEntry(entry);
  };

  const handleUpdateEntry = (updatedData: Partial<EntryData>) => {
    if (editingEntry && onUpdateEntry) {
      onUpdateEntry(editingEntry.id, updatedData);
      setEditingEntry(null);
    }
  };

  const exportToCsv = () => {
    const headers = [
      'Nom de l\'employé',
      'Occupation',
      'Sous-traitant',
      'Date d\'entrée',
      'Heure d\'entrée',
      'Téléphone',
      'Numéro d\'immatriculation',
      'Est secouriste',
      'Date échéancier secouriste',
      'Formations'
    ];

    const csvContent = [
      headers.join(','),
      ...entries.map(entry => [
        `"${entry.nomEmploye}"`,
        `"${cleanOccupation(entry.occupations || entry.corpsMetier)}"`,
        `"${entry.soustraitant}"`,
        entry.dateEntree,
        entry.heureEntree,
        `"${entry.telephone || ''}"`,
        `"${entry.numeroImmatriculation || ''}"`,
        entry.estSecouriste ? 'Oui' : 'Non',
        entry.dateEcheancierSecouriste || '',
        `"${entry.selectedFormations?.join(', ') || ''}"`
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', 'registre_accueil.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Registre d'accueil - {entries.length} entrée{entries.length !== 1 ? 's' : ''}</CardTitle>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAllColumns(!showAllColumns)}
              className="flex items-center gap-2"
            >
              {showAllColumns ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              {showAllColumns ? 'Masquer détails' : 'Afficher détails'}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={exportToCsv}
              className="flex items-center gap-2"
              disabled={entries.length === 0}
            >
              <Download className="w-4 h-4" />
              Exporter CSV
            </Button>
            {selectedEntries.length > 0 && (
              <Button
                variant="destructive"
                size="sm"
                onClick={handleDeleteSelected}
                className="flex items-center gap-2"
              >
                <Trash2 className="w-4 h-4" />
                Supprimer ({selectedEntries.length})
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {entries.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <p>Aucune entrée enregistrée</p>
            <p className="text-sm">Les travailleurs ajoutés apparaîtront ici</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedEntries.length === entries.length}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead>Nom</TableHead>
                  <TableHead>Occupation</TableHead>
                  <TableHead>Sous-traitant</TableHead>
                  <TableHead>Date/Heure</TableHead>
                  {showAllColumns && (
                    <>
                      <TableHead>Téléphone</TableHead>
                      <TableHead>Immatriculation</TableHead>
                      <TableHead>Formations</TableHead>
                      <TableHead>Secouriste</TableHead>
                      <TableHead>Échéancier</TableHead>
                    </>
                  )}
                  <TableHead className="w-20">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {entries.map((entry) => {
                  console.log('🎯 TABLE ROW DEBUG - Entrée:', entry.nomEmploye, 'données complètes:', JSON.stringify(entry, null, 2));
                  return (
                    <TableRow key={entry.id}>
                      <TableCell>
                        <Checkbox
                          checked={selectedEntries.includes(entry.id)}
                          onCheckedChange={(checked) => handleSelectEntry(entry.id, checked as boolean)}
                        />
                      </TableCell>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          {entry.estSecouriste && (
                            <Heart className="w-4 h-4 text-red-600" />
                          )}
                          {entry.nomEmploye}
                        </div>
                      </TableCell>
                      <TableCell>{cleanOccupation(entry.occupations || entry.corpsMetier)}</TableCell>
                      <TableCell>{entry.soustraitant}</TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{entry.dateEntree}</div>
                          <div className="text-gray-500">{entry.heureEntree}</div>
                        </div>
                      </TableCell>
                      {showAllColumns && (
                        <>
                          <TableCell>{entry.telephone || '-'}</TableCell>
                          <TableCell>{entry.numeroImmatriculation || '-'}</TableCell>
                          <TableCell>
                            <div className="max-w-32">
                              {entry.selectedFormations && entry.selectedFormations.length > 0 ? (
                                <div className="flex flex-wrap gap-1">
                                  {entry.selectedFormations.map((formation, i) => {
                                    console.log('🎯 TABLE FORMATION BADGE DEBUG - Formation:', formation, 'pour', entry.nomEmploye);
                                    return (
                                      <Badge key={i} variant="outline" className="text-xs">
                                        {formation}
                                      </Badge>
                                    );
                                  })}
                                </div>
                              ) : (
                                <span className="text-gray-400 text-xs">Aucune</span>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={entry.estSecouriste ? "default" : "secondary"}>
                              {entry.estSecouriste ? "Oui" : "Non"}
                            </Badge>
                          </TableCell>
                          <TableCell>{entry.dateEcheancierSecouriste || '-'}</TableCell>
                        </>
                      )}
                      <TableCell>
                        <div className="flex items-center gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEditEntry(entry)}
                            className="text-blue-600 hover:text-blue-800 hover:bg-blue-100"
                          >
                            <Edit2 className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => onDeleteEntry(entry.id)}
                            className="text-red-600 hover:text-red-800 hover:bg-red-100"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      {/* Modal d'édition */}
      {editingEntry && (
        <EditWorkerModal
          entry={editingEntry}
          isOpen={!!editingEntry}
          onClose={() => setEditingEntry(null)}
          onSave={handleUpdateEntry}
        />
      )}
    </Card>
  );
};
