
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Building2 } from "lucide-react";
import type { EntryData } from "../types";
import { cleanOccupation } from "../utils/occupationUtils";

interface SecouristesSectionProps {
  entries: EntryData[];
}

export const SecouristesSection = ({ entries }: SecouristesSectionProps) => {
  // Filtrer les secouristes
  const secouristes = entries.filter(entry => {
    console.log('🔍 SECOURISTES SECTION FILTER - Worker:', entry.nomEmploye, 'estSecouriste:', entry.estSecouriste, 'type:', typeof entry.estSecouriste);
    return entry.estSecouriste;
  });

  console.log('🚨 DEBUG SECOURISTES SECTION - Secouristes filtrés:', secouristes);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-red-600" />
          Liste des secouristes ({secouristes.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        {secouristes.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Heart className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>Aucun secouriste déclaré</p>
            <p className="text-sm">Les travailleurs avec la qualification secouriste apparaîtront ici</p>
          </div>
        ) : (
          <div className="space-y-3">
            {secouristes.map((secouriste, index) => {
              console.log('🚨 DEBUG SECOURISTES SECTION - Rendu secouriste:', secouriste.nomEmploye, 'données complètes:', JSON.stringify(secouriste, null, 2));
              return (
                <div key={secouriste.id} className="flex items-center justify-between p-3 bg-gradient-to-r from-red-50 to-pink-50 rounded-lg border border-red-200">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center text-red-600 font-semibold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{secouriste.nomEmploye}</p>
                      <p className="text-sm text-gray-600">{cleanOccupation(secouriste.occupations || secouriste.corpsMetier)}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1">
                      <Building2 className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{secouriste.soustraitant}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
