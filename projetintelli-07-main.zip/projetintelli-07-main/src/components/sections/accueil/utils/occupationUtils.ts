
// Fonction pour nettoyer l'occupation
export const cleanOccupation = (occupations: string[] | string): string => {
  // Gestion du cas où occupations est un tableau
  let occupation: string;
  if (Array.isArray(occupations)) {
    occupation = occupations.length > 0 ? occupations[0] : '';
  } else {
    occupation = occupations || '';
  }

  // Liste des valeurs incorrectes à filtrer
  const invalidValues = [
    'Formule: Valide',
    'Formule: Échue',
    'Valide',
    'Échue'
  ];
  
  if (!occupation || invalidValues.includes(occupation)) {
    return 'Non spécifié';
  }
  
  return occupation;
};
