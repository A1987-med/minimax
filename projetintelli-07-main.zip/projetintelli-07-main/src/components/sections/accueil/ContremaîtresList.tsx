
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, Phone, Mail } from "lucide-react";
import type { EntryData } from "./types";

interface ContremaîtresListProps {
  entries: EntryData[];
}

export const ContremaîtresList = ({ entries }: ContremaîtresListProps) => {
  // Filtrer les entrées pour ne garder que les contremaîtres
  const contremaîtres = entries.filter(entry => entry.estContremaitre);

  console.log('📋 CONTREMAÎTRES - Nombre total d\'entrées:', entries.length);
  console.log('👷 CONTREMAÎTRES - Nombre de contremaîtres:', contremaîtres.length);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-800 flex items-center gap-2">
          <Users className="w-5 h-5 text-blue-600" />
          Liste des Contremaîtres
        </h3>
        <Badge variant="outline" className="text-blue-600 border-blue-200">
          {contremaîtres.length} contremaître{contremaîtres.length !== 1 ? 's' : ''}
        </Badge>
      </div>

      {contremaîtres.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h4 className="text-lg font-medium text-gray-600 mb-2">
                Aucun contremaître enregistré
              </h4>
              <p className="text-gray-500">
                Les contremaîtres apparaîtront ici une fois qu'ils seront enregistrés dans le système.
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {contremaîtres.map((contremaître) => (
            <Card key={contremaître.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  {contremaître.nomEmploye}
                </CardTitle>
                <CardDescription className="text-sm">
                  {contremaître.entreprise}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span className="font-medium">Fonction:</span>
                    <span>{contremaître.fonction || 'Non spécifié'}</span>
                  </div>
                  
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span className="font-medium">Corps de métier:</span>
                    <span>{contremaître.corpsMetier || 'Non spécifié'}</span>
                  </div>

                  {contremaître.telephone && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Phone className="w-4 h-4" />
                      <span>{contremaître.telephone}</span>
                    </div>
                  )}

                  {contremaître.courriel && (
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <Mail className="w-4 h-4" />
                      <span>{contremaître.courriel}</span>
                    </div>
                  )}
                </div>

                <div className="pt-2 border-t border-gray-100">
                  <div className="flex items-center justify-between text-xs text-gray-500">
                    <span>Entrée: {contremaître.dateEntree}</span>
                    <span>{contremaître.heureEntree}</span>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1">
                  <Badge variant="secondary" className="text-xs">
                    Contremaître
                  </Badge>
                  {contremaître.estSecouriste && (
                    <Badge variant="outline" className="text-xs text-green-600 border-green-200">
                      Secouriste
                    </Badge>
                  )}
                  {contremaître.estSousTraitant && (
                    <Badge variant="outline" className="text-xs text-orange-600 border-orange-200">
                      Sous-traitant
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
