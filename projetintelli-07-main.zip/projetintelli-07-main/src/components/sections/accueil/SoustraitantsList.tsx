
import React from 'react';
import { SoustraitantCard } from './SoustraitantCard';

interface EnrichedSoustraitant {
  id: string;
  nom: string;
  actif: boolean;
  logo?: string | null;
  corpsMetiers?: string[];
  nombreEmployes?: number;
}

interface SoustraitantsListProps {
  soustraitants: EnrichedSoustraitant[];
  onEdit: (soustraitant: EnrichedSoustraitant) => void;
  onDelete: (id: string) => void;
  onToggleActif: (id: string) => void;
  isLoading: boolean;
}

export const SoustraitantsList = ({ 
  soustraitants, 
  onEdit, 
  onDelete, 
  onToggleActif, 
  isLoading 
}: SoustraitantsListProps) => {
  return (
    <div className="space-y-2 max-h-64 overflow-y-auto">
      {soustraitants.map((soustraitant) => (
        <SoustraitantCard
          key={soustraitant.id}
          soustraitant={soustraitant}
          onEdit={onEdit}
          onDelete={onDelete}
          onToggleActif={onToggleActif}
          isLoading={isLoading}
        />
      ))}
      {soustraitants.length === 0 && (
        <div className="text-center text-gray-500 py-8">
          Aucun sous-traitant trouvé
        </div>
      )}
    </div>
  );
};
