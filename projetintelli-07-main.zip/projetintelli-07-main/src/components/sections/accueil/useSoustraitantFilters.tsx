
import { useState, useMemo } from 'react';

interface EnrichedSoustraitant {
  id: string;
  nom: string;
  actif: boolean;
  logo?: string | null;
  corpsMetiers?: string[];
  nombreEmployes?: number;
}

export const useSoustraitantFilters = (enrichedSoustraitants: EnrichedSoustraitant[]) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatut, setFilterStatut] = useState('all');

  // Filtrage des sous-traitants
  const filteredSoustraitants = useMemo(() => {
    return enrichedSoustraitants.filter(soustraitant => {
      const matchesSearch = soustraitant.nom.toLowerCase().includes(searchTerm.toLowerCase());
      
      const matchesStatut = filterStatut === 'all' || 
                           (filterStatut === 'actif' && soustraitant.actif) ||
                           (filterStatut === 'inactif' && !soustraitant.actif);
      
      return matchesSearch && matchesStatut;
    });
  }, [enrichedSoustraitants, searchTerm, filterStatut]);

  const clearFilters = () => {
    setSearchTerm('');
    setFilterStatut('all');
  };

  return {
    searchTerm,
    setSearchTerm,
    filterStatut,
    setFilterStatut,
    filteredSoustraitants,
    clearFilters
  };
};
