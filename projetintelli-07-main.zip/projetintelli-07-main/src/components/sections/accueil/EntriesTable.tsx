
import React, { useEffect } from 'react';
import type { EntryData } from "./types";
import { SecouristesSection } from "./components/SecouristesSection";
import { FormationsSection } from "./components/FormationsSection";
import { EntriesMainTable } from "./components/EntriesMainTable";

interface EntriesTableProps {
  entries: EntryData[];
  onDeleteEntry: (id: string) => void;
  onUpdateEntry?: (id: string, data: Partial<EntryData>) => void;
}

export const EntriesTable = ({ entries, onDeleteEntry, onUpdateEntry }: EntriesTableProps) => {
  useEffect(() => {
    console.log('📊 ENTRIES TABLE - useEffect - Props reçues:', {
      entriesLength: entries.length,
      entriesData: entries
    });
  }, [entries]);

  console.log('📊 ENTRIES TABLE - Rendu avec', entries.length, 'entrées');
  console.log('📊 ENTRIES TABLE - Données complètes:', entries);

  return (
    <div className="space-y-6">
      <SecouristesSection entries={entries} />
      <FormationsSection entries={entries} />
      <EntriesMainTable 
        entries={entries} 
        onDeleteEntry={onDeleteEntry} 
        onUpdateEntry={onUpdateEntry} 
      />
    </div>
  );
};
