
import { useSoustraitantOperations } from './useSoustraitantOperations';
import { useSoustraitantFilters } from './useSoustraitantFilters';
import { useSoustraitantEnrichment } from './useSoustraitantEnrichment';
import type { EntryData } from "./types";

interface Soustraitant {
  id: string;
  nom: string;
  actif: boolean;
}

export const useSoustraitantManager = (
  soustraitants: Soustraitant[],
  onSoustraitantsChange: (soustraitants: Soustraitant[]) => void,
  entries: EntryData[] = []
) => {
  // Enrichissement des données
  const { enrichedSoustraitants } = useSoustraitantEnrichment(soustraitants, entries);
  
  // Filtrage et recherche
  const {
    searchTerm,
    setSearchTerm,
    filterStatut,
    setFilterStatut,
    filteredSoustraitants,
    clearFilters
  } = useSoustraitantFilters(enrichedSoustraitants);
  
  // Opérations CRUD
  const {
    isDialogOpen,
    setIsDialogOpen,
    editingSoustraitant,
    newSoustraitant,
    setNewSoustraitant,
    isLoading,
    handleAddSoustraitant,
    handleEditSoustraitant,
    handleUpdateSoustraitant,
    handleDeleteSoustraitant,
    handleToggleActif,
    handleExport,
    handleImport,
    resetDialog
  } = useSoustraitantOperations(soustraitants, onSoustraitantsChange);

  return {
    isDialogOpen,
    setIsDialogOpen,
    editingSoustraitant,
    newSoustraitant,
    setNewSoustraitant,
    isLoading,
    searchTerm,
    setSearchTerm,
    filterStatut,
    setFilterStatut,
    enrichedSoustraitants,
    filteredSoustraitants,
    handleAddSoustraitant,
    handleEditSoustraitant,
    handleUpdateSoustraitant,
    handleDeleteSoustraitant,
    handleToggleActif,
    handleExport,
    handleImport,
    resetDialog,
    clearFilters,
  };
};
