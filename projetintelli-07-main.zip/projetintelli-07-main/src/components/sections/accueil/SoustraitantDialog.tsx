
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Loader2 } from "lucide-react";

interface SoustraitantDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  editingSoustraitant: any;
  newSoustraitant: { nom: string };
  onNewSoustraitantChange: (soustraitant: { nom: string }) => void;
  onAdd: () => void;
  onUpdate: () => void;
  onReset: () => void;
  isLoading: boolean;
}

export const SoustraitantDialog = ({
  isOpen,
  onOpenChange,
  editingSoustraitant,
  newSoustraitant,
  onNewSoustraitantChange,
  onAdd,
  onUpdate,
  onReset,
  isLoading
}: SoustraitantDialogProps) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <Button size="sm" onClick={onReset} disabled={isLoading}>
          <Plus className="w-4 h-4 mr-1" />
          Ajouter
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {editingSoustraitant ? 'Modifier' : 'Ajouter'} un sous-traitant
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="nom">Nom du sous-traitant</Label>
            <Input
              id="nom"
              value={newSoustraitant.nom}
              onChange={(e) => onNewSoustraitantChange({ ...newSoustraitant, nom: e.target.value })}
              placeholder="Ex: Corsim"
              disabled={isLoading}
            />
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="outline" onClick={onReset} disabled={isLoading}>
              Annuler
            </Button>
            <Button 
              onClick={editingSoustraitant ? onUpdate : onAdd}
              disabled={isLoading}
            >
              {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {editingSoustraitant ? 'Modifier' : 'Ajouter'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
