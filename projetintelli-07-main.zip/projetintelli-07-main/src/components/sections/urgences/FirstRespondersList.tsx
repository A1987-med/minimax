
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Heart, Building2, Phone, Users, Edit } from "lucide-react";
import { EntryData } from "@/types/accueil";
import { EditWorkerModal } from "../accueil/EditWorkerModal";

interface FirstRespondersListProps {
  entries: EntryData[];
  onCall: (number: string) => void;
  onUpdate?: (id: string, data: Partial<EntryData>) => void;
}

// Fonction pour nettoyer le corps de métier
const cleanCorpsMetier = (corpsMetier: string): string => {
  // Liste des valeurs incorrectes à filtrer
  const invalidValues = [
    'Formule: Valide',
    'Formule: Échue',
    'Valide',
    'Échue'
  ];
  
  if (!corpsMetier || invalidValues.includes(corpsMetier)) {
    return 'Non spécifié';
  }
  
  return corpsMetier;
};

export const FirstRespondersList = ({ entries, onCall, onUpdate }: FirstRespondersListProps) => {
  const [editingEntry, setEditingEntry] = useState<EntryData | null>(null);

  // Filtrer UNIQUEMENT les vrais secouristes avec une vérification stricte
  const secouristes = entries.filter(entry => {
    console.log('🔍 FILTER DEBUG - Worker:', entry.nomEmploye, 'estSecouriste:', entry.estSecouriste, 'type:', typeof entry.estSecouriste);
    return entry.estSecouriste === true;
  });
  
  console.log('🚨 DEBUG FirstRespondersList - Total entries:', entries.length);
  console.log('🚨 DEBUG FirstRespondersList - Secouristes filtrés:', secouristes.length);
  
  // Grouper par sous-traitant
  const secouristesParSoustraitant = secouristes.reduce((acc, entry) => {
    const soustraitant = entry.soustraitant || entry.entreprise || 'Non spécifié';
    if (!acc[soustraitant]) {
      acc[soustraitant] = [];
    }
    acc[soustraitant].push(entry);
    return acc;
  }, {} as Record<string, EntryData[]>);

  // Trier les entreprises par ordre alphabétique
  const sortedEntreprises = Object.entries(secouristesParSoustraitant).sort(([a], [b]) => a.localeCompare(b));

  const handleEdit = (entry: EntryData) => {
    setEditingEntry(entry);
  };

  const handleSave = (updatedData: Partial<EntryData>) => {
    if (editingEntry && onUpdate) {
      onUpdate(editingEntry.id, updatedData);
    }
    setEditingEntry(null);
  };

  if (secouristes.length === 0) {
    return (
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-orange-800">
            <Heart className="w-5 h-5" />
            Secouristes disponibles (0)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-4 text-orange-600">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Aucun secouriste déclaré sur le chantier</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-800">
            <Heart className="w-5 h-5" />
            Secouristes disponibles ({secouristes.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {sortedEntreprises.map(([soustraitant, workers]) => (
            <div key={soustraitant} className="border rounded-lg p-3 bg-white shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <Building2 className="w-4 h-4 text-green-600" />
                <h3 className="font-semibold text-green-800">{soustraitant}</h3>
                <Badge variant="outline" className="text-green-700 border-green-300">
                  {workers.length} secouriste{workers.length > 1 ? 's' : ''}
                </Badge>
              </div>
              
              {/* En-tête des colonnes */}
              <div className="grid grid-cols-6 gap-2 mb-2 text-xs font-medium text-gray-600 px-2">
                <div className="col-span-3">Secouriste</div>
                <div className="col-span-1 text-center">Éditer</div>
                <div className="col-span-2 text-center">Appeler</div>
              </div>
              
              <div className="space-y-1">
                {workers.map((worker) => {
                  console.log('🚨 DEBUG Rendu worker:', worker.nomEmploye, 'Données complètes:', JSON.stringify(worker, null, 2));
                  
                  return (
                    <div key={worker.id} className="grid grid-cols-6 gap-2 items-center p-2 bg-green-50 rounded">
                      {/* Informations du secouriste - 3 colonnes */}
                      <div className="col-span-3 flex items-center gap-2">
                        <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center">
                          <Heart className="w-3 h-3 text-green-600" />
                        </div>
                        <div>
                          <p className="font-medium text-gray-900 text-sm">{worker.nomEmploye}</p>
                          <p className="text-xs text-gray-600">{cleanCorpsMetier(worker.corpsMetier)}</p>
                        </div>
                      </div>
                      
                      {/* Colonne Éditer - 1 colonne */}
                      <div className="col-span-1 flex justify-center">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEdit(worker)}
                          className="flex items-center gap-1 h-8 px-3 text-xs bg-blue-100 hover:bg-blue-200 text-blue-700 border-blue-300"
                        >
                          <Edit className="w-3 h-3" />
                          Éditer
                        </Button>
                      </div>
                      
                      {/* Colonne Appeler - 2 colonnes */}
                      <div className="col-span-2 flex justify-center">
                        {worker.telephone && worker.telephone.replace(/[^\d]/g, '').length === 10 ? (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onCall(worker.telephone)}
                            className="flex items-center gap-1 h-8 px-3 text-xs bg-green-100 hover:bg-green-200 text-green-700 border-green-300"
                          >
                            <Phone className="w-3 h-3" />
                            Appeler
                          </Button>
                        ) : (
                          <Badge variant="outline" className="h-6 px-2 text-xs text-gray-500 border-gray-300 flex items-center whitespace-nowrap">
                            Pas de téléphone
                          </Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {editingEntry && (
        <EditWorkerModal
          entry={editingEntry}
          isOpen={true}
          onClose={() => setEditingEntry(null)}
          onSave={handleSave}
        />
      )}
    </>
  );
};
