
interface Position {
  latitude: number;
  longitude: number;
}

interface MedicalFacility {
  name: string;
  address: string;
  phone?: string;
  distance?: number;
  type: 'hospital' | 'clinic';
}

export const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
  const R = 6371; // Rayon de la Terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c;
  return Math.round(distance * 10) / 10; // Arrondi à 1 décimale
};

export const getDataAge = (timestamp: string): string => {
  const now = new Date();
  const savedTime = new Date(timestamp);
  const diffMs = now.getTime() - savedTime.getTime();
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  
  if (diffHours > 0) {
    return `il y a ${diffHours}h${diffMinutes > 0 ? ` ${diffMinutes}min` : ''}`;
  } else if (diffMinutes > 0) {
    return `il y a ${diffMinutes}min`;
  } else {
    return 'à l\'instant';
  }
};

// Base de données enrichie des établissements médicaux de Montréal avec numéros de téléphone
const enrichedMedicalDatabase = {
  hospitals: [
    {
      name: "CUSM - Centre Universitaire de Santé McGill",
      address: "1001 Boulevard Décarie, Montréal, QC H4A 3J1",
      phone: "514-934-1934",
      type: "hospital" as const
    },
    {
      name: "Hôpital général de Montréal",
      address: "1650 Avenue Cedar, Montréal, QC H3G 1A4",
      phone: "514-934-1934",
      type: "hospital" as const
    },
    {
      name: "Centre hospitalier de l'Université de Montréal (CHUM)",
      address: "1051 Rue Sanguinet, Montréal, QC H2X 3E4",
      phone: "514-890-8000",
      type: "hospital" as const
    },
    {
      name: "Hôpital Maisonneuve-Rosemont",
      address: "5415 Boulevard de l'Assomption, Montréal, QC H1T 2M4",
      phone: "514-252-3400",
      type: "hospital" as const
    },
    {
      name: "Hôpital du Sacré-Cœur de Montréal",
      address: "5400 Boulevard Gouin Ouest, Montréal, QC H4J 1C5",
      phone: "514-338-2222",
      type: "hospital" as const
    },
    {
      name: "Hôpital Royal Victoria",
      address: "1001 Boulevard Décarie, Montréal, QC H4A 3J1",
      phone: "514-934-1934",
      type: "hospital" as const
    },
    {
      name: "Centre hospitalier de LaSalle",
      address: "8585 Rue Terrasse, LaSalle, QC H8P 1C1",
      phone: "514-362-8000",
      type: "hospital" as const
    },
    {
      name: "Hôpital de Verdun",
      address: "4000 Boulevard LaSalle, Verdun, QC H4G 2A3",
      phone: "514-362-1000",
      type: "hospital" as const
    },
    {
      name: "St. Mary's Hospital",
      address: "3830 Avenue Lacombe, Montréal, QC H3T 1M5",
      phone: "514-345-3511",
      type: "hospital" as const
    },
    {
      name: "Hôpital de Lachine",
      address: "650 16e Avenue, Lachine, QC H8S 3N5",
      phone: "514-637-2351",
      type: "hospital" as const
    }
  ],
  clinics: [
    {
      name: "Clinique Médicale Rockland MD",
      address: "100 Chemin Rockland, Mont-Royal, QC H3P 2V9",
      phone: "514-731-4949",
      type: "clinic" as const
    },
    {
      name: "CLSC Côte-des-Neiges",
      address: "5700 Chemin de la Côte-des-Neiges, Montréal, QC H3T 2A8",
      phone: "514-731-8531",
      type: "clinic" as const
    },
    {
      name: "Clinique Médicale Diamant",
      address: "5885 Chemin de la Côte-des-Neiges, Montréal, QC H3S 1Z2",
      phone: "514-739-4636",
      type: "clinic" as const
    },
    {
      name: "CLSC Saint-Louis-du-Parc",
      address: "155 Boulevard Saint-Joseph Est, Montréal, QC H2T 1H4",
      phone: "514-286-9657",
      type: "clinic" as const
    },
    {
      name: "Clinique Greene Avenue",
      address: "1255 Avenue Greene, Westmount, QC H3Z 2A4",
      phone: "514-932-3003",
      type: "clinic" as const
    },
    {
      name: "CLSC de Saint-Michel",
      address: "3355 Rue Jarry Est, Montréal, QC H1Z 2E5",
      phone: "514-374-8223",
      type: "clinic" as const
    },
    {
      name: "Polyclinique Levasseur",
      address: "8000 Boulevard Langelier, Saint-Léonard, QC H1P 3K2",
      phone: "514-383-0559",
      type: "clinic" as const
    },
    {
      name: "CLSC Rene Cassin",
      address: "5800 Boulevard Cavendish, Côte Saint-Luc, QC H4W 2T5",
      phone: "514-484-7878",
      type: "clinic" as const
    },
    {
      name: "Centre de Gynécologie et de Maternité de Lasalle",
      address: "1811 Avenue Dollard, LaSalle, QC H8N 1T9",
      phone: "514-364-3700",
      type: "clinic" as const
    },
    {
      name: "CLSC de Benny Farm",
      address: "6484 Avenue de Monkland, Montréal, QC H4B 1H3",
      phone: "514-484-1471",
      type: "clinic" as const
    }
  ]
};

// Fonction pour enrichir les données OpenStreetMap avec notre base de données
const enrichFacilityData = (osmFacility: any, userPosition: Position): MedicalFacility | null => {
  const facilityName = osmFacility.tags?.name;
  if (!facilityName) return null;

  // Coordonnées de l'établissement
  let lat = osmFacility.lat;
  let lon = osmFacility.lon;
  
  if (!lat || !lon) {
    // Pour les ways et relations, utiliser le centre
    if (osmFacility.center) {
      lat = osmFacility.center.lat;
      lon = osmFacility.center.lon;
    } else {
      return null;
    }
  }

  // Calculer la distance
  const distance = calculateDistance(userPosition.latitude, userPosition.longitude, lat, lon);

  // Essayer de trouver un numéro de téléphone dans les tags OSM
  let phone = osmFacility.tags?.phone || osmFacility.tags?.['contact:phone'];
  
  // Si pas de téléphone dans OSM, chercher dans notre base enrichie
  if (!phone) {
    const enrichedData = [
      ...enrichedMedicalDatabase.hospitals,
      ...enrichedMedicalDatabase.clinics
    ];
    
    const match = enrichedData.find(facility => 
      facility.name.toLowerCase().includes(facilityName.toLowerCase()) ||
      facilityName.toLowerCase().includes(facility.name.toLowerCase())
    );
    
    if (match) {
      phone = match.phone;
    }
  }

  // Construire l'adresse
  let address = '';
  if (osmFacility.tags?.['addr:housenumber'] && osmFacility.tags?.['addr:street']) {
    address = `${osmFacility.tags['addr:housenumber']} ${osmFacility.tags['addr:street']}`;
    if (osmFacility.tags?.['addr:city']) {
      address += `, ${osmFacility.tags['addr:city']}`;
    }
    if (osmFacility.tags?.['addr:postcode']) {
      address += `, ${osmFacility.tags['addr:postcode']}`;
    }
  } else {
    // Utiliser les coordonnées comme adresse de secours
    address = `${lat.toFixed(6)}, ${lon.toFixed(6)}`;
  }

  // Déterminer le type
  const type = osmFacility.tags?.amenity === 'hospital' ? 'hospital' : 'clinic';

  return {
    name: facilityName,
    address,
    phone,
    distance,
    type
  };
};

export const processFacilities = (elements: any[], userPosition: Position, type: 'hospital' | 'clinic'): MedicalFacility[] => {
  const facilities: MedicalFacility[] = [];
  
  console.log(`Traitement de ${elements.length} éléments ${type} depuis OpenStreetMap`);
  
  for (const element of elements) {
    const facility = enrichFacilityData(element, userPosition);
    if (facility && facility.type === type) {
      facilities.push(facility);
    }
  }
  
  // Trier par distance
  facilities.sort((a, b) => (a.distance || 0) - (b.distance || 0));
  
  console.log(`${facilities.length} ${type}s traités et triés par distance`);
  
  return facilities;
};

export const getDefaultFacilities = (type: 'hospital' | 'clinic'): MedicalFacility[] => {
  const facilities = type === 'hospital' 
    ? enrichedMedicalDatabase.hospitals 
    : enrichedMedicalDatabase.clinics;
    
  return facilities.slice(0, 3).map(facility => ({
    ...facility,
    distance: undefined // La distance sera calculée plus tard si nécessaire
  }));
};

// Nouvelle fonction pour enrichir les résultats avec des données supplémentaires
export const enrichFacilitiesWithExternalData = async (facilities: MedicalFacility[]): Promise<MedicalFacility[]> => {
  const enrichedFacilities = [...facilities];
  
  for (let i = 0; i < enrichedFacilities.length; i++) {
    const facility = enrichedFacilities[i];
    
    // Si pas de téléphone, chercher dans notre base enrichie
    if (!facility.phone) {
      const enrichedData = [
        ...enrichedMedicalDatabase.hospitals,
        ...enrichedMedicalDatabase.clinics
      ];
      
      const match = enrichedData.find(enriched => 
        enriched.name.toLowerCase().includes(facility.name.toLowerCase()) ||
        facility.name.toLowerCase().includes(enriched.name.toLowerCase()) ||
        // Recherche par mots-clés
        facility.name.toLowerCase().includes('chum') && enriched.name.toLowerCase().includes('chum') ||
        facility.name.toLowerCase().includes('cusm') && enriched.name.toLowerCase().includes('cusm') ||
        facility.name.toLowerCase().includes('clsc') && enriched.name.toLowerCase().includes('clsc')
      );
      
      if (match) {
        enrichedFacilities[i] = {
          ...facility,
          phone: match.phone,
          address: match.address || facility.address
        };
        console.log(`✅ Enrichi ${facility.name} avec le téléphone ${match.phone}`);
      } else {
        console.log(`ℹ️ Aucune correspondance trouvée pour ${facility.name}`);
      }
    }
  }
  
  return enrichedFacilities;
};
