
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Phone } from "lucide-react";

interface EmergencyNumbersProps {
  onCall: (number: string) => void;
  cossStatus: string;
  onCossStatusChange: (status: string) => void;
}

export const EmergencyNumbers = ({ onCall, cossStatus, onCossStatusChange }: EmergencyNumbersProps) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Disponible':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'En déplacement':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Absent':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card className="border-red-200">
      <CardHeader>
        <CardTitle className="text-red-600 flex items-center gap-2">
          <Phone className="w-5 h-5" />
          Numéros d'urgence
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button 
            variant="outline" 
            className="h-16 justify-start border-red-200 hover:bg-red-50"
            onClick={() => onCall("911")}
          >
            <div className="text-left">
              <div className="font-semibold text-red-600">🚨 Urgences (Police, Pompiers, Ambulance)</div>
              <div className="text-sm text-gray-600">911</div>
            </div>
          </Button>

          <Button 
            variant="outline" 
            className="h-16 justify-start border-blue-200 hover:bg-blue-50"
            onClick={() => onCall("*4141")}
          >
            <div className="text-left">
              <div className="font-semibold text-blue-600">ℹ️ Info-Santé</div>
              <div className="text-sm text-gray-600">811 ou *4141</div>
            </div>
          </Button>

          <div className="md:col-span-2">
            <div 
              className="h-20 w-full border border-orange-200 rounded-md p-4 hover:bg-orange-50 cursor-pointer transition-colors"
              onClick={() => onCall("14384392609")}
            >
              <div className="text-left w-full">
                <div className="flex items-center justify-between mb-2">
                  <div className="font-semibold text-orange-600">🛡️ CoSS - Abdelhamid Ouldzeid</div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Statut :</span>
                    <Select value={cossStatus} onValueChange={onCossStatusChange}>
                      <SelectTrigger className={`w-32 h-6 text-xs ${getStatusColor(cossStatus)}`} onClick={(e) => e.stopPropagation()}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Disponible">Disponible</SelectItem>
                        <SelectItem value="En déplacement">En déplacement</SelectItem>
                        <SelectItem value="Absent">Absent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="text-sm text-gray-600">1(438) 439-2609</div>
              </div>
            </div>
          </div>

          <Button 
            variant="outline" 
            className="h-16 justify-start border-purple-200 hover:bg-purple-50"
            onClick={() => onCall("18002684911")}
          >
            <div className="text-left">
              <div className="font-semibold text-purple-600">☠️ Centre Antipoison du Québec</div>
              <div className="text-sm text-gray-600">1-800-268-4911</div>
            </div>
          </Button>

          <Button 
            variant="outline" 
            className="h-16 justify-start border-gray-200 hover:bg-gray-50"
            onClick={() => onCall("18448773388")}
          >
            <div className="text-left">
              <div className="font-semibold text-gray-600">🧠 Ligne d'écoute et de prévention du suicide</div>
              <div className="text-sm text-gray-600">1-844-877-3388</div>
            </div>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};
