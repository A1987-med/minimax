
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Shield } from "lucide-react";

export const EmergencyProcedures = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5 text-green-600" />
          Procédures d'urgence
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-semibold mb-3">En cas d'accident :</h4>
            <ol className="text-sm space-y-2 text-gray-700">
              <li>1. Sécuriser la zone</li>
              <li>2. Alerter les secours (911)</li>
              <li>3. Prodiguer les premiers secours si formé</li>
              <li>4. Prévenir le CoSS : Abdelhamid Ouldzeid</li>
              <li>5. Ne pas déplacer la victime sauf danger immédiat</li>
            </ol>
          </div>
          
          <div>
            <h4 className="font-semibold mb-3">Contact avec produit chimique :</h4>
            <ol className="text-sm space-y-2 text-gray-700">
              <li>1. Rincer abondamment à l'eau claire (15 min)</li>
              <li>2. Retirer les vêtements contaminés</li>
              <li>3. Contacter le centre antipoison</li>
              <li>4. Consulter la fiche de sécurité du produit</li>
              <li>5. Surveiller les symptômes</li>
            </ol>
          </div>
        </div>
        
        <Alert className="mt-4 border-blue-200 bg-blue-50">
          <Shield className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            Trousse de premiers secours la plus proche : <strong>Bureau de chantier - Armoire rouge</strong>
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  );
};
