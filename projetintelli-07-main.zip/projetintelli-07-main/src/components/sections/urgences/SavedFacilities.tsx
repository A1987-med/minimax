
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Trash2 } from "lucide-react";
import { FacilityCard } from './FacilityCard';
import { getDataAge } from './urgencesUtils';

interface Position {
  latitude: number;
  longitude: number;
}

interface MedicalFacility {
  name: string;
  address: string;
  phone?: string;
  distance?: number;
  type: 'hospital' | 'clinic';
}

interface SavedFacilitiesData {
  hospitals: MedicalFacility[];
  clinics: MedicalFacility[];
  position: Position;
  timestamp: string;
}

interface SavedFacilitiesProps {
  savedData: SavedFacilitiesData | null;
  onClearSavedData: () => void;
  onCall: (number: string) => void;
  onOpenMaps: (address: string, name: string) => void;
}

export const SavedFacilities = ({ savedData, onClearSavedData, onCall, onOpenMaps }: SavedFacilitiesProps) => {
  if (!savedData) return null;

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-blue-600 flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            📍 Mes établissements sauvegardés
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-blue-600 border-blue-200 flex items-center gap-1">
              <Clock className="w-3 h-3" />
              Sauvegardé {getDataAge(savedData.timestamp)}
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={onClearSavedData}
              className="border-red-300 text-red-700 hover:bg-red-100 flex items-center gap-1"
            >
              <Trash2 className="w-4 h-4" />
              Supprimer la liste
            </Button>
          </div>
        </div>
        <CardDescription>
          Établissements médicaux précédemment localisés et sauvegardés
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {/* Position sauvegardée */}
          <div className="bg-white border border-blue-200 rounded p-3">
            <p className="text-sm text-blue-700 font-medium">
              📍 Position sauvegardée: {savedData.position.latitude.toFixed(6)}, {savedData.position.longitude.toFixed(6)}
            </p>
          </div>

          {/* Hôpitaux sauvegardés */}
          {savedData.hospitals.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-semibold text-blue-800">🏥 Hôpitaux sauvegardés</h4>
              <div className="space-y-3">
                {savedData.hospitals.map((hospital, index) => (
                  <FacilityCard 
                    key={`saved-hospital-${index}`}
                    facility={hospital}
                    index={index}
                    onCall={onCall}
                    onOpenMaps={onOpenMaps}
                  />
                ))}
              </div>
            </div>
          )}

          {/* Cliniques sauvegardées */}
          {savedData.clinics.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-semibold text-blue-800">🏥 Cliniques sauvegardées</h4>
              <div className="space-y-3">
                {savedData.clinics.map((clinic, index) => (
                  <FacilityCard 
                    key={`saved-clinic-${index}`}
                    facility={clinic}
                    index={index}
                    onCall={onCall}
                    onOpenMaps={onOpenMaps}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
