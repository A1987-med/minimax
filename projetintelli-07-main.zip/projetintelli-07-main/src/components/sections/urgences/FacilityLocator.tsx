
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Navigation, MapPin, Loader2 } from "lucide-react";
import { FacilityCard } from './FacilityCard';

interface Position {
  latitude: number;
  longitude: number;
}

interface MedicalFacility {
  name: string;
  address: string;
  phone?: string;
  distance?: number;
  type: 'hospital' | 'clinic';
}

interface SavedFacilitiesData {
  hospitals: MedicalFacility[];
  clinics: MedicalFacility[];
  position: Position;
  timestamp: string;
}

interface FacilityLocatorProps {
  userPosition: Position | null;
  isLoadingPosition: boolean;
  isLoadingFacilities: boolean;
  nearestHospitals: MedicalFacility[];
  nearestClinics: MedicalFacility[];
  savedData: SavedFacilitiesData | null;
  onGetLocation: () => void;
  onCall: (number: string) => void;
  onOpenMaps: (address: string, name: string) => void;
}

export const FacilityLocator = ({
  userPosition,
  isLoadingPosition,
  isLoadingFacilities,
  nearestHospitals,
  nearestClinics,
  savedData,
  onGetLocation,
  onCall,
  onOpenMaps
}: FacilityLocatorProps) => {
  return (
    <Card className="border-green-200">
      <CardHeader>
        <CardTitle className="text-green-600 flex items-center gap-2">
          <Navigation className="w-5 h-5" />
          Localiser de nouveaux établissements médicaux
        </CardTitle>
        <CardDescription>
          Rechercher les 3 hôpitaux et 3 cliniques les plus proches de votre position GPS actuelle
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              onClick={onGetLocation}
              disabled={isLoadingPosition}
              className="flex items-center gap-2"
            >
              {isLoadingPosition ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <MapPin className="w-4 h-4" />
              )}
              {isLoadingPosition ? 'Localisation...' : '📍 Localiser établissements proches'}
            </Button>
            {userPosition && (
              <Badge variant="outline" className="text-green-600 border-green-200">
                Position obtenue
              </Badge>
            )}
          </div>

          {isLoadingFacilities && (
            <div className="flex items-center gap-2 text-blue-600">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-sm">Recherche des établissements les plus proches...</span>
            </div>
          )}

          {/* Affichage des résultats uniquement si pas de données sauvegardées ou si nouvelle recherche */}
          {!savedData && nearestHospitals.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-semibold text-green-800">🏥 Nouveaux hôpitaux trouvés</h4>
              <div className="space-y-3">
                {nearestHospitals.map((hospital, index) => (
                  <FacilityCard 
                    key={`new-hospital-${index}`}
                    facility={hospital}
                    index={index}
                    onCall={onCall}
                    onOpenMaps={onOpenMaps}
                  />
                ))}
              </div>
            </div>
          )}

          {!savedData && nearestClinics.length > 0 && (
            <div className="space-y-3">
              <h4 className="font-semibold text-green-800">🏥 Nouvelles cliniques trouvées</h4>
              <div className="space-y-3">
                {nearestClinics.map((clinic, index) => (
                  <FacilityCard 
                    key={`new-clinic-${index}`}
                    facility={clinic}
                    index={index}
                    onCall={onCall}
                    onOpenMaps={onOpenMaps}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
