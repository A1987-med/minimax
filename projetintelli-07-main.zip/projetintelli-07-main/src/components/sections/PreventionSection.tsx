
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowDown, Shield, Search, Filter, BookOpen, AlertTriangle, Wrench, Building, Zap, Wind, Flame, Droplets, Eye, Users, Map, Truck, Mountain } from "lucide-react";
import { Input } from "@/components/ui/input";

interface PreventionSectionProps {
  onBack: () => void;
}

export const PreventionSection = ({ onBack }: PreventionSectionProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedSubsection, setSelectedSubsection] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const preventionCategories = [
    {
      id: 'securite-generale',
      title: 'Sécurité Générale',
      icon: Shield,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      borderColor: 'border-blue-200',
      subsections: [
        'Accidents et analyses des risques',
        'Aspects psychologiques',
        'Discipline vs Infraction',
        'Périmètre de sécurité',
        'Signalisation et sécurité routière',
        'Travailleur isolé'
      ]
    },
    {
      id: 'equipements-outils',
      title: 'Équipements et Outils',
      icon: Wrench,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200',
      subsections: [
        'Air comprimé',
        'Appareils de protection respiratoire',
        'Engins, équipements et outils',
        'Équipements de protection individuelle',
        'Échafaudages',
        'Échelles et escabeaux',
        'Jet d\'eau à haute pression'
      ]
    },
    {
      id: 'construction-batiment',
      title: 'Construction et Bâtiment',
      icon: Building,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      subsections: [
        'Armatures en saillie',
        'Chantier de construction',
        'Charpente de bois',
        'Circulation et stationnement au chantier',
        'Comité de chantier',
        'Creusement',
        'Démolition',
        'Escaliers',
        'Plate-forme',
        'Tenue des lieux'
      ]
    },
    {
      id: 'electricite-energie',
      title: 'Électricité et Énergie',
      icon: Zap,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
      subsections: [
        'Circuits électroniques',
        'Électricité',
        'Éoliennes',
        'Soudage et découpage'
      ]
    },
    {
      id: 'environnement-sante',
      title: 'Environnement et Santé',
      icon: Wind,
      color: 'text-teal-600',
      bgColor: 'bg-teal-50',
      borderColor: 'border-teal-200',
      subsections: [
        'Bruit',
        'Contraintes thermiques',
        'HEPA',
        'Hygiène, santé et environnement',
        'Qualité de l\'air et ventilation',
        'Systèmes de refroidissement',
        'TMS et ergonomie',
        'Vibrations'
      ]
    },
    {
      id: 'substances-dangereuses',
      title: 'Substances Dangereuses',
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200',
      subsections: [
        'Déversement accidentel de produits dangereux',
        'Dynamitage',
        'Hydrocarbures et industries',
        'Matières dangereuses'
      ]
    },
    {
      id: 'espaces-confines',
      title: 'Espaces et Infrastructures',
      icon: Map,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
      borderColor: 'border-purple-200',
      subsections: [
        'Canalisations',
        'Espace clos',
        'Mines',
        'Silos',
        'Tunnels',
        'Usine de concassage'
      ]
    },
    {
      id: 'incendie-urgence',
      title: 'Incendie et Urgences',
      icon: Flame,
      color: 'text-rose-600',
      bgColor: 'bg-rose-50',
      borderColor: 'border-rose-200',
      subsections: [
        'Bouilloire',
        'Boutefeu',
        'Incendie'
      ]
    },
    {
      id: 'travaux-speciaux',
      title: 'Travaux Spécialisés',
      icon: Mountain,
      color: 'text-indigo-600',
      bgColor: 'bg-indigo-50',
      borderColor: 'border-indigo-200',
      subsections: [
        'Déboisement',
        'Déneigement',
        'Travail sur l\'eau',
        'Travaux de toiture - Bitume',
        'Travaux en hauteur',
        'Travaux superposés'
      ]
    },
    {
      id: 'administration',
      title: 'Administration et Références',
      icon: BookOpen,
      color: 'text-gray-600',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      subsections: [
        'Dictionnaire',
        'Mobilisation',
        'MTQ'
      ]
    }
  ];

  const filteredCategories = preventionCategories.filter(category => 
    category.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    category.subsections.some(sub => sub.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const renderSubsectionContent = (subsection: string) => {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={() => setSelectedSubsection(null)} className="flex items-center gap-2">
            <ArrowDown className="w-4 h-4 rotate-90" />
            Retour aux sections
          </Button>
          <h1 className="text-3xl font-bold text-green-600">{subsection}</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              {subsection}
            </CardTitle>
            <CardDescription>
              Contenu en cours de développement pour cette section.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Eye className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Contenu à venir</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Le contenu détaillé pour "{subsection}" sera ajouté prochainement. 
                Cette section contiendra des protocoles, procédures et bonnes pratiques spécifiques.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  const renderCategoryContent = (category: any) => {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={() => setSelectedCategory(null)} className="flex items-center gap-2">
            <ArrowDown className="w-4 h-4 rotate-90" />
            Retour aux catégories
          </Button>
          <h1 className="text-3xl font-bold text-green-600">{category.title}</h1>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {category.subsections.map((subsection: string, index: number) => (
            <Card 
              key={index}
              className="hover:shadow-lg transition-shadow cursor-pointer border-green-200 hover:bg-green-50"
              onClick={() => setSelectedSubsection(subsection)}
            >
              <CardHeader className="pb-3">
                <CardTitle className="text-lg text-gray-800">{subsection}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-xs">
                    En développement
                  </Badge>
                  <ArrowDown className="w-4 h-4 rotate-270 text-green-600" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  };

  if (selectedSubsection) {
    return renderSubsectionContent(selectedSubsection);
  }

  if (selectedCategory) {
    const category = preventionCategories.find(cat => cat.id === selectedCategory);
    if (category) {
      return renderCategoryContent(category);
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-green-600">Inspections</h1>
      </div>

      {/* Barre de recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher une section d'inspection..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Grille des catégories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCategories.map((category) => {
          const IconComponent = category.icon;
          return (
            <Card 
              key={category.id}
              className={`hover:shadow-lg transition-all duration-300 cursor-pointer ${category.borderColor} hover:scale-105`}
              onClick={() => setSelectedCategory(category.id)}
            >
              <CardHeader className={`${category.bgColor} rounded-t-lg`}>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-sm">
                    <IconComponent className={`w-6 h-6 ${category.color}`} />
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-lg text-gray-800">{category.title}</CardTitle>
                    <Badge variant="secondary" className="mt-1">
                      {category.subsections.length} sections
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-4">
                <CardDescription className="mb-3">
                  {category.subsections.slice(0, 3).join(', ')}
                  {category.subsections.length > 3 && '...'}
                </CardDescription>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">
                    Cliquer pour explorer
                  </span>
                  <ArrowDown className={`w-4 h-4 rotate-270 ${category.color}`} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {searchTerm && filteredCategories.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">Aucun résultat trouvé</h3>
            <p className="text-gray-500">
              Aucune section ne correspond à votre recherche "{searchTerm}".
            </p>
          </CardContent>
        </Card>
      )}

      {/* Statistiques rapides */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-green-600" />
            Aperçu des sections d'inspection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{preventionCategories.length}</div>
              <div className="text-sm text-blue-700">Catégories</div>
            </div>
            <div className="p-4 bg-green-50 rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {preventionCategories.reduce((total, cat) => total + cat.subsections.length, 0)}
              </div>
              <div className="text-sm text-green-700">Sections totales</div>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">0</div>
              <div className="text-sm text-orange-700">Contenus développés</div>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">100%</div>
              <div className="text-sm text-purple-700">À développer</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
