
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowDown, FileText, Search, Shield, BookOpen, Lightbulb } from "lucide-react";
import { Input } from "@/components/ui/input";

interface PreventionGeneraleSectionProps {
  onBack: () => void;
}

export const PreventionGeneraleSection = ({ onBack }: PreventionGeneraleSectionProps) => {
  const [selectedSubsection, setSelectedSubsection] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const preventionSections = [
    'ASP Construction',
    'Comité de chantier',
    'Divers',
    'Formulaires SST',
    'Législation et normes SST',
    'Métiers',
    'Mobilisation',
    'Négligence criminelle vs Diligence raisonnable',
    'Pauses-sécurité',
    'Planification',
    'Procédures, plans et permis',
    'Programmes de prévention',
    'Rapports d\'évènements',
    'Rapports quotidiens',
    'Rapports CNESST'
  ];

  const filteredSections = preventionSections.filter(section =>
    section.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderSubsectionContent = (subsection: string) => {
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={() => setSelectedSubsection(null)} className="flex items-center gap-2">
            <ArrowDown className="w-4 h-4 rotate-90" />
            Retour aux sections
          </Button>
          <h1 className="text-3xl font-bold text-emerald-600">{subsection}</h1>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-600" />
              Guide de prévention - {subsection}
            </CardTitle>
            <CardDescription>
              Ressources et bonnes pratiques pour cette section.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Lightbulb className="w-16 h-16 mx-auto text-gray-400 mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">Contenu à venir</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Le guide de prévention détaillé pour "{subsection}" sera ajouté prochainement. 
                Cette section contiendra des conseils pratiques, des bonnes pratiques et des ressources utiles.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  };

  if (selectedSubsection) {
    return renderSubsectionContent(selectedSubsection);
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-emerald-600">Prévention</h1>
      </div>

      {/* Barre de recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Rechercher un guide de prévention..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </CardContent>
      </Card>

      {/* Grille des sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSections.map((section, index) => (
          <Card 
            key={index}
            className="hover:shadow-lg transition-shadow cursor-pointer border-emerald-200 hover:bg-emerald-50"
            onClick={() => setSelectedSubsection(section)}
          >
            <CardHeader className="pb-3">
              <CardTitle className="text-lg text-gray-800 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-emerald-600" />
                {section}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-xs">
                  Guide à développer
                </Badge>
                <ArrowDown className="w-4 h-4 rotate-270 text-emerald-600" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {searchTerm && filteredSections.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="w-16 h-16 mx-auto text-gray-400 mb-4" />
            <h3 className="text-xl font-semibold text-gray-600 mb-2">Aucun résultat trouvé</h3>
            <p className="text-gray-500">
              Aucun guide ne correspond à votre recherche "{searchTerm}".
            </p>
          </CardContent>
        </Card>
      )}

      {/* Statistiques rapides */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-600" />
            Aperçu des guides de prévention
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div className="p-4 bg-blue-50 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{preventionSections.length}</div>
              <div className="text-sm text-blue-700">Guides totaux</div>
            </div>
            <div className="p-4 bg-emerald-50 rounded-lg">
              <div className="text-2xl font-bold text-emerald-600">0</div>
              <div className="text-sm text-emerald-700">Guides développés</div>
            </div>
            <div className="p-4 bg-orange-50 rounded-lg">
              <div className="text-2xl font-bold text-orange-600">100%</div>
              <div className="text-sm text-orange-700">À développer</div>
            </div>
            <div className="p-4 bg-purple-50 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">SST</div>
              <div className="text-sm text-purple-700">Focus</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
