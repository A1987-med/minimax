
import React, { useCallback } from 'react';
import { Upload, Camera, AlertTriangle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useNativeFeatures } from '@/hooks/useNativeFeatures';
import { imageFormatService } from '@/services/imageFormatService';
import { useToast } from "@/hooks/use-toast";

interface PhotoUploadProps {
  onAddPhoto: (files: File[]) => void;
  photoCount: number;
}

export const PhotoUpload = ({ onAddPhoto, photoCount }: PhotoUploadProps) => {
  const { takePicture, selectFromGallery } = useNativeFeatures();
  const { toast } = useToast();

  const validateFiles = (files: FileList | null): File[] => {
    if (!files || files.length === 0) return [];

    const validFiles: File[] = [];
    const invalidFiles: string[] = [];

    Array.from(files).forEach(file => {
      // Vérifier si c'est une image
      if (!file.type.startsWith('image/')) {
        invalidFiles.push(`${file.name} (pas une image)`);
        return;
      }

      // Vérifier la taille (max 100MB)
      const maxSize = 100 * 1024 * 1024; // 100MB
      if (file.size > maxSize) {
        invalidFiles.push(`${file.name} (trop volumineux: ${Math.round(file.size / (1024 * 1024))}MB)`);
        return;
      }

      validFiles.push(file);
    });

    // Afficher les erreurs pour les fichiers invalides
    if (invalidFiles.length > 0) {
      toast({
        title: "Fichiers non valides",
        description: `${invalidFiles.length} fichier(s) ignoré(s): ${invalidFiles.join(', ')}`,
        variant: "destructive",
        duration: 6000,
      });
    }

    return validFiles;
  };

  const handleFileInput = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const files = validateFiles(event.target.files);
    if (files.length > 0) {
      onAddPhoto(files);
    }
    // Reset input pour permettre de sélectionner le même fichier
    event.target.value = '';
  }, [onAddPhoto]);

  const handleDrop = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    const files = validateFiles(event.dataTransfer.files);
    if (files.length > 0) {
      onAddPhoto(files);
    }
  }, [onAddPhoto]);

  const handleDragOver = useCallback((event: React.DragEvent<HTMLDivElement>) => {
    event.preventDefault();
  }, []);

  const handleTakePhoto = async () => {
    try {
      const photoData = await takePicture();
      if (photoData) {
        // Convertir dataURL en File
        const response = await fetch(photoData);
        const blob = await response.blob();
        const file = new File([blob], `photo-${Date.now()}.jpg`, { type: 'image/jpeg' });
        onAddPhoto([file]);
      }
    } catch (error) {
      console.error('Erreur prise de photo:', error);
      toast({
        title: "Erreur",
        description: "Impossible de prendre une photo",
        variant: "destructive",
      });
    }
  };

  const handleSelectGallery = async () => {
    try {
      const photosData = await selectFromGallery();
      if (photosData && photosData.length > 0) {
        const files: File[] = [];
        
        for (const photoData of photosData) {
          const response = await fetch(photoData);
          const blob = await response.blob();
          const file = new File([blob], `gallery-${Date.now()}-${Math.random()}.jpg`, { type: 'image/jpeg' });
          files.push(file);
        }
        
        onAddPhoto(files);
      }
    } catch (error) {
      console.error('Erreur sélection galerie:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sélectionner depuis la galerie",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Informations sur les formats supportés */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-800 mb-2">Formats d'image supportés par l'IA Claude</h4>
              <div className="text-sm text-blue-700 space-y-1">
                <p><strong>✅ Supportés :</strong> JPEG, PNG, WebP, GIF</p>
                <p><strong>❌ Non supportés :</strong> DNG, RAW, TIFF, BMP, HEIC, SVG</p>
                <p className="text-xs mt-2">💡 Les formats non supportés seront automatiquement convertis en JPEG</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Zone de téléchargement */}
      <Card 
        className="border-2 border-dashed border-teal-300 bg-teal-50/50 hover:bg-teal-50 transition-colors cursor-pointer"
        onDrop={handleDrop}
        onDragOver={handleDragOver}
      >
        <CardContent className="p-8">
          <div className="text-center space-y-4">
            <div className="w-16 h-16 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto">
              <Upload className="w-8 h-8 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">
                Glissez vos photos ici ou cliquez pour sélectionner
              </h3>
              <p className="text-gray-600">
                L'analyse IA Claude commencera automatiquement (tous formats acceptés)
              </p>
              <p className="text-sm text-gray-500 mt-2">
                Photos actuelles: {photoCount} • Limite: 100MB par photo
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <label className="cursor-pointer">
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  onChange={handleFileInput}
                  className="hidden"
                />
                <Button variant="outline" className="w-full sm:w-auto">
                  <Upload className="w-4 h-4 mr-2" />
                  Sélectionner fichiers
                </Button>
              </label>
              
              <Button 
                onClick={handleTakePhoto}
                variant="outline"
                className="w-full sm:w-auto"
              >
                <Camera className="w-4 h-4 mr-2" />
                Prendre photo
              </Button>
              
              <Button 
                onClick={handleSelectGallery}
                variant="outline"
                className="w-full sm:w-auto"
              >
                <Upload className="w-4 h-4 mr-2" />
                Galerie
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
