
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Trash2, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Clock,
  Camera,
  Eye,
  Maximize2,
  Calendar
} from "lucide-react";
import { PhotoAnalysisResults } from './PhotoAnalysisResults';
import { PhotoDetailModal } from './PhotoDetailModal';
import { formatExifDate } from '@/services/exifService';
import type { AnalyzedPhoto } from '../PhotoInspectionSection';

interface PhotoListProps {
  photos: AnalyzedPhoto[];
  onRemovePhoto: (photoId: string) => Promise<void>;
  onRetryAnalysis: (photoId: string) => Promise<void>;
}

export const PhotoList = ({ photos, onRemovePhoto, onRetryAnalysis }: PhotoListProps) => {
  const [selectedPhoto, setSelectedPhoto] = useState<AnalyzedPhoto | null>(null);

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    if (score >= 40) return "text-orange-600";
    return "text-red-600";
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (score >= 60) return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
    if (score >= 40) return <AlertTriangle className="w-5 h-5 text-orange-600" />;
    return <XCircle className="w-5 h-5 text-red-600" />;
  };

  return (
    <div className="space-y-6">
      {photos.map((photo, index) => (
        <Card key={photo.id} className="bg-white/80 backdrop-blur-sm border-0 shadow-xl overflow-hidden">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3 text-lg">
                <div className="w-10 h-10 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-lg flex items-center justify-center shadow-md">
                  <Camera className="w-5 h-5 text-white" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    Photo {index + 1}
                    {photo.analyzing ? (
                      <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                        <Clock className="w-3 h-3 mr-1 animate-pulse" />
                        Analyse en cours...
                      </Badge>
                    ) : photo.analysis ? (
                      <div className="flex items-center gap-2">
                        {getScoreIcon(photo.analysis.scoreGlobal)}
                        <span className={`font-semibold ${getScoreColor(photo.analysis.scoreGlobal)}`}>
                          {photo.analysis.scoreGlobal}%
                        </span>
                      </div>
                    ) : (
                      <Badge variant="destructive">
                        Erreur d'analyse
                      </Badge>
                    )}
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm text-gray-600">
                      {photo.file.name} • {Math.round(photo.file.size / 1024)} KB
                    </p>
                    {photo.exifData?.dateTime ? (
                      <p className="text-xs text-green-600 flex items-center gap-1 font-medium">
                        <Calendar className="w-3 h-3" />
                        📅 Prise le {formatExifDate(photo.exifData.dateTime)}
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Date de prise non disponible
                      </p>
                    )}
                    {photo.exifData?.cameraMake && photo.exifData?.cameraModel && (
                      <p className="text-xs text-blue-600 font-medium">
                        📱 {photo.exifData.cameraMake} {photo.exifData.cameraModel}
                      </p>
                    )}
                    {photo.exifData?.gpsLatitude && photo.exifData?.gpsLongitude && (
                      <p className="text-xs text-purple-600 font-medium">
                        📍 GPS: {photo.exifData.gpsLatitude.toFixed(4)}, {photo.exifData.gpsLongitude.toFixed(4)}
                      </p>
                    )}
                  </div>
                </div>
              </CardTitle>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => setSelectedPhoto(photo)}
                  variant="outline"
                  size="sm"
                  className="text-green-600 hover:bg-green-50"
                >
                  <Maximize2 className="w-4 h-4 mr-1" />
                  Agrandir
                </Button>
                {photo.analysis && !photo.analyzing && (
                  <Button
                    onClick={() => onRetryAnalysis(photo.id)}
                    variant="outline"
                    size="sm"
                    className="text-blue-600 hover:bg-blue-50"
                  >
                    <RefreshCw className="w-4 h-4 mr-1" />
                    Relancer
                  </Button>
                )}
                <Button
                  onClick={() => onRemovePhoto(photo.id)}
                  variant="outline"
                  size="sm"
                  className="text-red-600 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            {/* Aperçu de l'image */}
            <div className="flex items-center gap-4">
              <div className="relative w-32 h-24 bg-gray-100 rounded-lg overflow-hidden shadow-md cursor-pointer"
                   onClick={() => setSelectedPhoto(photo)}>
                <img 
                  src={photo.url} 
                  alt={`Photo ${index + 1}`}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-black/0 hover:bg-black/10 transition-colors flex items-center justify-center">
                  <Maximize2 className="w-6 h-6 text-white opacity-0 hover:opacity-100 transition-opacity" />
                </div>
                <div className="absolute bottom-1 right-1">
                  <Badge variant="secondary" className="text-xs bg-black/70 text-white">
                    <Eye className="w-3 h-3 mr-1" />
                    Aperçu
                  </Badge>
                </div>
              </div>
              
              {/* Résumé rapide */}
              {photo.analysis && (
                <div className="flex-1 grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-lg font-bold text-red-600">
                      {photo.analysis.nonConformites?.length || 0}
                    </div>
                    <div className="text-xs text-gray-600">Non-conformités</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-orange-600">
                      {photo.analysis.risques?.length || 0}
                    </div>
                    <div className="text-xs text-gray-600">Risques</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold text-green-600">
                      {photo.analysis.recommandations?.length || 0}
                    </div>
                    <div className="text-xs text-gray-600">Recommandations</div>
                  </div>
                </div>
              )}
            </div>

            {/* Analyse en cours */}
            {photo.analyzing && (
              <div className="flex items-center justify-center py-8 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-center">
                  <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3"></div>
                  <p className="text-blue-800 font-medium">Analyse IA en cours...</p>
                  <p className="text-blue-600 text-sm">Détection des risques de sécurité</p>
                </div>
              </div>
            )}

            {/* Résultats de l'analyse */}
            {photo.analysis && !photo.analyzing && (
              <PhotoAnalysisResults analysis={photo.analysis} />
            )}
          </CardContent>
        </Card>
      ))}

      {/* Modal de détail avec analyse complète */}
      {selectedPhoto && (
        <PhotoDetailModal
          isOpen={!!selectedPhoto}
          onClose={() => setSelectedPhoto(null)}
          photo={selectedPhoto}
        />
      )}
    </div>
  );
};
