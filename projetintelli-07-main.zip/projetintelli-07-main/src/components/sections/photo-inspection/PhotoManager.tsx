
import { useToast } from "@/hooks/use-toast";
import { photoStorageService } from '@/services/photoStorageService';
import { exifService } from '@/services/exifService';
import { ImageFormatService } from '@/services/imageFormatService';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';

interface PhotoManagerProps {
  onPhotoProcessed: (photoData: { url: string; photoInspection: any }) => void;
}

export const PhotoManager = ({ onPhotoProcessed }: PhotoManagerProps) => {
  const { toast } = useToast();

  const handleAddPhoto = async (files: File[]) => {
    console.log('📸 === DÉBUT TRAITEMENT PHOTOS AVEC VALIDATION FORMAT ===');
    console.log('📸 Nombre de photos à traiter:', files.length);

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      console.log(`📸 Traitement photo ${i + 1}/${files.length}`, {
        name: file.name,
        type: file.type,
        size: file.size
      });

      try {
        let processedFile = file;

        // Vérification spéciale pour les fichiers DNG/RAW
        if (ImageFormatService.isDngOrRawFile(file.name, file.type)) {
          console.log('🚫 Fichier DNG/RAW détecté:', file.name);
          
          toast({
            title: "Format DNG/RAW non supporté",
            description: `${file.name} est un fichier RAW/DNG. Veuillez le convertir en JPEG avec Lightroom, Photoshop ou un autre logiciel photo avant de l'importer.`,
            variant: "destructive",
            duration: 10000,
          });
          continue; // Passer au fichier suivant
        }

        // Vérifier et convertir le format si nécessaire (autres formats)
        if (!ImageFormatService.isFormatSupported(file.type)) {
          console.log('⚠️ Format non supporté détecté:', file.type);
          
          // Vérifier si c'est un format convertible
          if (ImageFormatService.isFormatUnsupported(file.type)) {
            toast({
              title: "Format non supporté",
              description: `${file.name}: ${ImageFormatService.getFormatErrorMessage(file.type)}`,
              variant: "destructive",
              duration: 8000,
            });
            continue; // Passer au fichier suivant
          }

          // Tentative de conversion pour les formats convertibles
          toast({
            title: "Conversion en cours",
            description: `${file.name}: Format non supporté, conversion automatique en JPEG...`,
            duration: 4000,
          });

          try {
            processedFile = await ImageFormatService.convertToSupportedFormat(file);
            console.log('✅ Conversion réussie:', processedFile.type);
            
            toast({
              title: "Conversion réussie",
              description: `${file.name} a été converti en JPEG pour l'analyse IA.`,
              duration: 4000,
            });
          } catch (conversionError) {
            console.error('❌ Erreur conversion:', conversionError);
            toast({
              title: "Erreur de conversion",
              description: `Impossible de convertir ${file.name}. ${conversionError instanceof Error ? conversionError.message : 'Erreur inconnue'}`,
              variant: "destructive",
              duration: 8000,
            });
            continue; // Passer au fichier suivant
          }
        }

        // Extraire les données EXIF
        const exifData = await exifService.extractExifData(processedFile);
        console.log('📊 EXIF extraites:', exifData ? 'Oui' : 'Non');

        // Upload vers Supabase
        const uploadResult = await photoStorageService.uploadPhoto(processedFile);
        console.log('✅ Upload réussi:', uploadResult.photoInspection.file_name);

        // Callback avec les données
        onPhotoProcessed({
          url: uploadResult.url,
          photoInspection: {
            ...uploadResult.photoInspection,
            exifData
          }
        });

        toast({
          title: "Photo ajoutée avec succès ✅",
          description: `${processedFile.name} prête pour l'analyse IA Claude`,
          duration: 4000,
        });

      } catch (error) {
        console.error(`❌ Erreur traitement photo ${i + 1}:`, error);
        
        toast({
          title: "Erreur traitement photo",
          description: `${file.name}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          variant: "destructive",
          duration: 6000,
        });
      }
    }

    console.log('📸 === FIN TRAITEMENT PHOTOS ===');
  };

  return { handleAddPhoto };
};
