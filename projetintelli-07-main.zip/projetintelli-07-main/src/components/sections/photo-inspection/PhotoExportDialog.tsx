
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { FileText, Download, Calendar, Settings, AlertCircle, Palette, Image } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { pdfExportService, ExportFilters } from '@/services/pdfExportService';
import { AnalyzedPhoto } from '../PhotoInspectionSection';

interface PhotoExportDialogProps {
  isOpen: boolean;
  onClose: () => void;
  photos: AnalyzedPhoto[];
  projectInfo?: {
    nomProjet?: string;
    numeroProjet?: string;
    adresseProjet?: string;
  };
}

export const PhotoExportDialog = ({ isOpen, onClose, photos, projectInfo }: PhotoExportDialogProps) => {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [filters, setFilters] = useState<ExportFilters>({
    includeAnalyses: true,
    includePhotos: true,
    projectInfo
  });

  const handleDateChange = (field: 'dateDebut' | 'dateFin', value: string) => {
    setFilters(prev => ({
      ...prev,
      [field]: value ? new Date(value) : undefined
    }));
  };

  const handleCheckboxChange = (field: 'includeAnalyses' | 'includePhotos', checked: boolean) => {
    setFilters(prev => ({
      ...prev,
      [field]: checked
    }));
  };

  const handleExport = async () => {
    setIsExporting(true);
    
    try {
      console.log('📄 Début de l\'exportation PDF professionnel avec filtres:', filters);
      
      const filtersWithProject = {
        ...filters,
        projectInfo
      };
      
      await pdfExportService.exportPhotoReport(photos, filtersWithProject);
      
      toast({
        title: "Rapport PDF professionnel généré ✅",
        description: "Le rapport d'inspection photos formaté avec couleurs et images a été téléchargé",
        duration: 4000,
      });
      
      onClose();
    } catch (error) {
      console.error('❌ Erreur exportation PDF:', error);
      toast({
        title: "Erreur d'exportation ❌",
        description: error instanceof Error ? error.message : "Impossible de générer le rapport PDF",
        variant: "destructive",
        duration: 6000,
      });
    } finally {
      setIsExporting(false);
    }
  };

  const getFilteredPhotosCount = () => {
    if (!filters.dateDebut && !filters.dateFin) {
      return photos.length;
    }
    
    return photos.filter(photo => {
      let photoDate: Date;
      
      if (photo.exifData?.dateTime) {
        photoDate = new Date(photo.exifData.dateTime);
      } else {
        photoDate = new Date(photo.file.lastModified || Date.now());
      }

      if (filters.dateDebut && photoDate < filters.dateDebut) {
        return false;
      }
      
      if (filters.dateFin && photoDate > filters.dateFin) {
        return false;
      }
      
      return true;
    }).length;
  };

  const filteredCount = getFilteredPhotosCount();

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-white" />
            </div>
            <div>
              <div>Exporter le rapport PDF professionnel</div>
              <p className="text-sm text-gray-600 font-normal">
                Générer un rapport formaté avec couleurs et images
              </p>
            </div>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Filtres par date */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
                <Calendar className="w-4 h-4" />
                Période de sélection
              </div>
              
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label htmlFor="dateDebut" className="text-xs text-gray-600">
                    Date de début
                  </Label>
                  <Input
                    id="dateDebut"
                    type="date"
                    value={filters.dateDebut ? filters.dateDebut.toISOString().split('T')[0] : ''}
                    onChange={(e) => handleDateChange('dateDebut', e.target.value)}
                    className="text-xs w-full"
                  />
                </div>
                <div>
                  <Label htmlFor="dateFin" className="text-xs text-gray-600">
                    Date de fin
                  </Label>
                  <Input
                    id="dateFin"
                    type="date"
                    value={filters.dateFin ? filters.dateFin.toISOString().split('T')[0] : ''}
                    onChange={(e) => handleDateChange('dateFin', e.target.value)}
                    className="text-xs w-full"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Options d'export améliorées */}
          <Card>
            <CardContent className="p-4 space-y-4">
              <div className="flex items-center gap-2 text-sm font-medium text-gray-700">
                <Settings className="w-4 h-4" />
                Options de formatage professionnel
              </div>
              
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includeAnalyses"
                    checked={filters.includeAnalyses}
                    onCheckedChange={(checked) => handleCheckboxChange('includeAnalyses', checked as boolean)}
                  />
                  <Label htmlFor="includeAnalyses" className="text-sm flex items-center gap-2">
                    <Palette className="w-4 h-4 text-blue-600" />
                    Inclure les analyses IA avec mise en forme colorée
                  </Label>
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="includePhotos"
                    checked={filters.includePhotos}
                    onCheckedChange={(checked) => handleCheckboxChange('includePhotos', checked as boolean)}
                  />
                  <Label htmlFor="includePhotos" className="text-sm flex items-center gap-2">
                    <Image className="w-4 h-4 text-green-600" />
                    Inclure les images dans le rapport
                  </Label>
                </div>
              </div>
              
              {/* Aperçu des fonctionnalités */}
              <div className="mt-4 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border border-blue-200">
                <div className="text-xs text-blue-800 font-medium">✨ Format professionnel inclut:</div>
                <div className="text-xs text-blue-700 mt-1 space-y-1">
                  <div>• Page de couverture avec logo</div>
                  <div>• Table des matières</div>
                  <div>• Graphiques colorés des statistiques</div>
                  <div>• Mise en page avec couleurs et icônes</div>
                  <div>• Page de conclusions</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Aperçu */}
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                <div className="text-sm">
                  <div className="font-medium text-blue-800">
                    Aperçu du rapport professionnel
                  </div>
                  <div className="text-blue-700 mt-1">
                    {filteredCount === 0 ? (
                      <span className="text-red-600">
                        Aucune photo trouvée pour cette période
                      </span>
                    ) : (
                      <>
                        {filteredCount} photo{filteredCount > 1 ? 's' : ''} sera{filteredCount > 1 ? 'ont' : ''} incluse{filteredCount > 1 ? 's' : ''} dans le rapport formaté
                        <div className="text-xs mt-2 space-y-1">
                          {filters.includeAnalyses && (
                            <div>✓ Analyses IA avec couleurs et graphiques</div>
                          )}
                          {filters.includePhotos && (
                            <div>✓ Images intégrées dans le PDF</div>
                          )}
                          <div>✓ Mise en page professionnelle avec couleurs</div>
                        </div>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isExporting}
            >
              Annuler
            </Button>
            <Button
              onClick={handleExport}
              disabled={isExporting || filteredCount === 0}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              {isExporting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Génération...
                </>
              ) : (
                <>
                  <Download className="w-4 h-4 mr-2" />
                  Générer PDF Professionnel
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
