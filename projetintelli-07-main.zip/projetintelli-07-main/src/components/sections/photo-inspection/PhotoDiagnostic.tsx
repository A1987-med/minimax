
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Loader2, Settings } from "lucide-react";
import { supabase } from '@/integrations/supabase/client';

export const PhotoDiagnostic = () => {
  const [diagnosticResults, setDiagnosticResults] = useState<any[]>([]);
  const [running, setRunning] = useState(false);

  const runDiagnostic = async () => {
    setRunning(true);
    setDiagnosticResults([]);
    
    const results = [];

    // Test 1: Connexion Supabase
    try {
      const { data, error } = await supabase.from('signalements').select('count').limit(1);
      if (error) throw error;
      results.push({
        test: "Connexion Supabase",
        status: "success",
        message: "✅ Connexion à Supabase fonctionnelle",
        details: { data }
      });
    } catch (error) {
      results.push({
        test: "Connexion Supabase",
        status: "error",
        message: "❌ Problème de connexion Supabase",
        details: { error: error.message }
      });
    }

    // Test 2: Test de la fonction edge analyze-photo
    try {
      console.log('🧪 Test diagnostic de la fonction analyze-photo...');
      
      // Créer une image de test simple
      const canvas = document.createElement('canvas');
      canvas.width = 100;
      canvas.height = 100;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.fillStyle = '#ff0000';
        ctx.fillRect(0, 0, 100, 100);
        ctx.fillStyle = '#ffffff';
        ctx.font = '12px Arial';
        ctx.fillText('TEST', 35, 55);
      }
      
      const testImageUrl = canvas.toDataURL('image/jpeg', 0.5);
      
      const { data, error } = await supabase.functions.invoke('analyze-photo', {
        body: { imageUrl: testImageUrl }
      });

      console.log('🧪 Réponse fonction analyze-photo:', { data, error });

      if (error) {
        results.push({
          test: "Fonction Edge analyze-photo",
          status: "error",
          message: `❌ Erreur fonction: ${error.message}`,
          details: { error, data }
        });
      } else if (data && data.success) {
        // Vérifier si c'est une vraie analyse ou un fallback
        const isFallback = data.analysis?.nonConformites?.some((nc: any) => 
          nc.type?.includes('Analyse technique limitée') || 
          nc.type?.includes('Erreur d\'analyse')
        );
        
        if (isFallback) {
          results.push({
            test: "Fonction Edge analyze-photo",
            status: "warning",
            message: "⚠️ Fonction fonctionne mais utilise l'analyse de secours (fallback)",
            details: { 
              reason: "La clé OpenAI n'est pas configurée correctement ou a un quota insuffisant",
              analysis: data.analysis 
            }
          });
        } else {
          results.push({
            test: "Fonction Edge analyze-photo",
            status: "success",
            message: "✅ Fonction et analyse OpenAI fonctionnelles",
            details: { analysis: data.analysis }
          });
        }
      } else {
        results.push({
          test: "Fonction Edge analyze-photo",
          status: "error",
          message: "❌ Réponse inattendue de la fonction",
          details: { data, error }
        });
      }
    } catch (error) {
      results.push({
        test: "Fonction Edge analyze-photo",
        status: "error",
        message: `❌ Erreur lors du test: ${error.message}`,
        details: { error: error.message }
      });
    }

    // Test 3: Configuration Secrets
    results.push({
      test: "Configuration Secrets",
      status: "info",
      message: "ℹ️ Vérifiez manuellement dans le dashboard Supabase",
      details: {
        instruction: "Allez dans Settings > Edge Functions pour vérifier que OPENAI_API_KEY est configuré",
        expectedFormat: "sk-proj-... ou sk-..."
      }
    });

    setDiagnosticResults(results);
    setRunning(false);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'warning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'error': return 'bg-red-100 text-red-800 border-red-200';
      case 'info': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-600" />;
      case 'info': return <Settings className="w-4 h-4 text-blue-600" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getOverallStatus = () => {
    if (diagnosticResults.length === 0) return 'unknown';
    const hasErrors = diagnosticResults.some(r => r.status === 'error');
    const hasWarnings = diagnosticResults.some(r => r.status === 'warning');
    
    if (hasErrors) return 'error';
    if (hasWarnings) return 'warning';
    return 'success';
  };

  return (
    <Card className="border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="w-5 h-5" />
          Diagnostic IA Photo - Problème OpenAI
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Button 
            onClick={runDiagnostic} 
            disabled={running}
            className="bg-orange-600 hover:bg-orange-700"
          >
            {running ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Diagnostic en cours...
              </>
            ) : (
              'Lancer le diagnostic'
            )}
          </Button>
          
          {diagnosticResults.length > 0 && (
            <Badge className={getStatusColor(getOverallStatus())}>
              {getOverallStatus() === 'success' && '✅ Système OK'}
              {getOverallStatus() === 'warning' && '⚠️ Problèmes détectés'}
              {getOverallStatus() === 'error' && '❌ Erreurs critiques'}
            </Badge>
          )}
        </div>

        {diagnosticResults.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-semibold text-lg">Résultats du diagnostic :</h4>
            
            {diagnosticResults.map((result, index) => (
              <div key={index} className={`border rounded-lg p-4 bg-white ${getStatusColor(result.status).includes('border') ? '' : 'border-gray-200'}`}>
                <div className="flex items-center gap-3 mb-3">
                  {getStatusIcon(result.status)}
                  <span className="font-semibold text-lg">{result.test}</span>
                  <Badge className={getStatusColor(result.status)}>
                    {result.status.toUpperCase()}
                  </Badge>
                </div>
                <p className="text-sm text-gray-700 mb-3 font-medium">{result.message}</p>
                {result.details && (
                  <details className="text-xs">
                    <summary className="cursor-pointer text-blue-600 font-medium hover:text-blue-800">
                      🔍 Voir les détails techniques
                    </summary>
                    <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40 border">
                      {JSON.stringify(result.details, null, 2)}
                    </pre>
                  </details>
                )}
              </div>
            ))}
            
            {getOverallStatus() === 'warning' && (
              <div className="mt-4 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                <h4 className="font-semibold text-yellow-800 mb-2">🔧 Actions recommandées :</h4>
                <ul className="text-sm text-yellow-700 space-y-1">
                  <li>• Vérifiez que votre clé OpenAI est valide et a du crédit</li>
                  <li>• Assurez-vous qu'elle commence par 'sk-proj-' ou 'sk-'</li>
                  <li>• Supprimez et recréez le secret dans Supabase si nécessaire</li>
                  <li>• Vérifiez les logs de la fonction edge pour plus de détails</li>
                </ul>
              </div>
            )}
            
            {getOverallStatus() === 'success' && (
              <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">✅ Système fonctionnel !</h4>
                <p className="text-sm text-green-700">
                  L'analyse IA est opérationnelle. Vos photos de sécurité seront analysées par OpenAI.
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
