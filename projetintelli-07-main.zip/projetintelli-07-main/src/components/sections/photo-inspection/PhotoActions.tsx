
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Save, SaveAll, RefreshCw, FileText } from 'lucide-react';
import { PhotoExportDialog } from './PhotoExportDialog';
import { AnalyzedPhoto } from '../PhotoInspectionSection';
import { projectInfoService } from '@/services/projectInfoService';

interface PhotoActionsProps {
  photoCount: number;
  isSaving: boolean;
  isLoading: boolean;
  photos: AnalyzedPhoto[];
  onSaveAll: () => void;
  onClearAll: () => void;
  onReload: () => void;
}

export const PhotoActions = ({ 
  photoCount, 
  isSaving, 
  isLoading, 
  photos,
  onSaveAll, 
  onClearAll, 
  onReload 
}: PhotoActionsProps) => {
  const [showExportDialog, setShowExportDialog] = useState(false);

  if (photoCount === 0) return null;

  const projectInfo = projectInfoService.getProjectInfo();

  return (
    <>
      <div className="flex gap-2">
        <Button
          onClick={() => setShowExportDialog(true)}
          variant="outline"
          className="text-blue-600 hover:bg-blue-50 border-blue-300"
        >
          <FileText className="w-4 h-4 mr-2" />
          Exporter PDF
        </Button>
        <Button
          onClick={onSaveAll}
          disabled={isSaving}
          className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white"
        >
          {isSaving ? (
            <>
              <Save className="w-4 h-4 mr-2 animate-pulse" />
              Sauvegarde...
            </>
          ) : (
            <>
              <SaveAll className="w-4 h-4 mr-2" />
              Sauvegarder tout
            </>
          )}
        </Button>
        <Button
          onClick={onClearAll}
          variant="outline"
          className="text-red-600 hover:bg-red-50"
        >
          Effacer tout
        </Button>
        <Button
          onClick={onReload}
          variant="outline"
          className="text-green-600 hover:bg-green-50"
          disabled={isLoading}
        >
          <RefreshCw className="w-4 h-4 mr-2" />
          Recharger
        </Button>
      </div>

      <PhotoExportDialog
        isOpen={showExportDialog}
        onClose={() => setShowExportDialog(false)}
        photos={photos}
        projectInfo={projectInfo}
      />
    </>
  );
};
