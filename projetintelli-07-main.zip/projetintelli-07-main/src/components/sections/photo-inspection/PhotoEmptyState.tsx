
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Camera } from 'lucide-react';

export const PhotoEmptyState = () => {
  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-xl">
      <CardContent className="p-12 text-center">
        <div className="w-20 h-20 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg">
          <Camera className="w-10 h-10 text-white" />
        </div>
        <h3 className="text-xl font-semibold text-gray-800 mb-3">Analyse IA Claude de photos de sécurité</h3>
        <p className="text-gray-600 mb-6 max-w-md mx-auto">
          Utilisez Claude (Anthropic) pour détecter automatiquement les problèmes de sécurité sur vos photos de chantier.
        </p>
        <div className="text-sm text-gray-500">
          Maximum 20 photos • Analyse Claude en temps réel • Stockage Supabase
        </div>
      </CardContent>
    </Card>
  );
};
