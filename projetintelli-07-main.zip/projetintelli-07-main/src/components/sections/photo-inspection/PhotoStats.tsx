
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { AnalyzedPhoto } from '../PhotoInspectionSection';

interface PhotoStatsProps {
  photos: AnalyzedPhoto[];
}

export const PhotoStats = ({ photos }: PhotoStatsProps) => {
  const getGlobalStats = () => {
    const analyzedPhotos = photos.filter(p => p.analysis);
    const totalNonConformites = analyzedPhotos.reduce((acc, photo) => 
      acc + (photo.analysis?.nonConformites.length || 0), 0
    );
    const totalRisques = analyzedPhotos.reduce((acc, photo) => 
      acc + (photo.analysis?.risques.length || 0), 0
    );
    const avgScore = analyzedPhotos.length > 0 
      ? analyzedPhotos.reduce((acc, photo) => acc + (photo.analysis?.scoreGlobal || 0), 0) / analyzedPhotos.length
      : 0;

    return { totalNonConformites, totalRisques, avgScore: Math.round(avgScore) };
  };

  const stats = getGlobalStats();

  if (photos.length === 0) return null;

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-teal-600 mb-1">{photos.length}</div>
          <div className="text-sm text-gray-600">Photos analysées</div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-orange-600 mb-1">{stats.totalNonConformites}</div>
          <div className="text-sm text-gray-600">Non-conformités</div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-4 text-center">
          <div className="text-2xl font-bold text-red-600 mb-1">{stats.totalRisques}</div>
          <div className="text-sm text-gray-600">Risques détectés</div>
        </CardContent>
      </Card>
      
      <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-4 text-center">
          <div className={`text-2xl font-bold mb-1 ${
            stats.avgScore >= 80 ? 'text-green-600' : 
            stats.avgScore >= 60 ? 'text-yellow-600' : 'text-red-600'
          }`}>
            {stats.avgScore}%
          </div>
          <div className="text-sm text-gray-600">Score moyen Claude</div>
        </CardContent>
      </Card>
    </div>
  );
};
