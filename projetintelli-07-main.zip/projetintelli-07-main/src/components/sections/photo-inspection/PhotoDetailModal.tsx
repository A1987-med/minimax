
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PhotoAnalysisResults } from './PhotoAnalysisResults';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, Camera, MapPin } from 'lucide-react';
import { formatExifDate } from '@/services/exifService';

interface PhotoDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  photo: {
    url: string;
    file: { name: string };
    analysis?: any;
    exifData?: {
      dateTime?: string;
      cameraMake?: string;
      cameraModel?: string;
      gpsLatitude?: number;
      gpsLongitude?: number;
    };
  } | null;
}

export const PhotoDetailModal: React.FC<PhotoDetailModalProps> = ({ isOpen, onClose, photo }) => {
  if (!photo) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-800">
            Analyse détaillée de l'inspection
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 py-4">
          {/* Colonne de gauche - Image */}
          <div className="lg:col-span-1">
            <Card className="overflow-hidden border border-gray-200">
              <div className="aspect-square relative">
                <img 
                  src={photo.url} 
                  alt="Photo du chantier" 
                  className="absolute inset-0 w-full h-full object-cover"
                />
              </div>
            </Card>

            {/* Informations EXIF */}
            {photo.exifData && (
              <Card className="mt-4">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Camera className="w-4 h-4" />
                    Métadonnées EXIF
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {photo.exifData.dateTime && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-green-600" />
                      <div>
                        <p className="text-sm font-medium">Date de prise</p>
                        <p className="text-xs text-gray-600">
                          {formatExifDate(photo.exifData.dateTime)}
                        </p>
                      </div>
                    </div>
                  )}
                  
                  {(photo.exifData.cameraMake || photo.exifData.cameraModel) && (
                    <div className="flex items-center gap-2">
                      <Camera className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="text-sm font-medium">Appareil</p>
                        <p className="text-xs text-gray-600">
                          {photo.exifData.cameraMake} {photo.exifData.cameraModel}
                        </p>
                      </div>
                    </div>
                  )}

                  {photo.exifData.gpsLatitude && photo.exifData.gpsLongitude && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-red-600" />
                      <div>
                        <p className="text-sm font-medium">Géolocalisation</p>
                        <p className="text-xs text-gray-600">
                          {photo.exifData.gpsLatitude.toFixed(6)}, {photo.exifData.gpsLongitude.toFixed(6)}
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            )}
          </div>

          {/* Colonnes de droite - Résultats d'analyse */}
          <div className="lg:col-span-2 overflow-y-auto max-h-[70vh]">
            {photo.analysis ? (
              <PhotoAnalysisResults analysis={photo.analysis} />
            ) : (
              <div className="p-6 text-center">
                <div className="w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                <p className="text-gray-600">Analyse en cours...</p>
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
