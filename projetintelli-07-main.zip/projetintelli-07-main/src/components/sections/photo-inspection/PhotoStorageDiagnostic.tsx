
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Loader2, Database, RefreshCw } from 'lucide-react';
import { supabasePhotoStorageService } from '@/services/supabasePhotoStorageService';

interface DiagnosticTest {
  name: string;
  status: 'pending' | 'running' | 'success' | 'error';
  message: string;
  details?: string;
}

export const PhotoStorageDiagnostic = () => {
  const [tests, setTests] = useState<DiagnosticTest[]>([
    {
      name: 'Connexion Supabase',
      status: 'pending',
      message: 'Test de connexion à Supabase Storage...'
    },
    {
      name: 'Lecture photos existantes',
      status: 'pending',
      message: 'Vérification de la récupération des photos...'
    }
  ]);

  const [isRunning, setIsRunning] = useState(false);

  const updateTest = (index: number, updates: Partial<DiagnosticTest>) => {
    setTests(prev => prev.map((test, i) => 
      i === index ? { ...test, ...updates } : test
    ));
  };

  const runDiagnostics = async () => {
    setIsRunning(true);
    console.log('🔍 === DÉBUT DIAGNOSTIC STORAGE SUPABASE ===');

    // Test 1: Connexion Supabase
    updateTest(0, { status: 'running', message: 'Test de connexion en cours...' });
    
    try {
      const photos = await supabasePhotoStorageService.getAllPhotos();
      updateTest(0, { 
        status: 'success', 
        message: 'Connexion Supabase réussie',
        details: `Service Supabase opérationnel`
      });
      
      // Test 2: Lecture des photos
      updateTest(1, { status: 'running', message: 'Récupération des photos...' });
      
      updateTest(1, { 
        status: 'success', 
        message: `${photos.length} photo(s) trouvée(s)`,
        details: `Photos chargées depuis Supabase Storage`
      });
      
      console.log('✅ Diagnostic Supabase Storage complet');
      
    } catch (error) {
      console.error('❌ Erreur diagnostic:', error);
      
      updateTest(0, { 
        status: 'error', 
        message: 'Erreur de connexion Supabase',
        details: error instanceof Error ? error.message : 'Erreur inconnue'
      });
      
      updateTest(1, { 
        status: 'error', 
        message: 'Impossible de lire les photos',
        details: 'Échec de connexion Supabase'
      });
    }

    setIsRunning(false);
    console.log('🔍 === FIN DIAGNOSTIC STORAGE SUPABASE ===');
  };

  useEffect(() => {
    runDiagnostics();
  }, []);

  const getStatusIcon = (status: DiagnosticTest['status']) => {
    switch (status) {
      case 'running':
        return <Loader2 className="w-4 h-4 animate-spin text-blue-600" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-600" />;
      default:
        return <div className="w-4 h-4 rounded-full bg-gray-300" />;
    }
  };

  const getStatusBadge = (status: DiagnosticTest['status']) => {
    switch (status) {
      case 'running':
        return <Badge variant="outline" className="text-blue-600 border-blue-200">En cours</Badge>;
      case 'success':
        return <Badge variant="outline" className="text-green-600 border-green-200">Réussi</Badge>;
      case 'error':
        return <Badge variant="outline" className="text-red-600 border-red-200">Échec</Badge>;
      default:
        return <Badge variant="outline" className="text-gray-600 border-gray-200">En attente</Badge>;
    }
  };

  return (
    <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Database className="w-5 h-5 text-teal-600" />
            Diagnostic Supabase Storage
          </CardTitle>
          <Button
            onClick={runDiagnostics}
            disabled={isRunning}
            variant="outline"
            size="sm"
            className="text-teal-600 hover:bg-teal-50"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRunning ? 'animate-spin' : ''}`} />
            Relancer
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {tests.map((test, index) => (
          <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              {getStatusIcon(test.status)}
              <div>
                <div className="font-medium text-sm">{test.name}</div>
                <div className="text-sm text-gray-600">{test.message}</div>
                {test.details && (
                  <div className="text-xs text-gray-500 mt-1">{test.details}</div>
                )}
              </div>
            </div>
            {getStatusBadge(test.status)}
          </div>
        ))}
        
        <div className="text-xs text-gray-500 bg-blue-50 p-2 rounded">
          💡 Ce diagnostic vérifie la connectivité avec Supabase Storage et la capacité à lire les photos existantes.
        </div>
      </CardContent>
    </Card>
  );
};
