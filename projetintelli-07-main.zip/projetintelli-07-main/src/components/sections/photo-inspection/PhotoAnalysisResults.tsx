
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  AlertTriangle, 
  Shield, 
  CheckCircle, 
  XCircle, 
  Users, 
  HardHat, 
  Truck, 
  Wrench, 
  Eye, 
  MapPin,
  Clock,
  AlertCircle,
  Construction,
  Camera
} from "lucide-react";
import type { PhotoAnalysisResult } from '@/services/photoAnalysisService';

interface PhotoAnalysisResultsProps {
  analysis: PhotoAnalysisResult;
}

export const PhotoAnalysisResults = ({ analysis }: PhotoAnalysisResultsProps) => {
  const getGraviteColor = (gravite: string) => {
    switch (gravite) {
      case 'critique': return 'bg-red-100 text-red-800 border-red-200';
      case 'eleve': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'moyen': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'faible': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getImpactColor = (impact: string) => {
    switch (impact) {
      case 'critique': return 'bg-red-100 text-red-800 border-red-200';
      case 'eleve': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'moyen': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'faible': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 bg-green-50";
    if (score >= 60) return "text-yellow-600 bg-yellow-50";
    if (score >= 40) return "text-orange-600 bg-orange-50";
    return "text-red-600 bg-red-50";
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle className="w-5 h-5 text-green-600" />;
    if (score >= 60) return <AlertTriangle className="w-5 h-5 text-yellow-600" />;
    if (score >= 40) return <AlertTriangle className="w-5 h-5 text-orange-600" />;
    return <XCircle className="w-5 h-5 text-red-600" />;
  };

  return (
    <div className="space-y-6">
      {/* Score Global */}
      <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              {getScoreIcon(analysis.scoreGlobal)}
              <div>
                <h3 className="font-semibold text-gray-800">Score de Sécurité IA</h3>
                <p className="text-sm text-gray-600">Évaluation globale automatique</p>
              </div>
            </div>
            <div className={`text-3xl font-bold px-4 py-2 rounded-lg ${getScoreColor(analysis.scoreGlobal)}`}>
              {analysis.scoreGlobal}%
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Analyse Environnementale Ultra-Détaillée */}
      {analysis.environmentAnalysis && (
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-lg">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg flex items-center justify-center shadow-md">
                <Camera className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-lg font-bold text-gray-800">Analyse Environnementale Ultra-Détaillée</div>
                <p className="text-sm text-gray-600">Détection précise de l'environnement de travail</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            
            {/* Présence Humaine Ultra-Détaillée */}
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Users className="w-5 h-5 text-blue-600" />
                <h4 className="font-semibold text-blue-800">👥 Présence Humaine Ultra-Précise</h4>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Détection:</span>
                  <div className={`mt-1 px-2 py-1 rounded ${analysis.environmentAnalysis.humans.detected ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {analysis.environmentAnalysis.humans.detected ? '✅ Confirmée' : '❌ Non détectée'}
                  </div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Nombre exact:</span>
                  <div className="mt-1 text-blue-800 font-medium">{analysis.environmentAnalysis.humans.count}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Équipements:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.humans.equipmentStatus}</div>
                </div>
                <div className="col-span-2 md:col-span-3">
                  <span className="font-medium text-gray-700">Activités observées:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.humans.activities.join(', ')}</div>
                </div>
                {analysis.environmentAnalysis.humans.positions && (
                  <div className="col-span-2 md:col-span-3">
                    <span className="font-medium text-gray-700">Positions:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.humans.positions}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.humans.safetyDistance && (
                  <div className="col-span-2 md:col-span-3">
                    <span className="font-medium text-gray-700">Distance sécurité:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.humans.safetyDistance}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Équipements de Sécurité Ultra-Détaillés */}
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center gap-2 mb-3">
                <HardHat className="w-5 h-5 text-green-600" />
                <h4 className="font-semibold text-green-800">🛡️ Équipements de Sécurité Ultra-Spécifiques</h4>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Casques:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.helmet}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Gilets haute visibilité:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.vest}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Harnais:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.harness}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Chaussures sécurité:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.boots}</div>
                </div>
                {analysis.environmentAnalysis.safety.badges && (
                  <div>
                    <span className="font-medium text-gray-700">Dossards/Badges:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.badges}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.safety.compliance && (
                  <div className="col-span-2 md:col-span-3">
                    <span className="font-medium text-gray-700">Conformité équipements:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.safety.compliance}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Matériaux et Équipements Ultra-Détaillés */}
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <div className="flex items-center gap-2 mb-3">
                <Construction className="w-5 h-5 text-orange-600" />
                <h4 className="font-semibold text-orange-800">🏗️ Matériaux et Équipements Ultra-Spécifiques</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Matériaux construction:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.materials.construction?.join(', ')}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Outils identifiés:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.materials.tools?.join(', ')}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Organisation stockage:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.materials.storage}</div>
                </div>
                {analysis.environmentAnalysis.materials.vehicles && (
                  <div>
                    <span className="font-medium text-gray-700">Véhicules/Engins:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.materials.vehicles}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.materials.machinery && (
                  <div className="col-span-1 md:col-span-2">
                    <span className="font-medium text-gray-700">Machines spécifiques:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.materials.machinery}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Risques et Infrastructure Ultra-Détaillés */}
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <div className="flex items-center gap-2 mb-3">
                <AlertCircle className="w-5 h-5 text-red-600" />
                <h4 className="font-semibold text-red-800">⚠️ Risques et Infrastructure Ultra-Précis</h4>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="font-medium text-gray-700">Niveau de risque:</span>
                  <div className="mt-1 text-red-700 font-medium">{analysis.environmentAnalysis.hazards.level}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Zones dangereuses:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.hazards.zones.join(', ')}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Conditions détectées:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.hazards.conditions}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Éclairage:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.infrastructure.lighting}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Surfaces travail:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.infrastructure.surfaces}</div>
                </div>
                <div>
                  <span className="font-medium text-gray-700">Contrôle accès:</span>
                  <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.infrastructure.access}</div>
                </div>
                {analysis.environmentAnalysis.hazards.signage && (
                  <div>
                    <span className="font-medium text-gray-700">Signalisation:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.hazards.signage}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.hazards.barriers && (
                  <div>
                    <span className="font-medium text-gray-700">Barrières protection:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.hazards.barriers}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.infrastructure.weather && (
                  <div>
                    <span className="font-medium text-gray-700">Conditions météo:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.infrastructure.weather}</div>
                  </div>
                )}
                {analysis.environmentAnalysis.infrastructure.organization && (
                  <div className="col-span-1 md:col-span-2">
                    <span className="font-medium text-gray-700">Organisation chantier:</span>
                    <div className="mt-1 text-gray-700">{analysis.environmentAnalysis.infrastructure.organization}</div>
                  </div>
                )}
              </div>
            </div>

            {/* Description Environnementale Complète */}
            {analysis.environmentDescription && (
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                <div className="flex items-center gap-2 mb-3">
                  <Eye className="w-5 h-5 text-gray-600" />
                  <h4 className="font-semibold text-gray-800">📋 Résumé Environnemental Ultra-Détaillé</h4>
                </div>
                <div className="text-sm text-gray-700 whitespace-pre-line">
                  {analysis.environmentDescription}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Non-conformités */}
      {analysis.nonConformites && analysis.nonConformites.length > 0 && (
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-lg">
              <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-orange-600 rounded-lg flex items-center justify-center shadow-md">
                <XCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-red-700 font-bold">Non-conformités détectées</div>
                <p className="text-sm text-gray-600">{analysis.nonConformites.length} problème(s) identifié(s)</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {analysis.nonConformites.map((nonConformite, index) => (
              <div key={index} className="bg-red-50 p-4 rounded-lg border border-red-200">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-red-800">{nonConformite.type}</h4>
                      <Badge variant="outline" className={`text-xs ${getGraviteColor(nonConformite.gravite)}`}>
                        {nonConformite.gravite}
                      </Badge>
                    </div>
                    <p className="text-red-700 text-sm mb-2">{nonConformite.description}</p>
                    <div className="bg-red-100 p-2 rounded border border-red-200">
                      <p className="text-xs text-red-800"><strong>Solution:</strong> {nonConformite.solution}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Risques */}
      {analysis.risques && analysis.risques.length > 0 && (
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-lg">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center shadow-md">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-orange-700 font-bold">Risques identifiés</div>
                <p className="text-sm text-gray-600">{analysis.risques.length} risque(s) détecté(s)</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {analysis.risques.map((risque, index) => (
              <div key={index} className="bg-orange-50 p-4 rounded-lg border border-orange-200">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-orange-600 mt-1" />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h4 className="font-semibold text-orange-800">{risque.type}</h4>
                      <div className="flex gap-1">
                        <Badge variant="outline" className={`text-xs ${getImpactColor(risque.probabilite)}`}>
                          Probabilité: {risque.probabilite}
                        </Badge>
                        <Badge variant="outline" className={`text-xs ${getImpactColor(risque.impact)}`}>
                          Impact: {risque.impact}
                        </Badge>
                      </div>
                    </div>
                    <p className="text-orange-700 text-sm mb-2">{risque.description}</p>
                    <div className="bg-orange-100 p-2 rounded border border-orange-200">
                      <p className="text-xs text-orange-800"><strong>Prévention:</strong> {risque.prevention}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* Recommandations */}
      {analysis.recommandations && analysis.recommandations.length > 0 && (
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-3 text-lg">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-lg flex items-center justify-center shadow-md">
                <CheckCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="text-blue-700 font-bold">Recommandations</div>
                <p className="text-sm text-gray-600">{analysis.recommandations.length} action(s) recommandée(s)</p>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {analysis.recommandations.map((recommandation, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <CheckCircle className="w-5 h-5 text-blue-600 mt-0.5" />
                  <p className="text-blue-800 text-sm">{recommandation}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
