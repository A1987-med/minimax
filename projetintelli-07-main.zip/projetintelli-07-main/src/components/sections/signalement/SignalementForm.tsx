
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowDown, AlertTriangle } from "lucide-react";
import { SignalementTypeSelector } from './SignalementTypeSelector';
import { LocationCapture } from './LocationCapture';
import { PhotoCapture } from './PhotoCapture';
import { signalementService } from '@/services/signalementService';
import { useToast } from "@/hooks/use-toast";

interface FormData {
  type: string;
  description: string;
  lieu: string;
  date: string;
  heure: string;
  nom: string;
  personnesImpliquees: string;
  suggestions: string;
  gpsLocation: { latitude: number; longitude: number } | null;
  photos: string[];
}

interface SignalementFormProps {
  onBack: () => void;
  onSubmit: () => void;
}

export const SignalementForm = ({ onBack, onSubmit }: SignalementFormProps) => {
  const [formData, setFormData] = useState<FormData>({
    type: '',
    description: '',
    lieu: '',
    date: '',
    heure: '',
    nom: '',
    personnesImpliquees: '',
    suggestions: '',
    gpsLocation: null,
    photos: []
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('🚀 SIGNALEMENT - Début de la soumission:', formData);
    
    setIsSubmitting(true);
    
    try {
      // Déterminer la gravité basée sur le type d'incident
      let gravite: 'faible' | 'moyenne' | 'elevee' | 'critique' = 'faible';
      
      if (formData.type.toLowerCase().includes('accident')) {
        gravite = 'elevee';
      } else if (formData.type.toLowerCase().includes('incident')) {
        gravite = 'moyenne';
      } else if (formData.type.toLowerCase().includes('dangereuse')) {
        gravite = 'moyenne';
      }
      
      // Créer l'objet signalement pour Supabase
      const signalementData = {
        type_incident: formData.type,
        description: formData.description,
        lieu: formData.lieu,
        date_incident: formData.date,
        heure_incident: formData.heure,
        temoin_nom: formData.personnesImpliquees || null,
        temoin_contact: null,
        mesures_prises: formData.suggestions || null,
        gravite: gravite,
        statut: 'ouvert' as const,
        rapporte_par: formData.nom || 'Anonyme'
      };
      
      console.log('💾 SIGNALEMENT - Données à sauvegarder:', signalementData);
      
      // Sauvegarder en base de données
      const nouveauSignalement = await signalementService.create(signalementData);
      console.log('✅ SIGNALEMENT - Signalement créé:', nouveauSignalement);
      
      toast({
        title: "Signalement envoyé",
        description: "Votre signalement a été enregistré avec succès",
        variant: "default"
      });
      
      // Appeler le callback de réussite
      onSubmit();
      
    } catch (error) {
      console.error('❌ SIGNALEMENT - Erreur lors de la sauvegarde:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer le signalement. Veuillez réessayer.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateFormData = (updates: Partial<FormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const isFormValid = formData.type && formData.description && formData.lieu && formData.date && formData.heure;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-orange-600">Signalement</h1>
      </div>

      <Alert className="border-orange-200 bg-orange-50">
        <AlertTriangle className="h-4 w-4 text-orange-600" />
        <AlertDescription className="text-orange-800">
          Signaler tout incident, presqu'accident ou condition dangereuse contribue à améliorer la sécurité de tous.
          Les signalements peuvent être anonymes.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-600" />
            Formulaire de signalement
          </CardTitle>
          <CardDescription>
            Tous les champs marqués d'un * sont obligatoires
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <SignalementTypeSelector
              selectedType={formData.type}
              onTypeSelect={(type) => updateFormData({ type })}
            />

            {/* Description */}
            <div>
              <label className="block text-sm font-medium mb-2">Description de l'événement *</label>
              <textarea
                value={formData.description}
                onChange={(e) => updateFormData({ description: e.target.value })}
                placeholder="Décrivez en détail ce qui s'est passé, les circonstances, les causes possibles..."
                className="w-full p-3 border border-gray-200 rounded-lg h-32 resize-none"
                required
              />
            </div>

            {/* Lieu et date */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Lieu précis *</label>
                <input
                  type="text"
                  value={formData.lieu}
                  onChange={(e) => updateFormData({ lieu: e.target.value })}
                  placeholder="Zone, bâtiment, étage..."
                  className="w-full p-3 border border-gray-200 rounded-lg"
                  required
                />
                {formData.gpsLocation && (
                  <div className="mt-2 text-xs text-green-600">
                    📍 Position GPS: {formData.gpsLocation.latitude.toFixed(6)}, {formData.gpsLocation.longitude.toFixed(6)}
                  </div>
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Date *</label>
                <input
                  type="date"
                  value={formData.date}
                  onChange={(e) => updateFormData({ date: e.target.value })}
                  className="w-40 p-3 border border-gray-200 rounded-lg"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Heure *</label>
                <input
                  type="time"
                  value={formData.heure}
                  onChange={(e) => updateFormData({ heure: e.target.value })}
                  className="w-32 p-3 border border-gray-200 rounded-lg"
                  required
                />
              </div>
            </div>

            {/* Champs facultatifs */}
            <div className="space-y-4">
              <h3 className="font-medium text-gray-700">Informations complémentaires (facultatif)</h3>
              
              <div>
                <label className="block text-sm font-medium mb-2">Nom du signalant (peut rester anonyme)</label>
                <input
                  type="text"
                  value={formData.nom}
                  onChange={(e) => updateFormData({ nom: e.target.value })}
                  placeholder="Votre nom (optionnel)"
                  className="w-full p-3 border border-gray-200 rounded-lg"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Personnes impliquées</label>
                <input
                  type="text"
                  value={formData.personnesImpliquees}
                  onChange={(e) => updateFormData({ personnesImpliquees: e.target.value })}
                  placeholder="Noms des personnes concernées (optionnel)"
                  className="w-full p-3 border border-gray-200 rounded-lg"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium mb-2">Suggestions d'actions correctives</label>
                <textarea
                  value={formData.suggestions}
                  onChange={(e) => updateFormData({ suggestions: e.target.value })}
                  placeholder="Vos suggestions pour éviter que cela se reproduise..."
                  className="w-full p-3 border border-gray-200 rounded-lg h-24 resize-none"
                />
              </div>
            </div>

            <LocationCapture
              gpsLocation={formData.gpsLocation}
              onLocationCaptured={(location) => updateFormData({ gpsLocation: location })}
            />

            <PhotoCapture
              photos={formData.photos}
              onPhotosChange={(photos) => updateFormData({ photos })}
            />

            <Button 
              type="submit" 
              className="w-full bg-orange-600 hover:bg-orange-700"
              disabled={!isFormValid || isSubmitting}
            >
              {isSubmitting ? 'Envoi en cours...' : 'Envoyer le signalement'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
