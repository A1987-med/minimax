
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin } from "lucide-react";
import { useNativeFeatures } from "@/hooks/useNativeFeatures";
import { toast } from "sonner";

interface LocationCaptureProps {
  gpsLocation: { latitude: number; longitude: number } | null;
  onLocationCaptured: (location: { latitude: number; longitude: number }) => void;
}

export const LocationCapture = ({ gpsLocation, onLocationCaptured }: LocationCaptureProps) => {
  const { getCurrentPosition } = useNativeFeatures();
  const [loadingLocation, setLoadingLocation] = React.useState(false);

  const handleGetLocation = async () => {
    console.log('Début de la géolocalisation...');
    setLoadingLocation(true);
    try {
      const position = await getCurrentPosition();
      console.log('Position reçue dans le composant:', position);
      if (position) {
        onLocationCaptured(position);
        console.log('Position GPS enregistrée:', position);
        toast.success('Position GPS capturée avec succès !', {
          description: `Lat: ${position.latitude.toFixed(6)}, Lng: ${position.longitude.toFixed(6)}`
        });
      } else {
        console.log('Aucune position reçue');
        toast.error('Aucune position GPS reçue');
      }
    } catch (error) {
      console.error('Erreur lors de l\'obtention de la position:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erreur inconnue lors de la géolocalisation';
      toast.error('Erreur de géolocalisation', {
        description: errorMessage
      });
    } finally {
      setLoadingLocation(false);
    }
  };

  return (
    <Card className="border-green-200 bg-green-50">
      <CardContent className="p-4">
        <div className="flex items-center gap-2 mb-2">
          <MapPin className="w-5 h-5 text-green-600" />
          <span className="font-medium text-green-800">Localisation GPS</span>
        </div>
        <p className="text-sm text-green-700 mb-3">
          Cliquez pour capturer votre position GPS actuelle et préciser automatiquement le lieu
        </p>
        <Button 
          type="button" 
          variant="outline" 
          className="border-green-300 bg-white hover:bg-green-50"
          onClick={handleGetLocation}
          disabled={loadingLocation}
        >
          <MapPin className="w-4 h-4 mr-2" />
          {loadingLocation ? 'Géolocalisation en cours...' : 
           gpsLocation ? 'Mettre à jour la position' : 'Capturer ma position GPS'}
        </Button>
        {gpsLocation && (
          <div className="mt-3 p-3 bg-white rounded border border-green-200">
            <p className="text-sm text-green-700">
              <strong>✓ Position GPS capturée:</strong><br />
              Latitude: {gpsLocation.latitude.toFixed(6)}<br />
              Longitude: {gpsLocation.longitude.toFixed(6)}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
