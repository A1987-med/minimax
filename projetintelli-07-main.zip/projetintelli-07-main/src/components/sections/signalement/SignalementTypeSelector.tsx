
import React from 'react';

interface SignalementTypeSelectorProps {
  selectedType: string;
  onTypeSelect: (type: string) => void;
}

export const SignalementTypeSelector = ({ selectedType, onTypeSelect }: SignalementTypeSelectorProps) => {
  const types = [
    {
      value: 'Incident',
      label: 'Incident',
      description: 'Événement qui s\'est produit'
    },
    {
      value: 'Presqu\'accident',
      label: 'Presqu\'accident',
      description: 'Situation qui aurait pu mal tourner'
    },
    {
      value: 'Condition dangereuse',
      label: 'Condition dangereuse',
      description: 'Situation à risque observée'
    }
  ];

  return (
    <div>
      <label className="block text-sm font-medium mb-2">Type de signalement *</label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {types.map((type) => (
          <button
            key={type.value}
            type="button"
            onClick={() => onTypeSelect(type.value)}
            className={`p-3 border rounded-lg text-left transition-colors ${
              selectedType === type.value 
                ? 'border-orange-500 bg-orange-50 text-orange-700' 
                : 'border-gray-200 hover:bg-gray-50'
            }`}
          >
            <div className="font-medium">{type.label}</div>
            <div className="text-xs text-gray-500 mt-1">{type.description}</div>
          </button>
        ))}
      </div>
    </div>
  );
};
