
import React, { useState } from 'react';
import { Camera, Upload, X, AlertCircle } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useNativeFeatures } from '@/hooks/useNativeFeatures';

interface PhotoCaptureProps {
  photos: string[];
  onPhotosChange: (photos: string[]) => void;
}

export const PhotoCapture = ({ photos, onPhotosChange }: PhotoCaptureProps) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const { takePicture, selectFromGallery } = useNativeFeatures();

  const handleTakePhoto = async () => {
    try {
      setIsCapturing(true);
      const photoData = await takePicture();
      if (photoData) {
        onPhotosChange([...photos, photoData]);
      }
    } catch (error) {
      console.error('Erreur lors de la prise de photo:', error);
    } finally {
      setIsCapturing(false);
    }
  };

  const handleSelectFromGallery = async () => {
    try {
      setIsCapturing(true);
      const photosData = await selectFromGallery();
      if (photosData && photosData.length > 0) {
        onPhotosChange([...photos, ...photosData]);
      }
    } catch (error) {
      console.error('Erreur lors de la sélection depuis la galerie:', error);
    } finally {
      setIsCapturing(false);
    }
  };

  const removePhoto = (index: number) => {
    const newPhotos = photos.filter((_, i) => i !== index);
    onPhotosChange(newPhotos);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="w-5 h-5" />
          Photos du signalement
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Button
            onClick={handleTakePhoto}
            disabled={isCapturing}
            className="h-24 flex flex-col gap-2"
          >
            <Camera className="w-8 h-8" />
            <span>{isCapturing ? "Capture..." : "Prendre une photo"}</span>
          </Button>
          
          <Button
            onClick={handleSelectFromGallery}
            disabled={isCapturing}
            variant="outline"
            className="h-24 flex flex-col gap-2"
          >
            <Upload className="w-8 h-8" />
            <span>{isCapturing ? "Sélection..." : "Importer depuis la galerie"}</span>
          </Button>
        </div>

        {photos.length > 0 && (
          <div className="space-y-3">
            <h4 className="font-medium">Photos capturées ({photos.length})</h4>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {photos.map((photo, index) => (
                <div key={index} className="relative group">
                  <img
                    src={photo}
                    alt={`Photo ${index + 1}`}
                    className="w-full h-24 object-cover rounded-lg border"
                  />
                  <Button
                    onClick={() => removePhoto(index)}
                    size="sm"
                    variant="destructive"
                    className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
          <div className="text-sm text-blue-800">
            <p className="font-medium mb-1">Conseils pour de bonnes photos :</p>
            <ul className="space-y-1 text-xs">
              <li>• Prenez des photos claires et bien éclairées</li>
              <li>• Capturez plusieurs angles si nécessaire</li>
              <li>• Assurez-vous que les détails importants sont visibles</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
