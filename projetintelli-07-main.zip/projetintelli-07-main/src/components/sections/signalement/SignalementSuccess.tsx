
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, Check } from "lucide-react";

interface SignalementSuccessProps {
  onBack: () => void;
}

export const SignalementSuccess = ({ onBack }: SignalementSuccessProps) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-orange-600">Signalement</h1>
      </div>

      <Card className="border-green-200 bg-green-50">
        <CardContent className="p-8 text-center">
          <Check className="w-16 h-16 text-green-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-green-800 mb-2">Signalement envoyé avec succès !</h2>
          <p className="text-green-700">
            Votre signalement a été transmis au responsable sécurité. 
            Un accusé de réception vous sera envoyé sous 24h.
          </p>
        </CardContent>
      </Card>
    </div>
  );
};
