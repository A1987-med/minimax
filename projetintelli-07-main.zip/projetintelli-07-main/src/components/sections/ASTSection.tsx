
import React, { useState, useEffect } from 'react';
import { ASTCorpsMetierSelector } from './ast/ASTCorpsMetierSelector';
import { ASTCalorifugeurOrganigramme } from './ast/ASTCalorifugeurOrganigramme';
import { ASTOrganigramme } from './ast/ASTOrganigramme';

interface ASTSectionProps {
  onBack?: () => void;
  setASTOperationLock?: (locked: boolean) => void;
  initialOccupation?: string;
}

export const ASTSection = ({ onBack, setASTOperationLock, initialOccupation }: ASTSectionProps) => {
  const [selectedCorpsMetier, setSelectedCorpsMetier] = useState<string>(initialOccupation || '');

  // Mettre à jour l'occupation sélectionnée si initialOccupation change
  useEffect(() => {
    if (initialOccupation) {
      console.log('🎯 Initialisation avec occupation:', initialOccupation);
      setSelectedCorpsMetier(initialOccupation);
    }
  }, [initialOccupation]);

  const handleOccupationChange = (occupation: string) => {
    console.log('🎯 Occupation sélectionnée:', occupation);
    setSelectedCorpsMetier(occupation);
  };

  const handleMetierSelect = (metier: string) => {
    console.log('🎯 Métier sélectionné depuis RH:', metier);
    setSelectedCorpsMetier(metier);
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold text-foreground mb-2">
          Analyse Sécuritaire du Travail (AST)
        </h1>
        <p className="text-muted-foreground">
          Sélectionnez une occupation pour visualiser l'analyse sécuritaire
        </p>
      </div>

      <ASTCorpsMetierSelector
        selectedCorpsMetier={selectedCorpsMetier}
        onCorpsMetierChange={handleOccupationChange}
      />

      {selectedCorpsMetier === 'Calorifugeur' && (
        <ASTCalorifugeurOrganigramme />
      )}
      
      {selectedCorpsMetier === 'Arpenteur' && (
        <ASTOrganigramme 
          corpsMetier={selectedCorpsMetier}
          refreshKey={Date.now()}
          onMetierSelect={handleMetierSelect}
        />
      )}
      
      {selectedCorpsMetier && !['Calorifugeur', 'Arpenteur'].includes(selectedCorpsMetier) && (
        <ASTOrganigramme 
          corpsMetier={selectedCorpsMetier}
          refreshKey={Date.now()}
          onMetierSelect={handleMetierSelect}
        />
      )}
    </div>
  );
};
