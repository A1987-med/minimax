
import React from 'react';
import { 
  BookOpen,
  Building2,
  ClipboardList
} from "lucide-react";
import { HomeHeader } from "./home/HomeHeader";
import { QuickInfoCards } from "./home/QuickInfoCards";
import { SectionCards } from "./home/SectionCards";
import { useJoursSansAccident } from "@/hooks/useJoursSansAccident";
import { useProchaineInspection } from "@/hooks/useProchaineInspection";

const sections = [
  {
    id: 'projet-informations',
    title: 'Projet & Informations',
    description: 'Configuration du projet et contacts SST',
    icon: Building2,
    color: 'blue-600',
    textColor: 'text-blue-600',
    bgLight: 'bg-blue-50',
    borderColor: 'border-blue-200',
    iconBg: 'bg-gradient-to-br from-blue-500 to-blue-600'
  },
  {
    id: 'gestion',
    title: 'Gestion RH',
    description: 'Administration et gestion des employés',
    icon: Building2,
    color: 'slate-600',
    textColor: 'text-slate-600',
    bgLight: 'bg-slate-50',
    borderColor: 'border-slate-200',
    iconBg: 'bg-gradient-to-br from-slate-500 to-slate-600'
  },
  {
    id: 'rapport-journalier',
    title: 'Inspection SST',
    description: 'Rapports d\'inspection du coordonnateur SST',
    icon: ClipboardList,
    color: 'emerald-600',
    textColor: 'text-emerald-600',
    bgLight: 'bg-emerald-50',
    borderColor: 'border-emerald-200',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-emerald-600'
  },
  {
    id: 'protocoles',
    title: 'Protocoles SST',
    description: 'Tolérances zéro, signalements, inspections, AST, photos, vidéos et urgences',
    icon: BookOpen,
    color: 'indigo-600',
    textColor: 'text-indigo-600',
    bgLight: 'bg-indigo-50',
    borderColor: 'border-indigo-200',
    iconBg: 'bg-gradient-to-br from-indigo-500 to-indigo-600'
  }
];

interface HomeSectionProps {
  onSectionSelect: (sectionId: string) => void;
}

export const HomeSection = ({ onSectionSelect }: HomeSectionProps) => {
  const { joursSansAccident, isLoading: isLoadingJours, error: errorJours } = useJoursSansAccident();
  const { prochaineInspection, isLoading: isLoadingInspection, error: errorInspection } = useProchaineInspection();

  const handleInspectionClick = () => {
    onSectionSelect('prevention');
  };

  return (
    <div className="min-h-screen p-6 relative">
      <HomeHeader 
        joursSansAccident={joursSansAccident}
        isLoadingJours={isLoadingJours}
        errorJours={errorJours}
      />
      
      <QuickInfoCards
        prochaineInspection={prochaineInspection}
        isLoadingInspection={isLoadingInspection}
        errorInspection={errorInspection}
        onInspectionClick={handleInspectionClick}
      />
      
      <SectionCards
        sections={sections}
        onSectionClick={onSectionSelect}
      />
    </div>
  );
};
