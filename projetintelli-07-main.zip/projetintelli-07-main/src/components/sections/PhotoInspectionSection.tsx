import React from 'react';
import { ArrowLeft, Camera } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { PhotoUpload } from './photo-inspection/PhotoUpload';
import { PhotoList } from './photo-inspection/PhotoList';
import { PhotoDiagnostic } from './photo-inspection/PhotoDiagnostic';
import { PhotoStorageDiagnostic } from './photo-inspection/PhotoStorageDiagnostic';
import { PhotoStats } from './photo-inspection/PhotoStats';
import { PhotoActions } from './photo-inspection/PhotoActions';
import { PhotoEmptyState } from './photo-inspection/PhotoEmptyState';
import { PhotoManager } from './photo-inspection/PhotoManager';
import { usePhotoManagement } from '@/hooks/usePhotoManagement';
import { ExifData } from '@/services/exifService';

interface PhotoInspectionSectionProps {
  onBack: () => void;
}

export interface AnalyzedPhoto {
  id: string;
  file: File;
  url: string;
  analysis?: any;
  analyzing: boolean;
  analysisStartTime?: number;
  exifData?: ExifData;
}

export const PhotoInspectionSection = ({ onBack }: PhotoInspectionSectionProps) => {
  const {
    photos,
    isLoading,
    isSaving,
    debugInfo,
    loadSavedPhotos,
    processPhotoData,
    handleRetryAnalysis,
    handleRemovePhoto,
    handleSaveAll,
    clearSavedPhotos
  } = usePhotoManagement();

  const { handleAddPhoto } = PhotoManager({ 
    onPhotoProcessed: (photoData) => {
      // Convert single photo data to the expected format for processPhotoData
      processPhotoData([photoData.url]);
    }
  });

  const handleClearAll = () => {
    clearSavedPhotos();
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50 p-8 flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des photos depuis Supabase...</p>
          <p className="text-sm text-gray-500 mt-2">{debugInfo}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-white to-cyan-50 p-8 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-20 -right-20 w-80 h-80 bg-gradient-to-br from-teal-200/30 to-cyan-200/30 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-gradient-to-br from-emerald-200/30 to-teal-200/30 rounded-full blur-3xl"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button 
            onClick={onBack}
            variant="outline" 
            size="icon"
            className="hover:bg-teal-100"
          >
            <ArrowLeft className="w-4 h-4" />
          </Button>
          
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-600 rounded-xl flex items-center justify-center shadow-lg">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-800">Photo Inspection IA Claude</h1>
                <p className="text-gray-600">Analyse automatique de sécurité par Anthropic Claude</p>
                <p className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded mt-1">
                  🤖 IA: Claude (Anthropic) - 💾 Stockage: Supabase - {debugInfo}
                </p>
              </div>
            </div>
          </div>

          <PhotoActions
            photoCount={photos.length}
            isSaving={isSaving}
            isLoading={isLoading}
            photos={photos}
            onSaveAll={handleSaveAll}
            onClearAll={handleClearAll}
            onReload={loadSavedPhotos}
          />
        </div>

        {/* Diagnostic Components */}
        <PhotoDiagnostic />
        <PhotoStorageDiagnostic />

        {/* Global Stats */}
        <PhotoStats photos={photos} />

        {/* Upload Section */}
        <PhotoUpload onAddPhoto={handleAddPhoto} photoCount={photos.length} />

        {/* Photos List */}
        {photos.length > 0 && (
          <PhotoList 
            photos={photos} 
            onRemovePhoto={handleRemovePhoto}
            onRetryAnalysis={handleRetryAnalysis}
          />
        )}

        {/* Empty State */}
        {photos.length === 0 && <PhotoEmptyState />}
      </div>
    </div>
  );
};
