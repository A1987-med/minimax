
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface Section {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  color: string;
  textColor: string;
  bgLight: string;
  borderColor: string;
  iconBg: string;
}

interface SectionCardsProps {
  sections: Section[];
  onSectionClick: (sectionId: string) => void;
}

export const SectionCards = ({ sections, onSectionClick }: SectionCardsProps) => {
  const handleSectionClick = (sectionId: string) => {
    console.log('📱 iPad - SOLUTION FINALE - Section cliquée:', sectionId);
    console.log('📱 iPad - SOLUTION FINALE - Fonction onSectionClick:', typeof onSectionClick);
    
    // Solution finale : appels multiples avec event.preventDefault() et event.stopPropagation()
    const performClick = (delay: number = 0) => {
      setTimeout(() => {
        console.log(`📱 iPad - SOLUTION FINALE - Appel ${delay}ms:`, sectionId);
        try {
          onSectionClick(sectionId);
        } catch (error) {
          console.error('📱 iPad - SOLUTION FINALE - Erreur:', error);
        }
      }, delay);
    };
    
    // Appels multiples pour forcer la navigation sur iPad
    performClick(0);    // Immédiat
    performClick(50);   // 50ms
    performClick(100);  // 100ms
    performClick(200);  // 200ms
    
    // Forcer avec requestAnimationFrame
    requestAnimationFrame(() => {
      console.log('📱 iPad - SOLUTION FINALE - Appel RAF:', sectionId);
      onSectionClick(sectionId);
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
      {sections.map((section, index) => (
        <Card 
          key={section.id}
          className={`group bg-gray-800/80 backdrop-blur-md border-0 shadow-xl hover:shadow-2xl transition-all duration-500 cursor-pointer transform hover:scale-105 hover:-translate-y-2 relative overflow-hidden hover:bg-gray-700/80`}
          onClick={(e) => {
            console.log('📱 iPad - SOLUTION FINALE - Événement click:', section.id);
            e.preventDefault();
            e.stopPropagation();
            handleSectionClick(section.id);
          }}
          onTouchEnd={(e) => {
            console.log('📱 iPad - SOLUTION FINALE - Événement touchEnd:', section.id);
            e.preventDefault();
            e.stopPropagation();
            handleSectionClick(section.id);
          }}
          style={{
            animationDelay: `${index * 0.1}s`,
            touchAction: 'manipulation'
          }}
        >
          <div className={`absolute inset-0 ${section.bgLight} opacity-20 group-hover:opacity-30 transition-opacity duration-300`}></div>
          
          <CardHeader className="text-center pb-4 relative z-10">
            <div className={`w-16 h-16 ${section.iconBg} rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg group-hover:shadow-xl transition-all duration-300 group-hover:scale-110 relative`}>
              <section.icon className="w-8 h-8 text-white" />
              <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            </div>
            <CardTitle className={`text-white text-xl font-bold group-hover:text-gray-100 transition-colors duration-300`}>
              {section.title}
            </CardTitle>
            <CardDescription className="text-gray-300 group-hover:text-gray-200 transition-colors duration-300 font-medium">
              {section.description}
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-0 text-center relative z-10">
            <Badge 
              variant="outline" 
              className={`text-white border-white/30 bg-white/20 group-hover:bg-white/30 group-hover:shadow-md transition-all duration-300 font-medium`}
            >
              Cliquez pour accéder
            </Badge>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
