
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield } from "lucide-react";

interface HomeHeaderProps {
  joursSansAccident: number | null;
  isLoadingJours: boolean;
  errorJours: any;
}

export const HomeHeader = ({ joursSansAccident, isLoadingJours, errorJours }: HomeHeaderProps) => {
  return (
    <div className="text-center mb-12">
      <div className="mb-8">
        {/* Section avec fond dégradé moderne contrastant */}
        <div className="relative">
          {/* Fond dégradé moderne avec couleurs contrastantes */}
          <div className="absolute inset-0 bg-gradient-to-b from-emerald-700/90 via-teal-800/95 to-cyan-900/90 rounded-2xl shadow-2xl"></div>
          
          {/* Contenu par-dessus le fond */}
          <div className="relative z-10 px-8 py-8">
            {/* Image d'innovation au-dessus du titre - taille réduite */}
            <div className="w-80 h-60 overflow-hidden mx-auto mb-6 shadow-2xl border-4 border-white/20 rounded-lg">
              <img
                src="https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
                alt="Innovation dans la gestion de la prévention sur chantiers"
                className="w-full h-full object-cover"
              />
            </div>
            
            <h1 className="text-6xl font-bold bg-gradient-to-r from-red-600 via-orange-500 to-yellow-500 bg-clip-text text-transparent mb-4 drop-shadow-2xl">
              Intelli-SST
            </h1>
            <p className="text-xl text-gray-200 mb-2 font-medium">
              Application de sécurité - Travaux de construction
            </p>
            <p className="text-lg text-gray-300">
              Votre sécurité est notre priorité absolue
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-md mx-auto">
        {/* Compteur jours sans accident */}
        <Card className="bg-gradient-to-br from-green-50 to-emerald-100 border-emerald-200 shadow-xl hover:shadow-2xl transition-all duration-300">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-emerald-700 flex items-center gap-2 justify-center">
              <Shield className="w-5 h-5" />
              Sécurité du chantier
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              {isLoadingJours ? (
                <div className="text-2xl text-emerald-600">Chargement...</div>
              ) : errorJours ? (
                <div className="text-sm text-red-600">Erreur de chargement</div>
              ) : (
                <>
                  <div className="text-4xl font-bold text-emerald-600 mb-2">
                    {joursSansAccident || 0}
                  </div>
                  <div className="text-sm text-emerald-700 font-medium">
                    {(joursSansAccident || 0) === 1 ? 'jour sans accident' : 'jours sans accident'}
                  </div>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
