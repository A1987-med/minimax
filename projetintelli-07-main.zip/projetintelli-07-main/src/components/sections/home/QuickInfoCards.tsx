
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, User, Loader2, Phone, Mail, X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface QuickInfoCardsProps {
  prochaineInspection: string;
  isLoadingInspection: boolean;
  errorInspection: string | null;
  onInspectionClick: () => void;
}

export const QuickInfoCards = ({
  prochaineInspection,
  isLoadingInspection,
  errorInspection,
  onInspectionClick
}: QuickInfoCardsProps) => {
  // Cette section est maintenant vide car les cartes ont été déplacées
  return null;
};
