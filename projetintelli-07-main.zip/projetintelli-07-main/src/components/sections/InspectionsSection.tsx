
import React, { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, Search, ClipboardCheck, Plus } from "lucide-react";
import { Input } from "@/components/ui/input";
import { NewInspectionForm } from "./inspections/NewInspectionForm";
import { SimpleInspectionsList } from "./inspections/SimpleInspectionsList";
import { SectionDetail } from "./inspections/SectionDetail";
import { InspectionSectionCard } from "./inspections/InspectionSectionCard";
import { INSPECTION_SECTIONS } from "./inspections/constants";

interface InspectionsSectionProps {
  onBack: () => void;
}

export const InspectionsSection = ({ onBack }: InspectionsSectionProps) => {
  const [selectedSubsection, setSelectedSubsection] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewInspectionForm, setShowNewInspectionForm] = useState(false);
  const [showInspectionsList, setShowInspectionsList] = useState(false);

  console.log('🔍 InspectionsSection - État actuel:', {
    selectedSubsection,
    showNewInspectionForm,
    showInspectionsList
  });

  const filteredSections = INSPECTION_SECTIONS.filter(section =>
    section.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Fonctions ultra-simples sans complexité
  const handleNewInspection = () => {
    console.log('🔍 SIMPLE - handleNewInspection appelé');
    setShowNewInspectionForm(true);
    setSelectedSubsection(null);
    setShowInspectionsList(false);
  };

  const handleShowInspectionsList = () => {
    console.log('📋 SIMPLE - handleShowInspectionsList appelé');
    setShowInspectionsList(true);
    setShowNewInspectionForm(false);
    setSelectedSubsection(null);
  };

  const handleBackToMain = () => {
    console.log('🔙 SIMPLE - handleBackToMain appelé');
    setShowNewInspectionForm(false);
    setShowInspectionsList(false);
    setSelectedSubsection(null);
  };

  // Formulaire ultra-simple sans complexité
  if (showNewInspectionForm) {
    return <NewInspectionForm onBack={handleBackToMain} />;
  }

  // Liste ultra-simple
  if (showInspectionsList) {
    return <SimpleInspectionsList onBack={handleBackToMain} />;
  }

  if (selectedSubsection) {
    return (
      <SectionDetail 
        selectedSubsection={selectedSubsection} 
        onBack={() => setSelectedSubsection(null)} 
      />
    );
  }

  console.log('🔍 AFFICHAGE - Vue principale ultra-simple');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-4xl font-bold text-green-600">Inspections SST - Version Simple</h1>
      </div>

      {/* Boutons d'actions ultra-simples */}
      <div className="flex gap-4 mb-6">
        <Button 
          onClick={handleNewInspection}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white"
        >
          <Plus className="w-4 h-4" />
          Nouvelle inspection
        </Button>
        
        <Button 
          onClick={handleShowInspectionsList}
          variant="outline"
          className="flex items-center gap-2 border-emerald-300 text-emerald-700 hover:bg-emerald-50"
        >
          <ClipboardCheck className="w-4 h-4" />
          Voir les inspections
        </Button>
      </div>

      {/* Barre de recherche */}
      <Card>
        <CardContent className="pt-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-green-500 w-5 h-5" />
            <Input
              placeholder="🔍 Rechercher une section..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 text-lg"
            />
          </div>
        </CardContent>
      </Card>

      {/* Grille des sections simplifiée */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredSections.map((section, index) => (
          <InspectionSectionCard
            key={index}
            section={section}
            index={index}
            onClick={setSelectedSubsection}
          />
        ))}
      </div>

      {searchTerm && filteredSections.length === 0 && (
        <Card>
          <CardContent className="text-center py-12">
            <Search className="w-20 h-20 mx-auto text-red-400 mb-6" />
            <h3 className="text-2xl font-semibold text-red-600 mb-4">Aucun résultat</h3>
            <p className="text-gray-600 text-lg">
              Aucune section ne correspond à "{searchTerm}".
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
