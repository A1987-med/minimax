
import React, { useState } from 'react';
import { GestionHeader } from './gestion/GestionHeader';
import { GestionTabs } from './gestion/GestionTabs';
import { GestionTabContent } from './gestion/GestionTabContent';
import { useGestionData } from './gestion/hooks/useGestionData';

interface GestionSectionProps {
  onBack: () => void;
  onASTNavigation?: (corpsMetier: string) => void;
}

export const GestionSection = ({ onBack, onASTNavigation }: GestionSectionProps) => {
  const [activeTab, setActiveTab] = useState("accueil-employes");
  
  const {
    soustraitants,
    entries,
    isLoadingSoustraitants,
    isLoadingEntries,
    handleSubmitEntry,
    handleUpdateEntry,
    handleDeleteEntry,
    handleSoustraitantsChange
  } = useGestionData();

  console.log('🏗️ GESTION SECTION - Debug état:', {
    activeTab,
    entriesCount: entries.length,
    soustraitantsCount: soustraitants.length,
    isLoadingEntries,
    isLoadingSoustraitants
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="container mx-auto px-4 py-8">
        <GestionHeader onBack={onBack} />
        
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <GestionTabs activeTab={activeTab} setActiveTab={setActiveTab}>
            <GestionTabContent
              activeTab={activeTab}
              soustraitants={soustraitants}
              entries={entries}
              onSubmitEntry={handleSubmitEntry}
              onUpdateEntry={handleUpdateEntry}
              onDeleteEntry={handleDeleteEntry}
              onSoustraitantsChange={handleSoustraitantsChange}
              onASTNavigation={onASTNavigation}
            />
          </GestionTabs>
        </div>
      </div>
    </div>
  );
};
