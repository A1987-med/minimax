
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Video } from "lucide-react";

export const VideoUploadInfo = () => {
  return (
    <Card className="bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
      <CardContent className="p-6">
        <h4 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
          <Video className="w-5 h-5 text-green-600" />
          Que va analyser l'IA ?
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div className="space-y-2">
            <h5 className="font-medium text-gray-700">🔍 Détection visuelle :</h5>
            <ul className="space-y-1 text-gray-600">
              <li>• EPI manquants ou incorrects</li>
              <li>• Conditions dangereuses</li>
              <li>• Non-respect des procédures</li>
              <li>• État des équipements</li>
            </ul>
          </div>
          <div className="space-y-2">
            <h5 className="font-medium text-gray-700">🎙️ Transcription audio :</h5>
            <ul className="space-y-1 text-gray-600">
              <li>• Avertissements de sécurité</li>
              <li>• Instructions données</li>
              <li>• Conversations importantes</li>
              <li>• Mots-clés de sécurité</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
