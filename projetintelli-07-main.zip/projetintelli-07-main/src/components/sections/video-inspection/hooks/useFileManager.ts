
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";

export const useFileManager = () => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoPreview, setVideoPreview] = useState<string | null>(null);
  const { toast } = useToast();

  const clearSelectedFile = () => {
    console.log('🗑️ === SUPPRESSION FICHIER SÉLECTIONNÉ ===');
    
    setSelectedFile(null);
    
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
      setVideoPreview(null);
    }
    
    // Reset de l'input file
    const fileInput = document.getElementById('video-upload') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
    
    console.log('✅ Fichier supprimé et interface réinitialisée');
    
    toast({
      title: "Fichier supprimé",
      description: "Vous pouvez maintenant sélectionner une nouvelle vidéo",
    });
  };

  const setFileWithPreview = (file: File) => {
    // Nettoyer l'ancien fichier avant d'en traiter un nouveau
    if (selectedFile || videoPreview) {
      clearSelectedFile();
    }
    
    setSelectedFile(file);
    
    // Créer aperçu vidéo
    try {
      const videoUrl = URL.createObjectURL(file);
      setVideoPreview(videoUrl);
      
      console.log('✅ Aperçu vidéo créé:', videoUrl.substring(0, 50) + '...');
      
      toast({
        title: "Fichier sélectionné ✅",
        description: `"${file.name}" prêt pour l'upload`,
      });
      
      return true;
      
    } catch (error) {
      console.error('❌ Erreur création aperçu:', error);
      toast({
        title: "Erreur aperçu",
        description: "Impossible de créer l'aperçu vidéo",
        variant: "destructive"
      });
      return false;
    }
  };

  return {
    selectedFile,
    videoPreview,
    clearSelectedFile,
    setFileWithPreview
  };
};
