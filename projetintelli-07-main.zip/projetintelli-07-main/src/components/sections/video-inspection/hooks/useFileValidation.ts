
import { useState } from 'react';
import { useToast } from "@/hooks/use-toast";

export const useFileValidation = () => {
  const [uploadError, setUploadError] = useState<string | null>(null);
  const { toast } = useToast();

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const validateFile = (file: File): boolean => {
    console.log('🎬 === DÉBUT VALIDATION FICHIER ===');
    console.log('🎬 Fichier reçu:', {
      name: file.name,
      type: file.type,
      size: file.size,
      sizeFormatted: formatFileSize(file.size)
    });

    setUploadError(null);

    // Extensions supportées incluant .mov
    const validExtensions = ['.mp4', '.mov', '.avi', '.webm', '.mkv', '.3gp', '.m4v', '.wmv'];
    const hasValidExtension = validExtensions.some(ext => 
      file.name.toLowerCase().includes(ext)
    );
    
    // Types MIME supportés - plus complet
    const supportedMimeTypes = [
      'video/mp4',
      'video/quicktime',     // .mov files
      'video/x-msvideo',     // .avi files
      'video/webm',
      'video/avi',
      'video/mkv',
      'video/3gp',
      'video/x-ms-wmv'       // .wmv files
    ];
    
    const isVideoType = file.type.startsWith('video/') || supportedMimeTypes.includes(file.type) || hasValidExtension;
    
    if (!isVideoType) {
      console.error('❌ Type de fichier invalide:', file.type);
      const error = `Type: ${file.type}. Formats supportés: MP4, MOV, AVI, WebM, MKV`;
      setUploadError(error);
      toast({
        title: "Format non supporté",
        description: error,
        variant: "destructive"
      });
      return false;
    }

    // Limite à 5GB pour correspondre à la configuration Supabase
    const maxSize = 5 * 1024 * 1024 * 1024; // 5GB
    if (file.size > maxSize) {
      console.error('❌ Fichier trop volumineux:', file.size);
      const error = `Taille: ${formatFileSize(file.size)}. Maximum configuré: 5GB`;
      setUploadError(error);
      toast({
        title: "Fichier trop volumineux",
        description: error,
        variant: "destructive"
      });
      return false;
    }

    console.log('✅ Fichier validé avec succès (limite 5GB)');
    return true;
  };

  return {
    uploadError,
    setUploadError,
    validateFile,
    formatFileSize
  };
};
