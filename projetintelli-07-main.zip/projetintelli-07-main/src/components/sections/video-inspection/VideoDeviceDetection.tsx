
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";

export const VideoDeviceDetection = () => {
  // Test de détection iPad
  const isIPad = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  console.log('🔍 Device Detection:', {
    userAgent: navigator.userAgent,
    platform: navigator.platform,
    maxTouchPoints: navigator.maxTouchPoints,
    isIPad
  });

  if (!isIPad) return null;

  return (
    <Card className="bg-blue-50 border-blue-200">
      <CardContent className="p-4">
        <p className="text-sm text-blue-700">
          🍎 iPad détecté - Mode optimisé Safari activé (Galerie vidéo corrigée)
        </p>
      </CardContent>
    </Card>
  );
};
