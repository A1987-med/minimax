
import { useToast } from "@/hooks/use-toast";

export const useVideoFileHandler = () => {
  const { toast } = useToast();

  const processSelectedFile = (file: File, setSelectedFile: (file: File | null) => void, setVideoPreview: (url: string | null) => void) => {
    console.log('🎥 === DEBUT processSelectedFile CORRIGÉ ===');
    console.log('🎥 Fichier reçu:', {
      name: file.name,
      type: file.type,
      size: file.size,
      sizeGB: (file.size / (1024 * 1024 * 1024)).toFixed(2) + ' GB'
    });
    
    // Vérifier le type de fichier - plus permissif pour iPad
    const allowedTypes = [
      'video/mp4', 
      'video/webm', 
      'video/quicktime', 
      'video/x-msvideo', 
      'video/avi', 
      'video/mov',
      'video/3gp',
      'video/x-ms-wmv',
      'video/mkv'
    ];
    
    const isValidType = allowedTypes.includes(file.type) || file.type.startsWith('video/');
    
    console.log('🎥 Validation type:', {
      fileType: file.type,
      isValidType,
      allowedTypes
    });
    
    if (!isValidType) {
      console.error('❌ Type de fichier non supporté:', file.type);
      toast({
        title: "Format non supporté",
        description: `Type détecté: ${file.type}. Veuillez sélectionner une vidéo.`,
        variant: "destructive"
      });
      return;
    }

    // Vérifier la taille (2GB max)
    const maxSize = 2 * 1024 * 1024 * 1024; // 2GB
    
    if (file.size > maxSize) {
      console.error('❌ Fichier trop volumineux:', file.size, 'bytes');
      toast({
        title: "Fichier trop volumineux",
        description: `Taille: ${(file.size / (1024 * 1024 * 1024)).toFixed(2)}GB. Maximum autorisé: 2GB`,
        variant: "destructive"
      });
      return;
    }

    console.log('✅ Fichier validé, traitement...');
    setSelectedFile(file);
    
    // Créer un aperçu vidéo
    try {
      const videoUrl = URL.createObjectURL(file);
      console.log('✅ URL aperçu créée:', videoUrl);
      setVideoPreview(videoUrl);
      
      toast({
        title: "Fichier sélectionné ✅",
        description: `Vidéo "${file.name}" prête pour l'upload`,
      });
    } catch (error) {
      console.error('❌ Erreur création aperçu:', error);
      toast({
        title: "Erreur aperçu",
        description: "Impossible de créer l'aperçu vidéo",
        variant: "destructive"
      });
    }
    
    console.log('🎥 === FIN processSelectedFile CORRIGÉ ===');
  };

  const processNativeFileResult = (dataString: string, onFileProcessed: (file: File) => void) => {
    console.log('📱 === DEBUT processNativeFileResult CORRIGÉ ===');
    console.log('📱 DataString reçu:', dataString.substring(0, 100) + '...');
    
    try {
      if (dataString.startsWith('data:')) {
        // Extraire les métadonnées de la chaîne
        const parts = dataString.split(';');
        let mimeType = 'video/mp4';
        let fileName = `video_${Date.now()}.mp4`;
        let objectURL = '';
        
        console.log('📱 Parsing parts:', parts);
        
        for (const part of parts) {
          if (part.startsWith('data:')) {
            mimeType = part.substring(5);
          } else if (part.startsWith('name=')) {
            fileName = part.substring(5);
          } else if (part.startsWith('objectURL=')) {
            objectURL = part.substring(10);
          }
        }
        
        console.log('📱 Métadonnées extraites:', {
          mimeType,
          fileName,
          objectURL: objectURL.substring(0, 50) + '...'
        });
        
        if (objectURL) {
          console.log('📱 Conversion objectURL vers File...');
          fetch(objectURL)
            .then(response => {
              console.log('📱 Response reçue:', response.status);
              return response.blob();
            })
            .then(blob => {
              console.log('📱 Blob créé:', {
                size: blob.size,
                type: blob.type
              });
              const file = new File([blob], fileName, { type: mimeType });
              console.log('📱 File créé, appel onFileProcessed...');
              onFileProcessed(file);
            })
            .catch(error => {
              console.error('📱 Erreur conversion objectURL:', error);
              toast({
                title: "Erreur de traitement",
                description: "Impossible de traiter la vidéo sélectionnée",
                variant: "destructive"
              });
            });
        } else {
          console.error('📱 ObjectURL manquant dans dataString');
          toast({
            title: "Erreur",
            description: "Données de fichier invalides",
            variant: "destructive"
          });
        }
      } else {
        console.error('📱 Format dataString invalide:', dataString.substring(0, 50));
        toast({
          title: "Erreur",
          description: "Format de données non reconnu",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('📱 Erreur traitement résultat natif:', error);
      toast({
        title: "Erreur",
        description: "Impossible de traiter le fichier sélectionné",
        variant: "destructive"
      });
    }
    
    console.log('📱 === FIN processNativeFileResult CORRIGÉ ===');
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return {
    processSelectedFile,
    processNativeFileResult,
    formatFileSize
  };
};
