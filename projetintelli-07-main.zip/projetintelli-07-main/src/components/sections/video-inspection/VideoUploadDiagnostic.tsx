
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";
import { DiagnosticResults } from './diagnostic/DiagnosticResults';
import { useDiagnosticTests } from './diagnostic/useDiagnosticTests';

export const VideoUploadDiagnostic = () => {
  const { diagnosticResults, running, runDiagnostic } = useDiagnosticTests();

  const getOverallStatus = () => {
    if (diagnosticResults.length === 0) return 'unknown';
    const hasErrors = diagnosticResults.some(r => r.status === 'error');
    const hasWarnings = diagnosticResults.some(r => r.status === 'warning');
    
    if (hasErrors) return 'error';
    if (hasWarnings) return 'warning';
    return 'success';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'warning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'error': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="w-5 h-5 text-blue-600" />
          Configuration Supabase - Limite 5GB
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <Button 
            onClick={runDiagnostic} 
            disabled={running}
            className="bg-blue-600 hover:bg-blue-700"
          >
            {running ? 'Diagnostic en cours...' : 'Vérifier la configuration'}
          </Button>
          
          {diagnosticResults.length > 0 && (
            <Badge className={getStatusColor(getOverallStatus())}>
              {getOverallStatus() === 'success' && '✅ Système opérationnel'}
              {getOverallStatus() === 'warning' && '⚠️ Avertissements'}
              {getOverallStatus() === 'error' && '❌ Erreurs détectées'}
            </Badge>
          )}
        </div>

        <div className="text-sm text-blue-700 bg-blue-100 p-3 rounded-lg">
          ℹ️ <strong>Configuration :</strong> Limite configurée à 5GB dans votre bucket Supabase. Si vous rencontrez des erreurs avec des fichiers volumineux, vérifiez les logs pour plus de détails.
        </div>

        {diagnosticResults.length > 0 && (
          <DiagnosticResults results={diagnosticResults} />
        )}
      </CardContent>
    </Card>
  );
};
