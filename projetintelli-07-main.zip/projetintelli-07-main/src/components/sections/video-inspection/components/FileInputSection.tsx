
import React from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Calendar, FileVideo, Trash2 } from "lucide-react";

interface FileInputSectionProps {
  dateInspection: string;
  selectedFile: File | null;
  onDateChange: (date: string) => void;
  onFileSelect: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onClearFile: () => void;
}

export const FileInputSection = ({
  dateInspection,
  selectedFile,
  onDateChange,
  onFileSelect,
  onClearFile
}: FileInputSectionProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="space-y-2">
        <Label htmlFor="date-inspection" className="text-sm font-medium flex items-center gap-2">
          <Calendar className="w-4 h-4" />
          Date d'inspection
        </Label>
        <Input
          id="date-inspection"
          type="date"
          value={dateInspection}
          onChange={(e) => onDateChange(e.target.value)}
          className="w-48"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="video-upload" className="text-sm font-medium flex items-center gap-2">
          <FileVideo className="w-4 h-4" />
          Fichier vidéo
        </Label>
        <div className="flex gap-2">
          {!selectedFile && (
            <Input
              id="video-upload"
              type="file"
              accept="video/*,.mp4,.mov,.avi,.webm,.mkv"
              onChange={onFileSelect}
              className="flex-1"
            />
          )}
          {selectedFile && (
            <>
              <div className="flex-1 p-2 border border-gray-300 rounded-md bg-gray-50 text-sm">
                {selectedFile.name}
              </div>
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={onClearFile}
                className="shrink-0"
                title="Supprimer le fichier sélectionné"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </>
          )}
        </div>
        <p className="text-xs text-gray-500">
          Formats: MP4, WebM, MOV, AVI (max. 500MB recommandé pour Supabase)
        </p>
      </div>
    </div>
  );
};
