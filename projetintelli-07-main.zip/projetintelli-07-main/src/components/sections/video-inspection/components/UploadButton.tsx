
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Upload, Loader2 } from "lucide-react";

interface UploadButtonProps {
  selectedFile: File | null;
  dateInspection: string;
  uploading: boolean;
  onUpload: () => void;
}

export const UploadButton = ({
  selectedFile,
  dateInspection,
  uploading,
  onUpload
}: UploadButtonProps) => {
  return (
    <Card className="border-2 border-dashed border-purple-300 bg-purple-50/50 hover:bg-purple-50 transition-colors">
      <CardContent className="p-8">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full flex items-center justify-center mx-auto">
            <Upload className="w-8 h-8 text-white" />
          </div>
          <div>
            <h3 className="text-lg font-semibold text-gray-800">
              Glissez votre vidéo ici ou utilisez les options ci-dessus
            </h3>
            <p className="text-gray-600">
              L'analyse IA commencera automatiquement après l'upload (limite: 5GB)
            </p>
          </div>
          
          <div className="flex justify-center">
            <Button
              onClick={onUpload}
              disabled={!selectedFile || !dateInspection || uploading}
              className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
            >
              {uploading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Upload en cours...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4 mr-2" />
                  Uploader et analyser
                </>
              )}
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
