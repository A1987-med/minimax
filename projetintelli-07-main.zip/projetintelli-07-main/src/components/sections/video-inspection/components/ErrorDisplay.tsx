
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertTriangle } from "lucide-react";

interface ErrorDisplayProps {
  error: string;
  onClose: () => void;
}

export const ErrorDisplay = ({ error, onClose }: ErrorDisplayProps) => {
  return (
    <Card className="border-red-200 bg-red-50">
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5 shrink-0" />
          <div className="flex-1">
            <h4 className="font-medium text-red-800 mb-1">Erreur d'upload</h4>
            <p className="text-sm text-red-700">{error}</p>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onClose}
              className="mt-2 border-red-200 text-red-700 hover:bg-red-100"
            >
              Fermer
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
