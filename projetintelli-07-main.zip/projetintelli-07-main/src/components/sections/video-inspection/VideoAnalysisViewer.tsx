import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Video, 
  AlertTriangle, 
  FileText, 
  Play, 
  Clock, 
  Volume2, 
  Shield,
  TrendingUp,
  Eye,
  Loader2,
  MapPin,
  PlayCircle
} from "lucide-react";
import { VideoInspection, NonConformiteVideo, TranscriptionAudio, videoInspectionService } from '@/services/videoInspectionService';
import { useToast } from "@/hooks/use-toast";

interface VideoAnalysisViewerProps {
  video: VideoInspection;
}

export const VideoAnalysisViewer = ({ video }: VideoAnalysisViewerProps) => {
  const [nonConformites, setNonConformites] = useState<NonConformiteVideo[]>([]);
  const [transcriptions, setTranscriptions] = useState<TranscriptionAudio[]>([]);
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('video');
  const [videoReady, setVideoReady] = useState(false);
  const [videoElement, setVideoElement] = useState<HTMLVideoElement | null>(null);
  const { toast } = useToast();
  
  const videoRef = useRef<HTMLVideoElement | null>(null);

  useEffect(() => {
    loadAnalysisData();
  }, [video.id]);

  // Ne plus réinitialiser videoReady lors des changements d'onglets
  useEffect(() => {
    console.log('🔄 Changement d\'onglet vers:', activeTab);
    // On ne remet plus videoReady à false ici
  }, [activeTab]);

  // Réinitialiser seulement lors d'un changement de vidéo
  useEffect(() => {
    console.log('🔄 Reset pour nouvelle vidéo');
    setVideoReady(false);
    setVideoElement(null);
  }, [video.id]);

  const loadAnalysisData = async () => {
    try {
      setLoading(true);
      
      // Charger l'URL de la vidéo
      const url = await videoInspectionService.getVideoUrl(video.chemin_video);
      setVideoUrl(url);

      // Charger les non-conformités
      const nonConf = await videoInspectionService.getNonConformites(video.id);
      setNonConformites(nonConf);

      // Charger les transcriptions
      const trans = await videoInspectionService.getTranscriptions(video.id);
      setTranscriptions(trans);

    } catch (error) {
      console.error('Erreur chargement données analyse:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les données d'analyse",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const seekToTimestamp = async (timestamp: number) => {
    console.log(`🎯 Navigation vers timestamp: ${timestamp}s`);
    
    // Basculer vers l'onglet vidéo d'abord
    setActiveTab('video');
    
    // Attendre un peu que l'onglet se charge
    await new Promise(resolve => setTimeout(resolve, 300));
    
    // Utiliser l'élément vidéo stocké
    const currentVideoElement = videoElement || videoRef.current;
    if (!currentVideoElement) {
      console.log('❌ Élément vidéo non disponible');
      toast({
        title: "Vidéo non disponible",
        description: "L'élément vidéo n'est pas encore initialisé",
        variant: "destructive"
      });
      return;
    }

    if (!videoUrl) {
      console.log('❌ URL vidéo non disponible');
      toast({
        title: "Vidéo non disponible",
        description: "L'URL de la vidéo n'est pas encore chargée",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log(`⏯️ État vidéo avant seek: readyState=${currentVideoElement.readyState}, currentTime=${currentVideoElement.currentTime}`);
      
      // Attendre que la vidéo soit prête si nécessaire
      if (currentVideoElement.readyState < 3) {
        console.log('📱 Attente du chargement complet de la vidéo...');
        
        await new Promise<void>((resolve, reject) => {
          const timeout = setTimeout(() => {
            cleanup();
            reject(new Error('Timeout: la vidéo n\'a pas pu se charger'));
          }, 10000);

          const handleCanPlayThrough = () => {
            console.log('✅ Vidéo complètement chargée');
            cleanup();
            resolve();
          };

          const handleError = () => {
            console.log('❌ Erreur de chargement vidéo');
            cleanup();
            reject(new Error('Erreur de chargement de la vidéo'));
          };

          const cleanup = () => {
            clearTimeout(timeout);
            currentVideoElement.removeEventListener('canplaythrough', handleCanPlayThrough);
            currentVideoElement.removeEventListener('error', handleError);
          };

          currentVideoElement.addEventListener('canplaythrough', handleCanPlayThrough);
          currentVideoElement.addEventListener('error', handleError);
          
          // Forcer le chargement si nécessaire
          if (currentVideoElement.src !== videoUrl) {
            currentVideoElement.src = videoUrl;
            currentVideoElement.load();
          }
        });
      }

      // Vérifier que le timestamp est valide
      if (currentVideoElement.duration && timestamp >= currentVideoElement.duration) {
        console.log(`⚠️ Timestamp ${timestamp}s supérieur à la durée ${currentVideoElement.duration}s`);
        toast({
          title: "Position invalide",
          description: `Le timestamp ${formatTimestamp(timestamp)} dépasse la durée de la vidéo`,
          variant: "destructive"
        });
        return;
      }

      // Pauser la vidéo
      currentVideoElement.pause();
      console.log('⏸️ Vidéo pausée');
      
      // Positionner à la bonne position
      currentVideoElement.currentTime = timestamp;
      console.log(`⏱️ Position définie à ${timestamp}s`);
      
      // Attendre que le seek soit effectif
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(() => {
          cleanup();
          reject(new Error('Timeout: impossible de positionner la vidéo'));
        }, 5000);

        const handleSeeked = () => {
          console.log(`✅ Seek terminé, position actuelle: ${currentVideoElement.currentTime}s`);
          cleanup();
          resolve();
        };

        const handleError = () => {
          console.log('❌ Erreur pendant le seek');
          cleanup();
          reject(new Error('Erreur pendant le positionnement'));
        };

        const cleanup = () => {
          clearTimeout(timeout);
          currentVideoElement.removeEventListener('seeked', handleSeeked);
          currentVideoElement.removeEventListener('error', handleError);
        };

        currentVideoElement.addEventListener('seeked', handleSeeked);
        currentVideoElement.addEventListener('error', handleError);
      });
      
      // Lancer la lecture
      await currentVideoElement.play();
      console.log('▶️ Lecture démarrée');
      
      toast({
        title: "Navigation réussie",
        description: `Vidéo positionnée à ${formatTimestamp(timestamp)}`,
        variant: "default"
      });
      
    } catch (error) {
      console.error('❌ Erreur navigation vidéo:', error);
      toast({
        title: "Erreur de navigation",
        description: error.message || "Impossible de naviguer vers ce timestamp",
        variant: "destructive"
      });
    }
  };

  const handleVideoRef = useCallback((element: HTMLVideoElement | null) => {
    console.log('📹 Référence vidéo mise à jour:', element ? 'Disponible' : 'Null');
    
    videoRef.current = element;
    setVideoElement(element);
    
    if (element) {
      console.log('📹 Configuration des événements vidéo...');
      
      const handleLoadedData = () => {
        console.log('📹 Données vidéo chargées - VideoReady = TRUE');
        setVideoReady(true);
      };

      const handleCanPlay = () => {
        console.log('📹 Vidéo peut jouer - VideoReady = TRUE');
        setVideoReady(true);
      };

      const handleCanPlayThrough = () => {
        console.log('📹 Vidéo prête pour lecture complète - VideoReady = TRUE');
        setVideoReady(true);
      };

      const handleVideoError = (e: Event) => {
        console.error('📹 Erreur vidéo:', e);
        setVideoReady(false);
      };

      // Vérifier l'état initial
      if (element.readyState >= 3) {
        console.log('✅ Vidéo déjà prête au montage - VideoReady = TRUE');
        setVideoReady(true);
      }

      // Ajouter les listeners
      element.addEventListener('loadeddata', handleLoadedData);
      element.addEventListener('canplay', handleCanPlay);
      element.addEventListener('canplaythrough', handleCanPlayThrough);
      element.addEventListener('error', handleVideoError);

      // Nettoyer lors du démontage
      return () => {
        console.log('🧹 Nettoyage des événements vidéo');
        element.removeEventListener('loadeddata', handleLoadedData);
        element.removeEventListener('canplay', handleCanPlay);
        element.removeEventListener('canplaythrough', handleCanPlayThrough);
        element.removeEventListener('error', handleVideoError);
      };
    } else {
      console.log('❌ Élément vidéo null');
      setVideoReady(false);
    }
  }, []);

  const playAudioSegment = (startTime: number, endTime: number) => {
    console.log(`🔊 Tentative lecture audio: ${startTime}s - ${endTime}s`);
    
    // Utiliser l'élément vidéo stocké
    const currentVideoElement = videoElement || videoRef.current;
    
    if (!currentVideoElement) {
      console.log('❌ Élément vidéo non disponible pour lecture audio');
      toast({
        title: "Vidéo non disponible",
        description: "L'élément vidéo n'est pas encore chargé",
        variant: "destructive"
      });
      return;
    }

    if (!videoReady) {
      console.log('❌ Vidéo pas prête pour lecture audio');
      toast({
        title: "Vidéo en chargement",
        description: "Veuillez attendre que la vidéo soit complètement chargée",
        variant: "destructive"
      });
      return;
    }

    try {
      // Basculer vers l'onglet vidéo
      setActiveTab('video');
      
      currentVideoElement.currentTime = startTime;
      currentVideoElement.play().then(() => {
        console.log(`✅ Lecture audio démarrée à ${startTime}s`);
      }).catch(error => {
        console.error('Erreur lecture audio:', error);
        toast({
          title: "Lecture impossible",
          description: "Impossible de lire ce segment audio",
          variant: "destructive"
        });
      });
      
      // Arrêter la lecture à la fin du segment
      const handleTimeUpdate = () => {
        if (currentVideoElement.currentTime >= endTime) {
          currentVideoElement.pause();
          currentVideoElement.removeEventListener('timeupdate', handleTimeUpdate);
          console.log(`⏸️ Lecture audio arrêtée à ${endTime}s`);
        }
      };
      
      currentVideoElement.addEventListener('timeupdate', handleTimeUpdate);
    } catch (error) {
      console.error('❌ Erreur playAudioSegment:', error);
      toast({
        title: "Erreur",
        description: "Impossible de lire ce segment",
        variant: "destructive"
      });
    }
  };

  const getGraviteColor = (gravite: NonConformiteVideo['niveau_gravite']) => {
    switch (gravite) {
      case 'faible': return 'bg-yellow-100 text-yellow-800';
      case 'moyen': return 'bg-orange-100 text-orange-800';
      case 'eleve': return 'bg-red-100 text-red-800';
      case 'critique': return 'bg-red-200 text-red-900 font-bold';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getGraviteLabel = (gravite: NonConformiteVideo['niveau_gravite']) => {
    switch (gravite) {
      case 'faible': return 'Faible';
      case 'moyen': return 'Moyen';
      case 'eleve': return 'Élevé';
      case 'critique': return 'Critique';
      default: return gravite;
    }
  };

  const formatTimestamp = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
        <span className="ml-2 text-lg text-gray-600">Chargement de l'analyse...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header avec informations vidéo */}
      <Card className="bg-gradient-to-r from-purple-50 to-indigo-50">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <Video className="w-8 h-8 text-white" />
              </div>
              <div>
                <CardTitle className="text-xl text-gray-800">{video.nom_fichier}</CardTitle>
                <p className="text-gray-600">
                  Inspection du {new Date(video.date_inspection).toLocaleDateString('fr-FR')}
                </p>
                {video.duree_video && (
                  <p className="text-sm text-gray-500">
                    Durée: {formatTimestamp(video.duree_video)}
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge 
                className={video.statut_analyse === 'terminee' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-blue-100 text-blue-800'
                }
              >
                {video.statut_analyse === 'terminee' ? 'Analyse terminée' : 'En cours...'}
              </Badge>
              {videoReady && (
                <Badge variant="outline" className="text-green-600 border-green-600">
                  ✅ Contrôles actifs
                </Badge>
              )}
              {!videoReady && videoUrl && (
                <Badge variant="outline" className="text-orange-600 border-orange-600">
                  ⏳ Chargement...
                </Badge>
              )}
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Description de l'environnement */}
      {video.description_environnement && (
        <Card className="border-l-4 border-l-blue-500">
          <CardHeader className="pb-3">
            <CardTitle className="text-lg flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600" />
              Description de l'environnement
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-700 leading-relaxed">{video.description_environnement}</p>
          </CardContent>
        </Card>
      )}

      {/* Statistiques rapides */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <AlertTriangle className="w-5 h-5 text-red-600" />
            </div>
            <div className="text-2xl font-bold text-gray-800">{nonConformites.length}</div>
            <div className="text-sm text-gray-600">Non-conformités détectées</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div className="text-2xl font-bold text-gray-800">{transcriptions.length}</div>
            <div className="text-sm text-gray-600">Segments audio</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-2">
              <TrendingUp className="w-5 h-5 text-green-600" />
            </div>
            <div className="text-2xl font-bold text-gray-800">
              {nonConformites.filter(nc => nc.niveau_gravite === 'critique' || nc.niveau_gravite === 'eleve').length}
            </div>
            <div className="text-sm text-gray-600">Prioritaires</div>
          </CardContent>
        </Card>
      </div>

      {/* Contenu principal avec onglets */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="video" className="flex items-center gap-2">
            <Play className="w-4 h-4" />
            Vidéo
          </TabsTrigger>
          <TabsTrigger value="non-conformites" className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4" />
            Non-conformités ({nonConformites.length})
          </TabsTrigger>
          <TabsTrigger value="transcriptions" className="flex items-center gap-2">
            <Volume2 className="w-4 h-4" />
            Audio ({transcriptions.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="video" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Eye className="w-5 h-5" />
                Lecture vidéo
                {videoReady && (
                  <Badge variant="outline" className="ml-2 text-green-600 border-green-600">
                    ✅ Contrôles activés
                  </Badge>
                )}
                {!videoReady && videoUrl && (
                  <Badge variant="outline" className="ml-2 text-orange-600 border-orange-600">
                    ⏳ Chargement...
                  </Badge>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              {videoUrl ? (
                <video 
                  ref={handleVideoRef}
                  controls 
                  className="w-full max-w-4xl mx-auto rounded-lg shadow-lg"
                  poster="/placeholder.svg"
                  src={videoUrl}
                  preload="metadata"
                >
                  Votre navigateur ne supporte pas la lecture vidéo.
                </video>
              ) : (
                <div className="bg-gray-100 rounded-lg p-8 text-center">
                  <Video className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Vidéo non disponible</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="non-conformites" className="space-y-4">
          {nonConformites.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Shield className="w-16 h-16 text-green-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-600 mb-2">
                  Aucune non-conformité détectée
                </h4>
                <p className="text-gray-500">
                  L'analyse IA n'a détecté aucun problème de sécurité dans cette vidéo.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {nonConformites.map((nc) => (
                <Card key={nc.id} className="border-l-4 border-l-red-500">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                          <AlertTriangle className="w-5 h-5 text-red-600" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-800">{nc.type_non_conformite}</h4>
                          <div className="flex items-center gap-2 text-sm text-gray-500">
                            <Clock className="w-3 h-3" />
                            <Button
                              variant="link"
                              size="sm"
                              className="p-0 h-auto text-blue-600 hover:text-blue-800 font-medium"
                              onClick={() => seekToTimestamp(nc.timestamp_video)}
                              disabled={!videoReady}
                            >
                              {formatTimestamp(nc.timestamp_video)} - {videoReady ? 'Voir dans la vidéo' : 'Vidéo en chargement...'}
                            </Button>
                          </div>
                        </div>
                      </div>
                      <Badge className={getGraviteColor(nc.niveau_gravite)}>
                        {getGraviteLabel(nc.niveau_gravite)}
                      </Badge>
                    </div>
                    
                    <p className="text-gray-700 mb-3">{nc.description}</p>
                    
                    {nc.confiance_score && (
                      <div className="flex items-center gap-2 text-sm text-gray-500">
                        <TrendingUp className="w-3 h-3" />
                        Confiance: {Math.round(nc.confiance_score * 100)}%
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="transcriptions" className="space-y-4">
          {transcriptions.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <Volume2 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-semibold text-gray-600 mb-2">
                  Aucun contenu audio détecté
                </h4>
                <p className="text-gray-500">
                  Cette vidéo ne contient pas de contenu audio à transcrire.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {transcriptions.map((trans) => (
                <Card key={trans.id}>
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Volume2 className="w-5 h-5 text-blue-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-sm text-gray-500">
                            {formatTimestamp(trans.timestamp_debut)} - {formatTimestamp(trans.timestamp_fin)}
                          </span>
                          {trans.locuteur && (
                            <Badge variant="outline">{trans.locuteur}</Badge>
                          )}
                          <Button
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-1"
                            onClick={() => playAudioSegment(trans.timestamp_debut, trans.timestamp_fin)}
                            disabled={!videoReady}
                          >
                            <PlayCircle className="w-3 h-3" />
                            {videoReady ? 'Écouter' : 'Vidéo en chargement...'}
                          </Button>
                        </div>
                        <p className="text-gray-800 mb-3">{trans.texte_transcrit}</p>
                        {trans.mots_cles_securite && trans.mots_cles_securite.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {trans.mots_cles_securite.map((mot, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {mot}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};
