
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Video } from "lucide-react";

interface VideoPreviewProps {
  selectedFile: File | null;
  videoPreview: string | null;
  formatFileSize: (bytes: number) => string;
}

export const VideoPreview = ({ selectedFile, videoPreview, formatFileSize }: VideoPreviewProps) => {
  if (!selectedFile) return null;

  return (
    <Card className="bg-blue-50 border-blue-200">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
            <Video className="w-6 h-6 text-blue-600" />
          </div>
          <div className="flex-1">
            <h4 className="font-medium text-gray-800">{selectedFile.name}</h4>
            <div className="flex items-center gap-4 text-sm text-gray-600">
              <span>Taille: {formatFileSize(selectedFile.size)}</span>
              <span>Type: {selectedFile.type}</span>
            </div>
          </div>
        </div>
        
        {videoPreview && (
          <div className="mt-4">
            <video
              src={videoPreview}
              controls
              className="w-full max-w-md rounded-lg"
              style={{ maxHeight: '200px' }}
              playsInline
              preload="metadata"
            >
              Votre navigateur ne supporte pas la lecture vidéo.
            </video>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
