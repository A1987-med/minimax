
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertCircle } from "lucide-react";

interface DiagnosticTestProps {
  test: string;
  status: string;
  message: string;
  details?: any;
}

export const DiagnosticTest = ({ test, status, message, details }: DiagnosticTestProps) => {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-4 h-4 text-green-600" />;
      case 'warning': return <AlertCircle className="w-4 h-4 text-yellow-600" />;
      case 'error': return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <AlertCircle className="w-4 h-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800 border-green-200';
      case 'warning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'error': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className={`border rounded-lg p-4 bg-white ${getStatusColor(status).includes('border') ? '' : 'border-gray-200'}`}>
      <div className="flex items-center gap-3 mb-3">
        {getStatusIcon(status)}
        <span className="font-semibold text-lg">{test}</span>
        <Badge className={getStatusColor(status)}>
          {status.toUpperCase()}
        </Badge>
      </div>
      <p className="text-sm text-gray-700 mb-3 font-medium">{message}</p>
      {details && (
        <details className="text-xs">
          <summary className="cursor-pointer text-blue-600 font-medium hover:text-blue-800">
            🔍 Voir les détails techniques
          </summary>
          <pre className="mt-2 p-3 bg-gray-100 rounded text-xs overflow-auto max-h-40 border">
            {JSON.stringify(details, null, 2)}
          </pre>
        </details>
      )}
    </div>
  );
};
