
import { useState } from 'react';

interface DiagnosticResult {
  test: string;
  status: string;
  message: string;
  details?: any;
}

export const useDiagnosticTests = () => {
  const [diagnosticResults, setDiagnosticResults] = useState<DiagnosticResult[]>([]);
  const [running, setRunning] = useState(false);

  const runEnvironmentTest = () => {
    const isIPad = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
    
    return {
      test: 'Détection Environnement',
      status: 'success',
      message: `Device: ${isIPad ? 'iPad' : 'Desktop'}, Browser: ${isSafari ? 'Safari' : 'Autre'}`,
      details: {
        userAgent: navigator.userAgent.substring(0, 100),
        platform: navigator.platform,
        maxTouchPoints: navigator.maxTouchPoints,
        isSafari,
        isIPad
      }
    };
  };

  const runFileAPITest = () => {
    const fileAPISupported = !!(window.File && window.FileReader && window.FileList && window.Blob);
    return {
      test: 'Support File API',
      status: fileAPISupported ? 'success' : 'error',
      message: fileAPISupported ? 'File API complètement supportée' : 'File API non supportée',
      details: {
        File: !!window.File,
        FileReader: !!window.FileReader,
        FileList: !!window.FileList,
        Blob: !!window.Blob,
        URL: !!window.URL,
        createObjectURL: !!(window.URL && window.URL.createObjectURL)
      }
    };
  };

  const runMemoryTest = async () => {
    let memoryInfo = 'Non disponible';
    try {
      // @ts-ignore - API expérimental
      if (navigator.deviceMemory) {
        // @ts-ignore
        memoryInfo = `${navigator.deviceMemory}GB`;
      }
      // @ts-ignore - API expérimental  
      if (navigator.storage && navigator.storage.estimate) {
        // @ts-ignore
        const storage = await navigator.storage.estimate();
        const availableGB = ((storage.quota || 0) / (1024 * 1024 * 1024)).toFixed(1);
        const usedGB = ((storage.usage || 0) / (1024 * 1024 * 1024)).toFixed(1);
        memoryInfo += ` | Storage: ${usedGB}/${availableGB}GB`;
      }
    } catch (e) {
      console.log('Memory info not available');
    }

    return {
      test: 'Mémoire et Stockage',
      status: 'success',
      message: `Info mémoire: ${memoryInfo}`,
      details: { memoryInfo }
    };
  };

  const runSupabaseTests = async () => {
    const results: DiagnosticResult[] = [];

    try {
      console.log('🔍 Test connexion Supabase...');
      const { supabase } = await import('@/integrations/supabase/client');
      
      // Test session
      const { data: authData, error: authError } = await supabase.auth.getSession();
      results.push({
        test: 'Session Supabase',
        status: authError ? 'warning' : 'success',
        message: authError ? `Session error: ${authError.message}` : 'Session OK',
        details: { 
          hasSession: !!authData.session,
          user: authData.session?.user?.email || 'Anonyme',
          error: authError?.message 
        }
      });

      // Test buckets
      await runBucketsTest(supabase, results);
      
      // Test upload si bucket accessible
      await runUploadTest(supabase, results);
      
      // Test base de données
      await runDatabaseTest(supabase, results);

    } catch (supabaseError) {
      results.push({
        test: 'Connexion Supabase',
        status: 'error',
        message: `❌ Erreur import/connexion Supabase: ${supabaseError}`,
        details: { error: String(supabaseError) }
      });
    }

    return results;
  };

  const runBucketsTest = async (supabase: any, results: DiagnosticResult[]) => {
    try {
      console.log('🪣 Test bucket video-inspections...');
      
      const { data: bucketFiles, error: listFilesError } = await supabase.storage
        .from('video-inspections')
        .list('', { limit: 5 });
      
      console.log('📁 Test accès bucket:', { bucketFiles, listFilesError });
      
      if (listFilesError) {
        results.push({
          test: 'Bucket video-inspections',
          status: 'error',
          message: `❌ Erreur accès bucket: ${listFilesError.message}`,
          details: { error: listFilesError }
        });
      } else {
        results.push({
          test: 'Bucket video-inspections',
          status: 'success',
          message: `✅ Bucket accessible - ${bucketFiles?.length || 0} fichiers/dossiers`,
          details: { files: bucketFiles || [] }
        });

        // Test dossier uploads/
        const { data: uploadFolders, error: folderError } = await supabase.storage
          .from('video-inspections')
          .list('uploads', { limit: 1 });
        
        results.push({
          test: 'Dossier uploads/',
          status: folderError ? 'warning' : 'success',
          message: folderError ? '📁 Dossier sera créé automatiquement' : `✅ Dossier accessible`,
          details: { 
            error: folderError?.message,
            files: uploadFolders || []
          }
        });
      }

    } catch (bucketsError) {
      console.error('❌ Erreur test bucket:', bucketsError);
      results.push({
        test: 'Bucket video-inspections',
        status: 'error',
        message: `❌ Exception test bucket: ${bucketsError}`,
        details: { exception: String(bucketsError) }
      });
    }
  };

  const runUploadTest = async (supabase: any, results: DiagnosticResult[]) => {
    const bucketAccessible = results.some(r => 
      r.test === 'Bucket video-inspections' && r.status === 'success'
    );

    if (bucketAccessible) {
      try {
        console.log('🧪 Test upload réel...');
        
        const mp4Header = new Uint8Array([
          0x00, 0x00, 0x00, 0x20, 0x66, 0x74, 0x79, 0x70,
          0x69, 0x73, 0x6F, 0x6D, 0x00, 0x00, 0x02, 0x00,
          0x69, 0x73, 0x6F, 0x6D, 0x69, 0x73, 0x6F, 0x32,
          0x61, 0x76, 0x63, 0x31, 0x6D, 0x70, 0x34, 0x31
        ]);
        
        const testBlob = new Blob([mp4Header], { type: 'video/mp4' });
        const testFile = new File([testBlob], `diagnostic_${Date.now()}.mp4`, { type: 'video/mp4' });
        
        const uploadStartTime = Date.now();
        const { data: uploadData, error: uploadError } = await supabase.storage
          .from('video-inspections')
          .upload(`uploads/${testFile.name}`, testFile, {
            cacheControl: '3600',
            upsert: false
          });
        const uploadDuration = Date.now() - uploadStartTime;

        if (uploadError) {
          results.push({
            test: 'Test Upload Réel',
            status: 'error',
            message: `❌ Échec upload: ${uploadError.message}`,
            details: { 
              error: uploadError,
              fileSize: testFile.size,
              fileName: testFile.name,
              duration: uploadDuration
            }
          });
        } else {
          results.push({
            test: 'Test Upload Réel',
            status: 'success',
            message: `✅ Upload réussi en ${uploadDuration}ms (limit 5GB)`,
            details: { 
              path: uploadData.path,
              fileSize: testFile.size,
              fileName: testFile.name,
              duration: uploadDuration
            }
          });

          // Nettoyer le fichier test
          await supabase.storage.from('video-inspections').remove([uploadData.path]);
        }
      } catch (uploadTestError) {
        results.push({
          test: 'Test Upload Réel',
          status: 'error',
          message: `❌ Erreur test upload: ${uploadTestError}`,
          details: { error: String(uploadTestError) }
        });
      }
    } else {
      results.push({
        test: 'Test Upload Réel',
        status: 'warning',
        message: '⚠️ Upload ignoré - bucket inaccessible',
        details: { reason: 'Bucket video-inspections non accessible' }
      });
    }
  };

  const runDatabaseTest = async (supabase: any, results: DiagnosticResult[]) => {
    try {
      const { data: dbTest, error: dbError } = await supabase
        .from('video_inspections')
        .select('id')
        .limit(1);
      
      results.push({
        test: 'Base de Données',
        status: dbError ? 'error' : 'success',
        message: dbError ? `❌ Erreur DB: ${dbError.message}` : '✅ Accès DB OK',
        details: { 
          canRead: !dbError,
          recordsFound: dbTest?.length || 0,
          error: dbError?.message 
        }
      });
    } catch (dbTestError) {
      results.push({
        test: 'Base de Données',
        status: 'error',
        message: `❌ Erreur test DB: ${dbTestError}`,
        details: { error: String(dbTestError) }
      });
    }
  };

  const runLimitsTest = () => {
    return {
      test: 'Configuration Bucket',
      status: 'success',
      message: `✅ Bucket configuré avec limite 5GB et politiques RLS`,
      details: {
        bucketLimitGB: 5,
        allowedMimeTypes: ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/webm', 'video/avi', 'video/mkv'],
        rlsPolicies: 'uploads/ folder required, public read/write enabled',
        created: 'Bucket créé via migration SQL'
      }
    };
  };

  const runDiagnostic = async () => {
    setRunning(true);
    const results: DiagnosticResult[] = [];

    // Tests basiques
    results.push(runEnvironmentTest());
    results.push(runFileAPITest());
    results.push(await runMemoryTest());

    // Tests Supabase
    const supabaseResults = await runSupabaseTests();
    results.push(...supabaseResults);

    // Test configuration
    results.push(runLimitsTest());

    console.log('🔍 Diagnostic terminé:', results);
    setDiagnosticResults(results);
    setRunning(false);
  };

  return {
    diagnosticResults,
    running,
    runDiagnostic
  };
};
