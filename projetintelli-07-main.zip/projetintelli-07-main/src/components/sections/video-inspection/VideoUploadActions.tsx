
import React from 'react';
import { Camera, Upload, FileVideo } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { useNativeFeatures } from '@/hooks/useNativeFeatures';

interface VideoUploadActionsProps {
  onVideoCapture: (videoData: string) => void;
  onFileSelect: (file: File) => void;
  isUploading: boolean;
}

export const VideoUploadActions = ({ onVideoCapture, onFileSelect, isUploading }: VideoUploadActionsProps) => {
  const { takePicture } = useNativeFeatures();

  const handleCameraCapture = async () => {
    try {
      const videoData = await takePicture();
      if (videoData) {
        onVideoCapture(videoData);
      }
    } catch (error) {
      console.error('Erreur lors de la capture vidéo:', error);
    }
  };

  const handleVideoGallerySelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('🎥 === SÉLECTION VIDÉO DEPUIS GALERIE ===');
    const file = event.target.files?.[0];
    if (file) {
      console.log('🎥 Fichier vidéo sélectionné:', {
        name: file.name,
        type: file.type,
        size: file.size
      });
      onFileSelect(file);
    }
  };

  const handleFileInput = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <Button
        onClick={handleCameraCapture}
        disabled={isUploading}
        className="h-24 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col gap-2"
      >
        <Camera className="w-8 h-8" />
        <span className="font-medium">Filmer</span>
      </Button>
      
      <div className="relative">
        <input
          type="file"
          accept="video/*,.mp4,.mov,.avi,.webm,.mkv"
          onChange={handleVideoGallerySelect}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isUploading}
        />
        <Button
          disabled={isUploading}
          variant="outline"
          className="w-full h-24 border-2 border-red-200 hover:border-red-300 hover:bg-red-50 flex flex-col gap-2 transition-all duration-300"
        >
          <Upload className="w-8 h-8 text-red-600" />
          <span className="font-medium text-red-700">Importer vidéo</span>
          <span className="text-xs text-red-600">MP4, MOV, AVI</span>
        </Button>
      </div>
      
      <div className="relative">
        <input
          type="file"
          accept="video/*"
          onChange={handleFileInput}
          className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          disabled={isUploading}
        />
        <Button
          disabled={isUploading}
          variant="outline"
          className="w-full h-24 border-2 border-blue-200 hover:border-blue-300 hover:bg-blue-50 flex flex-col gap-2 transition-all duration-300"
        >
          <FileVideo className="w-8 h-8 text-blue-600" />
          <span className="font-medium text-blue-700">Choisir fichier</span>
          <span className="text-xs text-blue-600">MP4, MOV, AVI</span>
        </Button>
      </div>
    </div>
  );
};
