
import React from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Video, Play, Clock, Calendar, HardDrive, RefreshCw, Loader2, Trash2 } from "lucide-react";
import { VideoInspection, videoInspectionService } from '@/services/videoInspectionService';
import { useToast } from "@/hooks/use-toast";

interface VideoInspectionsListProps {
  videos: VideoInspection[];
  loading: boolean;
  onVideoSelect: (video: VideoInspection) => void;
  onRefresh: () => void;
}

export const VideoInspectionsList = ({ 
  videos, 
  loading, 
  onVideoSelect, 
  onRefresh 
}: VideoInspectionsListProps) => {
  const { toast } = useToast();
  
  const getStatutColor = (statut: VideoInspection['statut_analyse']) => {
    switch (statut) {
      case 'en_attente': return 'bg-yellow-100 text-yellow-800';
      case 'en_cours': return 'bg-blue-100 text-blue-800';
      case 'terminee': return 'bg-green-100 text-green-800';
      case 'erreur': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatutLabel = (statut: VideoInspection['statut_analyse']) => {
    switch (statut) {
      case 'en_attente': return 'En attente';
      case 'en_cours': return 'En cours';
      case 'terminee': return 'Terminée';
      case 'erreur': return 'Erreur';
      default: return statut;
    }
  };

  const formatFileSize = (bytes?: number) => {
    if (!bytes) return '-';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const formatDuration = (seconds?: number) => {
    if (!seconds) return '-';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleDeleteVideo = async (video: VideoInspection, e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!confirm(`Êtes-vous sûr de vouloir supprimer la vidéo "${video.nom_fichier}" ? Cette action est irréversible.`)) {
      return;
    }

    try {
      console.log('🗑️ Début suppression vidéo:', video.nom_fichier);
      await videoInspectionService.deleteVideo(video.id);
      
      toast({
        title: "Vidéo supprimée",
        description: `La vidéo "${video.nom_fichier}" a été supprimée avec succès.`,
      });
      
      // Rafraîchir la liste après suppression
      onRefresh();
    } catch (error) {
      console.error('❌ Erreur suppression:', error);
      toast({
        title: "Erreur",
        description: `Impossible de supprimer la vidéo: ${error.message}`,
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
        <span className="ml-2 text-lg text-gray-600">Chargement des vidéos...</span>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header avec refresh */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-800">
          {videos.length} vidéo{videos.length > 1 ? 's' : ''} d'inspection
        </h3>
        <Button
          variant="outline"
          onClick={onRefresh}
          className="flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          Actualiser
        </Button>
      </div>

      {/* Liste des vidéos */}
      {videos.length === 0 ? (
        <Card className="bg-gray-50">
          <CardContent className="p-8 text-center">
            <Video className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h4 className="text-lg font-semibold text-gray-600 mb-2">
              Aucune vidéo d'inspection
            </h4>
            <p className="text-gray-500">
              Uploadez votre première vidéo pour commencer l'analyse IA
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {videos.map((video) => (
            <Card 
              key={video.id} 
              className="bg-white hover:shadow-lg transition-all duration-300 cursor-pointer border hover:border-purple-300"
              onClick={() => onVideoSelect(video)}
            >
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Header avec bouton supprimer plus visible */}
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
                        <Video className="w-6 h-6 text-white" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h4 className="font-semibold text-gray-800 truncate">
                          {video.nom_fichier}
                        </h4>
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Calendar className="w-3 h-3" />
                          {new Date(video.date_inspection).toLocaleDateString('fr-FR')}
                        </div>
                      </div>
                    </div>
                    
                    {/* Badge de statut et bouton supprimer plus visibles */}
                    <div className="flex items-center gap-2 ml-2">
                      <Badge className={getStatutColor(video.statut_analyse)}>
                        {getStatutLabel(video.statut_analyse)}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={(e) => handleDeleteVideo(video, e)}
                        className="flex items-center gap-1 px-3 py-1 h-8 text-red-600 hover:text-white hover:bg-red-600 border-red-300 hover:border-red-600 transition-colors"
                        title="Supprimer cette vidéo"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span className="text-xs">Supprimer</span>
                      </Button>
                    </div>
                  </div>

                  {/* Métadonnées */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center gap-2 text-gray-600">
                      <HardDrive className="w-4 h-4" />
                      <span>{formatFileSize(video.taille_fichier)}</span>
                    </div>
                    <div className="flex items-center gap-2 text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{formatDuration(video.duree_video)}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center justify-between pt-2 border-t">
                    <div className="text-xs text-gray-500">
                      Créée le {new Date(video.created_at).toLocaleDateString('fr-FR')}
                    </div>
                    
                    <Button
                      size="sm"
                      className="bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
                      onClick={(e) => {
                        e.stopPropagation();
                        onVideoSelect(video);
                      }}
                    >
                      <Play className="w-4 h-4 mr-1" />
                      {video.statut_analyse === 'terminee' ? 'Voir analyse' : 'Ouvrir'}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
