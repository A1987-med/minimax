
import React, { useState } from 'react';
import { videoInspectionService, VideoInspection } from '@/services/videoInspectionService';
import { useToast } from "@/hooks/use-toast";
import { VideoDeviceDetection } from './VideoDeviceDetection';
import { VideoUploadActions } from './VideoUploadActions';
import { VideoPreview } from './VideoPreview';
import { VideoUploadInfo } from './VideoUploadInfo';
import { VideoUploadDiagnostic } from './VideoUploadDiagnostic';
import { useFileValidation } from './hooks/useFileValidation';
import { useFileManager } from './hooks/useFileManager';
import { ErrorDisplay } from './components/ErrorDisplay';
import { FileInputSection } from './components/FileInputSection';
import { UploadButton } from './components/UploadButton';

interface VideoUploadFormProps {
  onVideoUploaded: (video: VideoInspection) => void;
}

export const VideoUploadForm = ({ onVideoUploaded }: VideoUploadFormProps) => {
  const [dateInspection, setDateInspection] = useState(new Date().toISOString().split('T')[0]);
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const { uploadError, setUploadError, validateFile, formatFileSize } = useFileValidation();
  const { selectedFile, videoPreview, clearSelectedFile, setFileWithPreview } = useFileManager();

  const validateAndProcessFile = (file: File) => {
    console.log('🎬 === DÉBUT VALIDATION ET TRAITEMENT FICHIER ===');
    console.log('🎬 Fichier reçu:', {
      name: file.name,
      type: file.type,
      size: file.size,
      sizeFormatted: formatFileSize(file.size)
    });

    setUploadError(null);

    if (!validateFile(file)) {
      return false;
    }

    return setFileWithPreview(file);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    console.log('🎬 === DÉBUT SÉLECTION FICHIER INPUT ===');
    const file = event.target.files?.[0];
    
    if (file) {
      console.log('🎬 Fichier sélectionné depuis input:', file.name);
      validateAndProcessFile(file);
    } else {
      console.log('🎬 Aucun fichier sélectionné, pas de reset automatique');
    }
    console.log('🎬 === FIN SÉLECTION FICHIER INPUT ===');
  };

  const handleFileFromAction = (file: File) => {
    console.log('🎬 === DÉBUT FICHIER DEPUIS ACTION ===');
    console.log('🎬 Fichier reçu depuis action:', file.name);
    validateAndProcessFile(file);
    console.log('🎬 === FIN FICHIER DEPUIS ACTION ===');
  };

  const handleNativeDataString = (dataString: string) => {
    console.log('📱 === DÉBUT TRAITEMENT DATA STRING NATIVE ===');
    console.log('📱 DataString reçu:', dataString.substring(0, 100) + '...');
    
    try {
      if (dataString.startsWith('data:')) {
        const parts = dataString.split(';');
        let mimeType = 'video/mp4';
        let fileName = `video_${Date.now()}.mp4`;
        let objectURL = '';
        
        for (const part of parts) {
          if (part.startsWith('data:')) {
            mimeType = part.substring(5);
          } else if (part.startsWith('name=')) {
            fileName = part.substring(5);
          } else if (part.startsWith('objectURL=')) {
            objectURL = part.substring(10);
          }
        }
        
        console.log('📱 Métadonnées extraites:', { mimeType, fileName, objectURL: objectURL.substring(0, 50) + '...' });
        
        if (objectURL) {
          fetch(objectURL)
            .then(response => response.blob())
            .then(blob => {
              console.log('📱 Blob récupéré:', { size: blob.size, type: blob.type });
              const file = new File([blob], fileName, { type: mimeType });
              validateAndProcessFile(file);
            })
            .catch(error => {
              console.error('📱 Erreur conversion blob:', error);
              setUploadError("Impossible de traiter la vidéo");
              toast({
                title: "Erreur",
                description: "Impossible de traiter la vidéo",
                variant: "destructive"
              });
            });
        }
      }
    } catch (error) {
      console.error('📱 Erreur traitement dataString:', error);
      setUploadError("Format de données invalide");
      toast({
        title: "Erreur",
        description: "Format de données invalide",
        variant: "destructive"
      });
    }
    
    console.log('📱 === FIN TRAITEMENT DATA STRING NATIVE ===');
  };

  const handleUpload = async () => {
    if (!selectedFile || !dateInspection) {
      const error = !selectedFile ? "Aucun fichier sélectionné" : "Date manquante";
      setUploadError(error);
      toast({
        title: "Validation échouée",
        description: error,
        variant: "destructive"
      });
      return;
    }

    setUploading(true);
    setUploadError(null);
    
    try {
      console.log('🚀 === DÉBUT UPLOAD FINAL AVEC GESTION ERREUR AMÉLIORÉE ===');
      console.log('🚀 Upload fichier:', {
        name: selectedFile.name,
        size: formatFileSize(selectedFile.size),
        type: selectedFile.type,
        plan: 'Supabase Plan Payant'
      });
      
      const result = await videoInspectionService.uploadVideo(selectedFile, dateInspection);
      
      onVideoUploaded(result.videoInspection);
      
      // Reset formulaire complet
      clearSelectedFile();
      setDateInspection(new Date().toISOString().split('T')[0]);
      
      toast({
        title: "Upload réussi ! 🎥",
        description: `Vidéo "${result.videoInspection.nom_fichier}" uploadée avec succès`,
      });
      
      console.log('🚀 === FIN UPLOAD FINAL RÉUSSI ===');
      
    } catch (error) {
      console.error('❌ === ERREUR UPLOAD FINAL DÉTAILLÉE ===');
      console.error('❌ Erreur upload complète:', error);
      
      // Messages d'erreur plus spécifiques pour Supabase
      let errorMessage = 'Erreur inconnue';
      let errorDetails = '';
      
      if (error?.message) {
        if (error.message.includes('exceeded the maximum allowed size') || error.message.includes('object too large')) {
          errorMessage = 'Fichier trop volumineux pour Supabase';
          errorDetails = `Votre fichier (${formatFileSize(selectedFile.size)}) dépasse les limites de votre bucket Supabase. Vérifiez les paramètres de votre bucket dans le dashboard Supabase Storage.`;
        } else if (error.message.includes('413') || error.message.includes('too large')) {
          errorMessage = 'Limite de taille serveur dépassée';
          errorDetails = 'Essayez avec un fichier plus petit (< 500MB recommandé pour Supabase)';
        } else if (error.message.includes('timeout')) {
          errorMessage = 'Timeout d\'upload';
          errorDetails = 'Le fichier est peut-être trop volumineux ou la connexion trop lente';
        } else if (error.message.includes('storage') || error.message.includes('bucket')) {
          errorMessage = 'Erreur de stockage Supabase';
          errorDetails = 'Vérifiez la configuration du bucket ou les permissions dans votre dashboard Supabase';
        } else if (error.message.includes('unauthorized') || error.message.includes('forbidden')) {
          errorMessage = 'Permissions insuffisantes';
          errorDetails = 'Problème d\'autorisation Supabase - vérifiez vos politiques RLS';
        } else if (error.message.includes('network') || error.message.includes('fetch')) {
          errorMessage = 'Erreur de connexion';
          errorDetails = 'Vérifiez votre connexion internet';
        } else {
          errorMessage = error.message;
          errorDetails = 'Consultez les logs de la console pour plus de détails';
        }
      }
      
      const fullError = errorDetails ? `${errorMessage}. ${errorDetails}` : errorMessage;
      setUploadError(fullError);
      
      toast({
        title: "Erreur d'upload",
        description: fullError,
        variant: "destructive"
      });
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      <VideoDeviceDetection />
      
      <VideoUploadDiagnostic />

      {uploadError && (
        <ErrorDisplay error={uploadError} onClose={() => setUploadError(null)} />
      )}

      <FileInputSection
        dateInspection={dateInspection}
        selectedFile={selectedFile}
        onDateChange={setDateInspection}
        onFileSelect={handleFileSelect}
        onClearFile={clearSelectedFile}
      />

      <VideoUploadActions
        onVideoCapture={handleNativeDataString}
        onFileSelect={handleFileFromAction}
        isUploading={uploading}
      />

      <VideoPreview
        selectedFile={selectedFile}
        videoPreview={videoPreview}
        formatFileSize={formatFileSize}
      />

      <UploadButton
        selectedFile={selectedFile}
        dateInspection={dateInspection}
        uploading={uploading}
        onUpload={handleUpload}
      />

      <VideoUploadInfo />
    </div>
  );
};
