
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, Calendar } from "lucide-react";

interface NewInspectionFormProps {
  onBack: () => void;
}

export const NewInspectionForm = ({ onBack }: NewInspectionFormProps) => {
  console.log('🔍 AFFICHAGE - Formulaire ultra-simple');

  const handleSave = () => {
    console.log('✅ Test sauvegarde OK');
    alert('Test réussi !');
    onBack();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-emerald-600">Nouvelle Inspection - Ultra Simple</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Test de Formulaire Simple</CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Nom inspection</label>
              <input 
                type="text" 
                placeholder="Tapez le nom..."
                className="w-full p-3 border border-gray-200 rounded-lg"
              />
            </div>
            
            <div className="flex gap-4 pt-4">
              <Button 
                className="bg-emerald-600 hover:bg-emerald-700" 
                onClick={handleSave}
              >
                Test Sauvegarde
              </Button>
              <Button variant="outline" onClick={onBack}>
                Retour
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
