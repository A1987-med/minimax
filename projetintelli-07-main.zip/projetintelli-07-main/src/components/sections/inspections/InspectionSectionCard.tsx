
import React from 'react';
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowDown, Shield, AlertTriangle, Wrench, Building, Zap } from "lucide-react";

interface InspectionSectionCardProps {
  section: string;
  index: number;
  onClick: (section: string) => void;
}

export const InspectionSectionCard = ({ section, index, onClick }: InspectionSectionCardProps) => {
  const getSectionColor = (index: number) => {
    const colors = [
      'bg-gradient-to-br from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700',
      'bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700',
      'bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700',
      'bg-gradient-to-br from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700',
      'bg-gradient-to-br from-teal-500 to-teal-600 hover:from-teal-600 hover:to-teal-700'
    ];
    return colors[index % colors.length];
  };

  const getIcon = (index: number) => {
    const icons = [Shield, AlertTriangle, Wrench, Building, Zap];
    const IconComponent = icons[index % icons.length];
    return <IconComponent className="w-6 h-6 text-white" />;
  };

  return (
    <Card 
      className="group hover:shadow-2xl transition-all duration-300 cursor-pointer border-0 overflow-hidden transform hover:scale-105"
      onClick={() => onClick(section)}
    >
      <div className={`${getSectionColor(index)} p-6`}>
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 bg-white/20 rounded-lg flex items-center justify-center">
            {getIcon(index)}
          </div>
          <h3 className="font-bold text-white text-lg">{section}</h3>
        </div>
        <div className="flex items-center justify-between">
          <Badge className="bg-white/20 text-white border-white/30">
            À développer
          </Badge>
          <ArrowDown className="w-5 h-5 rotate-270 text-white" />
        </div>
      </div>
    </Card>
  );
};
