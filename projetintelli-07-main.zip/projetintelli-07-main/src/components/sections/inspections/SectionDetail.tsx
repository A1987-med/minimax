
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, ClipboardCheck, FileCheck } from "lucide-react";

interface SectionDetailProps {
  selectedSubsection: string;
  onBack: () => void;
}

export const SectionDetail = ({ selectedSubsection, onBack }: SectionDetailProps) => {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour aux sections
        </Button>
        <h1 className="text-3xl font-bold text-green-600">{selectedSubsection}</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ClipboardCheck className="w-6 h-6" />
            {selectedSubsection}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-8">
          <div className="text-center py-12">
            <FileCheck className="w-20 h-20 mx-auto text-green-400 mb-6" />
            <h3 className="text-2xl font-semibold text-gray-700 mb-4">Section à développer</h3>
            <p className="text-gray-600 max-w-md mx-auto text-lg">
              Cette section sera développée prochainement.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
