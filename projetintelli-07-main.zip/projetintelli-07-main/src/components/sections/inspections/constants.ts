
export const INSPECTION_SECTIONS = [
  'Accidents et analyses des risques',
  'Air comprimé',
  'Appareils de protection respiratoire',
  'Engins, équipements et outils',
  'Armatures en saillie'
];
