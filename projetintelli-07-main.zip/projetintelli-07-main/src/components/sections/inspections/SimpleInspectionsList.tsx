
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowDown, Calendar } from "lucide-react";

interface SimpleInspectionsListProps {
  onBack: () => void;
}

export const SimpleInspectionsList = ({ onBack }: SimpleInspectionsListProps) => {
  console.log('📋 AFFICHAGE - Liste ultra-simple');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack}>
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-emerald-600">Liste Simple</h1>
      </div>

      <Card>
        <CardContent className="p-8 text-center">
          <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-600 mb-2">Liste vide</h3>
          <p className="text-gray-500 mb-6">Aucune inspection pour le moment.</p>
          <Button onClick={onBack} className="bg-emerald-600 hover:bg-emerald-700">
            Retour
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};
