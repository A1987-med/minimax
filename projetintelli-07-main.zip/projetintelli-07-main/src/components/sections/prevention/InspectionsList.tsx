
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, MapPin, CheckCircle, XCircle, Clock, ArrowDown } from "lucide-react";
import { inspectionService } from '@/services/preventionService';
import type { Inspection } from '@/types/prevention';
import { useToast } from "@/hooks/use-toast";

interface InspectionsListProps {
  onBack: () => void;
}

export const InspectionsList = ({ onBack }: InspectionsListProps) => {
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    const loadInspections = async () => {
      try {
        const data = await inspectionService.getAll();
        setInspections(data);
      } catch (error) {
        console.error('Erreur lors du chargement des inspections:', error);
        toast({
          title: "Erreur",
          description: "Impossible de charger les inspections",
          variant: "destructive"
        });
      } finally {
        setIsLoading(false);
      }
    };

    loadInspections();
  }, [toast]);

  const getStatutBadge = (statut: string) => {
    const variants = {
      'planifiee': { variant: 'outline' as const, color: 'text-blue-600', icon: Clock },
      'en_cours': { variant: 'default' as const, color: 'text-orange-600', icon: Clock },
      'complete': { variant: 'default' as const, color: 'text-green-600', icon: CheckCircle },
      'reportee': { variant: 'destructive' as const, color: 'text-red-600', icon: XCircle }
    };
    
    const config = variants[statut as keyof typeof variants] || variants.planifiee;
    const Icon = config.icon;
    
    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="w-3 h-3" />
        {statut.charAt(0).toUpperCase() + statut.slice(1).replace('_', ' ')}
      </Badge>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-64">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Chargement des inspections...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-emerald-600">Historique des Inspections</h1>
        <Badge variant="outline" className="text-emerald-600 border-emerald-200">
          {inspections.length} inspection{inspections.length > 1 ? 's' : ''}
        </Badge>
      </div>

      {inspections.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center">
            <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">Aucune inspection enregistrée</h3>
            <p className="text-gray-500">Les inspections que vous créerez apparaîtront ici.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {inspections.map((inspection) => (
            <Card key={inspection.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg text-emerald-700">
                      {inspection.typeInspection}
                    </CardTitle>
                    <CardDescription className="flex items-center gap-2 mt-1">
                      <MapPin className="w-4 h-4" />
                      {inspection.equipementZone}
                    </CardDescription>
                  </div>
                  {getStatutBadge(inspection.statut)}
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-600" />
                    <span className="font-medium">Date:</span>
                    <span>{formatDate(inspection.dateInspection)} à {inspection.heureInspection}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-600" />
                    <span className="font-medium">Inspecteur:</span>
                    <span>{inspection.inspecteur}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {inspection.conformite ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <XCircle className="w-4 h-4 text-red-600" />
                    )}
                    <span className="font-medium">Conformité:</span>
                    <span className={inspection.conformite ? 'text-green-600' : 'text-red-600'}>
                      {inspection.conformite ? 'Conforme' : 'Non conforme'}
                    </span>
                  </div>
                </div>

                {inspection.actionsCorrectives && (
                  <div className="bg-orange-50 p-3 rounded-lg">
                    <h4 className="font-medium text-orange-800 mb-1">Actions correctives:</h4>
                    <p className="text-sm text-orange-700">{inspection.actionsCorrectives}</p>
                  </div>
                )}

                {inspection.dateProchaineInspection && (
                  <div className="bg-blue-50 p-3 rounded-lg">
                    <h4 className="font-medium text-blue-800 mb-1">Prochaine inspection prévue:</h4>
                    <p className="text-sm text-blue-700">{formatDate(inspection.dateProchaineInspection)}</p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
