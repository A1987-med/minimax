
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ArrowDown, Shield, Calendar } from "lucide-react";
import { inspectionService } from '@/services/preventionService';
import { useToast } from "@/hooks/use-toast";

interface InspectionFormData {
  typeInspection: string;
  equipementZone: string;
  inspecteur: string;
  dateInspection: string;
  heureInspection: string;
  resultats: Record<string, any>;
  conformite: boolean;
  actionsCorrectives: string;
  dateProchaineInspection: string;
  statut: 'planifiee' | 'en_cours' | 'complete' | 'reportee';
}

interface InspectionFormProps {
  onBack: () => void;
  onSubmit: () => void;
}

export const InspectionForm = ({ onBack, onSubmit }: InspectionFormProps) => {
  const [formData, setFormData] = useState<InspectionFormData>({
    typeInspection: '',
    equipementZone: '',
    inspecteur: '',
    dateInspection: '',
    heureInspection: '',
    resultats: {},
    conformite: true,
    actionsCorrectives: '',
    dateProchaineInspection: '',
    statut: 'planifiee'
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    console.log('🔍 INSPECTION - Début de la soumission:', formData);
    
    setIsSubmitting(true);
    
    try {
      // Créer l'objet inspection pour Supabase
      const inspectionData = {
        typeInspection: formData.typeInspection,
        equipementZone: formData.equipementZone,
        inspecteur: formData.inspecteur,
        dateInspection: formData.dateInspection,
        heureInspection: formData.heureInspection,
        resultats: formData.resultats,
        conformite: formData.conformite,
        actionsCorrectives: formData.actionsCorrectives || '',
        dateProchaineInspection: formData.dateProchaineInspection || '',
        statut: formData.statut
      };
      
      console.log('💾 INSPECTION - Données à sauvegarder:', inspectionData);
      
      // Sauvegarder en base de données
      const nouvelleInspection = await inspectionService.create(inspectionData);
      console.log('✅ INSPECTION - Inspection créée:', nouvelleInspection);
      
      toast({
        title: "Inspection enregistrée",
        description: "L'inspection a été enregistrée avec succès",
        variant: "default"
      });
      
      // Appeler le callback de réussite
      onSubmit();
      
    } catch (error) {
      console.error('❌ INSPECTION - Erreur lors de la sauvegarde:', error);
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer l'inspection. Veuillez réessayer.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateFormData = (updates: Partial<InspectionFormData>) => {
    setFormData(prev => ({ ...prev, ...updates }));
  };

  const isFormValid = formData.typeInspection && formData.equipementZone && formData.inspecteur && formData.dateInspection && formData.heureInspection;

  const typesInspection = [
    'Accidents et analyses des risques',
    'Air comprimé',
    'Appareils de protection respiratoire',
    'Engins, équipements et outils',
    'Armatures en saillie',
    'Aspects psychologiques',
    'Bouilloire',
    'Boutefeu',
    'Bruit',
    'Canalisations',
    'Chantier de construction',
    'Charpente de bois',
    'Circuits électroniques',
    'Circulation et stationnement au chantier',
    'Comité de chantier',
    'Contraintes thermiques',
    'Creusement',
    'Déboisement',
    'Démolition',
    'Déneigement',
    'Déversement accidentel de produits dangereux',
    'Dictionnaire',
    'Discipline vs Infraction',
    'Dynamitage',
    'Échafaudages',
    'Échelles et escabeaux',
    'Escaliers',
    'Électricité',
    'Éoliennes',
    'Équipements de protection individuelle',
    'Espace clos',
    'HEPA',
    'Hydrocarbures et industries',
    'Hygiène, santé et environnement',
    'Incendie',
    'Jet d\'eau à haute pression',
    'Matières dangereuses',
    'Mines',
    'Mobilisation',
    'MTQ',
    'Périmètre de sécurité',
    'Plate-forme',
    'Qualité de l\'air et ventilation',
    'Signalisation et sécurité routière',
    'Silos',
    'Soudage et découpage',
    'Systèmes de refroidissement',
    'Tenue des lieux',
    'TMS et ergonomie',
    'Travailleur isolé',
    'Travail sur l\'eau',
    'Travaux de toiture - Bitume',
    'Travaux en hauteur',
    'Travaux superposés',
    'Tunnels',
    'Usine de concassage',
    'Vibrations'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-emerald-600">Nouvelle Inspection</h1>
      </div>

      <Alert className="border-emerald-200 bg-emerald-50">
        <Shield className="h-4 w-4 text-emerald-600" />
        <AlertDescription className="text-emerald-800">
          Les inspections régulières sont essentielles pour maintenir un environnement de travail sécuritaire.
          Planifiez et documentez vos inspections pour assurer la conformité.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-emerald-600" />
            Formulaire d'inspection
          </CardTitle>
          <CardDescription>
            Tous les champs marqués d'un * sont obligatoires
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Type d'inspection */}
            <div>
              <label className="block text-sm font-medium mb-2">Type d'inspection *</label>
              <select
                value={formData.typeInspection}
                onChange={(e) => updateFormData({ typeInspection: e.target.value })}
                className="w-full p-3 border border-gray-200 rounded-lg"
                required
              >
                <option value="">Sélectionnez un type d'inspection</option>
                {typesInspection.map((type) => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Équipement/Zone */}
            <div>
              <label className="block text-sm font-medium mb-2">Équipement ou zone à inspécter *</label>
              <input
                type="text"
                value={formData.equipementZone}
                onChange={(e) => updateFormData({ equipementZone: e.target.value })}
                placeholder="ex: Bâtiment A, Zone de stockage, Grue principale..."
                className="w-full p-3 border border-gray-200 rounded-lg"
                required
              />
            </div>

            {/* Inspecteur */}
            <div>
              <label className="block text-sm font-medium mb-2">Inspecteur *</label>
              <input
                type="text"
                value={formData.inspecteur}
                onChange={(e) => updateFormData({ inspecteur: e.target.value })}
                placeholder="Nom de l'inspecteur"
                className="w-full p-3 border border-gray-200 rounded-lg"
                required
              />
            </div>

            {/* Date et heure */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Date d'inspection *</label>
                <input
                  type="date"
                  value={formData.dateInspection}
                  onChange={(e) => updateFormData({ dateInspection: e.target.value })}
                  className="w-full p-3 border border-gray-200 rounded-lg"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Heure *</label>
                <input
                  type="time"
                  value={formData.heureInspection}
                  onChange={(e) => updateFormData({ heureInspection: e.target.value })}
                  className="w-full p-3 border border-gray-200 rounded-lg"
                  required
                />
              </div>
            </div>

            {/* Statut */}
            <div>
              <label className="block text-sm font-medium mb-2">Statut *</label>
              <select
                value={formData.statut}
                onChange={(e) => updateFormData({ statut: e.target.value as any })}
                className="w-full p-3 border border-gray-200 rounded-lg"
                required
              >
                <option value="planifiee">Planifiée</option>
                <option value="en_cours">En cours</option>
                <option value="complete">Complète</option>
                <option value="reportee">Reportée</option>
              </select>
            </div>

            {/* Conformité */}
            <div>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={formData.conformite}
                  onChange={(e) => updateFormData({ conformite: e.target.checked })}
                  className="w-4 h-4"
                />
                <span className="text-sm font-medium">Inspection conforme</span>
              </label>
            </div>

            {/* Actions correctives */}
            <div>
              <label className="block text-sm font-medium mb-2">Actions correctives (si nécessaire)</label>
              <textarea
                value={formData.actionsCorrectives}
                onChange={(e) => updateFormData({ actionsCorrectives: e.target.value })}
                placeholder="Décrivez les actions correctives à prendre..."
                className="w-full p-3 border border-gray-200 rounded-lg h-24 resize-none"
              />
            </div>

            {/* Prochaine inspection */}
            <div>
              <label className="block text-sm font-medium mb-2">Date de la prochaine inspection</label>
              <input
                type="date"
                value={formData.dateProchaineInspection}
                onChange={(e) => updateFormData({ dateProchaineInspection: e.target.value })}
                className="w-full p-3 border border-gray-200 rounded-lg"
              />
            </div>

            <Button 
              type="submit" 
              className="w-full bg-emerald-600 hover:bg-emerald-700"
              disabled={!isFormValid || isSubmitting}
            >
              {isSubmitting ? 'Enregistrement en cours...' : 'Enregistrer l\'inspection'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
