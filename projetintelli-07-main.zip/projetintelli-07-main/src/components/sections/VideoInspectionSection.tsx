import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Upload, Video, Search, FileText, AlertTriangle } from "lucide-react";
import { VideoUploadForm } from './video-inspection/VideoUploadForm';
import { VideoInspectionsList } from './video-inspection/VideoInspectionsList';
import { VideoAnalysisViewer } from './video-inspection/VideoAnalysisViewer';
import { videoInspectionService, VideoInspection } from '@/services/videoInspectionService';
import { useToast } from "@/hooks/use-toast";

interface VideoInspectionSectionProps {
  onBack: () => void;
}

export const VideoInspectionSection = ({ onBack }: VideoInspectionSectionProps) => {
  const [activeTab, setActiveTab] = useState<'upload' | 'list' | 'analyze'>('upload');
  const [selectedVideo, setSelectedVideo] = useState<VideoInspection | null>(null);
  const [videoInspections, setVideoInspections] = useState<VideoInspection[]>([]);
  const [loading, setLoading] = useState(false);
  const [stats, setStats] = useState({
    totalNonConformites: 0,
    totalTranscriptions: 0
  });
  const { toast } = useToast();

  // Charger les vidéos automatiquement quand on change d'onglet vers 'list'
  useEffect(() => {
    if (activeTab === 'list') {
      loadVideoInspections();
    }
  }, [activeTab]);

  useEffect(() => {
    loadStatistics();
  }, [videoInspections]);

  const loadVideoInspections = async () => {
    try {
      setLoading(true);
      console.log('🎥 === DÉBUT CHARGEMENT VIDÉOS ===');
      const videos = await videoInspectionService.getAllVideoInspections();
      console.log('🎥 Vidéos chargées:', videos.length);
      setVideoInspections(videos);
    } catch (error) {
      console.error('❌ Erreur chargement vidéos:', error);
      toast({
        title: "Erreur",
        description: "Impossible de charger les vidéos d'inspection",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const loadStatistics = async () => {
    try {
      let totalNonConformites = 0;
      let totalTranscriptions = 0;

      for (const video of videoInspections.filter(v => v.statut_analyse === 'terminee')) {
        const nonConformites = await videoInspectionService.getNonConformites(video.id);
        const transcriptions = await videoInspectionService.getTranscriptions(video.id);
        
        totalNonConformites += nonConformites.length;
        totalTranscriptions += transcriptions.length;
      }

      setStats({
        totalNonConformites,
        totalTranscriptions
      });
    } catch (error) {
      console.error('Erreur chargement statistiques:', error);
    }
  };

  const handleVideoUploaded = async (newVideo: VideoInspection) => {
    console.log('🎥 === NOUVEAU UPLOAD REÇU ===');
    console.log('🎥 Nouvelle vidéo:', newVideo);
    
    // Ajouter immédiatement la nouvelle vidéo à la liste
    setVideoInspections(prev => {
      const updated = [newVideo, ...prev];
      console.log('🎥 Liste mise à jour avec', updated.length, 'vidéos');
      return updated;
    });
    
    // Recharger la liste complète pour s'assurer de la synchronisation
    await loadVideoInspections();
    
    toast({
      title: "Succès ! 🎥",
      description: "Vidéo uploadée avec succès. L'analyse IA va commencer automatiquement.",
    });
    
    // Basculer automatiquement vers l'onglet liste pour voir la vidéo
    setActiveTab('list');
  };

  const handleVideoSelect = (video: VideoInspection) => {
    setSelectedVideo(video);
    setActiveTab('analyze');
  };

  const tabs = [
    {
      id: 'upload' as const,
      label: 'Upload Vidéo',
      icon: Upload,
      description: 'Télécharger une nouvelle vidéo d\'inspection'
    },
    {
      id: 'list' as const,
      label: 'Mes Vidéos',
      icon: Video,
      description: 'Voir toutes les vidéos d\'inspection'
    },
    {
      id: 'analyze' as const,
      label: 'Analyse',
      icon: Search,
      description: 'Analyser et voir les résultats'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-purple-50 p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <Button
            variant="outline"
            onClick={onBack}
            className="flex items-center gap-2"
          >
            <ArrowLeft className="w-4 h-4" />
            Retour
          </Button>
          <div className="flex-1">
            <h1 className="text-4xl font-bold text-gray-800 flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center">
                <Video className="w-6 h-6 text-white" />
              </div>
              Vidéo Inspection IA
            </h1>
            <p className="text-lg text-gray-600 mt-2">
              Analyse automatique des non-conformités et transcription audio
            </p>
          </div>
        </div>

        {/* Statistiques rapides */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-emerald-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Video className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{videoInspections.length}</div>
              <div className="text-sm text-gray-600">Vidéos uploadées</div>
            </CardContent>
          </Card>
          
          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                <Search className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-800">
                {videoInspections.filter(v => v.statut_analyse === 'terminee').length}
              </div>
              <div className="text-sm text-gray-600">Analyses terminées</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                <AlertTriangle className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{stats.totalNonConformites}</div>
              <div className="text-sm text-gray-600">Non-conformités</div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6 text-center">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-violet-600 rounded-lg flex items-center justify-center mx-auto mb-2">
                <FileText className="w-5 h-5 text-white" />
              </div>
              <div className="text-2xl font-bold text-gray-800">{stats.totalTranscriptions}</div>
              <div className="text-sm text-gray-600">Transcriptions</div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-4">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "outline"}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 ${
                activeTab === tab.id 
                  ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white' 
                  : 'hover:bg-purple-50'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </Button>
          ))}
        </div>

        {/* Contenu principal */}
        <Card className="bg-white/90 backdrop-blur-sm shadow-xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {tabs.find(t => t.id === activeTab)?.icon && (
                React.createElement(tabs.find(t => t.id === activeTab)!.icon, { className: "w-5 h-5" })
              )}
              {tabs.find(t => t.id === activeTab)?.label}
            </CardTitle>
            <CardDescription>
              {tabs.find(t => t.id === activeTab)?.description}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {activeTab === 'upload' && (
              <VideoUploadForm onVideoUploaded={handleVideoUploaded} />
            )}
            
            {activeTab === 'list' && (
              <VideoInspectionsList
                videos={videoInspections}
                loading={loading}
                onVideoSelect={handleVideoSelect}
                onRefresh={loadVideoInspections}
              />
            )}
            
            {activeTab === 'analyze' && selectedVideo && (
              <VideoAnalysisViewer video={selectedVideo} />
            )}
            
            {activeTab === 'analyze' && !selectedVideo && (
              <div className="text-center py-12">
                <Video className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-lg text-gray-600">
                  Sélectionnez une vidéo dans la liste pour voir son analyse
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};
