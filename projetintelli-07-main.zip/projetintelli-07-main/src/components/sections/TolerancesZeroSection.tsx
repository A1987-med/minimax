
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, AlertTriangle, Ban, Eye, Gavel } from "lucide-react";

interface TolerancesZeroSectionProps {
  onBack: () => void;
}

export const TolerancesZeroSection = ({ onBack }: TolerancesZeroSectionProps) => {
  const tolerances = [
    {
      title: "Consommation d'alcool ou de drogues",
      description: "Interdiction absolue de consommer ou d'être sous l'influence d'alcool ou de drogues sur le chantier",
      icon: Ban,
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200"
    },
    {
      title: "Violence ou harcèlement",
      description: "Aucune forme de violence physique, verbale ou de harcèlement ne sera tolérée",
      icon: Shield,
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200"
    },
    {
      title: "Non-respect des EPI",
      description: "Le port d'équipements de protection individuelle est obligatoire en tout temps",
      icon: AlertTriangle,
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200"
    },
    {
      title: "Travail en hauteur non sécurisé",
      description: "Interdiction de travailler en hauteur sans équipement de protection contre les chutes",
      icon: Eye,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200"
    },
    {
      title: "Violations répétées",
      description: "Les violations répétées des règles de sécurité entraînent l'exclusion du chantier",
      icon: Gavel,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200"
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          ← Retour
        </Button>
        <h1 className="text-3xl font-bold text-gray-800">Tolérances Zéro</h1>
        <Badge variant="outline" className="text-red-600 border-red-200">
          Politique stricte
        </Badge>
      </div>

      <Card className="border-2 border-red-200 bg-gradient-to-br from-red-50 to-red-100">
        <CardHeader>
          <CardTitle className="text-xl flex items-center gap-3 text-red-700">
            <Shield className="w-6 h-6" />
            Politique de Tolérance Zéro
          </CardTitle>
          <CardDescription>
            Ces règles sont appliquées de manière stricte et sans exception sur tous nos chantiers
          </CardDescription>
        </CardHeader>
        <CardContent className="bg-white rounded-lg p-6 shadow-sm">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {tolerances.map((tolerance, index) => (
              <Card key={index} className={`${tolerance.borderColor} ${tolerance.bgColor} border-2`}>
                <CardContent className="p-4">
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 rounded-lg ${tolerance.bgColor} border ${tolerance.borderColor} flex items-center justify-center`}>
                      <tolerance.icon className={`w-5 h-5 ${tolerance.color}`} />
                    </div>
                    <div className="flex-1">
                      <h3 className={`font-semibold ${tolerance.color} mb-2`}>
                        {tolerance.title}
                      </h3>
                      <p className="text-sm text-gray-700">
                        {tolerance.description}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <div className="mt-6 p-4 bg-red-100 border border-red-300 rounded-lg">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-6 h-6 text-red-600 mt-1" />
              <div>
                <h4 className="font-semibold text-red-800 mb-2">Conséquences</h4>
                <ul className="text-sm text-red-700 space-y-1">
                  <li>• Première violation : Avertissement écrit et formation obligatoire</li>
                  <li>• Deuxième violation : Suspension temporaire du chantier</li>
                  <li>• Troisième violation : Exclusion définitive du projet</li>
                  <li>• Violations graves : Exclusion immédiate et signalement aux autorités</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
