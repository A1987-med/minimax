import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CloudIcon, ThermometerIcon, WindIcon, DropletIcon, RefreshCwIcon, SettingsIcon, MapPinIcon } from "lucide-react";
import { getMeteoData, MeteoData, saveMeteoData, getWeatherApiKey } from '@/services/meteoService';
import { useToast } from "@/hooks/use-toast";
import { ApiKeyConfig } from './ApiKeyConfig';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

interface MeteoWidgetProps {
  date: string;
  onMeteoChange: (meteoData: Partial<MeteoData>) => void;
}

export const MeteoWidget = ({ date, onMeteoChange }: MeteoWidgetProps) => {
  const [meteoData, setMeteoData] = useState<MeteoData | null>(null);
  const [loading, setLoading] = useState(false);
  const [showConfig, setShowConfig] = useState(false);
  const [hasApiKey, setHasApiKey] = useState(false);
  const { toast } = useToast();

  // Récupérer l'ID du projet depuis le contexte ou localStorage (peut être ajouté plus tard)
  const projetId = localStorage.getItem('current_projet_id') || undefined;

  // Fonction pour vérifier et mettre à jour le statut de la clé API
  const checkApiKeyStatus = () => {
    const apiKey = getWeatherApiKey();
    const newHasApiKey = !!apiKey;
    
    // Si le statut de la clé API a changé, recharger les données météo
    if (newHasApiKey !== hasApiKey) {
      console.log('🔄 Changement de statut de clé API détecté:', { ancien: hasApiKey, nouveau: newHasApiKey });
      setHasApiKey(newHasApiKey);
      
      // Si une clé API vient d'être configurée, recharger automatiquement les données
      if (newHasApiKey && date) {
        console.log('🌤️ Rechargement automatique des données météo avec la nouvelle clé API');
        fetchMeteoData();
      }
    } else {
      setHasApiKey(newHasApiKey);
    }
  };

  useEffect(() => {
    checkApiKeyStatus();
  }, []);

  // Écouter les changements dans le localStorage pour la clé API
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'weatherapi_key') {
        console.log('🔑 Changement de clé API détecté dans le localStorage');
        checkApiKeyStatus();
      }
    };

    window.addEventListener('storage', handleStorageChange);
    
    // Également vérifier périodiquement pour les changements dans le même onglet
    const interval = setInterval(checkApiKeyStatus, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [hasApiKey, date]);

  const fetchMeteoData = async () => {
    if (!date) return;
    
    setLoading(true);
    try {
      // Utiliser le service météo hybride avec support Supabase
      const data = await getMeteoData(date, projetId);
      setMeteoData(data);
      onMeteoChange(data);
      
      const today = new Date().toISOString().split('T')[0];
      const isToday = date === today;
      
      toast({
        title: "Données météo récupérées",
        description: data.isRealData 
          ? `Données météo réelles pour ${data.location || 'votre position'} - ${date}`
          : `Données météo simulées pour ${date}`,
      });
    } catch (error) {
      console.error('Erreur lors de la récupération des données météo:', error);
      toast({
        title: "Erreur météo",
        description: "Impossible de récupérer les données météo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManualChange = async (field: keyof MeteoData, value: string | number) => {
    if (!meteoData) return;
    
    const updatedData = { ...meteoData, [field]: value };
    setMeteoData(updatedData);
    onMeteoChange(updatedData);
    
    // Sauvegarder automatiquement les modifications dans Supabase
    try {
      await saveMeteoData(updatedData.date, updatedData, projetId);
      console.log('✅ Modification météo sauvegardée automatiquement');
    } catch (error) {
      console.error('❌ Erreur lors de la sauvegarde automatique:', error);
    }
  };

  useEffect(() => {
    if (date) {
      fetchMeteoData();
    }
  }, [date]);

  const getStatusBadge = () => {
    if (!meteoData) return null;
    
    if (meteoData.isRealData) {
      return (
        <span className="text-xs text-green-600 bg-green-100 px-2 py-1 rounded">
          Données réelles
        </span>
      );
    } else {
      return (
        <span className="text-xs text-yellow-600 bg-yellow-100 px-2 py-1 rounded">
          Données simulées
        </span>
      );
    }
  };

  return (
    <div className="space-y-4">
      <Collapsible open={showConfig} onOpenChange={setShowConfig}>
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <CloudIcon className="w-5 h-5" />
                Conditions météorologiques
                {meteoData && <span className="text-2xl ml-2">{meteoData.icone}</span>}
              </CardTitle>
              <div className="flex items-center gap-2">
                {getStatusBadge()}
                {hasApiKey && (
                  <span className="text-xs text-blue-600 bg-blue-100 px-2 py-1 rounded">
                    API configurée
                  </span>
                )}
                <CollapsibleTrigger asChild>
                  <Button variant="ghost" size="sm">
                    <SettingsIcon className="w-4 h-4" />
                  </Button>
                </CollapsibleTrigger>
              </div>
            </div>
            {meteoData && meteoData.location && (
              <div className="flex items-center gap-1 text-sm text-gray-600">
                <MapPinIcon className="w-4 h-4" />
                <span>{meteoData.location}</span>
              </div>
            )}
          </CardHeader>
          
          <CollapsibleContent>
            <CardContent>
              <ApiKeyConfig />
            </CardContent>
          </CollapsibleContent>

          {!meteoData && (
            <CardContent>
              <Button onClick={fetchMeteoData} disabled={loading || !date}>
                {loading ? (
                  <>
                    <RefreshCwIcon className="w-4 h-4 mr-2 animate-spin" />
                    Chargement...
                  </>
                ) : (
                  'Récupérer les données météo'
                )}
              </Button>
            </CardContent>
          )}
        </Card>
      </Collapsible>

      {meteoData && (
        <Card>
          <CardContent className="pt-6 space-y-4">
            <div className="flex justify-between items-center">
              <span className="font-medium">Conditions: {meteoData.conditions}</span>
              <Button onClick={fetchMeteoData} disabled={loading} size="sm" variant="outline">
                <RefreshCwIcon className="w-4 h-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="temperature" className="flex items-center gap-1">
                  <ThermometerIcon className="w-4 h-4" />
                  Température (°C)
                </Label>
                <Input
                  id="temperature"
                  type="number"
                  value={meteoData.temperature}
                  onChange={(e) => handleManualChange('temperature', parseInt(e.target.value))}
                />
              </div>
              
              <div>
                <Label htmlFor="temperatureRessentie" className="flex items-center gap-1">
                  <ThermometerIcon className="w-4 h-4" />
                  Ressentie (°C)
                </Label>
                <Input
                  id="temperatureRessentie"
                  type="number"
                  value={meteoData.temperatureRessentie}
                  onChange={(e) => handleManualChange('temperatureRessentie', parseInt(e.target.value))}
                />
              </div>
              
              <div>
                <Label htmlFor="vent" className="flex items-center gap-1">
                  <WindIcon className="w-4 h-4" />
                  Vent (km/h)
                </Label>
                <Input
                  id="vent"
                  type="number"
                  value={meteoData.vent}
                  onChange={(e) => handleManualChange('vent', parseInt(e.target.value))}
                />
              </div>
              
              <div>
                <Label htmlFor="rafales" className="flex items-center gap-1">
                  <WindIcon className="w-4 h-4" />
                  Rafales (km/h)
                </Label>
                <Input
                  id="rafales"
                  type="number"
                  value={meteoData.rafales}
                  onChange={(e) => handleManualChange('rafales', parseInt(e.target.value))}
                />
              </div>
              
              <div>
                <Label htmlFor="humidite" className="flex items-center gap-1">
                  <DropletIcon className="w-4 h-4" />
                  Humidité (%)
                </Label>
                <Input
                  id="humidite"
                  type="number"
                  value={meteoData.humidite}
                  onChange={(e) => handleManualChange('humidite', parseInt(e.target.value))}
                />
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
