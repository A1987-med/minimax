
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { CalendarIcon, TrendingUpIcon } from "lucide-react";
import { getMeteoHistory, getStoredMeteoHistory, MeteoData } from '@/services/meteoService';
import { Button } from "@/components/ui/button";

export const MeteoChart = () => {
  const [meteoHistory, setMeteoHistory] = useState<MeteoData[]>([]);
  const [loading, setLoading] = useState(false);

  const loadMeteoHistory = async () => {
    setLoading(true);
    try {
      // D'abord essayer de charger depuis le localStorage
      const storedData = getStoredMeteoHistory();
      if (storedData.length > 0) {
        setMeteoHistory(storedData.slice(-30)); // Garder les 30 derniers jours
      } else {
        // Si pas de données stockées, générer un historique
        const history = await getMeteoHistory(30);
        setMeteoHistory(history);
      }
    } catch (error) {
      console.error('Erreur lors du chargement de l\'historique météo:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadMeteoHistory();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit'
    });
  };

  const chartData = meteoHistory.map(data => ({
    date: formatDate(data.date),
    temperature: data.temperature,
    vent: data.vent,
    humidite: data.humidite
  }));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TrendingUpIcon className="w-5 h-5" />
          Graphique météorologique cumulé (30 derniers jours)
          <Button onClick={loadMeteoHistory} disabled={loading} size="sm" variant="outline" className="ml-auto">
            {loading ? 'Chargement...' : 'Actualiser'}
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {chartData.length > 0 ? (
          <div className="space-y-6">
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  labelFormatter={(label) => `Date: ${label}`}
                  formatter={(value, name) => {
                    const unit = name === 'temperature' ? '°C' : 
                                name === 'vent' ? 'km/h' : 
                                name === 'humidite' ? '%' : '';
                    return [`${value}${unit}`, name === 'temperature' ? 'Température' : 
                                                name === 'vent' ? 'Vent' : 'Humidité'];
                  }}
                />
                <Legend 
                  formatter={(value) => 
                    value === 'temperature' ? 'Température (°C)' : 
                    value === 'vent' ? 'Vent (km/h)' : 'Humidité (%)'
                  }
                />
                <Line 
                  type="monotone" 
                  dataKey="temperature" 
                  stroke="#ef4444" 
                  strokeWidth={2}
                  dot={{ fill: '#ef4444', strokeWidth: 2, r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="vent" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="humidite" 
                  stroke="#10b981" 
                  strokeWidth={2}
                  dot={{ fill: '#10b981', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div className="p-3 bg-red-50 rounded-lg">
                <div className="text-red-600 font-semibold">Température</div>
                <div className="text-sm text-gray-600">
                  Moy: {Math.round(chartData.reduce((sum, d) => sum + d.temperature, 0) / chartData.length)}°C
                </div>
              </div>
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="text-blue-600 font-semibold">Vent</div>
                <div className="text-sm text-gray-600">
                  Moy: {Math.round(chartData.reduce((sum, d) => sum + d.vent, 0) / chartData.length)} km/h
                </div>
              </div>
              <div className="p-3 bg-green-50 rounded-lg">
                <div className="text-green-600 font-semibold">Humidité</div>
                <div className="text-sm text-gray-600">
                  Moy: {Math.round(chartData.reduce((sum, d) => sum + d.humidite, 0) / chartData.length)}%
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <CalendarIcon className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p>Aucune donnée météorologique disponible</p>
            <Button onClick={loadMeteoHistory} className="mt-4">
              Charger l'historique météo
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
