
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { UsersIcon, Database, Users } from "lucide-react";
import { SoustraitantPresenceCard } from './components/SoustraitantPresenceCard';
import { usePresencesData } from './hooks/usePresencesData';
import { SoustraitantPresence } from '@/services/presencesService';

interface SoustraitantsWidgetProps {
  onTotalChange: (total: number, details: SoustraitantPresence[]) => void;
}

export const SoustraitantsWidget = ({ onTotalChange }: SoustraitantsWidgetProps) => {
  const {
    presences,
    isLoading,
    deletingIds,
    debugInfo,
    modifierNombre,
    supprimerPresence
  } = usePresencesData(onTotalChange);

  const totalTravailleurs = presences.reduce((sum, p) => sum + p.nombreTravailleurs, 0);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UsersIcon className="w-5 h-5" />
          Nombre de travailleurs par sous-traitant
          <Badge variant="secondary" className="ml-auto">
            Total: {totalTravailleurs}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-center p-3 bg-green-50 rounded-lg">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-green-600" />
            <span className="text-sm font-medium text-green-800">
              Données synchronisées avec localStorage (actualisation automatique)
            </span>
          </div>
        </div>

        <div className="p-3 bg-blue-50 rounded border-l-4 border-blue-400">
          <div className="text-sm">
            <strong>🔍 Statut:</strong> {debugInfo}
          </div>
          <div className="text-xs mt-2 text-gray-600">
            <div>Source: localStorage (presences_journalieres)</div>
            <div className="mt-1">Présences chargées: {presences.length}</div>
            {presences.length > 0 && (
              <div className="mt-1 space-y-1">
                {presences.map(p => (
                  <div key={p.id} className="text-xs">• {p.nom}: {p.nombreTravailleurs} travailleurs</div>
                ))}
              </div>
            )}
          </div>
        </div>

        {presences.length > 0 ? (
          <div className="space-y-2">
            <div className="mb-4 p-3 bg-green-50 rounded-lg">
              <p className="text-sm text-green-800 font-medium">
                ✅ {presences.length} sous-traitant{presences.length > 1 ? 's' : ''} avec présences enregistrées
              </p>
            </div>

            {presences.map((presence) => (
              <SoustraitantPresenceCard
                key={presence.id}
                presence={presence}
                onModifierNombre={modifierNombre}
                onSupprimer={supprimerPresence}
                isDeleting={deletingIds.has(presence.id)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-gray-500">
            <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm font-medium">Aucune présence enregistrée aujourd'hui</p>
            <p className="text-xs mt-1">
              Les contremaîtres peuvent scanner les codes QR pour saisir les présences
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
