
import React, { useCallback } from 'react';
import { Button } from "@/components/ui/button";
import { SaveIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useFormData } from './FormDataProvider';

interface FormActionsProps {
  onSubmit?: (data: any) => void;
}

export const FormActions = ({ onSubmit }: FormActionsProps) => {
  console.log('🎬 FormActions - Initialisation du composant');
  
  const { toast } = useToast();
  const { formData, resetForm } = useFormData();

  // Mémorisation de la fonction de soumission
  const handleSubmit = useCallback((e: React.FormEvent) => {
    e.preventDefault();
    console.log('📤 FormActions - Début de la soumission du formulaire');
    
    const rapportComplet = {
      ...formData,
      id: `inspection_${Date.now()}`,
      type: 'inspection_sst',
      dateCreation: new Date().toISOString()
    };

    console.log('📋 FormActions - Rapport créé:', rapportComplet);

    // Validation basique
    if (!formData.nomCoordonnateur || !formData.zoneInspectee || !formData.evaluationGlobale) {
      console.warn('⚠️ FormActions - Validation échouée - champs manquants');
      toast({
        title: "Erreur de validation",
        description: "Veuillez remplir les champs obligatoires (Coordonnateur, Zone inspectée, Évaluation globale)",
        variant: "destructive"
      });
      return;
    }

    try {
      console.log('💾 FormActions - Sauvegarde dans localStorage');
      
      // Sauvegarder dans le localStorage
      const rapportsExistants = JSON.parse(localStorage.getItem('rapports_journaliers') || '[]');
      rapportsExistants.push(rapportComplet);
      localStorage.setItem('rapports_journaliers', JSON.stringify(rapportsExistants));

      console.log('✅ FormActions - Sauvegarde réussie');

      toast({
        title: "Rapport d'inspection sauvegardé",
        description: "Le rapport d'inspection SST a été enregistré avec succès",
      });

      if (onSubmit) {
        console.log('🔄 FormActions - Exécution de onSubmit callback');
        onSubmit(rapportComplet);
      }

      // Réinitialiser le formulaire
      console.log('🔄 FormActions - Réinitialisation du formulaire');
      resetForm();

    } catch (error) {
      console.error('❌ FormActions - Erreur lors de la sauvegarde:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la sauvegarde du rapport d'inspection",
        variant: "destructive"
      });
    }
  }, [formData, toast, onSubmit, resetForm]);

  // Mémorisation de la fonction d'annulation
  const handleCancel = useCallback(() => {
    console.log('🚫 FormActions - Annulation du formulaire');
    if (window.confirm('Êtes-vous sûr de vouloir annuler ? Toutes les données non sauvegardées seront perdues.')) {
      resetForm();
      window.location.reload();
    }
  }, [resetForm]);

  console.log('🎯 FormActions - Rendu du composant avec fonctions mémorisées');

  return (
    <div className="flex justify-end gap-4 pt-6">
      <Button type="button" variant="outline" onClick={handleCancel}>
        Annuler
      </Button>
      <Button type="submit" className="flex items-center gap-2" onClick={handleSubmit}>
        <SaveIcon className="w-4 h-4" />
        Enregistrer le rapport d'inspection
      </Button>
    </div>
  );
};
