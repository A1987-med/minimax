
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertTriangleIcon } from "lucide-react";

interface NonConformitesSectionProps {
  formData: {
    nonConformites: string;
    niveauGravite: string;
    actionsCorrectivesRequises: string;
    delaiCorrection: string;
  };
  onInputChange: (field: string, value: string) => void;
  niveauGraviteOptions: string[];
}

export const NonConformitesSection = ({ formData, onInputChange, niveauGraviteOptions }: NonConformitesSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-950/30 dark:to-orange-950/30 border-red-200 dark:border-red-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-red-500 to-orange-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <AlertTriangleIcon className="w-6 h-6" />
          ⚠️ Non-conformités identifiées
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-red-200 dark:border-red-700 shadow-sm">
          <Label htmlFor="nonConformites" className="text-red-800 dark:text-red-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            📝 Description des non-conformités
          </Label>
          <Textarea
            id="nonConformites"
            value={formData.nonConformites}
            onChange={(e) => onInputChange('nonConformites', e.target.value)}
            placeholder="Décrire les problèmes observés..."
            className="min-h-[120px] border-red-300 dark:border-red-600 focus:border-red-500 dark:focus:border-red-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-orange-200 dark:border-orange-700 shadow-sm">
            <Label htmlFor="niveauGravite" className="text-orange-800 dark:text-orange-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🚨 Niveau de gravité
            </Label>
            <Select value={formData.niveauGravite} onValueChange={(value) => onInputChange('niveauGravite', value)}>
              <SelectTrigger className="border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                <SelectValue placeholder="Sélectionner le niveau..." />
              </SelectTrigger>
              <SelectContent>
                {niveauGraviteOptions.map((niveau) => (
                  <SelectItem key={niveau} value={niveau}>{niveau}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-yellow-200 dark:border-yellow-700 shadow-sm">
            <Label htmlFor="delaiCorrection" className="text-yellow-800 dark:text-yellow-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              ⏰ Délai de correction
            </Label>
            <Input
              id="delaiCorrection"
              value={formData.delaiCorrection}
              onChange={(e) => onInputChange('delaiCorrection', e.target.value)}
              placeholder="Ex: 24 heures"
              className="border-yellow-300 dark:border-yellow-600 focus:border-yellow-500 dark:focus:border-yellow-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-purple-200 dark:border-purple-700 shadow-sm">
          <Label htmlFor="actionsCorrectivesRequises" className="text-purple-800 dark:text-purple-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            🔧 Actions correctives requises
          </Label>
          <Textarea
            id="actionsCorrectivesRequises"
            value={formData.actionsCorrectivesRequises}
            onChange={(e) => onInputChange('actionsCorrectivesRequises', e.target.value)}
            placeholder="Mesures à prendre pour corriger..."
            className="min-h-[100px] border-purple-300 dark:border-purple-600 focus:border-purple-500 dark:focus:border-purple-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
      </CardContent>
    </Card>
  );
};
