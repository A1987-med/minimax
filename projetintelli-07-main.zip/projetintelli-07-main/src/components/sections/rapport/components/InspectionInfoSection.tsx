
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserIcon } from "lucide-react";

interface InspectionInfoSectionProps {
  formData: {
    date: string;
    heureDebut: string;
    heureFin: string;
    nomCoordonnateur: string;
    zoneInspectee: string;
    secteurChantier: string;
  };
  onInputChange: (field: string, value: string) => void;
}

export const InspectionInfoSection = ({ formData, onInputChange }: InspectionInfoSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-950/30 dark:to-blue-950/30 border-cyan-200 dark:border-cyan-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <UserIcon className="w-6 h-6" />
          👤 Informations sur l'inspection
        </CardTitle>
      </CardHeader>
      <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
          <Label htmlFor="date" className="text-blue-800 dark:text-blue-200 font-semibold mb-2 block flex items-center gap-2">
            📅 Date d'inspection *
          </Label>
          <Input
            id="date"
            type="date"
            value={formData.date}
            onChange={(e) => onInputChange('date', e.target.value)}
            className="w-48 border-blue-300 dark:border-blue-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-green-200 dark:border-green-700 shadow-sm">
          <Label htmlFor="nomCoordonnateur" className="text-green-800 dark:text-green-200 font-semibold mb-2 block flex items-center gap-2">
            👨‍💼 Nom du coordonnateur SST *
          </Label>
          <Input
            id="nomCoordonnateur"
            value={formData.nomCoordonnateur}
            onChange={(e) => onInputChange('nomCoordonnateur', e.target.value)}
            placeholder="Prénom Nom"
            className="border-green-300 dark:border-green-600 focus:border-green-500 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-teal-200 dark:border-teal-700 shadow-sm">
          <Label htmlFor="zoneInspectee" className="text-teal-800 dark:text-teal-200 font-semibold mb-2 block flex items-center gap-2">
            📍 Zone/Secteur inspecté *
          </Label>
          <Input
            id="zoneInspectee"
            value={formData.zoneInspectee}
            onChange={(e) => onInputChange('zoneInspectee', e.target.value)}
            placeholder="Ex: Bâtiment A - Étage 3"
            className="border-teal-300 dark:border-teal-600 focus:border-teal-500 dark:focus:border-teal-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg border border-indigo-200 dark:border-indigo-700 shadow-sm">
          <Label htmlFor="secteurChantier" className="text-indigo-800 dark:text-indigo-200 font-semibold mb-2 block flex items-center gap-2">
            🏗️ Secteur du chantier
          </Label>
          <Input
            id="secteurChantier"
            value={formData.secteurChantier}
            onChange={(e) => onInputChange('secteurChantier', e.target.value)}
            placeholder="Ex: Gros œuvre, Finition"
            className="border-indigo-300 dark:border-indigo-600 focus:border-indigo-500 dark:focus:border-indigo-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
      </CardContent>
    </Card>
  );
};
