
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { StarIcon } from "lucide-react";

interface EvaluationGlobaleSectionProps {
  formData: {
    evaluationGlobale: string;
    pointsAmeliorer: string;
    prochaineSuggestion: string;
  };
  onInputChange: (field: string, value: string) => void;
  evaluationOptions: string[];
}

export const EvaluationGlobaleSection = ({ formData, onInputChange, evaluationOptions }: EvaluationGlobaleSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-amber-50 to-yellow-50 dark:from-amber-950/30 dark:to-yellow-950/30 border-amber-200 dark:border-amber-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-amber-500 to-yellow-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <StarIcon className="w-6 h-6" />
          ⭐ Évaluation globale
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-amber-200 dark:border-amber-700 shadow-sm">
          <Label htmlFor="evaluationGlobale" className="text-amber-800 dark:text-amber-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            📊 Évaluation globale de l'inspection *
          </Label>
          <Select value={formData.evaluationGlobale} onValueChange={(value) => onInputChange('evaluationGlobale', value)}>
            <SelectTrigger className="border-amber-300 dark:border-amber-600 focus:border-amber-500 dark:focus:border-amber-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
              <SelectValue placeholder="Sélectionner l'évaluation..." />
            </SelectTrigger>
            <SelectContent>
              {evaluationOptions.map((evaluation) => (
                <SelectItem key={evaluation} value={evaluation}>{evaluation}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-orange-200 dark:border-orange-700 shadow-sm">
          <Label htmlFor="pointsAmeliorer" className="text-orange-800 dark:text-orange-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            🎯 Points prioritaires à améliorer
          </Label>
          <Textarea
            id="pointsAmeliorer"
            value={formData.pointsAmeliorer}
            onChange={(e) => onInputChange('pointsAmeliorer', e.target.value)}
            placeholder="Priorités d'amélioration..."
            className="min-h-[100px] border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
          <Label htmlFor="prochaineSuggestion" className="text-blue-800 dark:text-blue-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            🔮 Suggestions pour la prochaine inspection
          </Label>
          <Textarea
            id="prochaineSuggestion"
            value={formData.prochaineSuggestion}
            onChange={(e) => onInputChange('prochaineSuggestion', e.target.value)}
            placeholder="Points à vérifier lors de la prochaine inspection..."
            className="min-h-[100px] border-blue-300 dark:border-blue-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
      </CardContent>
    </Card>
  );
};
