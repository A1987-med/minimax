
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { InfoIcon } from "lucide-react";

interface InformationsGeneralesSectionProps {
  formData: {
    permis: {
      fermetureVoie: boolean;
      directiveCreusage: boolean;
      obstructionDomaine: boolean;
      planTravail: boolean;
      pointsChauds: boolean;
      pointsChauxEntreprise: string;
      entreeEspaceClos: boolean;
      autrePermis: boolean;
      autrePermisDetails: string;
    };
    autres: {
      accidentIncident: boolean;
      accidentIncidentDetails: string;
      travauxRisquesEleves: boolean;
      travauxRisquesElevesDetails: string;
      avisInfraction: boolean;
      avisInfractionNature: string;
      avisInfractionEntrepreneur: string;
    };
  };
  onInputChange: (field: string, value: any) => void;
}

export const InformationsGeneralesSection = ({ formData, onInputChange }: InformationsGeneralesSectionProps) => {
  const handlePermisChange = (field: string, checked: boolean) => {
    onInputChange('permis', {
      ...formData.permis,
      [field]: checked
    });
  };

  const handlePermisTextChange = (field: string, value: string) => {
    onInputChange('permis', {
      ...formData.permis,
      [field]: value
    });
  };

  const handleAutresChange = (field: string, value: any) => {
    onInputChange('autres', {
      ...formData.autres,
      [field]: value
    });
  };

  return (
    <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-950/30 dark:to-indigo-950/30 border-blue-200 dark:border-blue-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <InfoIcon className="w-6 h-6" />
          📋 Informations générales sur la journée
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-8 p-6">
        {/* Section Permis */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
          <h4 className="font-bold text-xl mb-6 text-blue-800 dark:text-blue-200 flex items-center gap-2">
            🔒 Permis et autorisations
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <Checkbox 
                id="permis-fermeture-voie"
                checked={formData.permis.fermetureVoie}
                onCheckedChange={(checked) => handlePermisChange('fermetureVoie', !!checked)}
                className="border-blue-400 dark:border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <Label htmlFor="permis-fermeture-voie" className="font-medium text-blue-800 dark:text-blue-200 cursor-pointer">
                🚧 Permis de fermeture de voie
              </Label>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <Checkbox 
                id="permis-directive-creusage"
                checked={formData.permis.directiveCreusage}
                onCheckedChange={(checked) => handlePermisChange('directiveCreusage', !!checked)}
                className="border-blue-400 dark:border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <Label htmlFor="permis-directive-creusage" className="font-medium text-blue-800 dark:text-blue-200 cursor-pointer">
                ⛏️ Directive de creusage
              </Label>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <Checkbox 
                id="permis-obstruction"
                checked={formData.permis.obstructionDomaine}
                onCheckedChange={(checked) => handlePermisChange('obstructionDomaine', !!checked)}
                className="border-blue-400 dark:border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <Label htmlFor="permis-obstruction" className="font-medium text-blue-800 dark:text-blue-200 cursor-pointer">
                🚨 Permis d'obstruction du domaine public
              </Label>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <Checkbox 
                id="permis-plan-travail"
                checked={formData.permis.planTravail}
                onCheckedChange={(checked) => handlePermisChange('planTravail', !!checked)}
                className="border-blue-400 dark:border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <Label htmlFor="permis-plan-travail" className="font-medium text-blue-800 dark:text-blue-200 cursor-pointer">
                📋 Plan de travail
              </Label>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <Checkbox 
                id="permis-espace-clos"
                checked={formData.permis.entreeEspaceClos}
                onCheckedChange={(checked) => handlePermisChange('entreeEspaceClos', !!checked)}
                className="border-blue-400 dark:border-blue-500 data-[state=checked]:bg-blue-600 data-[state=checked]:border-blue-600"
              />
              <Label htmlFor="permis-espace-clos" className="font-medium text-blue-800 dark:text-blue-200 cursor-pointer">
                🚪 Permis d'entrée en espace clos
              </Label>
            </div>
          </div>

          {/* Permis points chauds avec champ entreprise */}
          <div className="mt-6 space-y-3 p-4 bg-orange-50 dark:bg-orange-950/30 rounded-lg border border-orange-200 dark:border-orange-700">
            <div className="flex items-center space-x-3">
              <Checkbox 
                id="permis-points-chauds"
                checked={formData.permis.pointsChauds}
                onCheckedChange={(checked) => handlePermisChange('pointsChauds', !!checked)}
                className="border-orange-400 dark:border-orange-500 data-[state=checked]:bg-orange-600 data-[state=checked]:border-orange-600"
              />
              <Label htmlFor="permis-points-chauds" className="font-medium text-orange-800 dark:text-orange-200 cursor-pointer">
                🔥 Permis par points chauds (de feu)
              </Label>
            </div>
            {formData.permis.pointsChauds && (
              <div className="ml-6 space-y-2">
                <Label htmlFor="points-chauds-entreprise" className="text-orange-700 dark:text-orange-300 font-medium">
                  🏢 Entreprise :
                </Label>
                <Input
                  id="points-chauds-entreprise"
                  value={formData.permis.pointsChauxEntreprise}
                  onChange={(e) => handlePermisTextChange('pointsChauxEntreprise', e.target.value)}
                  placeholder="Nom de l'entreprise"
                  className="border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                />
              </div>
            )}
          </div>

          {/* Autre permis avec détails */}
          <div className="mt-6 space-y-3 p-4 bg-purple-50 dark:bg-purple-950/30 rounded-lg border border-purple-200 dark:border-purple-700">
            <div className="flex items-center space-x-3">
              <Checkbox 
                id="autre-permis"
                checked={formData.permis.autrePermis}
                onCheckedChange={(checked) => handlePermisChange('autrePermis', !!checked)}
                className="border-purple-400 dark:border-purple-500 data-[state=checked]:bg-purple-600 data-[state=checked]:border-purple-600"
              />
              <Label htmlFor="autre-permis" className="font-medium text-purple-800 dark:text-purple-200 cursor-pointer">
                📝 Autre permis, précisez :
              </Label>
            </div>
            {formData.permis.autrePermis && (
              <div className="ml-6">
                <Textarea
                  value={formData.permis.autrePermisDetails}
                  onChange={(e) => handlePermisTextChange('autrePermisDetails', e.target.value)}
                  placeholder="Précisez le type de permis..."
                  className="border-purple-300 dark:border-purple-600 focus:border-purple-500 dark:focus:border-purple-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                  rows={3}
                />
              </div>
            )}
          </div>
        </div>

        {/* Section Autres */}
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-green-200 dark:border-green-700 shadow-sm">
          <h4 className="font-bold text-xl mb-6 text-green-800 dark:text-green-200 flex items-center gap-2">
            📊 Autres informations
          </h4>
          <div className="space-y-6">
            {/* Accident/Incident */}
            <div className="space-y-3 p-4 bg-red-50 dark:bg-red-950/30 rounded-lg border border-red-200 dark:border-red-700">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="accident-incident"
                  checked={formData.autres.accidentIncident}
                  onCheckedChange={(checked) => handleAutresChange('accidentIncident', !!checked)}
                  className="border-red-400 dark:border-red-500 data-[state=checked]:bg-red-600 data-[state=checked]:border-red-600"
                />
                <Label htmlFor="accident-incident" className="font-medium text-red-800 dark:text-red-200 cursor-pointer">
                  🚨 Accident / Incident, précisez :
                </Label>
              </div>
              {formData.autres.accidentIncident && (
                <div className="ml-6">
                  <Textarea
                    value={formData.autres.accidentIncidentDetails}
                    onChange={(e) => handleAutresChange('accidentIncidentDetails', e.target.value)}
                    placeholder="Décrivez l'accident ou l'incident..."
                    className="border-red-300 dark:border-red-600 focus:border-red-500 dark:focus:border-red-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    rows={3}
                  />
                </div>
              )}
            </div>

            {/* Travaux à risques élevés - cochée par défaut */}
            <div className="space-y-3 p-4 bg-yellow-50 dark:bg-yellow-950/30 rounded-lg border border-yellow-200 dark:border-yellow-700">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="travaux-risques-eleves"
                  checked={formData.autres.travauxRisquesEleves}
                  onCheckedChange={(checked) => handleAutresChange('travauxRisquesEleves', !!checked)}
                  className="border-yellow-400 dark:border-yellow-500 data-[state=checked]:bg-yellow-600 data-[state=checked]:border-yellow-600"
                />
                <Label htmlFor="travaux-risques-eleves" className="font-medium text-yellow-800 dark:text-yellow-200 cursor-pointer">
                  ⚠️ Travaux à risques élevés (incluant les tolérances zéro) : Précisez :
                </Label>
              </div>
              {formData.autres.travauxRisquesEleves && (
                <div className="ml-6">
                  <Textarea
                    value={formData.autres.travauxRisquesElevesDetails}
                    onChange={(e) => handleAutresChange('travauxRisquesElevesDetails', e.target.value)}
                    placeholder="Ex: creusement, machinerie lourde et gestion de la circulation..."
                    className="border-yellow-300 dark:border-yellow-600 focus:border-yellow-500 dark:focus:border-yellow-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    rows={3}
                  />
                </div>
              )}
            </div>

            {/* Avis d'infraction */}
            <div className="space-y-3 p-4 bg-gray-50 dark:bg-gray-900/50 rounded-lg border border-gray-200 dark:border-gray-700">
              <div className="flex items-center space-x-3">
                <Checkbox 
                  id="avis-infraction"
                  checked={formData.autres.avisInfraction}
                  onCheckedChange={(checked) => handleAutresChange('avisInfraction', !!checked)}
                  className="border-gray-400 dark:border-gray-500 data-[state=checked]:bg-gray-600 data-[state=checked]:border-gray-600"
                />
                <Label htmlFor="avis-infraction" className="font-medium text-gray-800 dark:text-gray-200 cursor-pointer">
                  📋 Avis d'infraction
                </Label>
              </div>
              {formData.autres.avisInfraction && (
                <div className="ml-6 space-y-4">
                  <div>
                    <Label htmlFor="infraction-nature" className="text-gray-700 dark:text-gray-300 font-medium mb-2 block">
                      📝 Nature :
                    </Label>
                    <Input
                      id="infraction-nature"
                      value={formData.autres.avisInfractionNature}
                      onChange={(e) => handleAutresChange('avisInfractionNature', e.target.value)}
                      placeholder="Nature de l'infraction"
                      className="border-gray-300 dark:border-gray-600 focus:border-gray-500 dark:focus:border-gray-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                  <div>
                    <Label htmlFor="infraction-entrepreneur" className="text-gray-700 dark:text-gray-300 font-medium mb-2 block">
                      🏢 Entrepreneur concerné :
                    </Label>
                    <Input
                      id="infraction-entrepreneur"
                      value={formData.autres.avisInfractionEntrepreneur}
                      onChange={(e) => handleAutresChange('avisInfractionEntrepreneur', e.target.value)}
                      placeholder="Nom de l'entrepreneur"
                      className="border-gray-300 dark:border-gray-600 focus:border-gray-500 dark:focus:border-gray-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
