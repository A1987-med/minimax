
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BuildingIcon } from "lucide-react";

interface ProjectInfo {
  nomProjet: string;
  numeroProjet: string;
  adresseProjet: string;
  logoMaitreOeuvre?: string;
}

interface ProjectInfoSectionProps {
  projectInfo: ProjectInfo;
}

export const ProjectInfoSection = ({ projectInfo }: ProjectInfoSectionProps) => {
  if (!projectInfo.nomProjet && !projectInfo.numeroProjet) {
    return null;
  }

  return (
    <Card className="mb-6 border-blue-200 bg-blue-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-blue-800">
          <BuildingIcon className="w-5 h-5" />
          Informations du projet
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          {projectInfo.nomProjet && (
            <div className="flex items-center gap-3">
              {projectInfo.logoMaitreOeuvre && (
                <div className="flex-shrink-0">
                  <img 
                    src={projectInfo.logoMaitreOeuvre} 
                    alt="Logo maître d'œuvre" 
                    className="w-12 h-12 object-contain rounded border border-blue-200 bg-white p-1"
                    onError={(e) => {
                      e.currentTarget.style.display = 'none';
                    }}
                  />
                </div>
              )}
              <div>
                <span className="font-semibold text-blue-700">Nom du projet: </span>
                <span className="text-blue-900">{projectInfo.nomProjet}</span>
              </div>
            </div>
          )}
          {projectInfo.numeroProjet && (
            <div>
              <span className="font-semibold text-blue-700">Numéro du projet: </span>
              <span className="text-blue-900">{projectInfo.numeroProjet}</span>
            </div>
          )}
          {projectInfo.adresseProjet && (
            <div className="md:col-span-2">
              <span className="font-semibold text-blue-700">Adresse: </span>
              <span className="text-blue-900">{projectInfo.adresseProjet}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
