
export const articlesCCSTCPrincipaux = [
  "2.1", "2.2", "2.3", "2.4", "2.5", "2.6", "2.7", "2.8", "2.9", "2.10",
  "3.1", "3.2", "3.3", "3.4", "3.5", "3.6", "3.7", "3.8", "3.9", "3.10",
  "4.1", "4.2", "4.3", "4.4", "4.5", "4.6", "4.7", "4.8", "4.9", "4.10",
  "5.1", "5.2", "5.3", "5.4", "5.5", "5.6", "5.7", "5.8", "5.9", "5.10"
];

export const sousArticlesCSSTC: Record<string, string[]> = {
  "2.8": ["2.8.1", "2.8.2", "2.8.3", "2.8.4", "2.8.5"],
  "2.1": ["2.1.1", "2.1.2", "2.1.3"],
  "3.5": ["3.5.1", "3.5.2", "3.5.3", "3.5.4"],
  "4.2": ["4.2.1", "4.2.2", "4.2.3"],
  "5.7": ["5.7.1", "5.7.2", "5.7.3", "5.7.4"]
};

export const optionsSuivi = [
  { value: "C", label: "C", color: "bg-green-800 text-white" },
  { value: "NC-c", label: "NC-c", color: "bg-green-200 text-green-800" },
  { value: "NC-nc", label: "NC-nc", color: "bg-red-500 text-white" },
  { value: "En attente", label: "En attente", color: "bg-yellow-400 text-yellow-900" },
  { value: "À suivre", label: "À suivre", color: "bg-yellow-700 text-white" },
  { value: "NA", label: "NA", color: "bg-gray-500 text-white" },
  { value: "NÉ", label: "NÉ", color: "bg-blue-500 text-white" }
];
