
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { LightbulbIcon } from "lucide-react";

interface ActionsRecommandationsSectionProps {
  formData: {
    actionsImmediates: string;
    recommandationsAmelioration: string;
    suiviRequis: string;
    formationNecessaire: string;
  };
  onInputChange: (field: string, value: string) => void;
}

export const ActionsRecommandationsSection = ({ formData, onInputChange }: ActionsRecommandationsSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-emerald-50 to-teal-50 dark:from-emerald-950/30 dark:to-teal-950/30 border-emerald-200 dark:border-emerald-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-emerald-500 to-teal-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <LightbulbIcon className="w-6 h-6" />
          💡 Actions et recommandations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-green-200 dark:border-green-700 shadow-sm">
          <Label htmlFor="actionsImmediates" className="text-green-800 dark:text-green-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            ⚡ Mesures correctives immédiates prises
          </Label>
          <Textarea
            id="actionsImmediates"
            value={formData.actionsImmediates}
            onChange={(e) => onInputChange('actionsImmediates', e.target.value)}
            placeholder="Actions effectuées sur le champ..."
            className="min-h-[100px] border-green-300 dark:border-green-600 focus:border-green-500 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
            <Label htmlFor="recommandationsAmelioration" className="text-blue-800 dark:text-blue-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              📈 Recommandations pour amélioration
            </Label>
            <Textarea
              id="recommandationsAmelioration"
              value={formData.recommandationsAmelioration}
              onChange={(e) => onInputChange('recommandationsAmelioration', e.target.value)}
              placeholder="Suggestions d'amélioration..."
              className="min-h-[100px] border-blue-300 dark:border-blue-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-purple-200 dark:border-purple-700 shadow-sm">
            <Label htmlFor="formationNecessaire" className="text-purple-800 dark:text-purple-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🎓 Formation additionnelle nécessaire
            </Label>
            <Textarea
              id="formationNecessaire"
              value={formData.formationNecessaire}
              onChange={(e) => onInputChange('formationNecessaire', e.target.value)}
              placeholder="Besoins en formation..."
              className="min-h-[100px] border-purple-300 dark:border-purple-600 focus:border-purple-500 dark:focus:border-purple-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
