
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { NavigationIcon, MapPinIcon, RouteIcon, LoaderIcon } from "lucide-react";
import { useNativeFeatures } from '@/hooks/useNativeFeatures';
import { navigationService } from '@/services/navigationService';
import { useToast } from "@/hooks/use-toast";

interface Position {
  latitude: number;
  longitude: number;
}

interface NavigationWidgetProps {
  derogationInfo: {
    numero: string;
    soustraitant: string;
    description: string;
    position?: Position;
  };
}

export const NavigationWidget = ({ derogationInfo }: NavigationWidgetProps) => {
  const [currentPosition, setCurrentPosition] = useState<Position | null>(null);
  const [navigationInfo, setNavigationInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { getCurrentPosition } = useNativeFeatures();
  const { toast } = useToast();

  const targetPosition = derogationInfo.position;

  // Créer une clé stable pour identifier les changements de position
  const positionKey = useMemo(() => {
    return targetPosition ? `${targetPosition.latitude}-${targetPosition.longitude}` : null;
  }, [targetPosition]);

  const updatePosition = useCallback(async () => {
    if (!targetPosition) {
      setCurrentPosition(null);
      setNavigationInfo(null);
      return;
    }
    
    setLoading(true);
    try {
      const position = await getCurrentPosition();
      if (position) {
        setCurrentPosition(position);
        const navInfo = navigationService.getNavigationInfo(position, targetPosition);
        setNavigationInfo(navInfo);
        
        if (navInfo.distance < 10) {
          toast({
            title: "🎯 Vous êtes arrivé!",
            description: "Vous êtes à moins de 10m de la dérogation",
          });
        }
      }
    } catch (error) {
      console.error('NavigationWidget - Erreur GPS:', error);
      toast({
        title: "Erreur GPS",
        description: "Impossible d'obtenir votre position actuelle",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [targetPosition, getCurrentPosition, toast]);

  const startNavigation = useCallback(() => {
    if (!targetPosition) return;
    
    const label = `Dérogation #${derogationInfo.numero} - ${derogationInfo.soustraitant}`;
    navigationService.startNavigation(targetPosition, label);
    toast({
      title: "🗺️ Navigation démarrée",
      description: "L'application de navigation s'ouvre...",
    });
  }, [targetPosition, derogationInfo.numero, derogationInfo.soustraitant, toast]);

  const openInMaps = useCallback(() => {
    if (!targetPosition) return;
    
    const label = `Dérogation #${derogationInfo.numero} - ${derogationInfo.soustraitant}`;
    navigationService.openInNativeMap(targetPosition, label);
    toast({
      title: "📍 Carte ouverte",
      description: "L'application de carte s'ouvre...",
    });
  }, [targetPosition, derogationInfo.numero, derogationInfo.soustraitant, toast]);

  const getDistanceColor = (distance: number) => {
    if (distance < 50) return 'bg-green-100 text-green-800 border-green-300';
    if (distance < 200) return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    return 'bg-blue-100 text-blue-800 border-blue-300';
  };

  // Effect stable qui ne se déclenche que quand la position change réellement
  useEffect(() => {
    if (positionKey) {
      updatePosition();
    } else {
      setCurrentPosition(null);
      setNavigationInfo(null);
    }
  }, [positionKey]); // Dépendance stable

  // Si pas de position cible, afficher un message
  if (!targetPosition) {
    return (
      <Card className="bg-gradient-to-r from-gray-50 to-gray-100 border-gray-200 shadow-md">
        <CardContent className="p-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-2">
            <NavigationIcon className="w-5 h-5 text-gray-400" />
            <h4 className="font-semibold text-gray-600">Navigation indisponible</h4>
          </div>
          <p className="text-sm text-gray-500">
            Aucune position GPS enregistrée pour cette dérogation.
            Capturez d'abord la position dans l'onglet "Position/Lieu".
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200 shadow-md">
      <CardContent className="p-4 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <NavigationIcon className="w-5 h-5 text-blue-600" />
            <h4 className="font-semibold text-blue-800">Navigation vers la dérogation</h4>
          </div>
          <Button
            onClick={updatePosition}
            disabled={loading}
            size="sm"
            variant="outline"
            className="flex items-center gap-2"
          >
            {loading ? (
              <LoaderIcon className="w-4 h-4 animate-spin" />
            ) : (
              <MapPinIcon className="w-4 h-4" />
            )}
            Actualiser
          </Button>
        </div>

        {/* Affichage des positions */}
        <div className="bg-white p-3 rounded-lg border border-blue-200 space-y-3">
          <div>
            <p className="text-sm font-medium text-gray-700 mb-2">🎯 Position cible (dérogation #{derogationInfo.numero}):</p>
            <div className="text-xs font-mono bg-blue-50 p-3 rounded border">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-blue-600">📍 Latitude:</span>
                  <span className="font-bold text-blue-800">{targetPosition.latitude.toFixed(6)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-blue-600">📍 Longitude:</span>
                  <span className="font-bold text-blue-800">{targetPosition.longitude.toFixed(6)}</span>
                </div>
              </div>
            </div>
          </div>
          
          {currentPosition && (
            <div>
              <p className="text-sm font-medium text-gray-700 mb-2">📱 Votre position actuelle:</p>
              <div className="text-xs font-mono bg-green-50 p-3 rounded border">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-green-600">📍 Latitude:</span>
                    <span className="font-bold text-green-800">{currentPosition.latitude.toFixed(6)}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-green-600">📍 Longitude:</span>
                    <span className="font-bold text-green-800">{currentPosition.longitude.toFixed(6)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {navigationInfo && (
          <div className="space-y-3">
            <div className="flex items-center gap-3 justify-center">
              <Badge className={`px-3 py-1 ${getDistanceColor(navigationInfo.distance)}`}>
                📏 {navigationInfo.formattedDistance}
              </Badge>
              <Badge variant="outline" className="px-3 py-1">
                🧭 {navigationInfo.formattedBearing}
              </Badge>
            </div>
            
            <div className="flex gap-2">
              <Button
                onClick={startNavigation}
                className="flex-1 flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <RouteIcon className="w-4 h-4" />
                Navigation GPS
              </Button>
              <Button
                onClick={openInMaps}
                variant="outline"
                className="flex-1 flex items-center gap-2"
              >
                <MapPinIcon className="w-4 h-4" />
                Ouvrir carte
              </Button>
            </div>
          </div>
        )}

        <div className="text-xs text-gray-600 bg-gray-50 p-2 rounded">
          💡 <strong>Conseil:</strong> Utilisez le bouton "Actualiser" pour mettre à jour votre position.
        </div>
      </CardContent>
    </Card>
  );
};
