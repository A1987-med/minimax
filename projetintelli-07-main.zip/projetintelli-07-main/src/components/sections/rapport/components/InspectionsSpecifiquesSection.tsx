
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SearchIcon } from "lucide-react";

interface InspectionsSpecifiquesSectionProps {
  formData: {
    echafaudages: string;
    espacesClos: string;
    travailHauteur: string;
    matieresDangereuses: string;
    equipementsCollectifs: string;
  };
  onInputChange: (field: string, value: string) => void;
}

export const InspectionsSpecifiquesSection = ({ formData, onInputChange }: InspectionsSpecifiquesSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30 border-purple-200 dark:border-purple-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <SearchIcon className="w-6 h-6" />
          🔍 Inspections spécifiques
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
            <Label htmlFor="echafaudages" className="text-blue-800 dark:text-blue-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🏗️ Échafaudages et structures temporaires
            </Label>
            <Textarea
              id="echafaudages"
              value={formData.echafaudages}
              onChange={(e) => onInputChange('echafaudages', e.target.value)}
              placeholder="État et conformité..."
              className="min-h-[100px] border-blue-300 dark:border-blue-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-gray-200 dark:border-gray-700 shadow-sm">
            <Label htmlFor="espacesClos" className="text-gray-800 dark:text-gray-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🚪 Espaces clos
            </Label>
            <Textarea
              id="espacesClos"
              value={formData.espacesClos}
              onChange={(e) => onInputChange('espacesClos', e.target.value)}
              placeholder="Procédures et sécurité..."
              className="min-h-[100px] border-gray-300 dark:border-gray-600 focus:border-gray-500 dark:focus:border-gray-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-orange-200 dark:border-orange-700 shadow-sm">
            <Label htmlFor="travailHauteur" className="text-orange-800 dark:text-orange-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🪜 Travail en hauteur
            </Label>
            <Textarea
              id="travailHauteur"
              value={formData.travailHauteur}
              onChange={(e) => onInputChange('travailHauteur', e.target.value)}
              placeholder="Équipements et procédures..."
              className="min-h-[100px] border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-red-200 dark:border-red-700 shadow-sm">
            <Label htmlFor="matieresDangereuses" className="text-red-800 dark:text-red-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              ☣️ Manipulation de matières dangereuses
            </Label>
            <Textarea
              id="matieresDangereuses"
              value={formData.matieresDangereuses}
              onChange={(e) => onInputChange('matieresDangereuses', e.target.value)}
              placeholder="Stockage et manipulation..."
              className="min-h-[100px] border-red-300 dark:border-red-600 focus:border-red-500 dark:focus:border-red-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
