
import React, { createContext, useContext, useState, ReactNode, useCallback, useMemo } from 'react';
import { MeteoData } from '@/services/meteoService';

interface Position {
  latitude: number;
  longitude: number;
}

interface SoustraitantPresence {
  id: string;
  nom: string;
  nombreTravailleurs: number;
}

interface Derogation {
  id: string;
  numero: string;
  soustraitant: string;
  derogation: string;
  referenceLegale: string;
  suivi: string;
  observations: string;
  echeancier: string;
  position?: Position;
  images: string[];
  photosDerogation: string[];
  photosCorrection: string[];
}

interface FormData {
  date: string;
  heureDebut: string;
  heureFin: string;
  nomCoordonnateur: string;
  zoneInspectee: string;
  secteurChantier: string;
  nombreTravailleursPresents: number;
  detailsTravailleurs: SoustraitantPresence[];
  meteoData: MeteoData | null;
  derogations: Derogation[];
  permis: {
    fermetureVoie: boolean;
    directiveCreusage: boolean;
    obstructionDomaine: boolean;
    planTravail: boolean;
    pointsChauds: boolean;
    pointsChauxEntreprise: string;
    entreeEspaceClos: boolean;
    autrePermis: boolean;
    autrePermisDetails: string;
  };
  autres: {
    accidentIncident: boolean;
    accidentIncidentDetails: string;
    travauxRisquesEleves: boolean;
    travauxRisquesElevesDetails: string;
    avisInfraction: boolean;
    avisInfractionNature: string;
    avisInfractionEntrepreneur: string;
  };
  machinerie: {
    chariotElevateur: number;
    plateformeElevatrice: number;
    nacelle: number;
    fracoHydromobile: number;
    grueMobile: number;
    camionGrue: number;
    pelleMecanique: number;
    chargeur: number;
    tombereau: number;
    pelleusesPetite: number;
    rouleauCompacteur: number;
    pompeBeton: number;
    fichesInspection: {
      foreuse: boolean;
      scissorLift: boolean;
      nacelleInspection: boolean;
    };
  };
  conformiteProtocoles: string;
  portEPI: string;
  etatEquipements: string;
  respectProcedures: string;
  nonConformites: string;
  niveauGravite: string;
  actionsCorrectivesRequises: string;
  delaiCorrection: string;
  echafaudages: string;
  espacesClos: string;
  travailHauteur: string;
  matieresDangereuses: string;
  equipementsCollectifs: string;
  observationsPositives: string;
  observationsNegatives: string;
  risquesIdentifies: string;
  actionsImmediates: string;
  recommandationsAmelioration: string;
  suiviRequis: string;
  formationNecessaire: string;
  travailleursFormes: string;
  supervisionAdequate: string;
  communicationSecurite: string;
  evaluationGlobale: string;
  pointsAmeliorer: string;
  prochaineSuggestion: string;
  signature: string;
  dateSignature: string;
}

interface FormDataContextType {
  formData: FormData;
  setFormData: React.Dispatch<React.SetStateAction<FormData>>;
  handleInputChange: (field: string, value: string) => void;
  handleMeteoChange: (meteoData: Partial<MeteoData>) => void;
  handleTravailleursChange: (total: number, details: SoustraitantPresence[]) => void;
  resetForm: () => void;
}

const FormDataContext = createContext<FormDataContextType | undefined>(undefined);

const getInitialFormData = (): FormData => {
  console.log('🔄 FormDataProvider - Initialisation des données par défaut');
  return {
    date: new Date().toISOString().split('T')[0],
    heureDebut: '',
    heureFin: '',
    nomCoordonnateur: '',
    zoneInspectee: '',
    secteurChantier: '',
    nombreTravailleursPresents: 0,
    detailsTravailleurs: [],
    meteoData: null,
    derogations: [],
    permis: {
      fermetureVoie: false,
      directiveCreusage: false,
      obstructionDomaine: false,
      planTravail: false,
      pointsChauds: false,
      pointsChauxEntreprise: '',
      entreeEspaceClos: false,
      autrePermis: false,
      autrePermisDetails: ''
    },
    autres: {
      accidentIncident: false,
      accidentIncidentDetails: '',
      travauxRisquesEleves: true,
      travauxRisquesElevesDetails: 'creusement, machinerie lourde et gestion de la circulation',
      avisInfraction: false,
      avisInfractionNature: '',
      avisInfractionEntrepreneur: ''
    },
    machinerie: {
      chariotElevateur: 0,
      plateformeElevatrice: 0,
      nacelle: 0,
      fracoHydromobile: 0,
      grueMobile: 0,
      camionGrue: 0,
      pelleMecanique: 0,
      chargeur: 0,
      tombereau: 0,
      pelleusesPetite: 0,
      rouleauCompacteur: 0,
      pompeBeton: 0,
      fichesInspection: {
        foreuse: false,
        scissorLift: false,
        nacelleInspection: false
      }
    },
    conformiteProtocoles: '',
    portEPI: '',
    etatEquipements: '',
    respectProcedures: '',
    nonConformites: '',
    niveauGravite: '',
    actionsCorrectivesRequises: '',
    delaiCorrection: '',
    echafaudages: '',
    espacesClos: '',
    travailHauteur: '',
    matieresDangereuses: '',
    equipementsCollectifs: '',
    observationsPositives: '',
    observationsNegatives: '',
    risquesIdentifies: '',
    actionsImmediates: '',
    recommandationsAmelioration: '',
    suiviRequis: '',
    formationNecessaire: '',
    travailleursFormes: '',
    supervisionAdequate: '',
    communicationSecurite: '',
    evaluationGlobale: '',
    pointsAmeliorer: '',
    prochaineSuggestion: '',
    signature: '',
    dateSignature: new Date().toISOString()
  };
};

export const FormDataProvider = ({ children }: { children: ReactNode }) => {
  console.log('🚀 FormDataProvider - Initialisation du provider');
  
  const [formData, setFormData] = useState<FormData>(getInitialFormData);

  // Mémorisation des fonctions avec useCallback pour éviter les re-rendus
  const handleInputChange = useCallback((field: string, value: string) => {
    console.log('📝 FormDataProvider - Changement de champ:', field, '=', value);
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  const handleMeteoChange = useCallback((meteoData: Partial<MeteoData>) => {
    console.log('🌤️ FormDataProvider - Changement météo:', meteoData);
    setFormData(prev => ({
      ...prev,
      meteoData: meteoData as MeteoData
    }));
  }, []);

  const handleTravailleursChange = useCallback((total: number, details: SoustraitantPresence[]) => {
    console.log('👷 FormDataProvider - Changement travailleurs:', total, details);
    setFormData(prev => ({
      ...prev,
      nombreTravailleursPresents: total,
      detailsTravailleurs: details
    }));
  }, []);

  const resetForm = useCallback(() => {
    console.log('🔄 FormDataProvider - Réinitialisation du formulaire');
    setFormData(getInitialFormData());
  }, []);

  // Mémorisation du contexte pour éviter les re-rendus inutiles
  const contextValue = useMemo(() => ({
    formData,
    setFormData,
    handleInputChange,
    handleMeteoChange,
    handleTravailleursChange,
    resetForm
  }), [formData, handleInputChange, handleMeteoChange, handleTravailleursChange, resetForm]);

  console.log('🎯 FormDataProvider - Rendu du provider avec contexte mémorisé');

  return (
    <FormDataContext.Provider value={contextValue}>
      {children}
    </FormDataContext.Provider>
  );
};

export const useFormData = () => {
  const context = useContext(FormDataContext);
  if (context === undefined) {
    console.error('❌ useFormData doit être utilisé dans un FormDataProvider');
    throw new Error('useFormData must be used within a FormDataProvider');
  }
  console.log('✅ useFormData - Contexte récupéré avec succès');
  return context;
};
