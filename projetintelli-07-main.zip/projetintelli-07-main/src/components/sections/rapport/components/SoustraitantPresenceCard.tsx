
import React from 'react';
import { Input } from "@/components/ui/input";
import { UserIcon, Loader2 } from "lucide-react";

interface SoustraitantPresence {
  id: string;
  nom: string;
  nombreTravailleurs: number;
  presenceIds?: string[];
}

interface SoustraitantPresenceCardProps {
  presence: SoustraitantPresence;
  onModifierNombre: (id: string, nouveauNombre: number) => void;
  onSupprimer: (id: string) => void;
  isDeleting: boolean;
}

export const SoustraitantPresenceCard = ({ 
  presence, 
  onModifierNombre, 
  onSupprimer, 
  isDeleting 
}: SoustraitantPresenceCardProps) => {
  return (
    <div className="flex items-center justify-between p-3 border rounded-lg bg-white">
      <div className="flex items-center gap-2">
        <UserIcon className="w-4 h-4 text-blue-600" />
        <span className="font-medium">{presence.nom}</span>
      </div>
      <div className="flex items-center gap-2">
        <Input
          type="number"
          min="0"
          value={presence.nombreTravailleurs}
          onChange={(e) => onModifierNombre(presence.id, parseInt(e.target.value) || 0)}
          className="w-20 text-center"
          disabled={isDeleting}
        />
        <span className="text-sm text-gray-500">
          {presence.nombreTravailleurs > 1 ? 'travailleurs' : 'travailleur'}
        </span>
        <button
          onClick={() => onSupprimer(presence.id)}
          disabled={isDeleting}
          className={`
            px-3 py-2 text-sm border rounded-md transition-all duration-200
            ${isDeleting 
              ? 'bg-gray-100 border-gray-300 cursor-not-allowed' 
              : 'bg-white border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300'
            }
          `}
          type="button"
        >
          {isDeleting ? (
            <div className="flex items-center gap-1">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="text-xs">Suppression...</span>
            </div>
          ) : (
            <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M3 6h18M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6m3 0V4c0-1 1-2 2-2h4c0 1 1 2 2 2v2M10 11v6M14 11v6"/>
            </svg>
          )}
        </button>
      </div>
    </div>
  );
};
