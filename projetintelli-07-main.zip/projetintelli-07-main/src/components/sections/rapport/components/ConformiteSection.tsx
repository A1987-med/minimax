
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ShieldIcon } from "lucide-react";

interface ConformiteSectionProps {
  formData: {
    conformiteProtocoles: string;
    portEPI: string;
    etatEquipements: string;
    respectProcedures: string;
  };
  onInputChange: (field: string, value: string) => void;
}

export const ConformiteSection = ({ formData, onInputChange }: ConformiteSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 border-green-200 dark:border-green-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-green-500 to-emerald-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <ShieldIcon className="w-6 h-6" />
          🛡️ Conformité sécuritaire
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-green-200 dark:border-green-700 shadow-sm">
          <Label htmlFor="conformiteProtocoles" className="text-green-800 dark:text-green-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            📋 Conformité aux protocoles de sécurité
          </Label>
          <Textarea
            id="conformiteProtocoles"
            value={formData.conformiteProtocoles}
            onChange={(e) => onInputChange('conformiteProtocoles', e.target.value)}
            placeholder="Évaluation du respect des protocoles..."
            className="border-green-300 dark:border-green-600 focus:border-green-500 dark:focus:border-green-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 min-h-[100px]"
          />
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-blue-200 dark:border-blue-700 shadow-sm">
            <Label htmlFor="portEPI" className="text-blue-800 dark:text-blue-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🦺 Port des EPI par les travailleurs
            </Label>
            <Textarea
              id="portEPI"
              value={formData.portEPI}
              onChange={(e) => onInputChange('portEPI', e.target.value)}
              placeholder="Observations sur le port des EPI..."
              className="border-blue-300 dark:border-blue-600 focus:border-blue-500 dark:focus:border-blue-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 min-h-[100px]"
            />
          </div>
          
          <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-purple-200 dark:border-purple-700 shadow-sm">
            <Label htmlFor="etatEquipements" className="text-purple-800 dark:text-purple-200 font-semibold text-lg mb-3 block flex items-center gap-2">
              🔧 État des équipements de sécurité
            </Label>
            <Textarea
              id="etatEquipements"
              value={formData.etatEquipements}
              onChange={(e) => onInputChange('etatEquipements', e.target.value)}
              placeholder="État des équipements inspectés..."
              className="border-purple-300 dark:border-purple-600 focus:border-purple-500 dark:focus:border-purple-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 min-h-[100px]"
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
