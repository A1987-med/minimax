
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { TruckIcon } from "lucide-react";

interface MachinerieChantiersData {
  chariotElevateur: number;
  plateformeElevatrice: number;
  nacelle: number;
  fracoHydromobile: number;
  grueMobile: number;
  camionGrue: number;
  pelleMecanique: number;
  chargeur: number;
  tombereau: number;
  pelleusesPetite: number;
  rouleauCompacteur: number;
  pompeBeton: number;
  fichesInspection: {
    foreuse: boolean;
    scissorLift: boolean;
    nacelleInspection: boolean;
  };
}

interface MachinerieChantiersectionProps {
  formData: {
    machinerie: MachinerieChantiersData;
  };
  onInputChange: (field: string, value: any) => void;
}

export const MachinerieChantiersSection = ({ formData, onInputChange }: MachinerieChantiersectionProps) => {
  const handleMachinerieChange = (field: string, value: number) => {
    onInputChange('machinerie', {
      ...formData.machinerie,
      [field]: value
    });
  };

  const handleFichesInspectionChange = (field: string, checked: boolean) => {
    onInputChange('machinerie', {
      ...formData.machinerie,
      fichesInspection: {
        ...formData.machinerie.fichesInspection,
        [field]: checked
      }
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TruckIcon className="w-5 h-5" />
          Machinerie au chantier
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="chariot-elevateur">Chariot élévateur</Label>
            <Input
              id="chariot-elevateur"
              type="number"
              min="0"
              value={formData.machinerie.chariotElevateur}
              onChange={(e) => handleMachinerieChange('chariotElevateur', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="plateforme-elevatrice">Plateforme élévatrice</Label>
            <Input
              id="plateforme-elevatrice"
              type="number"
              min="0"
              value={formData.machinerie.plateformeElevatrice}
              onChange={(e) => handleMachinerieChange('plateformeElevatrice', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="nacelle">Nacelle</Label>
            <Input
              id="nacelle"
              type="number"
              min="0"
              value={formData.machinerie.nacelle}
              onChange={(e) => handleMachinerieChange('nacelle', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="fraco-hydromobile">Fraco ou hydromobile</Label>
            <Input
              id="fraco-hydromobile"
              type="number"
              min="0"
              value={formData.machinerie.fracoHydromobile}
              onChange={(e) => handleMachinerieChange('fracoHydromobile', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="grue-mobile">Grue mobile</Label>
            <Input
              id="grue-mobile"
              type="number"
              min="0"
              value={formData.machinerie.grueMobile}
              onChange={(e) => handleMachinerieChange('grueMobile', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="camion-grue">Camion-grue</Label>
            <Input
              id="camion-grue"
              type="number"
              min="0"
              value={formData.machinerie.camionGrue}
              onChange={(e) => handleMachinerieChange('camionGrue', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="pelle-mecanique">Pelle mécanique</Label>
            <Input
              id="pelle-mecanique"
              type="number"
              min="0"
              value={formData.machinerie.pelleMecanique}
              onChange={(e) => handleMachinerieChange('pelleMecanique', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="chargeur">Chargeur</Label>
            <Input
              id="chargeur"
              type="number"
              min="0"
              value={formData.machinerie.chargeur}
              onChange={(e) => handleMachinerieChange('chargeur', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="tombereau">Tombereau</Label>
            <Input
              id="tombereau"
              type="number"
              min="0"
              value={formData.machinerie.tombereau}
              onChange={(e) => handleMachinerieChange('tombereau', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="pelleteuse-petite">Pelleteuse (petite)</Label>
            <Input
              id="pelleteuse-petite"
              type="number"
              min="0"
              value={formData.machinerie.pelleusesPetite}
              onChange={(e) => handleMachinerieChange('pelleusesPetite', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="rouleau-compacteur">Rouleau compacteur (petit)</Label>
            <Input
              id="rouleau-compacteur"
              type="number"
              min="0"
              value={formData.machinerie.rouleauCompacteur}
              onChange={(e) => handleMachinerieChange('rouleauCompacteur', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>

          <div>
            <Label htmlFor="pompe-beton">Pompe à béton</Label>
            <Input
              id="pompe-beton"
              type="number"
              min="0"
              value={formData.machinerie.pompeBeton}
              onChange={(e) => handleMachinerieChange('pompeBeton', parseInt(e.target.value) || 0)}
              className="mt-1"
            />
          </div>
        </div>

        <div className="mt-8">
          <h4 className="font-semibold text-lg mb-4">Reçu fiches d'inspection</h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="foreuse-inspection"
                checked={formData.machinerie.fichesInspection.foreuse}
                onCheckedChange={(checked) => handleFichesInspectionChange('foreuse', !!checked)}
              />
              <Label htmlFor="foreuse-inspection">Foreuse</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="scissor-lift-inspection"
                checked={formData.machinerie.fichesInspection.scissorLift}
                onCheckedChange={(checked) => handleFichesInspectionChange('scissorLift', !!checked)}
              />
              <Label htmlFor="scissor-lift-inspection">Scissor-lift</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="nacelle-inspection"
                checked={formData.machinerie.fichesInspection.nacelleInspection}
                onCheckedChange={(checked) => handleFichesInspectionChange('nacelleInspection', !!checked)}
              />
              <Label htmlFor="nacelle-inspection">Nacelle</Label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
