
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PenToolIcon } from "lucide-react";

interface SignatureSectionProps {
  formData: {
    signature: string;
  };
  onInputChange: (field: string, value: string) => void;
}

export const SignatureSection = ({ formData, onInputChange }: SignatureSectionProps) => {
  return (
    <Card className="bg-gradient-to-br from-slate-50 to-gray-50 dark:from-slate-950/30 dark:to-gray-950/30 border-slate-200 dark:border-slate-800 shadow-xl">
      <CardHeader className="bg-gradient-to-r from-slate-500 to-gray-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <PenToolIcon className="w-6 h-6" />
          ✍️ Signature
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg border border-slate-200 dark:border-slate-700 shadow-sm">
          <Label htmlFor="signature" className="text-slate-800 dark:text-slate-200 font-semibold text-lg mb-3 block flex items-center gap-2">
            📝 Signature électronique du coordonnateur SST
          </Label>
          <Input
            id="signature"
            value={formData.signature}
            onChange={(e) => onInputChange('signature', e.target.value)}
            placeholder="Tapez votre nom complet pour signer"
            className="border-slate-300 dark:border-slate-600 focus:border-slate-500 dark:focus:border-slate-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 text-lg p-4"
          />
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-3 bg-slate-50 dark:bg-slate-800/50 p-3 rounded border border-slate-200 dark:border-slate-700">
            💡 En tapant votre nom, vous certifiez l'exactitude de cette inspection.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
