import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertTriangleIcon, PlusIcon, ImageIcon, Trash2Icon, MapPinIcon, LoaderIcon, MailIcon, X, FileTextIcon, MessageSquareIcon, NavigationIcon } from "lucide-react";
import { soustraitants } from '@/constants/soustraitants';
import { useNativeFeatures } from '@/hooks/useNativeFeatures';
import { notificationService } from '@/services/notificationService';
import { derogationPDFService } from '@/services/derogationPDFService';
import { useToast } from "@/hooks/use-toast";
import { articlesCCSTCPrincipaux, sousArticlesCSSTC, optionsSuivi } from './DerogationsConstants';
import { NavigationWidget } from './NavigationWidget';

interface Position {
  latitude: number;
  longitude: number;
}

interface Derogation {
  id: string;
  numero: string;
  soustraitant: string;
  derogation: string;
  referenceLegale: string;
  suivi: string;
  observations: string;
  echeancier: string;
  position?: Position;
  images: string[];
  photosDerogation: string[];
  photosCorrection: string[];
}

interface DerogationsSectionProps {
  formData: {
    derogations: Derogation[];
  };
  onInputChange: (field: string, value: any) => void;
}

export const DerogationsSection = ({ formData, onInputChange }: DerogationsSectionProps) => {
  const [derogations, setDerogations] = useState<Derogation[]>(
    formData.derogations.length > 0 ? formData.derogations : [{
      id: '1',
      numero: '1',
      soustraitant: '',
      derogation: '',
      referenceLegale: '',
      suivi: '',
      observations: '',
      echeancier: '',
      images: [],
      photosDerogation: [],
      photosCorrection: []
    }]
  );
  const [loadingPosition, setLoadingPosition] = useState<Record<string, boolean>>({});
  const [loadingNotification, setLoadingNotification] = useState<Record<string, boolean>>({});
  const [loadingImages, setLoadingImages] = useState<Record<string, boolean>>({});
  const { getCurrentPosition, selectFromGallery, takePicture } = useNativeFeatures();
  const { toast } = useToast();

  const envoyerNotificationSoustraitant = async (derogationId: string, derogation: Derogation) => {
    if (!derogation.soustraitant || !derogation.derogation || !derogation.observations) {
      toast({
        title: "Informations incomplètes",
        description: "Veuillez remplir tous les champs avant d'envoyer la notification",
        variant: "destructive"
      });
      return;
    }

    setLoadingNotification(prev => ({ ...prev, [derogationId]: true }));

    try {
      const success = await notificationService.envoyerNotificationDerogation({
        soustraitantNom: derogation.soustraitant,
        derogationNumero: derogation.numero,
        derogationType: derogation.derogation,
        referenceLegale: derogation.referenceLegale,
        observations: derogation.observations,
        echeancier: derogation.echeancier,
        dateInspection: new Date().toLocaleDateString('fr-CA')
      });

      if (success) {
        toast({
          title: "Notification envoyée",
          description: `La notification a été envoyée au contremaître de ${derogation.soustraitant}`,
        });
      } else {
        toast({
          title: "Erreur d'envoi",
          description: "Impossible d'envoyer la notification",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi de la notification:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'envoi de la notification",
        variant: "destructive"
      });
    } finally {
      setLoadingNotification(prev => ({ ...prev, [derogationId]: false }));
    }
  };

  const envoyerSMSSoustraitant = async (derogationId: string, derogation: Derogation) => {
    if (!derogation.soustraitant || !derogation.derogation || !derogation.observations) {
      toast({
        title: "Informations incomplètes",
        description: "Veuillez remplir tous les champs avant d'envoyer le SMS",
        variant: "destructive"
      });
      return;
    }

    setLoadingNotification(prev => ({ ...prev, [derogationId]: true }));

    try {
      const success = await notificationService.envoyerSMSDerogation({
        soustraitantNom: derogation.soustraitant,
        derogationNumero: derogation.numero,
        derogationType: derogation.derogation,
        referenceLegale: derogation.referenceLegale,
        observations: derogation.observations,
        echeancier: derogation.echeancier,
        dateInspection: new Date().toLocaleDateString('fr-CA')
      });

      if (success) {
        toast({
          title: "SMS envoyé",
          description: `Le SMS a été envoyé au contremaître de ${derogation.soustraitant}`,
        });
      } else {
        toast({
          title: "Erreur d'envoi SMS",
          description: "Impossible d'envoyer le SMS - vérifiez le numéro de téléphone",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Erreur lors de l\'envoi du SMS:', error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de l'envoi du SMS",
        variant: "destructive"
      });
    } finally {
      setLoadingNotification(prev => ({ ...prev, [derogationId]: false }));
    }
  };

  const exporterPDFDerogations = async () => {
    try {
      await derogationPDFService.exportDerogationsPDF(derogations);
      toast({
        title: "PDF généré",
        description: "Le rapport PDF des dérogations a été téléchargé",
      });
    } catch (error) {
      console.error('Erreur lors de l\'export PDF:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la génération du PDF",
        variant: "destructive"
      });
    }
  };

  const ajouterDerogation = () => {
    if (derogations.length >= 10) return;
    
    const nouvelleDerogation: Derogation = {
      id: Date.now().toString(),
      numero: (derogations.length + 1).toString(),
      soustraitant: '',
      derogation: '',
      referenceLegale: '',
      suivi: '',
      observations: '',
      echeancier: '',
      images: [],
      photosDerogation: [],
      photosCorrection: []
    };
    const nouvellesDerogations = [...derogations, nouvelleDerogation];
    setDerogations(nouvellesDerogations);
    onInputChange('derogations', nouvellesDerogations);
  };

  const supprimerDerogation = (id: string) => {
    if (derogations.length <= 1) return;
    
    const nouvellesDerogations = derogations.filter(d => d.id !== id);
    const derogationsRenumerotees = nouvellesDerogations.map((d, index) => ({
      ...d,
      numero: (index + 1).toString()
    }));
    setDerogations(derogationsRenumerotees);
    onInputChange('derogations', derogationsRenumerotees);
  };

  const mettreAJourDerogation = async (id: string, field: keyof Derogation, value: any) => {
    const nouvellesDerogations = derogations.map(d => 
      d.id === id ? { ...d, [field]: value } : d
    );
    setDerogations(nouvellesDerogations);
    onInputChange('derogations', nouvellesDerogations);

    if (field === 'soustraitant' && value) {
      const derogation = nouvellesDerogations.find(d => d.id === id);
      if (derogation && derogation.derogation && derogation.observations) {
        await envoyerNotificationSoustraitant(id, derogation);
      }
    }
  };

  const gererPrisePhoto = async (id: string, typePhoto: 'derogation' | 'correction') => {
    const fieldName = typePhoto === 'derogation' ? 'photosDerogation' : 'photosCorrection';
    const derogation = derogations.find(d => d.id === id);
    
    if (derogation && derogation[fieldName].length >= 2) {
      toast({
        title: "Limite atteinte",
        description: `Maximum 2 photos de ${typePhoto} autorisées`,
        variant: "destructive"
      });
      return;
    }

    setLoadingImages(prev => ({ ...prev, [`${id}-${typePhoto}`]: true }));
    
    try {
      const photoData = await takePicture();
      if (photoData && derogation) {
        const nouvellesImages = [...derogation[fieldName], photoData];
        await mettreAJourDerogation(id, fieldName, nouvellesImages);
        toast({
          title: "Photo ajoutée",
          description: `Photo de ${typePhoto} capturée avec succès`,
        });
      }
    } catch (error) {
      console.error('Erreur lors de la prise de photo:', error);
      toast({
        title: "Erreur",
        description: "Impossible de prendre une photo",
        variant: "destructive"
      });
    } finally {
      setLoadingImages(prev => ({ ...prev, [`${id}-${typePhoto}`]: false }));
    }
  };

  const gererSelectionGalerie = async (id: string, typePhoto: 'derogation' | 'correction') => {
    const fieldName = typePhoto === 'derogation' ? 'photosDerogation' : 'photosCorrection';
    const derogation = derogations.find(d => d.id === id);
    
    if (derogation && derogation[fieldName].length >= 2) {
      toast({
        title: "Limite atteinte",
        description: `Maximum 2 photos de ${typePhoto} autorisées`,
        variant: "destructive"
      });
      return;
    }

    setLoadingImages(prev => ({ ...prev, [`${id}-${typePhoto}`]: true }));
    
    try {
      const photosData = await selectFromGallery();
      if (photosData && photosData.length > 0 && derogation) {
        const espacesDisponibles = 2 - derogation[fieldName].length;
        const photosAjouter = photosData.slice(0, espacesDisponibles);
        const nouvellesImages = [...derogation[fieldName], ...photosAjouter];
        await mettreAJourDerogation(id, fieldName, nouvellesImages);
        toast({
          title: "Photos ajoutées",
          description: `${photosAjouter.length} photo(s) de ${typePhoto} importée(s)`,
        });
      }
    } catch (error) {
      console.error('Erreur lors de la sélection depuis la galerie:', error);
      toast({
        title: "Erreur",
        description: "Impossible de sélectionner depuis la galerie",
        variant: "destructive"
      });
    } finally {
      setLoadingImages(prev => ({ ...prev, [`${id}-${typePhoto}`]: false }));
    }
  };

  const supprimerPhoto = async (derogationId: string, imageIndex: number, typePhoto: 'derogation' | 'correction') => {
    const fieldName = typePhoto === 'derogation' ? 'photosDerogation' : 'photosCorrection';
    const derogation = derogations.find(d => d.id === derogationId);
    if (derogation) {
      const nouvellesImages = derogation[fieldName].filter((_, index) => index !== imageIndex);
      await mettreAJourDerogation(derogationId, fieldName, nouvellesImages);
    }
  };

  const supprimerImage = async (derogationId: string, imageIndex: number) => {
    const derogation = derogations.find(d => d.id === derogationId);
    if (derogation) {
      const nouvellesImages = derogation.images.filter((_, index) => index !== imageIndex);
      await mettreAJourDerogation(derogationId, 'images', nouvellesImages);
    }
  };

  const obtenirPositionGPS = async (id: string) => {
    setLoadingPosition(prev => ({ ...prev, [id]: true }));
    
    try {
      const position = await getCurrentPosition();
      if (position) {
        // Sauvegarder automatiquement comme position cible
        await mettreAJourDerogation(id, 'position', position);
        toast({
          title: "Position GPS capturée et sauvegardée",
          description: `Position cible définie: Lat: ${position.latitude.toFixed(6)}, Lng: ${position.longitude.toFixed(6)}`,
        });
        console.log('Position GPS obtenue et sauvegardée comme position cible:', position);
      } else {
        toast({
          title: "Erreur GPS",
          description: "Aucune position GPS obtenue",
          variant: "destructive"
        });
        console.log('Aucune position obtenue');
      }
    } catch (error) {
      console.error('Erreur lors de l\'obtention de la position:', error);
      toast({
        title: "Erreur GPS",
        description: "Erreur lors de l'obtention de la position GPS",
        variant: "destructive"
      });
    } finally {
      setLoadingPosition(prev => ({ ...prev, [id]: false }));
    }
  };

  const obtenirSousArticles = (articlePrincipal: string): string[] => {
    return sousArticlesCSSTC[articlePrincipal] || [];
  };

  const obtenirCouleurSuivi = (suivi: string): string => {
    const option = optionsSuivi.find(opt => opt.value === suivi);
    return option ? option.color : '';
  };

  const exporterRapportComplet = async () => {
    try {
      const { rapportInspectionPDFService } = await import('@/services/rapportInspectionPDFService');
      const { projectInfoService } = await import('@/services/projectInfoService');
      
      const projectInfo = projectInfoService.getProjectInfo();
      await rapportInspectionPDFService.exportRapportComplet(formData as any, projectInfo);
      
      toast({
        title: "PDF généré",
        description: "Le rapport complet d'inspection SST a été téléchargé",
      });
    } catch (error) {
      console.error('Erreur lors de l\'export du rapport complet:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la génération du rapport complet",
        variant: "destructive"
      });
    }
  };

  return (
    <Card className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-950/30 dark:to-red-950/30 border-orange-200 dark:border-orange-800 shadow-xl">
      <CardHeader className="flex flex-row items-center justify-between bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-t-lg">
        <CardTitle className="flex items-center gap-3 text-xl font-bold">
          <AlertTriangleIcon className="w-6 h-6" />
          🚨 Dérogations - Rapport d'inspection ({derogations.length}/10)
        </CardTitle>
        <div className="flex gap-2">
          <Button 
            onClick={exporterRapportComplet}
            size="sm" 
            className="flex items-center gap-2 bg-blue-600/80 hover:bg-blue-700/80 text-white border-blue-300/30 backdrop-blur-sm"
          >
            <FileTextIcon className="w-4 h-4" />
            Rapport complet SST
          </Button>
          <Button 
            onClick={exporterPDFDerogations}
            size="sm" 
            className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm"
            disabled={derogations.length === 0}
          >
            <FileTextIcon className="w-4 h-4" />
            Dérogations PDF
          </Button>
          <Button 
            onClick={ajouterDerogation} 
            size="sm" 
            className="flex items-center gap-2 bg-white/20 hover:bg-white/30 text-white border-white/30 backdrop-blur-sm"
            disabled={derogations.length >= 10}
          >
            <PlusIcon className="w-4 h-4" />
            Ajouter
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-6 p-6">
        <div className="overflow-x-auto">
          <Table className="bg-white dark:bg-gray-800 rounded-lg shadow-sm">
            <TableHeader>
              <TableRow className="bg-gradient-to-r from-orange-100 to-red-100 dark:from-orange-900/50 dark:to-red-900/50">
                <TableHead className="w-24 font-bold text-orange-800 dark:text-orange-200">Nº de la Non-Conformité</TableHead>
                <TableHead className="w-48 font-bold text-orange-800 dark:text-orange-200">Sous-traitant en infraction</TableHead>
                <TableHead className="w-32 font-bold text-orange-800 dark:text-orange-200">Dérogation</TableHead>
                <TableHead className="w-32 font-bold text-orange-800 dark:text-orange-200">Référence légale</TableHead>
                <TableHead className="w-32 font-bold text-orange-800 dark:text-orange-200">Suivi</TableHead>
                <TableHead className="w-16 font-bold text-orange-800 dark:text-orange-200">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {derogations.map((derogation) => (
                <React.Fragment key={derogation.id}>
                  <TableRow className="hover:bg-orange-50 dark:hover:bg-orange-950/20 border-b border-orange-200 dark:border-orange-800">
                    <TableCell className="bg-orange-50 dark:bg-orange-950/30">
                      <Input
                        value={derogation.numero}
                        onChange={(e) => mettreAJourDerogation(derogation.id, 'numero', e.target.value)}
                        className="w-full border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Select 
                          value={derogation.soustraitant} 
                          onValueChange={(value) => mettreAJourDerogation(derogation.id, 'soustraitant', value)}
                        >
                          <SelectTrigger className="border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                            <SelectValue placeholder="Sélectionner..." />
                          </SelectTrigger>
                          <SelectContent className="bg-white dark:bg-gray-800 border-orange-300 dark:border-orange-600">
                            {soustraitants.map((soustraitant) => (
                              <SelectItem key={soustraitant} value={soustraitant} className="text-gray-900 dark:text-gray-100 hover:bg-orange-100 dark:hover:bg-orange-900/50">
                                {soustraitant}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {loadingNotification[derogation.id] && (
                          <LoaderIcon className="w-4 h-4 animate-spin text-orange-600 dark:text-orange-400" />
                        )}
                        {derogation.soustraitant && !loadingNotification[derogation.id] && (
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => envoyerNotificationSoustraitant(derogation.id, derogation)}
                              className="flex items-center gap-1 text-xs border-orange-300 dark:border-orange-600 text-orange-700 dark:text-orange-300 hover:bg-orange-100 dark:hover:bg-orange-900/50"
                              disabled={!derogation.derogation || !derogation.observations}
                            >
                              <MailIcon className="w-3 h-3" />
                              Email
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => envoyerSMSSoustraitant(derogation.id, derogation)}
                              className="flex items-center gap-1 text-xs border-blue-300 dark:border-blue-600 text-blue-700 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900/50"
                              disabled={!derogation.derogation || !derogation.observations}
                            >
                              <MessageSquareIcon className="w-3 h-3" />
                              SMS
                            </Button>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Select 
                        value={derogation.derogation} 
                        onValueChange={(value) => {
                          mettreAJourDerogation(derogation.id, 'derogation', value);
                          mettreAJourDerogation(derogation.id, 'referenceLegale', '');
                        }}
                      >
                        <SelectTrigger className="border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                          <SelectValue placeholder="Article CSTC..." />
                        </SelectTrigger>
                        <SelectContent className="bg-white dark:bg-gray-800 border-orange-300 dark:border-orange-600 max-h-60">
                          {articlesCCSTCPrincipaux.map((article) => (
                            <SelectItem key={article} value={article} className="text-gray-900 dark:text-gray-100 hover:bg-orange-100 dark:hover:bg-orange-900/50">
                              {article}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Select 
                        value={derogation.referenceLegale} 
                        onValueChange={(value) => mettreAJourDerogation(derogation.id, 'referenceLegale', value)}
                        disabled={!derogation.derogation}
                      >
                        <SelectTrigger className="border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                          <SelectValue placeholder="Sous-article..." />
                        </SelectTrigger>
                        <SelectContent className="bg-white dark:bg-gray-800 border-orange-300 dark:border-orange-600 max-h-60">
                          {obtenirSousArticles(derogation.derogation).map((sousArticle) => (
                            <SelectItem key={sousArticle} value={sousArticle} className="text-gray-900 dark:text-gray-100 hover:bg-orange-100 dark:hover:bg-orange-900/50">
                              {sousArticle}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Select 
                        value={derogation.suivi} 
                        onValueChange={(value) => mettreAJourDerogation(derogation.id, 'suivi', value)}
                      >
                        <SelectTrigger className={`border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 ${obtenirCouleurSuivi(derogation.suivi)}`}>
                          <SelectValue placeholder="Statut..." />
                        </SelectTrigger>
                        <SelectContent className="bg-white dark:bg-gray-800 border-orange-300 dark:border-orange-600">
                          {optionsSuivi.map((option) => (
                            <SelectItem key={option.value} value={option.value} className="hover:bg-orange-100 dark:hover:bg-orange-900/50">
                              <span className={`px-2 py-1 rounded text-sm font-medium ${option.color}`}>
                                {option.label}
                              </span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => supprimerDerogation(derogation.id)}
                        disabled={derogations.length <= 1}
                        className="text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300 border-red-300 dark:border-red-600 hover:bg-red-50 dark:hover:bg-red-900/50"
                      >
                        <Trash2Icon className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                  
                  <TableRow className="bg-gradient-to-r from-orange-25 to-red-25 dark:from-orange-950/10 dark:to-red-950/10">
                    <TableCell colSpan={6} className="p-6">
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor={`observations-${derogation.id}`} className="text-lg font-semibold text-orange-800 dark:text-orange-200 mb-2 block">
                            📝 Observations détaillées
                          </Label>
                          <Textarea
                            id={`observations-${derogation.id}`}
                            value={derogation.observations}
                            onChange={(e) => mettreAJourDerogation(derogation.id, 'observations', e.target.value)}
                            placeholder="Décrivez précisément la dérogation observée, les risques associés et les mesures correctives nécessaires..."
                            className="min-h-[100px] resize-none border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                            rows={4}
                          />
                        </div>
                        
                        <Tabs defaultValue="echeancier" className="w-full">
                          <TabsList className="grid w-full grid-cols-5 bg-orange-100 dark:bg-orange-900/50 h-auto p-1">
                            <TabsTrigger 
                              value="echeancier" 
                              className="text-orange-800 dark:text-orange-200 data-[state=active]:bg-orange-200 dark:data-[state=active]:bg-orange-800 p-3 text-sm rounded-md"
                            >
                              ⏰ Délai de correction
                            </TabsTrigger>
                            <TabsTrigger 
                              value="position" 
                              className="text-orange-800 dark:text-orange-200 data-[state=active]:bg-orange-200 dark:data-[state=active]:bg-orange-800 p-3 text-sm rounded-md mx-1"
                            >
                              📍 Position/Lieu
                            </TabsTrigger>
                            <TabsTrigger 
                              value="navigation" 
                              className="text-orange-800 dark:text-orange-200 data-[state=active]:bg-orange-200 dark:data-[state=active]:bg-orange-800 p-3 text-sm rounded-md mx-1"
                            >
                              🧭 Navigation GPS
                            </TabsTrigger>
                            <TabsTrigger 
                              value="photos-derogation" 
                              className="text-orange-800 dark:text-orange-200 data-[state=active]:bg-orange-200 dark:data-[state=active]:bg-orange-800 p-3 text-sm rounded-md mx-1"
                            >
                              📸 Photos dérogation
                            </TabsTrigger>
                            <TabsTrigger 
                              value="photos-correction" 
                              className="text-orange-800 dark:text-orange-200 data-[state=active]:bg-orange-200 dark:data-[state=active]:bg-orange-800 p-3 text-sm rounded-md"
                            >
                              ✅ Photos correction
                            </TabsTrigger>
                          </TabsList>
                          
                          <TabsContent value="echeancier" className="space-y-3 mt-4">
                            <Label htmlFor={`echeancier-${derogation.id}`} className="text-base font-medium text-orange-800 dark:text-orange-200">
                              📅 Date limite pour la correction
                            </Label>
                            <Input
                              id={`echeancier-${derogation.id}`}
                              type="date"
                              value={derogation.echeancier}
                              onChange={(e) => mettreAJourDerogation(derogation.id, 'echeancier', e.target.value)}
                              className="w-fit border-orange-300 dark:border-orange-600 focus:border-orange-500 dark:focus:border-orange-400 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
                            />
                          </TabsContent>
                          
                          <TabsContent value="position" className="space-y-4 mt-4">
                            <div className="flex items-center gap-4">
                              <Label className="text-base font-medium text-orange-800 dark:text-orange-200">
                                🗺️ Capturer la position GPS de la dérogation
                              </Label>
                              <Button
                                onClick={() => obtenirPositionGPS(derogation.id)}
                                disabled={loadingPosition[derogation.id]}
                                size="sm"
                                className="flex items-center gap-2 bg-orange-600 hover:bg-orange-700 text-white"
                              >
                                {loadingPosition[derogation.id] ? (
                                  <LoaderIcon className="w-4 h-4 animate-spin" />
                                ) : (
                                  <MapPinIcon className="w-4 h-4" />
                                )}
                                {loadingPosition[derogation.id] ? 'Localisation...' : 'Capturer la position'}
                              </Button>
                            </div>
                            
                            {derogation.position && (
                              <div className="bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30 p-4 rounded-lg border border-green-200 dark:border-green-800">
                                <p className="text-sm font-medium text-green-800 dark:text-green-200 mb-2 flex items-center gap-2">
                                  ✅ Position GPS capturée et sauvegardée comme position cible
                                </p>
                                <p className="font-mono text-sm text-green-700 dark:text-green-300 bg-green-100 dark:bg-green-900/50 p-2 rounded">
                                  📍 Latitude: {derogation.position.latitude.toFixed(6)}<br />
                                  📍 Longitude: {derogation.position.longitude.toFixed(6)}
                                </p>
                                <div className="mt-3 p-3 bg-blue-50 dark:bg-blue-950/30 rounded border border-blue-200 dark:border-blue-800">
                                  <p className="text-xs text-blue-700 dark:text-blue-300">
                                    💡 Cette position est maintenant utilisée comme cible dans l'onglet "Navigation GPS"
                                  </p>
                                </div>
                              </div>
                            )}
                            
                            {!derogation.position && (
                              <div className="text-center p-8 border-2 border-dashed border-orange-300 dark:border-orange-600 rounded-lg bg-orange-50 dark:bg-orange-950/20">
                                <MapPinIcon className="w-12 h-12 mx-auto mb-4 text-orange-400 dark:text-orange-500" />
                                <p className="text-orange-600 dark:text-orange-300 font-medium">Aucune position GPS capturée</p>
                                <p className="text-sm text-orange-500 dark:text-orange-400 mt-1">
                                  Utilisez le bouton "Capturer la position" lorsque vous êtes sur le lieu de la dérogation
                                </p>
                              </div>
                            )}
                          </TabsContent>

                          <TabsContent value="navigation" className="space-y-4 mt-4">
                            <NavigationWidget
                              derogationInfo={{
                                numero: derogation.numero,
                                soustraitant: derogation.soustraitant,
                                description: derogation.observations,
                                position: derogation.position
                              }}
                            />
                          </TabsContent>
                          
                          <TabsContent value="photos-derogation" className="space-y-4 mt-4">
                            <div className="flex items-center gap-4">
                              <Label className="text-base font-medium text-orange-800 dark:text-orange-200">
                                📷 Photos de la dérogation ({derogation.photosDerogation.length}/2)
                              </Label>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => gererPrisePhoto(derogation.id, 'derogation')}
                                  disabled={loadingImages[`${derogation.id}-derogation`] || derogation.photosDerogation.length >= 2}
                                  size="sm"
                                  className="flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white"
                                >
                                  {loadingImages[`${derogation.id}-derogation`] ? (
                                    <LoaderIcon className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <ImageIcon className="w-4 h-4" />
                                  )}
                                  Prendre photo
                                </Button>
                                <Button
                                  onClick={() => gererSelectionGalerie(derogation.id, 'derogation')}
                                  disabled={loadingImages[`${derogation.id}-derogation`] || derogation.photosDerogation.length >= 2}
                                  size="sm"
                                  variant="outline"
                                  className="flex items-center gap-2 border-red-300 dark:border-red-600 text-red-700 dark:text-red-300 hover:bg-red-50 dark:hover:bg-red-900/50"
                                >
                                  {loadingImages[`${derogation.id}-derogation`] ? (
                                    <LoaderIcon className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <ImageIcon className="w-4 h-4" />
                                  )}
                                  Galerie
                                </Button>
                              </div>
                            </div>
                            
                            {derogation.photosDerogation.length > 0 && (
                              <div className="grid grid-cols-2 gap-4">
                                {derogation.photosDerogation.map((image, index) => (
                                  <div key={index} className="relative group">
                                    <img
                                      src={image}
                                      alt={`Photo dérogation ${index + 1}`}
                                      className="w-full h-64 object-cover rounded-lg border-2 border-red-200 dark:border-red-600 shadow-md cursor-pointer hover:scale-105 transition-transform"
                                      onClick={() => window.open(image, '_blank')}
                                    />
                                    <Button
                                      onClick={() => supprimerPhoto(derogation.id, index, 'derogation')}
                                      size="sm"
                                      variant="destructive"
                                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity bg-red-500 hover:bg-red-600"
                                    >
                                      <X className="w-3 h-3" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {derogation.photosDerogation.length === 0 && (
                              <div className="text-center p-8 border-2 border-dashed border-red-300 dark:border-red-600 rounded-lg bg-red-50 dark:bg-red-950/20">
                                <ImageIcon className="w-12 h-12 mx-auto mb-4 text-red-400 dark:text-red-500" />
                                <p className="text-red-600 dark:text-red-300 font-medium">Aucune photo de dérogation ajoutée</p>
                                <p className="text-sm text-red-500 dark:text-red-400 mt-1">Maximum 2 photos - Utilisez les boutons ci-dessus</p>
                              </div>
                            )}
                          </TabsContent>

                          <TabsContent value="photos-correction" className="space-y-4 mt-4">
                            <div className="flex items-center gap-4">
                              <Label className="text-base font-medium text-orange-800 dark:text-orange-200">
                                📷 Photos de correction ({derogation.photosCorrection.length}/2)
                              </Label>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() => gererPrisePhoto(derogation.id, 'correction')}
                                  disabled={loadingImages[`${derogation.id}-correction`] || derogation.photosCorrection.length >= 2}
                                  size="sm"
                                  className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white"
                                >
                                  {loadingImages[`${derogation.id}-correction`] ? (
                                    <LoaderIcon className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <ImageIcon className="w-4 h-4" />
                                  )}
                                  Prendre photo
                                </Button>
                                <Button
                                  onClick={() => gererSelectionGalerie(derogation.id, 'correction')}
                                  disabled={loadingImages[`${derogation.id}-correction`] || derogation.photosCorrection.length >= 2}
                                  size="sm"
                                  variant="outline"
                                  className="flex items-center gap-2 border-green-300 dark:border-green-600 text-green-700 dark:text-green-300 hover:bg-green-50 dark:hover:bg-green-900/50"
                                >
                                  {loadingImages[`${derogation.id}-correction`] ? (
                                    <LoaderIcon className="w-4 h-4 animate-spin" />
                                  ) : (
                                    <ImageIcon className="w-4 h-4" />
                                  )}
                                  Galerie
                                </Button>
                              </div>
                            </div>
                            
                            {derogation.photosCorrection.length > 0 && (
                              <div className="grid grid-cols-2 gap-4">
                                {derogation.photosCorrection.map((image, index) => (
                                  <div key={index} className="relative group">
                                    <img
                                      src={image}
                                      alt={`Photo correction ${index + 1}`}
                                      className="w-full h-64 object-cover rounded-lg border-2 border-green-200 dark:border-green-600 shadow-md cursor-pointer hover:scale-105 transition-transform"
                                      onClick={() => window.open(image, '_blank')}
                                    />
                                    <Button
                                      onClick={() => supprimerPhoto(derogation.id, index, 'correction')}
                                      size="sm"
                                      variant="destructive"
                                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 opacity-0 group-hover:opacity-100 transition-opacity bg-red-500 hover:bg-red-600"
                                    >
                                      <X className="w-3 h-3" />
                                    </Button>
                                  </div>
                                ))}
                              </div>
                            )}
                            
                            {derogation.photosCorrection.length === 0 && (
                              <div className="text-center p-8 border-2 border-dashed border-green-300 dark:border-green-600 rounded-lg bg-green-50 dark:bg-green-950/20">
                                <ImageIcon className="w-12 h-12 mx-auto mb-4 text-green-400 dark:text-green-500" />
                                <p className="text-green-600 dark:text-green-300 font-medium">Aucune photo de correction ajoutée</p>
                                <p className="text-sm text-green-500 dark:text-green-400 mt-1">Maximum 2 photos - Utilisez les boutons ci-dessus</p>
                              </div>
                            )}
                          </TabsContent>
                        </Tabs>
                      </div>
                    </TableCell>
                  </TableRow>
                </React.Fragment>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
};
