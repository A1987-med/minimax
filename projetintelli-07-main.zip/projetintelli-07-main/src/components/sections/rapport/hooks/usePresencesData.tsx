
import { useState, useEffect } from 'react';
import { presencesService, SoustraitantPresence } from '@/services/presencesService';
import { toast } from "sonner";

export const usePresencesData = (onTotalChange: (total: number, details: SoustraitantPresence[]) => void) => {
  const [presences, setPresences] = useState<SoustraitantPresence[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [deletingIds, setDeletingIds] = useState<Set<string>>(new Set());
  const [debugInfo, setDebugInfo] = useState<string>('Initialisation...');

  const loadPresencesFromSupabase = async () => {
    console.log('🔍 [WIDGET] Début du chargement des présences depuis Supabase...');
    setIsLoading(true);
    
    try {
      const today = new Date().toISOString().split('T')[0];
      console.log('📅 [WIDGET] Date d\'aujourd\'hui:', today);
      
      const groupedPresences = await presencesService.getPresencesGroupedBySoustraitant(today);
      console.log('📊 [WIDGET] Présences groupées récupérées:', groupedPresences);
      
      setDebugInfo(`${groupedPresences.length} sous-traitants avec présences pour ${today}`);
      setPresences(groupedPresences);
      
      const total = groupedPresences.reduce((sum, p) => sum + p.nombreTravailleurs, 0);
      console.log('📊 [WIDGET] Total calculé:', total);
      
      onTotalChange(total, groupedPresences);
      
    } catch (error) {
      console.error('❌ [WIDGET] Erreur lors du chargement depuis Supabase:', error);
      setPresences([]);
      onTotalChange(0, []);
      setDebugInfo(`Erreur: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
      toast.error('Erreur lors du chargement des présences');
    } finally {
      setIsLoading(false);
    }
  };

  const modifierNombre = (id: string, nouveauNombre: number) => {
    const nouvelleListe = presences.map(p => 
      p.id === id ? { ...p, nombreTravailleurs: nouveauNombre } : p
    );
    setPresences(nouvelleListe);
    
    const total = nouvelleListe.reduce((sum: number, p: SoustraitantPresence) => sum + p.nombreTravailleurs, 0);
    onTotalChange(total, nouvelleListe);
  };

  const supprimerPresence = async (id: string) => {
    setDeletingIds(prev => new Set([...prev, id]));
    
    try {
      console.log('🗑️ [WIDGET] Suppression de la présence:', id);
      
      const soustraitantASupprimer = presences.find(p => p.id === id);
      if (!soustraitantASupprimer) {
        toast.error('Sous-traitant non trouvé');
        return;
      }

      const today = new Date().toISOString().split('T')[0];
      await presencesService.deleteSoustraitantPresences(soustraitantASupprimer.nom, today);

      const nouvelleListe = presences.filter(p => p.id !== id);
      setPresences(nouvelleListe);
      
      const total = nouvelleListe.reduce((sum: number, p: SoustraitantPresence) => sum + p.nombreTravailleurs, 0);
      onTotalChange(total, nouvelleListe);
      
      toast.success(`Présences de ${soustraitantASupprimer.nom} supprimées avec succès`);
      
      window.dispatchEvent(new CustomEvent('presences-updated'));
      
    } catch (error) {
      console.error('❌ [WIDGET] Erreur lors de la suppression:', error);
      toast.error('Erreur lors de la suppression de la présence');
    } finally {
      setDeletingIds(prev => {
        const newSet = new Set(prev);
        newSet.delete(id);
        return newSet;
      });
    }
  };

  useEffect(() => {
    console.log('🚀 [WIDGET] useEffect - Montage du composant');
    loadPresencesFromSupabase();
    
    const handlePresencesUpdate = () => {
      console.log('🔄 [WIDGET] Événement presences-updated détecté');
      setTimeout(loadPresencesFromSupabase, 100);
    };
    
    window.addEventListener('presences-updated', handlePresencesUpdate);
    
    const interval = setInterval(() => {
      console.log('⏰ [WIDGET] Actualisation automatique');
      loadPresencesFromSupabase();
    }, 30000);
    
    return () => {
      console.log('🧹 [WIDGET] Nettoyage des événements');
      window.removeEventListener('presences-updated', handlePresencesUpdate);
      clearInterval(interval);
    };
  }, [onTotalChange]);

  return {
    presences,
    isLoading,
    deletingIds,
    debugInfo,
    modifierNombre,
    supprimerPresence
  };
};
