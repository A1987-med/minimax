
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, Users, Save, Plus, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { presencesService } from '../../../services/presencesService';
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { entryService } from '@/services/supabaseService';

interface PresenceEntry {
  id: string;
  sous_traitant: string;
  nombre_travailleurs: number;
}

export const SaisiePresenceForm = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [presences, setPresences] = useState<PresenceEntry[]>([]);
  const [newPresence, setNewPresence] = useState<Omit<PresenceEntry, 'id'>>({
    sous_traitant: '',
    nombre_travailleurs: 0
  });
  const [isLoading, setIsLoading] = useState(false);
  const [soustraitantSuggestions, setSoustraitantSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Récupérer le paramètre soustraitant de l'URL au chargement
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const soustraitantFromUrl = urlParams.get('soustraitant');
    
    if (soustraitantFromUrl) {
      console.log('Sous-traitant détecté dans URL:', soustraitantFromUrl);
      setNewPresence(prev => ({
        ...prev,
        sous_traitant: decodeURIComponent(soustraitantFromUrl)
      }));
      
      // Afficher un message pour confirmer le pré-remplissage
      toast({
        title: "Sous-traitant pré-sélectionné",
        description: `${decodeURIComponent(soustraitantFromUrl)} a été automatiquement sélectionné`,
      });
    }
  }, [toast]);

  // Charger les sous-traitants existants pour l'auto-complétion
  const { data: entries = [] } = useQuery({
    queryKey: ['entries_accueil'],
    queryFn: () => entryService.getAll(),
  });

  // Extraire les sous-traitants uniques
  useEffect(() => {
    const uniqueSoustraitants = [...new Set(entries.map(entry => entry.soustraitant || entry.entreprise).filter(Boolean))];
    setSoustraitantSuggestions(uniqueSoustraitants);
  }, [entries]);

  // Charger les présences pour la date sélectionnée
  const { data: presencesData = [] } = useQuery({
    queryKey: ['presences', date],
    queryFn: () => presencesService.getPresencesByDate(date),
  });

  const handleSoustraitantChange = (value: string) => {
    setNewPresence({ ...newPresence, sous_traitant: value });
    setShowSuggestions(value.length > 0);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setNewPresence({ ...newPresence, sous_traitant: suggestion });
    setShowSuggestions(false);
  };

  const handleAddPresence = () => {
    if (!newPresence.sous_traitant || newPresence.nombre_travailleurs <= 0) {
      toast({
        title: "Erreur",
        description: "Veuillez remplir tous les champs correctement",
        variant: "destructive",
      });
      return;
    }

    const presence: PresenceEntry = {
      id: Date.now().toString(),
      ...newPresence
    };

    setPresences([...presences, presence]);
    setNewPresence({
      sous_traitant: '',
      nombre_travailleurs: 0
    });
    setShowSuggestions(false);
  };

  const handleSavePresences = async () => {
    if (presences.length === 0) {
      toast({
        title: "Erreur",
        description: "Aucune présence à sauvegarder",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    try {
      const presencesToSave = presences.map(presence => ({
        date: date,
        sous_traitant: presence.sous_traitant,
        nombre_travailleurs: presence.nombre_travailleurs,
        heure_saisie: new Date().toLocaleTimeString()
      }));

      await presencesService.savePresences(presencesToSave);
      toast({
        title: "Succès",
        description: "Présences sauvegardées avec succès",
      });
      queryClient.invalidateQueries({ queryKey: ['presences', date] });
      setPresences([]);
    } catch (error) {
      console.error('Erreur lors de la sauvegarde:', error);
      toast({
        title: "Erreur",
        description: "Erreur lors de la sauvegarde des présences",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRemovePresence = (id: string) => {
    setPresences(presences.filter(presence => presence.id !== id));
  };

  // Filtrer les suggestions basées sur la saisie
  const filteredSuggestions = soustraitantSuggestions.filter(s => 
    s.toLowerCase().includes(newPresence.sous_traitant.toLowerCase())
  );

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Saisie des Présences Journalières
          <Badge variant="outline" className="ml-auto">
            {presencesData.length} saisies existantes
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <Label htmlFor="date">Date</Label>
            <div className="relative">
              <Input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
              <Calendar className="absolute top-2 right-2 w-4 h-4 text-gray-500" />
            </div>
          </div>
        </div>

        <div className="border-t pt-4">
          <h3 className="text-lg font-semibold mb-4">Ajouter une Présence</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2 relative">
              <Label htmlFor="sous_traitant">Sous-traitant</Label>
              <Input
                type="text"
                id="sous_traitant"
                placeholder="Nom du sous-traitant"
                value={newPresence.sous_traitant}
                onChange={(e) => handleSoustraitantChange(e.target.value)}
                onFocus={() => setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
              />
              {showSuggestions && filteredSuggestions.length > 0 && (
                <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-60 overflow-auto">
                  {filteredSuggestions.map((suggestion, index) => (
                    <div
                      key={index}
                      className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                      onClick={() => handleSuggestionClick(suggestion)}
                    >
                      {suggestion}
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div>
              <Label htmlFor="nombre_travailleurs">Nombre de travailleurs</Label>
              <Input
                type="number"
                id="nombre_travailleurs"
                min="1"
                placeholder="0"
                value={newPresence.nombre_travailleurs || ''}
                onChange={(e) => setNewPresence({ ...newPresence, nombre_travailleurs: parseInt(e.target.value) || 0 })}
              />
            </div>
          </div>
          <Button 
            onClick={handleAddPresence} 
            className="mt-4 w-full md:w-auto"
            disabled={!newPresence.sous_traitant || newPresence.nombre_travailleurs <= 0}
          >
            <Plus className="w-4 h-4 mr-2" />
            Ajouter à la liste
          </Button>
        </div>

        {presences.length > 0 && (
          <div className="border-t pt-4">
            <h3 className="text-lg font-semibold mb-4">Présences à Sauvegarder ({presences.length})</h3>
            <div className="space-y-2">
              {presences.map(presence => (
                <div key={presence.id} className="flex items-center justify-between p-3 border rounded-lg bg-gray-50">
                  <div className="flex-1">
                    <div className="font-medium">{presence.sous_traitant}</div>
                    <div className="text-sm text-gray-600">
                      {presence.nombre_travailleurs} travailleur{presence.nombre_travailleurs > 1 ? 's' : ''}
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => handleRemovePresence(presence.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="border-t pt-4">
          <Button
            onClick={handleSavePresences}
            disabled={isLoading || presences.length === 0}
            className="w-full"
            size="lg"
          >
            {isLoading ? (
              <>
                <Clock className="w-4 h-4 mr-2 animate-spin" />
                Sauvegarde en cours...
              </>
            ) : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Sauvegarder {presences.length} présence{presences.length > 1 ? 's' : ''}
              </>
            )}
          </Button>
        </div>

        {presencesData.length > 0 && (
          <div className="border-t pt-4">
            <h3 className="text-lg font-semibold mb-4">Présences déjà enregistrées pour {date}</h3>
            <div className="space-y-2">
              {presencesData.map(presence => (
                <div key={presence.id} className="flex items-center justify-between p-3 border rounded-lg bg-green-50">
                  <div className="flex-1">
                    <div className="font-medium">{presence.sous_traitant}</div>
                    <div className="text-sm text-gray-600">
                      {presence.nombre_travailleurs} travailleur{presence.nombre_travailleurs > 1 ? 's' : ''} • 
                      Saisi à {presence.heure_saisie}
                    </div>
                  </div>
                  <Badge variant="secondary">Enregistré</Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
