import React, { useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { ShieldIcon } from "lucide-react";
import { MeteoWidget } from './MeteoWidget';
import { SoustraitantsWidget } from './SoustraitantsWidget';
import { MeteoChart } from './MeteoChart';
import { projectInfoService } from '@/services/projectInfoService';
import { ProjectInfoSection } from './components/ProjectInfoSection';
import { InspectionInfoSection } from './components/InspectionInfoSection';
import { InformationsGeneralesSection } from './components/InformationsGeneralesSection';
import { MachinerieChantiersSection } from './components/MachinerieChantiersSection';
import { ConformiteSection } from './components/ConformiteSection';
import { NonConformitesSection } from './components/NonConformitesSection';
import { DerogationsSection } from './components/DerogationsSection';
import { InspectionsSpecifiquesSection } from './components/InspectionsSpecifiquesSection';
import { ActionsRecommandationsSection } from './components/ActionsRecommandationsSection';
import { EvaluationGlobaleSection } from './components/EvaluationGlobaleSection';
import { SignatureSection } from './components/SignatureSection';
import { FormDataProvider, useFormData } from './components/FormDataProvider';
import { FormActions } from './components/FormActions';

interface RapportJournalierFormProps {
  onSubmit?: (data: any) => void;
  onBack?: () => void;
}

const RapportJournalierFormContent = ({ onSubmit, onBack }: RapportJournalierFormProps) => {
  const { formData, handleInputChange, handleMeteoChange, handleTravailleursChange } = useFormData();
  const [projectInfo, setProjectInfo] = React.useState({ nomProjet: '', numeroProjet: '', adresseProjet: '' });

  const niveauGraviteOptions = [
    'Critique - Arrêt immédiat requis',
    'Majeur - Correction dans 24h',
    'Mineur - Correction dans la semaine'
  ];

  const evaluationOptions = [
    'Excellent - Aucun problème majeur',
    'Satisfaisant - Quelques améliorations mineures',
    'Acceptable - Corrections nécessaires',
    'Insatisfaisant - Actions immédiates requises'
  ];

  useEffect(() => {
    // Charger les informations du projet
    const info = projectInfoService.getProjectInfo();
    setProjectInfo(info);
  }, []);

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <ShieldIcon className="w-8 h-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-800">Rapport d'Inspection SST</h1>
          </div>
          {onBack && (
            <Button onClick={onBack} variant="outline">
              Retour
            </Button>
          )}
        </div>

        <ProjectInfoSection projectInfo={projectInfo} />

        <form className="space-y-6">
          <InspectionInfoSection formData={formData} onInputChange={handleInputChange} />

          <SoustraitantsWidget onTotalChange={handleTravailleursChange} />

          <MeteoWidget date={formData.date} onMeteoChange={handleMeteoChange} />

          <MeteoChart />

          <InformationsGeneralesSection formData={formData} onInputChange={handleInputChange} />

          <MachinerieChantiersSection formData={formData} onInputChange={handleInputChange} />

          <ConformiteSection formData={formData} onInputChange={handleInputChange} />

          <NonConformitesSection 
            formData={formData} 
            onInputChange={handleInputChange}
            niveauGraviteOptions={niveauGraviteOptions}
          />

          <DerogationsSection formData={formData} onInputChange={handleInputChange} />

          <InspectionsSpecifiquesSection formData={formData} onInputChange={handleInputChange} />

          <ActionsRecommandationsSection formData={formData} onInputChange={handleInputChange} />

          <EvaluationGlobaleSection 
            formData={formData} 
            onInputChange={handleInputChange}
            evaluationOptions={evaluationOptions}
          />

          <SignatureSection formData={formData} onInputChange={handleInputChange} />

          <FormActions onSubmit={onSubmit} />
        </form>
      </div>
    </div>
  );
};

export const RapportJournalierForm = (props: RapportJournalierFormProps) => {
  return (
    <FormDataProvider>
      <RapportJournalierFormContent {...props} />
    </FormDataProvider>
  );
};
