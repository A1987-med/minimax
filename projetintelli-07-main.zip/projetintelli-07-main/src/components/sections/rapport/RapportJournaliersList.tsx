
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ShieldIcon, SearchIcon, DownloadIcon, EyeIcon, CalendarIcon, UserIcon, AlertTriangleIcon } from "lucide-react";

interface RapportInspection {
  id: string;
  date: string;
  nomCoordonnateur: string;
  zoneInspectee: string;
  evaluationGlobale: string;
  niveauGravite: string;
  nonConformites: string;
  signature: string;
  dateCreation: string;
  type: string;
}

interface RapportJournaliersListProps {
  onViewReport?: (rapport: RapportInspection) => void;
  onNewReport?: () => void;
}

export const RapportJournaliersList = ({ onViewReport, onNewReport }: RapportJournaliersListProps) => {
  const [rapports, setRapports] = useState<RapportInspection[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredRapports, setFilteredRapports] = useState<RapportInspection[]>([]);

  useEffect(() => {
    // Charger les rapports depuis le localStorage
    const savedRapports = localStorage.getItem('rapports_journaliers');
    if (savedRapports) {
      const parsedRapports = JSON.parse(savedRapports);
      setRapports(parsedRapports);
      setFilteredRapports(parsedRapports);
    }
  }, []);

  useEffect(() => {
    // Filtrer les rapports en fonction du terme de recherche
    const filtered = rapports.filter(rapport => 
      rapport.nomCoordonnateur?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rapport.zoneInspectee?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rapport.evaluationGlobale?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rapport.date?.includes(searchTerm)
    );
    setFilteredRapports(filtered);
  }, [searchTerm, rapports]);

  const exportToCSV = () => {
    if (filteredRapports.length === 0) return;

    const headers = [
      'Date',
      'Coordonnateur SST',
      'Zone inspectée',
      'Évaluation globale',
      'Niveau de gravité',
      'Non-conformités',
      'Signé'
    ];

    const csvContent = [
      headers.join(','),
      ...filteredRapports.map(rapport => [
        rapport.date,
        `"${rapport.nomCoordonnateur || ''}"`,
        `"${rapport.zoneInspectee || ''}"`,
        `"${rapport.evaluationGlobale || ''}"`,
        `"${rapport.niveauGravite || ''}"`,
        `"${(rapport.nonConformites || '').substring(0, 100)}..."`,
        rapport.signature ? 'Oui' : 'Non'
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `inspections_sst_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('fr-FR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const getGraviteBadgeColor = (gravite: string) => {
    if (gravite?.includes('Critique')) return 'destructive';
    if (gravite?.includes('Majeur')) return 'default';
    if (gravite?.includes('Mineur')) return 'secondary';
    return 'outline';
  };

  const getEvaluationBadgeColor = (evaluation: string) => {
    if (evaluation?.includes('Excellent')) return 'default';
    if (evaluation?.includes('Satisfaisant')) return 'secondary';
    if (evaluation?.includes('Acceptable')) return 'outline';
    if (evaluation?.includes('Insatisfaisant')) return 'destructive';
    return 'outline';
  };

  return (
    <div className="space-y-6">
      {/* En-tête avec recherche et actions */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <ShieldIcon className="w-8 h-8 text-blue-600" />
          <div>
            <h2 className="text-2xl font-bold text-gray-800">Rapports d'Inspection SST</h2>
            <p className="text-gray-600">{filteredRapports.length} inspection(s) trouvée(s)</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          {onNewReport && (
            <Button onClick={onNewReport} className="flex items-center gap-2">
              <ShieldIcon className="w-4 h-4" />
              Nouvelle inspection
            </Button>
          )}
          <Button 
            onClick={exportToCSV} 
            variant="outline"
            disabled={filteredRapports.length === 0}
            className="flex items-center gap-2"
          >
            <DownloadIcon className="w-4 h-4" />
            Exporter CSV
          </Button>
        </div>
      </div>

      {/* Barre de recherche */}
      <div className="relative">
        <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
        <Input
          placeholder="Rechercher par coordonnateur, zone, évaluation ou date..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Liste des rapports */}
      {filteredRapports.length === 0 ? (
        <Card>
          <CardContent className="text-center py-12">
            <ShieldIcon className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-600 mb-2">
              {searchTerm ? 'Aucune inspection trouvée' : 'Aucun rapport d\'inspection SST'}
            </h3>
            <p className="text-gray-500 mb-4">
              {searchTerm 
                ? 'Essayez de modifier vos critères de recherche'
                : 'Commencez par créer votre premier rapport d\'inspection'
              }
            </p>
            {onNewReport && !searchTerm && (
              <Button onClick={onNewReport} className="flex items-center gap-2 mx-auto">
                <ShieldIcon className="w-4 h-4" />
                Créer une inspection
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredRapports.map((rapport) => (
            <Card key={rapport.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row justify-between items-start gap-4">
                  <div className="flex-1 space-y-2">
                    {/* En-tête du rapport */}
                    <div className="flex items-center gap-4 flex-wrap">
                      <div className="flex items-center gap-2">
                        <CalendarIcon className="w-4 h-4 text-blue-500" />
                        <span className="font-semibold text-lg">{formatDate(rapport.date)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <UserIcon className="w-4 h-4 text-green-500" />
                        <span className="font-medium">{rapport.nomCoordonnateur}</span>
                      </div>
                      <Badge variant="secondary">{rapport.zoneInspectee}</Badge>
                    </div>

                    {/* Évaluation et gravité */}
                    <div className="flex items-center gap-4 flex-wrap">
                      {rapport.evaluationGlobale && (
                        <Badge variant={getEvaluationBadgeColor(rapport.evaluationGlobale)}>
                          {rapport.evaluationGlobale.split(' - ')[0]}
                        </Badge>
                      )}
                      {rapport.niveauGravite && (
                        <div className="flex items-center gap-2">
                          <AlertTriangleIcon className="w-4 h-4 text-orange-500" />
                          <Badge variant={getGraviteBadgeColor(rapport.niveauGravite)}>
                            {rapport.niveauGravite.split(' - ')[0]}
                          </Badge>
                        </div>
                      )}
                    </div>

                    {/* Détails du rapport */}
                    {rapport.nonConformites && (
                      <div className="text-gray-600">
                        <p className="line-clamp-2">{rapport.nonConformites}</p>
                      </div>
                    )}

                    {/* Métadonnées */}
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      {rapport.signature && (
                        <Badge variant="default" className="bg-green-100 text-green-800">
                          Signé
                        </Badge>
                      )}
                      <span>Créé le {formatDate(rapport.dateCreation)}</span>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-2">
                    {onViewReport && (
                      <Button
                        onClick={() => onViewReport(rapport)}
                        variant="outline"
                        size="sm"
                        className="flex items-center gap-2"
                      >
                        <EyeIcon className="w-4 h-4" />
                        Voir
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};
