
import React, { useState, useEffect, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KeyIcon, EyeIcon, EyeOffIcon, ExternalLinkIcon, CheckIcon, XIcon } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { setWeatherApiKey, getWeatherApiKey, removeWeatherApiKey, testApiKey } from '@/services/meteoService';

export const ApiKeyConfig = () => {
  const [apiKey, setApiKeyState] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [hasKey, setHasKey] = useState(false);
  const [isTestingKey, setIsTestingKey] = useState(false);
  const [keyStatus, setKeyStatus] = useState<'valid' | 'invalid' | 'unknown'>('unknown');
  const { toast } = useToast();

  // Fonction pour charger et synchroniser l'état avec le localStorage
  const loadAndSyncApiKey = useCallback(() => {
    console.log('🔄 ApiKeyConfig - Synchronisation avec localStorage');
    const existingKey = getWeatherApiKey();
    
    if (existingKey) {
      console.log('✅ ApiKeyConfig - Clé API trouvée dans localStorage');
      setHasKey(true);
      setApiKeyState(existingKey);
      // On garde le statut précédent si on en a un, sinon 'unknown'
      if (keyStatus === 'unknown') {
        setKeyStatus('valid'); // Assume qu'une clé stockée est valide
      }
    } else {
      console.log('❌ ApiKeyConfig - Aucune clé API dans localStorage');
      setHasKey(false);
      setApiKeyState('');
      setKeyStatus('unknown');
    }
  }, [keyStatus]);

  // Charger la clé API au montage du composant
  useEffect(() => {
    console.log('🚀 ApiKeyConfig - Initialisation du composant');
    loadAndSyncApiKey();
  }, []);

  // Écouter les changements dans le localStorage (même onglet et autres onglets)
  useEffect(() => {
    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'weatherapi_key') {
        console.log('🔑 ApiKeyConfig - Changement de clé API détecté via storage event');
        loadAndSyncApiKey();
      }
    };

    // Écouter les changements d'autres onglets
    window.addEventListener('storage', handleStorageChange);
    
    // Vérifier périodiquement les changements dans le même onglet
    const interval = setInterval(() => {
      const currentKey = getWeatherApiKey();
      const storedKeyChanged = (currentKey !== null) !== hasKey || 
                              (currentKey && currentKey !== apiKey);
      
      if (storedKeyChanged) {
        console.log('🔄 ApiKeyConfig - Changement détecté via polling');
        loadAndSyncApiKey();
      }
    }, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      clearInterval(interval);
    };
  }, [hasKey, apiKey, loadAndSyncApiKey]);

  const handleTestKey = async (keyToTest: string) => {
    if (!keyToTest.trim()) return;
    
    setIsTestingKey(true);
    console.log('🔍 Test de la clé API en cours...');
    
    try {
      const result = await testApiKey(keyToTest);
      
      if (result.success) {
        setKeyStatus('valid');
        toast({
          title: "✅ Clé API valide",
          description: "La clé API fonctionne correctement avec WeatherAPI",
        });
      } else {
        setKeyStatus('invalid');
        toast({
          title: "❌ Clé API invalide",
          description: result.error || "La clé API ne fonctionne pas",
          variant: "destructive"
        });
      }
    } catch (error) {
      setKeyStatus('invalid');
      toast({
        title: "❌ Erreur de test",
        description: "Impossible de tester la clé API",
        variant: "destructive"
      });
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleSaveKey = async () => {
    if (!apiKey.trim()) {
      toast({
        title: "Erreur",
        description: "Veuillez entrer une clé API valide",
        variant: "destructive"
      });
      return;
    }

    console.log('💾 Sauvegarde de la clé API...');
    
    // Tester la clé avant de la sauvegarder
    setIsTestingKey(true);
    try {
      const result = await testApiKey(apiKey.trim());
      
      if (result.success) {
        setWeatherApiKey(apiKey.trim());
        setHasKey(true);
        setKeyStatus('valid');
        toast({
          title: "✅ Clé API configurée",
          description: "La clé API WeatherAPI a été configurée avec succès",
        });
      } else {
        setKeyStatus('invalid');
        toast({
          title: "❌ Test échoué",
          description: result.error || "La clé API ne fonctionne pas",
          variant: "destructive"
        });
      }
    } catch (error) {
      setKeyStatus('invalid');
      toast({
        title: "❌ Erreur",
        description: "Impossible de tester la clé API",
        variant: "destructive"
      });
    } finally {
      setIsTestingKey(false);
    }
  };

  const handleRemoveKey = () => {
    removeWeatherApiKey();
    setHasKey(false);
    setApiKeyState('');
    setKeyStatus('unknown');
    toast({
      title: "🗑️ Clé API supprimée",
      description: "La clé API a été supprimée. Les données météo simulées seront utilisées.",
    });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setApiKeyState(e.target.value);
    // Ne pas réinitialiser le statut si on a juste chargé une clé existante
    if (e.target.value !== getWeatherApiKey()) {
      setKeyStatus('unknown');
    }
  };

  const handleToggleVisibility = () => {
    setShowKey(!showKey);
  };

  const getStatusIcon = () => {
    if (isTestingKey) return null;
    
    switch (keyStatus) {
      case 'valid':
        return <CheckIcon className="w-4 h-4 text-green-600" />;
      case 'invalid':
        return <XIcon className="w-4 h-4 text-red-600" />;
      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <KeyIcon className="w-5 h-5" />
          Configuration API Météo
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-gray-600 space-y-2">
          <p>
            Pour obtenir des données météo réelles, configurez votre clé API WeatherAPI.com gratuite.
          </p>
          <div className="flex items-center gap-2">
            <span>Obtenez votre clé API gratuite sur:</span>
            <a 
              href="https://www.weatherapi.com/signup.aspx" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-600 hover:text-blue-800 flex items-center gap-1"
            >
              WeatherAPI.com
              <ExternalLinkIcon className="w-3 h-3" />
            </a>
          </div>
          <p className="text-xs text-green-600">
            ✅ 1 million d'appels gratuits par mois - Aucune carte de crédit requise
          </p>
        </div>

        {hasKey ? (
          <div className="space-y-3">
            <div className={`p-3 rounded-lg ${keyStatus === 'valid' ? 'bg-green-50' : keyStatus === 'invalid' ? 'bg-red-50' : 'bg-yellow-50'}`}>
              <p className={`text-sm font-medium ${keyStatus === 'valid' ? 'text-green-800' : keyStatus === 'invalid' ? 'text-red-800' : 'text-yellow-800'}`}>
                {keyStatus === 'valid' && '✅ Clé API configurée et validée - Données météo réelles activées'}
                {keyStatus === 'invalid' && '❌ Clé API configurée mais invalide - Données simulées utilisées'}
                {keyStatus === 'unknown' && '⚠️ Clé API configurée - Statut non vérifié'}
              </p>
            </div>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Input
                  type={showKey ? "text" : "password"}
                  value={apiKey}
                  onChange={handleInputChange}
                  placeholder="Votre clé API WeatherAPI"
                />
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center gap-1">
                  {getStatusIcon()}
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleToggleVisibility}
                  >
                    {showKey ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <Button 
                onClick={() => handleTestKey(apiKey)} 
                disabled={isTestingKey || !apiKey.trim()}
                variant="outline"
              >
                {isTestingKey ? 'Test...' : 'Tester'}
              </Button>
              <Button 
                onClick={handleSaveKey} 
                variant="outline"
                disabled={isTestingKey}
              >
                Mettre à jour
              </Button>
              <Button 
                onClick={handleRemoveKey} 
                variant="destructive"
                disabled={isTestingKey}
              >
                Supprimer
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-3">
            <Label htmlFor="apiKey">Clé API WeatherAPI</Label>
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Input
                  id="apiKey"
                  type={showKey ? "text" : "password"}
                  value={apiKey}
                  onChange={handleInputChange}
                  placeholder="Entrez votre clé API WeatherAPI (32 caractères)"
                />
                <div className="absolute right-2 top-1/2 transform -translate-y-1/2 flex items-center gap-1">
                  {getStatusIcon()}
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleToggleVisibility}
                  >
                    {showKey ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
              <Button 
                type="button"
                onClick={() => handleTestKey(apiKey)} 
                disabled={isTestingKey || !apiKey.trim()}
                variant="outline"
              >
                {isTestingKey ? 'Test...' : 'Tester'}
              </Button>
              <Button 
                onClick={handleSaveKey}
                disabled={isTestingKey || !apiKey.trim()}
              >
                {isTestingKey ? 'Configuration...' : 'Configurer'}
              </Button>
            </div>
            <div className="p-3 bg-yellow-50 rounded-lg">
              <p className="text-yellow-800 text-sm">
                ⚠️ Sans clé API valide, des données météo simulées seront utilisées
              </p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
