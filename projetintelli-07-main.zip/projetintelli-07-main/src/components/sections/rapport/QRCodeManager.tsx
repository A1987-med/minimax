
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { QrCode, Download, Users, Building2, Cable } from "lucide-react";
import { soustraitantService } from '@/services/accueilService';
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";

interface QRCodeManagerProps {
  onQRGenerated?: (soustraitant: string, qrUrl: string) => void;
}

export const QRCodeManager = ({ onQRGenerated }: QRCodeManagerProps) => {
  const [generatedQRs, setGeneratedQRs] = useState<Record<string, string>>({});

  const { data: soustraitants = [], isLoading } = useQuery({
    queryKey: ['soustraitants'],
    queryFn: () => soustraitantService.getAll(),
  });

  console.log('QRCodeManager - Soustraitants chargés:', soustraitants);

  const generateQRCode = async (soustraitantNom: string) => {
    console.log('Génération QR pour:', soustraitantNom);
    try {
      // URL vers le formulaire de saisie rapide avec le sous-traitant pré-sélectionné
      const baseUrl = window.location.origin;
      const qrUrl = `${baseUrl}/saisie-presence?soustraitant=${encodeURIComponent(soustraitantNom)}`;
      
      // Générer le code QR en utilisant une API publique
      const qrApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(qrUrl)}`;
      
      console.log('URL QR générée:', qrApiUrl);
      
      setGeneratedQRs(prev => ({
        ...prev,
        [soustraitantNom]: qrApiUrl
      }));

      if (onQRGenerated) {
        onQRGenerated(soustraitantNom, qrApiUrl);
      }

      toast.success(`Code QR généré pour ${soustraitantNom}`);
    } catch (error) {
      console.error('Erreur lors de la génération du code QR:', error);
      toast.error('Erreur lors de la génération du code QR');
    }
  };

  const downloadQR = (soustraitantNom: string, qrUrl: string) => {
    const link = document.createElement('a');
    link.href = qrUrl;
    link.download = `QR-${soustraitantNom.replace(/\s+/g, '-')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    toast.success(`Code QR téléchargé pour ${soustraitantNom}`);
  };

  const printQR = (soustraitantNom: string, qrUrl: string) => {
    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Code QR - ${soustraitantNom}</title>
            <style>
              body { 
                margin: 0; 
                padding: 20px; 
                text-align: center; 
                font-family: Arial, sans-serif;
                background-color: white;
                color: black;
              }
              .qr-container { 
                page-break-inside: avoid; 
                margin-bottom: 20px; 
                background-color: white;
              }
              h2 { 
                margin-bottom: 10px; 
                color: black !important;
                font-size: 18px;
                font-weight: bold;
              }
              .warning { 
                color: red !important; 
                font-weight: bold; 
                margin-top: 10px; 
                font-size: 14px; 
              }
              img {
                display: block;
                margin: 10px auto;
              }
              @media print {
                body { 
                  background-color: white !important;
                  color: black !important;
                }
                h2 {
                  color: black !important;
                }
                .warning {
                  color: red !important;
                }
              }
            </style>
          </head>
          <body>
            <div class="qr-container">
              <h2>${soustraitantNom}</h2>
              <img src="${qrUrl}" alt="Code QR ${soustraitantNom}" />
              <div class="warning">⚠️ Ne pas enlever le casque sur le chantier</div>
            </div>
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.onload = () => {
        printWindow.print();
        printWindow.close();
      };
      toast.success(`Impression du code QR pour ${soustraitantNom}`);
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <QrCode className="w-5 h-5" />
            Chargement des sous-traitants...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <QrCode className="w-5 h-5" />
          Codes QR pour Contremaîtres
          <Badge variant="outline" className="ml-auto">
            {soustraitants.length} sous-traitants
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-gray-600 dark:text-gray-300 mb-4">
          Générez des codes QR à coller sur les casques des contremaîtres pour la saisie rapide des présences.
        </div>
        
        <div className="p-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
          <p className="text-sm font-bold text-red-700 dark:text-red-300">
            ⚠️ Attention: Ne pas enlever vos casques sur le chantier.
          </p>
        </div>

        {soustraitants.length === 0 ? (
          <div className="text-center py-6 text-gray-500 dark:text-gray-400">
            <Users className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm">Aucun sous-traitant disponible</p>
            <p className="text-xs">Ajoutez des sous-traitants dans la section Gestion RH</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {soustraitants.map((soustraitant) => (
              <div key={soustraitant.id} className="border rounded-lg p-4 space-y-3 bg-white dark:bg-gray-800 shadow-sm border-gray-200 dark:border-gray-700">
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <span className="font-medium text-sm text-gray-900 dark:text-gray-100">{soustraitant.nom}</span>
                </div>

                {generatedQRs[soustraitant.nom] ? (
                  <div className="space-y-2">
                    <img 
                      src={generatedQRs[soustraitant.nom]} 
                      alt={`QR Code ${soustraitant.nom}`}
                      className="w-32 h-32 mx-auto border rounded"
                    />
                    <div className="flex gap-1">
                      <Button
                        onClick={() => downloadQR(soustraitant.nom, generatedQRs[soustraitant.nom])}
                        size="sm"
                        className="flex-1 text-xs"
                      >
                        <Download className="w-3 h-3 mr-1" />
                        Télécharger
                      </Button>
                      <Button
                        onClick={() => printQR(soustraitant.nom, generatedQRs[soustraitant.nom])}
                        size="sm"
                        variant="outline"
                        className="flex-1 text-xs"
                      >
                        <Cable className="w-3 h-3 mr-1" />
                        Imprimer
                      </Button>
                    </div>
                    <Button
                      onClick={() => generateQRCode(soustraitant.nom)}
                      size="sm"
                      variant="ghost"
                      className="w-full text-xs"
                    >
                      Régénérer
                    </Button>
                  </div>
                ) : (
                  <Button
                    onClick={() => {
                      console.log('Clic sur générer QR pour:', soustraitant.nom);
                      generateQRCode(soustraitant.nom);
                    }}
                    className="w-full"
                    size="sm"
                  >
                    <QrCode className="w-4 h-4 mr-2" />
                    Générer QR
                  </Button>
                )}
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};
