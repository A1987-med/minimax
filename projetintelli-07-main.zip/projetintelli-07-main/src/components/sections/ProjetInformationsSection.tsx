
import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Building2, Calendar, Search, Info } from "lucide-react";
import { projectInfoService } from "@/services/projectInfoService";
import { useToast } from "@/hooks/use-toast";
import { useNativeFeatures } from "@/hooks/useNativeFeatures";
import { ContactCard } from "./projet-informations/ContactCard";
import { InfoCard } from "./projet-informations/InfoCard";
import { ProjectConfigurationTab } from "./projet-informations/ProjectConfigurationTab";
import { CalendarTab } from "./projet-informations/CalendarTab";
import { AnalysesTab } from "./projet-informations/AnalysesTab";
import { GlossaireTab } from "./projet-informations/GlossaireTab";

interface ProjetInformationsSectionProps {
  onBack: () => void;
}

interface Inspection {
  id: string;
  date: string;
  type: string;
  zone: string;
  statut: 'Programmée' | 'Réalisé';
}

export const ProjetInformationsSection = ({ onBack }: ProjetInformationsSectionProps) => {
  const [nomProjet, setNomProjet] = useState("");
  const [numeroProjet, setNumeroProjet] = useState("");
  const [adresseProjet, setAdresseProjet] = useState("");
  const [hasChanges, setHasChanges] = useState(false);
  const [selectedTab, setSelectedTab] = useState('projet');
  const [selectedContact, setSelectedContact] = useState<string | null>(null);
  const [inspections, setInspections] = useState<Inspection[]>([]);
  const [newInspection, setNewInspection] = useState({
    date: '',
    type: '',
    zone: '',
    statut: 'Programmée' as const
  });
  const [isCapturingLocation, setIsCapturingLocation] = useState(false);
  const { toast } = useToast();
  const { getCurrentPosition } = useNativeFeatures();

  useEffect(() => {
    const projectInfo = projectInfoService.getProjectInfo();
    setNomProjet(projectInfo.nomProjet);
    setNumeroProjet(projectInfo.numeroProjet);
    setAdresseProjet(projectInfo.adresseProjet);
  }, []);

  const handleNomProjetChange = (value: string) => {
    setNomProjet(value);
    setHasChanges(true);
  };

  const handleNumeroProjetChange = (value: string) => {
    setNumeroProjet(value);
    setHasChanges(true);
  };

  const handleAdresseProjetChange = (value: string) => {
    setAdresseProjet(value);
    setHasChanges(true);
  };

  const handleSave = () => {
    projectInfoService.setProjectInfo({
      nomProjet,
      numeroProjet,
      adresseProjet
    });
    
    setHasChanges(false);
    
    toast({
      title: "Informations sauvegardées ✅",
      description: "Les informations du projet ont été mises à jour avec succès",
      duration: 3000,
    });
  };

  const handleCall = (phoneNumber: string) => {
    const cleanNumber = phoneNumber.replace(/\D/g, '');
    window.open(`tel:+${cleanNumber}`, '_self');
  };

  const handleEmail = (email: string) => {
    try {
      const mailtoLink = `mailto:${email}`;
      window.open(mailtoLink);
    } catch (error) {
      window.location.href = `mailto:${email}`;
    }
  };

  const handleCaptureGPS = async () => {
    console.log('🌍 Capture GPS demandée pour la zone');
    setIsCapturingLocation(true);
    
    try {
      const position = await getCurrentPosition();
      if (position) {
        const gpsCoords = `GPS: ${position.latitude.toFixed(6)}, ${position.longitude.toFixed(6)}`;
        const currentZone = newInspection.zone;
        const newZoneValue = currentZone ? `${currentZone} - ${gpsCoords}` : gpsCoords;
        
        setNewInspection(prev => ({ ...prev, zone: newZoneValue }));
        
        toast({
          title: "Position capturée ✅",
          description: "Les coordonnées GPS ont été ajoutées à la zone",
        });
      }
    } catch (error) {
      console.error('Erreur capture GPS:', error);
      toast({
        title: "Erreur GPS",
        description: "Impossible de capturer la position",
        variant: "destructive"
      });
    } finally {
      setIsCapturingLocation(false);
    }
  };

  const handleAddInspection = () => {
    console.log('🔍 Tentative d\'ajout d\'inspection:', newInspection);
    
    if (!newInspection.date || newInspection.date.trim() === '') {
      console.log('❌ Date manquante:', newInspection.date);
      toast({
        title: "Erreur",
        description: "Veuillez sélectionner une date",
        variant: "destructive"
      });
      return;
    }

    if (!newInspection.type || newInspection.type.trim() === '') {
      console.log('❌ Type manquant:', newInspection.type);
      toast({
        title: "Erreur",
        description: "Veuillez saisir le type d'inspection",
        variant: "destructive"
      });
      return;
    }

    if (!newInspection.zone || newInspection.zone.trim() === '') {
      console.log('❌ Zone manquante:', newInspection.zone);
      toast({
        title: "Erreur",
        description: "Veuillez saisir la zone",
        variant: "destructive"
      });
      return;
    }

    const dateObj = new Date(newInspection.date);
    const formattedDate = dateObj.toLocaleDateString('fr-FR');

    const inspection: Inspection = {
      id: Date.now().toString(),
      date: formattedDate,
      type: newInspection.type.trim(),
      zone: newInspection.zone.trim(),
      statut: newInspection.statut
    };

    console.log('✅ Inspection créée:', inspection);
    setInspections(prev => [...prev, inspection]);
    setNewInspection({ date: '', type: '', zone: '', statut: 'Programmée' });
    
    toast({
      title: "Inspection ajoutée ✅",
      description: "L'inspection a été ajoutée au calendrier",
    });
  };

  const handleDeleteInspection = (id: string) => {
    setInspections(prev => prev.filter(inspection => inspection.id !== id));
    toast({
      title: "Inspection supprimée",
      description: "L'inspection a été retirée du calendrier",
    });
  };

  const handleSyncCalendar = () => {
    const inspectionsProgrammees = inspections.filter(inspection => inspection.statut === 'Programmée');
    
    if (inspectionsProgrammees.length === 0) {
      toast({
        title: "Aucune inspection programmée",
        description: "Il n'y a pas d'inspections programmées à synchroniser",
        variant: "destructive"
      });
      return;
    }

    inspectionsProgrammees.forEach((inspection, index) => {
      setTimeout(() => {
        const title = `Inspection ${inspection.type}`;
        const details = `Zone: ${inspection.zone}\nType: ${inspection.type}`;
        
        const dateParts = inspection.date.split('/');
        const isoDate = `${dateParts[2]}-${dateParts[1].padStart(2, '0')}-${dateParts[0].padStart(2, '0')}`;
        console.log('🗓️ Conversion date:', inspection.date, '->', isoDate);
        
        const startDate = new Date(isoDate + 'T09:00:00');
        const endDate = new Date(startDate.getTime() + 60 * 60 * 1000);
        
        console.log('📅 Dates calculées:', { startDate, endDate });
        
        const formatDate = (date: Date) => {
          return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
        };

        const googleCalendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&dates=${formatDate(startDate)}/${formatDate(endDate)}&details=${encodeURIComponent(details)}&location=${encodeURIComponent(inspection.zone)}`;
        
        const outlookUrl = `https://outlook.live.com/calendar/0/deeplink/compose?subject=${encodeURIComponent(title)}&startdt=${formatDate(startDate)}&enddt=${formatDate(endDate)}&body=${encodeURIComponent(details)}&location=${encodeURIComponent(inspection.zone)}`;

        const isMobile = /Android|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isAndroid = /Android/i.test(navigator.userAgent);

        console.log('📱 Détection appareil:', { isMobile, isIOS, isAndroid });

        try {
          if (isIOS) {
            const iosCalendarUrl = `calshow:${Math.floor(startDate.getTime() / 1000)}`;
            window.location.href = iosCalendarUrl;
            console.log('🍎 Tentative ouverture calendrier iOS');
          } else if (isAndroid) {
            const androidCalendarUrl = `content://com.android.calendar/time/${startDate.getTime()}`;
            window.location.href = androidCalendarUrl;
            console.log('🤖 Tentative ouverture calendrier Android');
          } else {
            window.open(googleCalendarUrl, '_blank');
            console.log('💻 Ouverture Google Calendar desktop');
          }
        } catch (error) {
          console.error('Erreur ouverture calendrier natif, fallback vers Google Calendar:', error);
          window.open(googleCalendarUrl, '_blank');
        }
      }, index * 500);
    });

    toast({
      title: "Calendriers en cours d'ouverture 📅",
      description: `${inspectionsProgrammees.length} inspection(s) en cours d'ajout à votre calendrier`,
    });
  };

  const handleNewInspectionChange = (field: string, value: string) => {
    setNewInspection(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          ← Retour
        </Button>
        <h1 className="text-3xl font-bold text-gray-800">Projet & Informations</h1>
        <Badge variant="outline" className="text-blue-600 border-blue-200">
          Québec, Canada 🇨🇦
        </Badge>
      </div>

      {/* Cartes de contact rapide en haut - GRILLE 2x2 FORCÉE AVEC CARTES TRÈS GRANDES */}
      <div className="grid grid-cols-2 grid-rows-2 gap-12 mb-12 max-w-8xl mx-auto">
        <ContactCard
          name="Ahmed Afra"
          title="Coordonnateur SST"
          phone="1(450) 368-8815"
          email="aafra@corsim.ca"
          isSelected={selectedContact === 'ahmed'}
          onToggle={() => setSelectedContact(selectedContact === 'ahmed' ? null : 'ahmed')}
          onCall={handleCall}
          onEmail={handleEmail}
          colorScheme="purple"
        />

        <ContactCard
          name="Abdelhamid Ouldzeid"
          title="Coordonnateur SST"
          phone="1(438) 439-2609"
          email="aouldzeid@corsim.ca"
          isSelected={selectedContact === 'abdelhamid'}
          onToggle={() => setSelectedContact(selectedContact === 'abdelhamid' ? null : 'abdelhamid')}
          onCall={handleCall}
          onEmail={handleEmail}
          colorScheme="emerald"
        />

        <InfoCard
          title="Projet Actuel"
          subtitle="Configuration"
          icon={Building2}
          colorScheme="blue"
        >
          <div className="truncate font-medium">{nomProjet || "Non défini"}</div>
          <div className="truncate font-medium">{numeroProjet || "Non défini"}</div>
        </InfoCard>

        <InfoCard
          title="Inspections"
          subtitle="Calendrier"
          icon={Calendar}
          colorScheme="orange"
        >
          <div className="font-medium">{inspections.length} programmée{inspections.length > 1 ? 's' : ''}</div>
          <div className="text-base text-green-600 font-medium">
            {inspections.filter(i => i.statut === 'Réalisé').length} réalisée{inspections.filter(i => i.statut === 'Réalisé').length > 1 ? 's' : ''}
          </div>
        </InfoCard>
      </div>

      {/* Navigation tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {[
          { id: 'projet', label: 'Configuration Projet', icon: Building2 },
          { id: 'calendrier', label: 'Calendrier', icon: Calendar },
          { id: 'analyses', label: 'Analyses de risques', icon: Search },
          { id: 'glossaire', label: 'Glossaire', icon: Info }
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={selectedTab === tab.id ? "default" : "outline"}
            onClick={() => setSelectedTab(tab.id)}
            className="flex items-center gap-2"
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {selectedTab === 'projet' && (
        <ProjectConfigurationTab
          nomProjet={nomProjet}
          numeroProjet={numeroProjet}
          adresseProjet={adresseProjet}
          hasChanges={hasChanges}
          onNomProjetChange={handleNomProjetChange}
          onNumeroProjetChange={handleNumeroProjetChange}
          onAdresseProjetChange={handleAdresseProjetChange}
          onSave={handleSave}
        />
      )}

      {selectedTab === 'calendrier' && (
        <CalendarTab
          inspections={inspections}
          newInspection={newInspection}
          isCapturingLocation={isCapturingLocation}
          onNewInspectionChange={handleNewInspectionChange}
          onAddInspection={handleAddInspection}
          onDeleteInspection={handleDeleteInspection}
          onCaptureGPS={handleCaptureGPS}
          onSyncCalendar={handleSyncCalendar}
        />
      )}

      {selectedTab === 'analyses' && <AnalysesTab />}

      {selectedTab === 'glossaire' && <GlossaireTab />}
    </div>
  );
};
