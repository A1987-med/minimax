
import React, { useState } from 'react';
import { SignalementForm } from './signalement/SignalementForm';
import { SignalementSuccess } from './signalement/SignalementSuccess';

interface SignalementSectionProps {
  onBack: () => void;
  onSignalementAdded?: () => void;
}

export const SignalementSection = ({ onBack, onSignalementAdded }: SignalementSectionProps) => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    setSubmitted(true);
    
    // Appeler la fonction de callback si elle existe
    if (onSignalementAdded) {
      onSignalementAdded();
    }
    
    setTimeout(() => {
      setSubmitted(false);
    }, 3000);
  };

  if (submitted) {
    return <SignalementSuccess onBack={onBack} />;
  }

  return <SignalementForm onBack={onBack} onSubmit={handleSubmit} />;
};
