
import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowDown, Users, Phone, Calendar, Search, Mail } from "lucide-react";

interface InformationsSectionProps {
  onBack: () => void;
}

export const InformationsSection = ({ onBack }: InformationsSectionProps) => {
  const [selectedTab, setSelectedTab] = useState('contacts');
  const [statuses, setStatuses] = useState({
    abdelhamid: 'Disponible',
    ahmed: 'En déplacement',
    pierre: 'Disponible'
  });

  const contacts = [
    {
      id: 'abdelhamid',
      nom: 'Abdelhamid Ouldzeid',
      fonction: 'Coordonnateur en santé et sécurité',
      telephone: '1(438) 439-2609',
      email: 'aouldzeid@corsim.ca',
      disponibilite: statuses.abdelhamid
    },
    {
      id: 'ahmed',
      nom: 'Ahmed Afra',
      fonction: 'Coordonnateur en santé et sécurité',
      telephone: '1(450) 368-8815',
      email: 'aafra@corsim.ca',
      disponibilite: statuses.ahmed
    },
    {
      id: 'pierre',
      nom: 'Pierre Durand',
      fonction: 'Responsable Qualité',
      telephone: '01 23 45 67 91',
      email: 'p.durand@entreprise.com',
      disponibilite: statuses.pierre
    }
  ];

  const inspections = [
    { date: '18/12/2024', type: 'Échafaudages', zone: 'Bâtiment A', statut: 'Programmée' },
    { date: '20/12/2024', type: 'Engins de chantier', zone: 'Zone de stockage', statut: 'Programmée' },
    { date: '22/12/2024', type: 'Installation électrique', zone: 'Bâtiment B', statut: 'Programmée' },
    { date: '15/12/2024', type: 'Exercice évacuation', zone: 'Tout le chantier', statut: 'Réalisé' }
  ];

  const glossaire = [
    { terme: 'EPI', definition: 'Équipement de Protection Individuelle - Dispositif destiné à être porté par une personne pour la protéger des risques' },
    { terme: 'Harnais', definition: 'Équipement de protection contre les chutes, composé de sangles et de boucles' },
    { terme: 'Point d\'ancrage', definition: 'Point de fixation capable de supporter les efforts engendrés par l\'arrêt d\'une chute' },
    { terme: 'Signalisation temporaire', definition: 'Ensemble des dispositifs destinés à informer les usagers d\'une modification temporaire' },
    { terme: 'Zone de danger', definition: 'Espace où un travailleur peut être exposé à un risque pour sa sécurité ou sa santé' }
  ];

  const handleCall = (number: string) => {
    console.log('Calling:', number);
    const cleanNumber = number.replace(/\D/g, '');
    window.open(`tel:+${cleanNumber}`, '_self');
  };

  const handleEmail = (email: string) => {
    console.log('Opening email for:', email);
    // Essayer d'abord window.open pour iPad
    try {
      const mailtoLink = `mailto:${email}`;
      window.open(mailtoLink);
    } catch (error) {
      // Fallback pour certains navigateurs iPad
      window.location.href = `mailto:${email}`;
    }
  };

  const handleStatusChange = (contactId: string, newStatus: string) => {
    setStatuses(prev => ({
      ...prev,
      [contactId]: newStatus
    }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Disponible':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'En déplacement':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Absent':
        return 'bg-red-100 text-red-800 border-red-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-purple-600">Informations</h1>
      </div>

      {/* Navigation tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {[
          { id: 'contacts', label: 'Contacts', icon: Users },
          { id: 'calendrier', label: 'Calendrier', icon: Calendar },
          { id: 'analyses', label: 'Analyses de risques', icon: Search },
          { id: 'glossaire', label: 'Glossaire', icon: Search }
        ].map((tab) => (
          <Button
            key={tab.id}
            variant={selectedTab === tab.id ? "default" : "outline"}
            onClick={() => setSelectedTab(tab.id)}
            className="flex items-center gap-2"
          >
            <tab.icon className="w-4 h-4" />
            {tab.label}
          </Button>
        ))}
      </div>

      {selectedTab === 'contacts' && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Responsables de la sécurité</h2>
          {contacts.map((contact, index) => (
            <Card key={index}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{contact.nom}</h3>
                    <p className="text-gray-600">{contact.fonction}</p>
                    <div className="flex items-center gap-4 mt-2">
                      <a
                        href={`tel:${contact.telephone.replace(/\D/g, '')}`}
                        className="flex items-center gap-2 px-3 py-2 text-sm bg-green-50 hover:bg-green-100 text-green-700 rounded-md border border-green-200 transition-colors cursor-pointer"
                      >
                        <Phone className="w-4 h-4" />
                        {contact.telephone}
                      </a>
                      <a
                        href={`mailto:${contact.email}`}
                        onClick={(e) => {
                          e.preventDefault();
                          handleEmail(contact.email);
                        }}
                        className="flex items-center gap-2 px-3 py-2 text-sm bg-blue-50 hover:bg-blue-100 text-blue-700 rounded-md border border-blue-200 transition-colors cursor-pointer underline-offset-4 hover:underline"
                      >
                        <Mail className="w-4 h-4" />
                        {contact.email}
                      </a>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-600">Statut :</span>
                    <Select 
                      value={contact.disponibilite} 
                      onValueChange={(value) => handleStatusChange(contact.id, value)}
                    >
                      <SelectTrigger className={`w-32 h-8 text-xs ${getStatusColor(contact.disponibilite)}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Disponible">Disponible</SelectItem>
                        <SelectItem value="En déplacement">En déplacement</SelectItem>
                        <SelectItem value="Absent">Absent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {selectedTab === 'calendrier' && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Calendrier des inspections et vérifications</h2>
          <div className="space-y-3">
            {inspections.map((inspection, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3">
                        <Calendar className="w-5 h-5 text-blue-600" />
                        <div>
                          <h3 className="font-semibold">{inspection.type}</h3>
                          <p className="text-sm text-gray-600">{inspection.zone}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium">{inspection.date}</p>
                      <Badge 
                        variant={inspection.statut === 'Réalisé' ? 'default' : 'secondary'}
                        className={inspection.statut === 'Réalisé' ? 'bg-green-500' : 'bg-blue-500'}
                      >
                        {inspection.statut}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          
          <Card className="border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <h3 className="font-semibold text-blue-800 mb-2">📅 Rappels automatiques</h3>
              <p className="text-sm text-blue-700">
                Les inspections programmées peuvent être ajoutées à votre calendrier personnel pour recevoir des rappels.
              </p>
              <Button variant="outline" className="mt-2 border-blue-300">
                Synchroniser avec mon calendrier
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {selectedTab === 'analyses' && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Documents d'analyse des risques</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              'Analyse risques - Travaux en hauteur',
              'Analyse risques - Manipulation d\'engins',
              'Analyse risques - Soudage et découpe',
              'Analyse risques - Installation électrique',
              'Plan de prévention général',
              'Évaluation environnementale'
            ].map((doc, index) => (
              <Card key={index} className="hover:shadow-md transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                      <span className="text-red-600 font-bold text-sm">PDF</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{doc}</h3>
                      <p className="text-sm text-gray-500">Dernière mise à jour : {new Date().toLocaleDateString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {selectedTab === 'glossaire' && (
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-gray-800">Glossaire des termes de sécurité</h2>
          
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-4">
                <Search className="w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Rechercher un terme..."
                  className="flex-1 p-2 border border-gray-200 rounded-lg"
                />
              </div>
            </CardContent>
          </Card>

          <div className="space-y-3">
            {glossaire.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <h3 className="font-semibold text-purple-600 mb-2">{item.terme}</h3>
                  <p className="text-gray-700">{item.definition}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
