
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  CheckCircle,
  Trash2,
  RefreshCw,
  FileText,
  Download,
  Code
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { astDataService } from '@/services/astDataService';
import { ASTTextUploadManager } from './ASTTextUploadManager';
import { ASTRealTextUploadManager } from './ASTRealTextUploadManager';
import { ASTExportManager } from './ASTExportManager';

interface ASTUploadManagerProps {
  corpsMetier: string;
  onDataExtracted: () => void;
}

export const ASTUploadManager = ({ corpsMetier, onDataExtracted }: ASTUploadManagerProps) => {
  const { toast } = useToast();

  const handleDeleteData = () => {
    try {
      astDataService.deleteASTData(corpsMetier);
      toast({
        title: "Données supprimées",
        description: `Les données AST pour ${corpsMetier} ont été supprimées`,
      });
      onDataExtracted();
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible de supprimer les données",
        variant: "destructive"
      });
    }
  };

  const hasExistingData = astDataService.hasASTData(corpsMetier);

  return (
    <div className="space-y-6">
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <FileText className="w-5 h-5" />
            Gestion des données AST - {corpsMetier}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {hasExistingData && (
            <div className="flex items-center justify-between p-3 bg-green-100 border border-green-200 rounded-lg">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <span className="text-sm text-green-700">
                  Des données AST existent pour ce corps de métier
                </span>
              </div>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleDeleteData}
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  <Trash2 className="w-4 h-4 mr-1" />
                  Supprimer
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={onDataExtracted}
                >
                  <RefreshCw className="w-4 h-4 mr-1" />
                  Actualiser
                </Button>
              </div>
            </div>
          )}

          <Tabs defaultValue="extraction-html" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="extraction-html">HTML Réel</TabsTrigger>
              <TabsTrigger value="extraction-texte">Texte Structuré</TabsTrigger>
              <TabsTrigger value="export">Sauvegarde & Export</TabsTrigger>
            </TabsList>
            
            <TabsContent value="extraction-html" className="space-y-4">
              <Card className="border-green-200 bg-green-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-700">
                    <Code className="w-5 h-5" />
                    Extraction RÉELLE depuis HTML
                    <Badge variant="outline" className="ml-2 text-green-600">NOUVEAU</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ASTRealTextUploadManager 
                    corpsMetier={corpsMetier} 
                    onDataExtracted={onDataExtracted} 
                  />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="extraction-texte" className="space-y-4">
              <Card className="border-blue-200 bg-blue-50">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-blue-700">
                    <FileText className="w-5 h-5" />
                    Extraction depuis texte structuré
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ASTTextUploadManager 
                    corpsMetier={corpsMetier} 
                    onDataExtracted={onDataExtracted} 
                  />
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="export" className="space-y-4">
              <ASTExportManager />
            </TabsContent>
          </Tabs>

        </CardContent>
      </Card>
    </div>
  );
};
