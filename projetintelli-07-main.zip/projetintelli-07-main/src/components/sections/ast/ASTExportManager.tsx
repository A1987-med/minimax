import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  Download,
  FileText,
  FileSpreadsheet,
  Cloud,
  CloudUpload,
  CloudDownload,
  BarChart3,
  CheckCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { astDataService } from '@/services/astDataService';
import { astExportService } from '@/services/astExportService';
import { astCloudSyncService } from '@/services/astCloudSyncService';

export const ASTExportManager = () => {
  const { toast } = useToast();
  const [isExporting, setIsExporting] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isImporting, setIsImporting] = useState(false);
  const [selectedCorpsMetiers, setSelectedCorpsMetiers] = useState<string[]>([]);
  const [includeAll, setIncludeAll] = useState(true);

  const allData = astDataService.getAllASTData();
  const stats = astExportService.getExportStats();

  const handleExport = async (format: 'json' | 'pdf' | 'excel') => {
    if (allData.length === 0) {
      toast({
        title: "Aucune donnée",
        description: "Aucune donnée AST à exporter",
        variant: "destructive"
      });
      return;
    }

    setIsExporting(true);
    try {
      const options = {
        format,
        includeAllCorpsMetiers: includeAll,
        corpsMetiers: includeAll ? undefined : selectedCorpsMetiers
      };

      switch (format) {
        case 'json':
          astExportService.exportToJSON(options);
          break;
        case 'pdf':
          astExportService.exportToPDF(options);
          break;
        case 'excel':
          astExportService.exportToExcel(options);
          break;
      }

      toast({
        title: "Export réussi",
        description: `Données exportées au format ${format.toUpperCase()}`,
      });
    } catch (error) {
      toast({
        title: "Erreur d'export",
        description: "Impossible d'exporter les données",
        variant: "destructive"
      });
    } finally {
      setIsExporting(false);
    }
  };

  const handleCloudSync = async () => {
    if (allData.length === 0) {
      toast({
        title: "Aucune donnée",
        description: "Aucune donnée AST à synchroniser",
        variant: "destructive"
      });
      return;
    }

    setIsSyncing(true);
    try {
      const result = await astCloudSyncService.syncAllToCloud();
      
      toast({
        title: "Synchronisation terminée",
        description: `${result.success} corps de métiers synchronisés, ${result.errors} erreurs`,
        variant: result.errors > 0 ? "destructive" : "default"
      });
    } catch (error) {
      toast({
        title: "Erreur de synchronisation",
        description: "Impossible de synchroniser avec le cloud",
        variant: "destructive"
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const handleCloudImport = async () => {
    setIsImporting(true);
    try {
      const result = await astCloudSyncService.syncFromCloud();
      
      toast({
        title: "Import terminé",
        description: `${result.imported} corps de métiers importés du cloud, ${result.errors} erreurs`,
        variant: result.errors > 0 ? "destructive" : "default"
      });

      // Rafraîchir la page ou recharger les données si nécessaire
      window.location.reload();
    } catch (error) {
      toast({
        title: "Erreur d'import",
        description: "Impossible d'importer depuis le cloud",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
    }
  };

  const handleCorpsMetierSelection = (corpsMetier: string, checked: boolean) => {
    if (checked) {
      setSelectedCorpsMetiers(prev => [...prev, corpsMetier]);
    } else {
      setSelectedCorpsMetiers(prev => prev.filter(cm => cm !== corpsMetier));
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Statistiques */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-700">
            <BarChart3 className="w-5 h-5" />
            Statistiques des données
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{stats.totalCorpsMetiers}</div>
              <div className="text-sm text-gray-600">Corps de métiers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{stats.totalTaches}</div>
              <div className="text-sm text-gray-600">Tâches</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{stats.totalOperations}</div>
              <div className="text-sm text-gray-600">Opérations</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sélection des données à exporter */}
      {allData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Sélection des données à exporter</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="include-all"
                checked={includeAll}
                onCheckedChange={(checked) => setIncludeAll(checked as boolean)}
              />
              <label htmlFor="include-all" className="text-sm font-medium">
                Inclure tous les corps de métiers
              </label>
            </div>

            {!includeAll && (
              <div className="space-y-2">
                <p className="text-sm text-gray-600">Sélectionnez les corps de métiers :</p>
                {allData.map((data) => (
                  <div key={data.corpsMetier} className="flex items-center space-x-2">
                    <Checkbox
                      id={`cm-${data.corpsMetier}`}
                      checked={selectedCorpsMetiers.includes(data.corpsMetier)}
                      onCheckedChange={(checked) => 
                        handleCorpsMetierSelection(data.corpsMetier, checked as boolean)
                      }
                    />
                    <label htmlFor={`cm-${data.corpsMetier}`} className="text-sm">
                      {data.corpsMetier}
                      <Badge variant="outline" className="ml-2">
                        {data.taches.length} tâches
                      </Badge>
                    </label>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Exports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Exporter les données
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Export JSON */}
            <Button
              variant="outline"
              onClick={() => handleExport('json')}
              disabled={isExporting || allData.length === 0}
              className="h-20 flex flex-col items-center gap-2"
            >
              <FileText className="w-6 h-6" />
              <span>Export JSON</span>
              <span className="text-xs text-gray-500">Format de données</span>
            </Button>

            {/* Export PDF */}
            <Button
              variant="outline"
              onClick={() => handleExport('pdf')}
              disabled={isExporting || allData.length === 0}
              className="h-20 flex flex-col items-center gap-2"
            >
              <FileText className="w-6 h-6" />
              <span>Export PDF</span>
              <span className="text-xs text-gray-500">Rapport imprimable</span>
            </Button>

            {/* Export Excel */}
            <Button
              variant="outline"
              onClick={() => handleExport('excel')}
              disabled={isExporting || allData.length === 0}
              className="h-20 flex flex-col items-center gap-2"
            >
              <FileSpreadsheet className="w-6 h-6" />
              <span>Export Excel</span>
              <span className="text-xs text-gray-500">Tableau CSV</span>
            </Button>
          </div>

          {allData.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <Download className="w-12 h-12 mx-auto mb-4 opacity-50" />
              <p>Aucune donnée AST à exporter</p>
              <p className="text-sm">Ajoutez des données depuis l'onglet "Extraction"</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Synchronisation Cloud */}
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Cloud className="w-5 h-5" />
            Synchronisation Cloud
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-sm text-green-600">
              Sauvegardez vos données AST dans le cloud pour y accéder depuis n'importe quel appareil.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Upload vers cloud */}
              <Button
                onClick={handleCloudSync}
                disabled={isSyncing || allData.length === 0}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                {isSyncing ? (
                  <>
                    <CloudUpload className="w-4 h-4 mr-2 animate-spin" />
                    Synchronisation...
                  </>
                ) : (
                  <>
                    <CloudUpload className="w-4 h-4 mr-2" />
                    Envoyer vers le cloud
                  </>
                )}
              </Button>

              {/* Import depuis cloud */}
              <Button
                onClick={handleCloudImport}
                disabled={isImporting}
                variant="outline"
                className="w-full border-green-600 text-green-600 hover:bg-green-50"
              >
                {isImporting ? (
                  <>
                    <CloudDownload className="w-4 h-4 mr-2 animate-spin" />
                    Import en cours...
                  </>
                ) : (
                  <>
                    <CloudDownload className="w-4 h-4 mr-2" />
                    Importer du cloud
                  </>
                )}
              </Button>
            </div>

            {allData.length === 0 && (
              <div className="text-center py-4 text-gray-500">
                <Cloud className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">Aucune donnée locale</p>
                <p className="text-xs">Vous pouvez importer des données depuis le cloud</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

    </div>
  );
};
