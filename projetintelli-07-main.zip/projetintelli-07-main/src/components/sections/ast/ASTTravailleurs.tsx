import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Users, Briefcase } from "lucide-react";
import { entryService } from '@/services/supabaseService';
import { useQuery } from "@tanstack/react-query";
import { ASTMetierSection } from './components/ASTMetierSection';
import { ASTStatistiquesSection } from './components/ASTStatistiquesSection';

interface Travailleur {
  id: string;
  nom: string;
  prenom: string;
  occupation: string;
  sous_traitant: string;
}

interface TravailleurParMetier {
  [metier: string]: Travailleur[];
}

export const ASTTravailleurs = () => {
  const [metierSelectionne, setMetierSelectionne] = useState<string>("tous");
  const [travailleursParMetier, setTravailleursParMetier] = useState<TravailleurParMetier>({});

  // Charger tous les travailleurs
  const { data: travailleurs = [], isLoading } = useQuery({
    queryKey: ['entries_accueil'],
    queryFn: () => entryService.getAll(),
  });

  // Organiser les travailleurs par métier
  useEffect(() => {
    const groupes: TravailleurParMetier = {};
    
    travailleurs.forEach(travailleur => {
      // Gérer le cas où occupations est un tableau ou une chaîne
      const occupation = Array.isArray(travailleur.occupations) 
        ? travailleur.occupations[0] || 'Non spécifié'
        : travailleur.occupations || 'Non spécifié';
      
      if (!groupes[occupation]) {
        groupes[occupation] = [];
      }
      groupes[occupation].push({
        id: travailleur.id,
        nom: travailleur.nom,
        prenom: travailleur.prenom,
        occupation: occupation,
        sous_traitant: travailleur.soustraitant
      });
    });

    setTravailleursParMetier(groupes);
  }, [travailleurs]);

  const metiers = Object.keys(travailleursParMetier).sort();
  const totalTravailleurs = travailleurs.length;

  const getTravailleurs = () => {
    if (metierSelectionne === "tous") {
      return travailleursParMetier;
    } else {
      return { [metierSelectionne]: travailleursParMetier[metierSelectionne] || [] };
    }
  };

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Chargement des travailleurs...
          </CardTitle>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          Travailleurs par Corps de Métier - AST
          <Badge variant="outline" className="ml-auto">
            {totalTravailleurs} travailleurs
          </Badge>
        </CardTitle>
        <div className="flex items-center gap-4 mt-4">
          <div className="flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-blue-600" />
            <span className="text-sm font-medium">Filtrer par métier:</span>
          </div>
          <Select value={metierSelectionne} onValueChange={setMetierSelectionne}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Sélectionner un métier" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="tous">Tous les métiers</SelectItem>
              {metiers.map((metier) => (
                <SelectItem key={metier} value={metier}>
                  {metier} ({travailleursParMetier[metier]?.length || 0})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="text-sm text-gray-600 mb-4">
          Organisation des travailleurs selon leur métier pour faciliter l'analyse sécuritaire des tâches (AST).
          Sélectionnez un métier spécifique ou affichez tous les travailleurs.
        </div>

        {Object.keys(getTravailleurs()).length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <Users className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm font-medium">
              {metierSelectionne === "tous" 
                ? "Aucun travailleur enregistré" 
                : `Aucun travailleur pour le métier: ${metierSelectionne}`
              }
            </p>
            <p className="text-xs mt-1">
              Ajoutez des travailleurs dans la section Gestion RH
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {Object.entries(getTravailleurs()).map(([metier, listeTravailleurs]) => (
              <ASTMetierSection
                key={metier}
                metier={metier}
                travailleurs={listeTravailleurs}
              />
            ))}
          </div>
        )}

        <ASTStatistiquesSection 
          totalTravailleurs={totalTravailleurs}
          nombreMetiers={metiers.length}
        />
      </CardContent>
    </Card>
  );
};
