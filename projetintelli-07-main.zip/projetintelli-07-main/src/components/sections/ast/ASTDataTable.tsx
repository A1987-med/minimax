
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { 
  FileText,
  Settings,
  AlertTriangle,
  Wrench,
  Package,
  ChevronDown,
  ChevronRight,
  BarChart3
} from "lucide-react";

interface Tache {
  id: string;
  nom: string;
  description: string;
  operations: Operation[];
}

interface Operation {
  id: string;
  nom: string;
  description: string;
  sousOperations: SousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

interface SousOperation {
  id: string;
  nom: string;
  description: string;
  risques: Risque[];
}

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface Outil {
  id: string;
  nom: string;
  type: string;
  securiteRequise: string[];
}

interface Materiau {
  id: string;
  nom: string;
  type: string;
  precautions: string[];
}

interface ASTDataTableProps {
  taches: Tache[];
  corpsMetier: string;
}

export const ASTDataTable: React.FC<ASTDataTableProps> = ({ taches, corpsMetier }) => {
  const [expandedTaches, setExpandedTaches] = React.useState<Set<string>>(new Set());

  const toggleTache = (tacheId: string) => {
    setExpandedTaches(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(tacheId)) {
        newExpanded.delete(tacheId);
      } else {
        newExpanded.add(tacheId);
      }
      return newExpanded;
    });
  };

  const getRisqueColor = (niveau: string) => {
    switch (niveau) {
      case 'faible': return 'bg-green-100 text-green-800 border-green-200';
      case 'moyen': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'eleve': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'critique': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const totalOperations = taches.reduce((acc, t) => acc + t.operations.length, 0);
  const totalSousOperations = taches.reduce((acc, t) => 
    acc + t.operations.reduce((subAcc, op) => subAcc + op.sousOperations.length, 0), 0);
  const totalRisques = taches.reduce((acc, t) => 
    acc + t.operations.reduce((subAcc, op) => 
      subAcc + op.risques.length + op.sousOperations.reduce((risqueAcc, sousOp) => 
        risqueAcc + sousOp.risques.length, 0), 0), 0);

  return (
    <div className="space-y-4">
      {/* En-tête avec statistiques */}
      <Card className="border-blue-200 bg-blue-50 dark:bg-blue-950 dark:border-blue-800">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800 dark:text-blue-200">
            <BarChart3 className="w-5 h-5" />
            Données AST - {corpsMetier}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{taches.length}</div>
              <div className="text-sm text-muted-foreground">Tâches principales</div>
            </div>
            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{totalOperations}</div>
              <div className="text-sm text-muted-foreground">Opérations</div>
            </div>
            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{totalSousOperations}</div>
              <div className="text-sm text-muted-foreground">Sous-opérations</div>
            </div>
            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg">
              <div className="text-2xl font-bold text-red-600">{totalRisques}</div>
              <div className="text-sm text-muted-foreground">Risques identifiés</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Table des données */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Structure détaillée des tâches
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>Tâche</TableHead>
                <TableHead className="text-center">Opérations</TableHead>
                <TableHead className="text-center">Sous-opérations</TableHead>
                <TableHead className="text-center">Risques</TableHead>
                <TableHead className="text-center">Outils</TableHead>
                <TableHead className="text-center">Matériaux</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {taches.map((tache) => {
                const isExpanded = expandedTaches.has(tache.id);
                const operationsCount = tache.operations.length;
                const sousOperationsCount = tache.operations.reduce((acc, op) => acc + op.sousOperations.length, 0);
                const risquesCount = tache.operations.reduce((acc, op) => 
                  acc + op.risques.length + op.sousOperations.reduce((subAcc, sousOp) => 
                    subAcc + sousOp.risques.length, 0), 0);
                const outilsCount = tache.operations.reduce((acc, op) => acc + op.outils.length, 0);
                const materiauxCount = tache.operations.reduce((acc, op) => acc + op.materiaux.length, 0);

                return (
                  <React.Fragment key={tache.id}>
                    <TableRow className="cursor-pointer hover:bg-muted/50" onClick={() => toggleTache(tache.id)}>
                      <TableCell>
                        <Button variant="ghost" size="sm" className="p-1">
                          {isExpanded ? 
                            <ChevronDown className="w-4 h-4" /> : 
                            <ChevronRight className="w-4 h-4" />
                          }
                        </Button>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{tache.nom}</div>
                        <div className="text-sm text-muted-foreground">{tache.description}</div>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-blue-600 border-blue-300">
                          {operationsCount}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-purple-600 border-purple-300">
                          {sousOperationsCount}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-red-600 border-red-300">
                          {risquesCount}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-orange-600 border-orange-300">
                          {outilsCount}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <Badge variant="outline" className="text-green-600 border-green-300">
                          {materiauxCount}
                        </Badge>
                      </TableCell>
                    </TableRow>
                    
                    {isExpanded && (
                      <TableRow>
                        <TableCell colSpan={7} className="p-0">
                          <div className="p-4 bg-muted/30">
                            <div className="space-y-4">
                              {tache.operations.map((operation, index) => (
                                <div key={operation.id} className="border rounded-lg p-4 bg-background">
                                  <div className="flex items-center gap-2 mb-3">
                                    <Settings className="w-4 h-4 text-blue-600" />
                                    <span className="font-medium">{operation.nom}</span>
                                    <div className="ml-auto flex gap-2">
                                      <Badge variant="outline" className="text-purple-600">
                                        {operation.sousOperations.length} sous-op.
                                      </Badge>
                                      <Badge variant="outline" className="text-red-600">
                                        {operation.risques.length + operation.sousOperations.reduce((acc, sousOp) => acc + sousOp.risques.length, 0)} risques
                                      </Badge>
                                    </div>
                                  </div>
                                  
                                  <div className="text-sm text-muted-foreground mb-3">
                                    {operation.description}
                                  </div>

                                  {/* Sous-opérations */}
                                  {operation.sousOperations.length > 0 && (
                                    <div className="mb-3">
                                      <h5 className="text-sm font-medium text-purple-600 mb-2">Sous-opérations:</h5>
                                      <div className="grid gap-1">
                                        {operation.sousOperations.map((sousOp, sousIndex) => (
                                          <div key={sousOp.id} className="text-sm pl-4 border-l-2 border-purple-200">
                                            <span className="text-purple-800 font-medium">{sousIndex + 1}.</span> {sousOp.nom}
                                            {sousOp.risques.length > 0 && (
                                              <span className="ml-2">
                                                <Badge variant="outline" className="text-xs text-red-600">
                                                  {sousOp.risques.length} risque(s)
                                                </Badge>
                                              </span>
                                            )}
                                          </div>
                                        ))}
                                      </div>
                                    </div>
                                  )}

                                  {/* Grille des détails */}
                                  <div className="grid md:grid-cols-3 gap-4">
                                    {/* Risques */}
                                    {operation.risques.length > 0 && (
                                      <div>
                                        <h6 className="text-sm font-medium text-red-600 mb-2 flex items-center gap-1">
                                          <AlertTriangle className="w-3 h-3" />
                                          Risques principaux
                                        </h6>
                                        <div className="space-y-1">
                                          {operation.risques.slice(0, 2).map((risque, rIndex) => (
                                            <div key={rIndex} className={`text-xs p-2 rounded border ${getRisqueColor(risque.niveau)}`}>
                                              <div className="font-medium">{risque.description}</div>
                                              <div className="opacity-80">Niveau: {risque.niveau}</div>
                                            </div>
                                          ))}
                                          {operation.risques.length > 2 && (
                                            <div className="text-xs text-muted-foreground">
                                              +{operation.risques.length - 2} autres risques...
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}

                                    {/* Outils */}
                                    {operation.outils.length > 0 && (
                                      <div>
                                        <h6 className="text-sm font-medium text-orange-600 mb-2 flex items-center gap-1">
                                          <Wrench className="w-3 h-3" />
                                          Outils
                                        </h6>
                                        <div className="space-y-1">
                                          {operation.outils.slice(0, 2).map((outil, oIndex) => (
                                            <div key={oIndex} className="text-xs p-2 border border-orange-200 rounded bg-orange-50">
                                              <div className="font-medium text-orange-800">{outil.nom}</div>
                                              <div className="text-orange-600">{outil.type}</div>
                                            </div>
                                          ))}
                                          {operation.outils.length > 2 && (
                                            <div className="text-xs text-muted-foreground">
                                              +{operation.outils.length - 2} autres outils...
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}

                                    {/* Matériaux */}
                                    {operation.materiaux.length > 0 && (
                                      <div>
                                        <h6 className="text-sm font-medium text-green-600 mb-2 flex items-center gap-1">
                                          <Package className="w-3 h-3" />
                                          Matériaux
                                        </h6>
                                        <div className="space-y-1">
                                          {operation.materiaux.slice(0, 2).map((materiau, mIndex) => (
                                            <div key={mIndex} className="text-xs p-2 border border-green-200 rounded bg-green-50">
                                              <div className="font-medium text-green-800">{materiau.nom}</div>
                                              <div className="text-green-600">{materiau.type}</div>
                                            </div>
                                          ))}
                                          {operation.materiaux.length > 2 && (
                                            <div className="text-xs text-muted-foreground">
                                              +{operation.materiaux.length - 2} autres matériaux...
                                            </div>
                                          )}
                                        </div>
                                      </div>
                                    )}
                                  </div>
                                </div>
                              ))}
                            </div>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </React.Fragment>
                );
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
};
