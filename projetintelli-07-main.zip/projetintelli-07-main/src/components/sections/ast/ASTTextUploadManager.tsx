
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { astTextExtractionService } from '@/services/astTextExtractionService';
import { astDataService } from '@/services/astDataService';

interface ASTTextUploadManagerProps {
  corpsMetier: string;
  onDataExtracted: () => void;
}

export const ASTTextUploadManager = ({ corpsMetier, onDataExtracted }: ASTTextUploadManagerProps) => {
  const [textContent, setTextContent] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleExtractFromText = async () => {
    if (!textContent.trim()) {
      toast({
        title: "Texte manquant",
        description: "Veuillez coller le texte des tâches, opérations et sous-opérations",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      console.log('🚀 === DÉBUT EXTRACTION DEPUIS TEXTE ===');
      
      const astData = await astTextExtractionService.extractASTFromText({
        corpsMetier,
        textContent
      });

      // Sauvegarder les données
      astDataService.saveASTData(astData);

      const totalOperations = astData.taches.reduce((acc, t) => acc + t.operations.length, 0);
      const totalSousOperations = astData.taches.reduce((acc, t) => acc + t.operations.reduce((subAcc, op) => subAcc + op.sousOperations.length, 0), 0);

      toast({
        title: "Extraction réussie ! 🎉",
        description: `${astData.taches.length} tâches, ${totalOperations} opérations et ${totalSousOperations} sous-opérations extraites pour ${corpsMetier}`,
      });

      // Réinitialiser le formulaire
      setTextContent('');
      
      // Notifier le parent
      onDataExtracted();
      
      console.log('🎉 === EXTRACTION DEPUIS TEXTE TERMINÉE ===');
      
    } catch (error) {
      console.error('❌ Erreur extraction depuis texte:', error);
      
      toast({
        title: "Erreur d'extraction",
        description: error instanceof Error ? error.message : "Erreur inconnue lors de l'extraction",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const hasExistingData = astDataService.hasASTData(corpsMetier);

  return (
    <div className="space-y-6">
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-700">
            <FileText className="w-5 h-5" />
            Extraction AST depuis Texte - {corpsMetier}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {hasExistingData && (
            <div className="flex items-center gap-2 p-3 bg-green-100 border border-green-200 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-sm text-green-700">
                Des données AST existent déjà pour ce corps de métier. L'extraction remplacera les données existantes.
              </span>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Texte des tâches, opérations et sous-opérations numérotées :
            </label>
            <Textarea
              value={textContent}
              onChange={(e) => setTextContent(e.target.value)}
              placeholder="Collez ici le texte avec la structure : 1. TÂCHE, 1.1 Opération, 1.1.1 Sous-opération"
              className="min-h-[300px] font-mono text-sm"
              disabled={isProcessing}
            />
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span>{textContent.length} caractères</span>
              <span>Structure: Tâches (1.) → Opérations (1.1) → Sous-opérations (1.1.1)</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleExtractFromText}
              disabled={!textContent.trim() || isProcessing}
              className="flex items-center gap-2"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Extraction en cours...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  Extraire AST depuis Texte
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setTextContent('')}
              disabled={isProcessing}
            >
              Effacer
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-green-600">Hiérarchie correcte</Badge>
              <span className="text-xs text-gray-600">Tâches → Opérations → Sous-opérations</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-blue-600">Parsing intelligent</Badge>
              <span className="text-xs text-gray-600">Structure automatique</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-purple-600">Données complètes</Badge>
              <span className="text-xs text-gray-600">Risques, outils, matériaux</span>
            </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
};
