
import { useState } from 'react';

export const useASTExpansion = () => {
  const [expandedTaches, setExpandedTaches] = useState<Set<string>>(new Set());
  const [expandedOperations, setExpandedOperations] = useState<Set<string>>(new Set());
  const [expandedSousOperations, setExpandedSousOperations] = useState<Set<string>>(new Set());

  const toggleTache = (tacheId: string) => {
    console.log('🔄 Toggle tâche:', tacheId);
    setExpandedTaches(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(tacheId)) {
        newExpanded.delete(tacheId);
        console.log('➖ Fermeture tâche:', tacheId);
      } else {
        newExpanded.add(tacheId);
        console.log('➕ Ouverture tâche:', tacheId);
      }
      return newExpanded;
    });
  };

  const toggleOperation = (operationId: string) => {
    console.log('🔄 Toggle opération:', operationId);
    setExpandedOperations(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(operationId)) {
        newExpanded.delete(operationId);
        console.log('➖ Fermeture opération:', operationId);
      } else {
        newExpanded.add(operationId);
        console.log('➕ Ouverture opération:', operationId);
      }
      return newExpanded;
    });
  };

  const toggleSousOperation = (sousOperationId: string, event?: React.MouseEvent) => {
    if (event) {
      event.stopPropagation();
    }
    console.log('🔄 Toggle sous-opération:', sousOperationId);
    setExpandedSousOperations(prev => {
      const newExpanded = new Set(prev);
      if (newExpanded.has(sousOperationId)) {
        newExpanded.delete(sousOperationId);
        console.log('➖ Fermeture sous-opération:', sousOperationId);
      } else {
        newExpanded.add(sousOperationId);
        console.log('➕ Ouverture sous-opération:', sousOperationId);
      }
      return newExpanded;
    });
  };

  const handleOperationBadgeClick = (operationId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    console.log('🎯 Clic sur badge opération:', operationId);
    
    // Forcer l'ouverture de l'opération si elle n'est pas déjà ouverte
    setExpandedOperations(prev => {
      const newExpanded = new Set(prev);
      if (!newExpanded.has(operationId)) {
        newExpanded.add(operationId);
        console.log('➕ Ouverture forcée opération:', operationId);
      }
      return newExpanded;
    });
  };

  const expandAll = (taches: any[]) => {
    setExpandedTaches(new Set(taches.map(t => t.id)));
    setExpandedOperations(new Set(taches.flatMap(t => t.operations ? t.operations.map(op => op.id) : [])));
    setExpandedSousOperations(new Set(taches.flatMap(t => 
      t.operations ? t.operations.flatMap(op => 
        op.sousOperations ? op.sousOperations.map(sousOp => sousOp.id) : []
      ) : []
    )));
  };

  const collapseAll = () => {
    setExpandedTaches(new Set());
    setExpandedOperations(new Set());
    setExpandedSousOperations(new Set());
  };

  return {
    expandedTaches,
    expandedOperations,
    expandedSousOperations,
    toggleTache,
    toggleOperation,
    toggleSousOperation,
    handleOperationBadgeClick,
    expandAll,
    collapseAll
  };
};
