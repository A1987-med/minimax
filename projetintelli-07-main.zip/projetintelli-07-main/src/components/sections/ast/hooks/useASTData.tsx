
import { useState, useEffect, useRef } from 'react';
import { astDataService } from '../../../../services/astDataService';

interface Tache {
  id: string;
  nom: string;
  description: string;
  operations: Operation[];
}

interface Operation {
  id: string;
  nom: string;
  description: string;
  sousOperations: SousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

interface SousOperation {
  id: string;
  nom: string;
  description: string;
  risques: Risque[];
}

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface Outil {
  id: string;
  nom: string;
  type: string;
  securiteRequise: string[];
}

interface Materiau {
  id: string;
  nom: string;
  type: string;
  precautions: string[];
}

export const useASTData = (corpsMetier: string, refreshKey?: number) => {
  const [taches, setTaches] = useState<Tache[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [stats, setStats] = useState({ 
    totalTaches: 0, 
    totalOperations: 0, 
    totalSousOperations: 0, 
    totalRisques: 0, 
    totalOutils: 0, 
    totalMateriaux: 0 
  });
  const lastRefreshKeyRef = useRef<number>(0);

  const loadASTData = () => {
    console.log('📖 Chargement des données AST pour:', corpsMetier);
    setIsLoading(true);
    
    try {
      const astData = astDataService.getASTData(corpsMetier);
      
      if (astData && astData.taches && astData.taches.length > 0) {
        console.log('✅ Données AST trouvées:', astData.taches.length, 'tâches');
        
        const convertedTaches: Tache[] = astData.taches.map((tache, tIndex) => ({
          id: `tache-${tIndex + 1}`,
          nom: tache.nom || 'Tâche sans nom',
          description: tache.description || tache.nom || 'Tâche sans description',
          operations: (tache.operations || []).map((operation, oIndex) => ({
            id: `tache-${tIndex + 1}-op-${oIndex + 1}`,
            nom: operation.nom || 'Opération sans nom',
            description: operation.description || operation.nom || 'Opération sans description',
            sousOperations: (operation.sousOperations || []).map((sousOp, sIndex) => ({
              id: `t${tIndex + 1}-op${oIndex + 1}-sous${sIndex + 1}`,
              nom: sousOp.nom || 'Sous-opération sans nom',
              description: sousOp.description || sousOp.nom || 'Sous-opération sans description',
              risques: (sousOp.risques || []).map((risque, rIndex) => ({
                id: `t${tIndex + 1}-op${oIndex + 1}-sous${sIndex + 1}-r${rIndex + 1}`,
                description: risque.description || 'Risque sans description',
                niveau: risque.niveau || 'moyen',
                mesuresPrevention: risque.mesuresPrevention || []
              }))
            })),
            risques: (operation.risques || []).map((risque, rIndex) => ({
              id: `t${tIndex + 1}-op${oIndex + 1}-r${rIndex + 1}`,
              description: risque.description || 'Risque sans description',
              niveau: risque.niveau || 'moyen',
              mesuresPrevention: risque.mesuresPrevention || []
            })),
            outils: (operation.outils || []).map((outil, outilIndex) => ({
              id: `t${tIndex + 1}-op${oIndex + 1}-out${outilIndex + 1}`,
              nom: outil.nom || 'Outil sans nom',
              type: outil.type || 'Type non spécifié',
              securiteRequise: outil.securiteRequise || []
            })),
            materiaux: (operation.materiaux || []).map((materiau, matIndex) => ({
              id: `t${tIndex + 1}-op${oIndex + 1}-mat${matIndex + 1}`,
              nom: materiau.nom || 'Matériau sans nom',
              type: materiau.type || 'Type non spécifié',
              precautions: materiau.precautions || []
            }))
          }))
        }));
        
        setTaches(convertedTaches);
        
        const totalOperations = convertedTaches.reduce((acc, tache) => {
          return acc + (tache.operations ? tache.operations.length : 0);
        }, 0);
        
        const totalSousOperations = convertedTaches.reduce((acc, tache) => {
          if (!tache.operations) return acc;
          return acc + tache.operations.reduce((subAcc, operation) => {
            return subAcc + (operation.sousOperations ? operation.sousOperations.length : 0);
          }, 0);
        }, 0);
        
        const totalRisques = convertedTaches.reduce((acc, tache) => {
          if (!tache.operations) return acc;
          return acc + tache.operations.reduce((subAcc, operation) => {
            const operationRisques = operation.risques ? operation.risques.length : 0;
            const sousOperationRisques = operation.sousOperations ? 
              operation.sousOperations.reduce((risqueAcc, sousOp) => {
                return risqueAcc + (sousOp.risques ? sousOp.risques.length : 0);
              }, 0) : 0;
            return subAcc + operationRisques + sousOperationRisques;
          }, 0);
        }, 0);
        
        const totalOutils = convertedTaches.reduce((acc, tache) => {
          if (!tache.operations) return acc;
          return acc + tache.operations.reduce((subAcc, operation) => {
            return subAcc + (operation.outils ? operation.outils.length : 0);
          }, 0);
        }, 0);
        
        const totalMateriaux = convertedTaches.reduce((acc, tache) => {
          if (!tache.operations) return acc;
          return acc + tache.operations.reduce((subAcc, operation) => {
            return subAcc + (operation.materiaux ? operation.materiaux.length : 0);
          }, 0);
        }, 0);
        
        setStats({
          totalTaches: convertedTaches.length,
          totalOperations,
          totalSousOperations,
          totalRisques,
          totalOutils,
          totalMateriaux
        });
        
        console.log('🎯 Tâches converties et chargées:', convertedTaches.length);
        console.log('📊 Statistiques calculées:', { totalTaches: convertedTaches.length, totalOperations, totalSousOperations, totalRisques, totalOutils, totalMateriaux });
      } else {
        console.log('❌ Aucune donnée AST trouvée pour:', corpsMetier);
        setTaches([]);
        setStats({ totalTaches: 0, totalOperations: 0, totalSousOperations: 0, totalRisques: 0, totalOutils: 0, totalMateriaux: 0 });
      }
    } catch (error) {
      console.error('❌ Erreur chargement données AST:', error);
      setTaches([]);
      setStats({ totalTaches: 0, totalOperations: 0, totalSousOperations: 0, totalRisques: 0, totalOutils: 0, totalMateriaux: 0 });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    // Éviter les rechargements inutiles sur iPad
    if (refreshKey === lastRefreshKeyRef.current && lastRefreshKeyRef.current !== 0) {
      console.log('🔄 Même refreshKey, éviter rechargement inutile iPad:', refreshKey);
      return;
    }
    
    console.log('🔄 useASTData useEffect - corpsMetier:', corpsMetier, 'refreshKey:', refreshKey);
    lastRefreshKeyRef.current = refreshKey;
    loadASTData();
  }, [corpsMetier, refreshKey]);

  return {
    taches,
    isLoading,
    stats,
    loadASTData
  };
};
