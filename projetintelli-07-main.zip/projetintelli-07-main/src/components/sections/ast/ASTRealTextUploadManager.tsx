
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { FileText, Upload, CheckCircle, AlertCircle, Code } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { astRealHtmlExtractionService } from '@/services/astRealHtmlExtractionService';
import { astDataService } from '@/services/astDataService';

interface ASTRealTextUploadManagerProps {
  corpsMetier: string;
  onDataExtracted: () => void;
}

export const ASTRealTextUploadManager = ({ corpsMetier, onDataExtracted }: ASTRealTextUploadManagerProps) => {
  const [htmlContent, setHtmlContent] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleExtractFromHtml = async () => {
    if (!htmlContent.trim()) {
      toast({
        title: "Contenu HTML manquant",
        description: "Veuillez coller le contenu HTML avec les tâches, opérations et sous-opérations",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      console.log('🚀 === DÉBUT EXTRACTION HTML RÉELLE ===');
      
      const extractedData = await astRealHtmlExtractionService.extractFromHtml(htmlContent, corpsMetier);
      
      const astData = {
        corpsMetier,
        taches: extractedData.taches,
        extractedAt: new Date().toISOString()
      };

      // Sauvegarder les données
      astDataService.saveASTData(astData);

      const totalOperations = astData.taches.reduce((acc, t) => acc + t.operations.length, 0);
      const totalSousOperations = astData.taches.reduce((acc, t) => acc + t.operations.reduce((subAcc, op) => subAcc + op.sousOperations.length, 0), 0);

      toast({
        title: "Extraction HTML réussie ! 🎉",
        description: `${astData.taches.length} tâches, ${totalOperations} opérations et ${totalSousOperations} sous-opérations extraites RÉELLEMENT du HTML pour ${corpsMetier}`,
      });

      // Réinitialiser le formulaire
      setHtmlContent('');
      
      // Notifier le parent
      onDataExtracted();
      
      console.log('🎉 === EXTRACTION HTML RÉELLE TERMINÉE ===');
      
    } catch (error) {
      console.error('❌ Erreur extraction HTML réelle:', error);
      
      toast({
        title: "Erreur d'extraction HTML",
        description: error instanceof Error ? error.message : "Erreur inconnue lors de l'extraction du HTML",
        variant: "destructive"
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const hasExistingData = astDataService.hasASTData(corpsMetier);

  return (
    <div className="space-y-6">
      <Card className="border-green-200 bg-green-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-green-700">
            <Code className="w-5 h-5" />
            Extraction AST RÉELLE depuis HTML - {corpsMetier}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          
          {hasExistingData && (
            <div className="flex items-center gap-2 p-3 bg-green-100 border border-green-200 rounded-lg">
              <CheckCircle className="w-5 h-5 text-green-600" />
              <span className="text-sm text-green-700">
                Des données AST existent déjà pour ce corps de métier. L'extraction remplacera les données existantes.
              </span>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-sm font-medium text-gray-700">
              Contenu HTML avec les tâches réelles :
            </label>
            <Textarea
              value={htmlContent}
              onChange={(e) => setHtmlContent(e.target.value)}
              placeholder="Collez ici le contenu HTML de votre fichier avec les vraies tâches, opérations et sous-opérations..."
              className="min-h-[400px] font-mono text-xs"
              disabled={isProcessing}
            />
            <div className="flex justify-between items-center text-xs text-gray-500">
              <span>{htmlContent.length} caractères</span>
              <span>Extraction RÉELLE du contenu HTML fourni</span>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={handleExtractFromHtml}
              disabled={!htmlContent.trim() || isProcessing}
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Extraction RÉELLE en cours...
                </>
              ) : (
                <>
                  <Upload className="w-4 h-4" />
                  Extraire RÉELLEMENT du HTML
                </>
              )}
            </Button>
            
            <Button
              variant="outline"
              onClick={() => setHtmlContent('')}
              disabled={isProcessing}
            >
              Effacer
            </Button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4">
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-green-600">Analyse RÉELLE</Badge>
              <span className="text-xs text-gray-600">Parse le HTML fourni</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-blue-600">Multi-méthodes</Badge>
              <span className="text-xs text-gray-600">Listes, patterns, structure</span>
            </div>
            <div className="flex items-center gap-2 p-2 bg-white rounded border">
              <Badge variant="outline" className="text-purple-600">Contextuel</Badge>
              <span className="text-xs text-gray-600">Risques, outils adaptés</span>
            </div>
          </div>

          <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <p className="font-medium">Service d'extraction RÉELLE :</p>
                <ul className="list-disc list-inside mt-1 space-y-1 text-xs">
                  <li>Analyse les listes HTML (ol, ul)</li>
                  <li>Détecte les patterns de numérotation (1., 1.1, 1.1.1)</li>
                  <li>Parse le contenu structuré et les titres</li>
                  <li>Génère des risques, outils et matériaux contextuels</li>
                </ul>
              </div>
            </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
};
