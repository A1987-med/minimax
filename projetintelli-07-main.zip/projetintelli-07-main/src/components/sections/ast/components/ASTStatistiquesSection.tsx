
import React from 'react';

interface ASTStatistiquesSectionProps {
  totalTravailleurs: number;
  nombreMetiers: number;
}

export const ASTStatistiquesSection = ({ totalTravailleurs, nombreMetiers }: ASTStatistiquesSectionProps) => {
  return (
    <div className="mt-6 p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg">
      <h4 className="font-semibold text-blue-800 mb-3">Statistiques AST</h4>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
        <div className="text-center">
          <div className="text-2xl font-bold text-blue-600">{totalTravailleurs}</div>
          <div className="text-gray-600">Total travailleurs</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-green-600">{nombreMetiers}</div>
          <div className="text-gray-600">Corps de métier</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-orange-600">2</div>
          <div className="text-gray-600">AST développés</div>
        </div>
        <div className="text-center">
          <div className="text-2xl font-bold text-purple-600">{Math.round((2 / nombreMetiers) * 100)}%</div>
          <div className="text-gray-600">Couverture AST</div>
        </div>
      </div>
    </div>
  );
};
