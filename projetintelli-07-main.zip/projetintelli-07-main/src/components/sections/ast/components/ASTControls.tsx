
import React from 'react';
import { Button } from "@/components/ui/button";
import { ChevronDown, ChevronRight, RefreshCw } from "lucide-react";

interface ASTControlsProps {
  corpsMetier: string;
  isLoading: boolean;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onRefresh: () => void;
}

export const ASTControls = ({ 
  corpsMetier, 
  isLoading, 
  onExpandAll, 
  onCollapseAll, 
  onRefresh 
}: ASTControlsProps) => {
  return (
    <div className="flex items-center justify-between mb-4">
      <h3 className="text-lg font-semibold text-foreground">
        Organigramme AST - {corpsMetier}
      </h3>
      <div className="flex items-center gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onExpandAll}
          className="flex items-center gap-2"
        >
          <ChevronDown className="w-4 h-4" />
          Tout développer
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onCollapseAll}
          className="flex items-center gap-2"
        >
          <ChevronRight className="w-4 h-4" />
          Tout réduire
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onRefresh}
          disabled={isLoading}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          Actualiser
        </Button>
      </div>
    </div>
  );
};
