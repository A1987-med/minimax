
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Users, Briefcase, User } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { entryService } from '@/services/accueilService';

interface ASTDetectedOccupationsCardProps {
  occupations: string[];
  onMetierSelect?: (metier: string) => void;
}

export const ASTDetectedOccupationsCard = ({ occupations, onMetierSelect }: ASTDetectedOccupationsCardProps) => {
  // Charger tous les travailleurs pour afficher les noms
  const { data: travailleurs = [] } = useQuery({
    queryKey: ['entries'],
    queryFn: () => entryService.getAll(),
  });

  console.log('🔍 ASTDetectedOccupationsCard - Données reçues:', {
    occupations,
    nombreTravailleurs: travailleurs.length,
    travailleurs: travailleurs.map(t => ({
      id: t.id,
      nom: t.nom,
      prenom: t.prenom,
      nomEmploye: t.nomEmploye,
      occupation: t.occupation, // Champ occupation individual
      occupations: t.occupations, // Champ occupations array
      soustraitant: t.soustraitant
    }))
  });

  // Grouper les employés par occupation
  const employesParOccupation = React.useMemo(() => {
    const groupes: Record<string, any[]> = {};
    
    console.log('🔄 Début groupement des employés pour les occupations:', occupations);
    
    travailleurs.forEach((emp: any) => {
      console.log('👤 Analyse employé:', {
        id: emp.id,
        nom: emp.nom,
        prenom: emp.prenom,
        nomEmploye: emp.nomEmploye,
        occupation: emp.occupation,
        occupations: emp.occupations,
        typeOccupation: typeof emp.occupation,
        typeOccupations: typeof emp.occupations,
        isArrayOccupations: Array.isArray(emp.occupations)
      });
      
      // Fonction pour ajouter un employé à une occupation
      const ajouterEmployeAOccupation = (occupation: string) => {
        if (!groupes[occupation]) {
          groupes[occupation] = [];
          console.log(`📝 Création nouveau groupe pour: ${occupation}`);
        }
        
        // Éviter les doublons en vérifiant l'ID
        if (!groupes[occupation].find(e => e.id === emp.id)) {
          groupes[occupation].push(emp);
          console.log(`✅ Employé ajouté à ${occupation}:`, emp.nomEmploye || `${emp.prenom} ${emp.nom}`);
        } else {
          console.log(`⚠️ Employé déjà présent dans ${occupation}`);
        }
      };

      // Chercher dans le champ occupation (string)
      if (emp.occupation && typeof emp.occupation === 'string' && emp.occupation.trim() && 
          emp.occupation !== 'Non spécifié' && emp.occupation !== 'Valide' && emp.occupation !== 'Échue') {
        const occupation = emp.occupation.trim();
        console.log(`🎯 Occupation trouvée (occupation string): ${occupation}`);
        
        // Vérifier si cette occupation est dans la liste des occupations à afficher
        if (occupations.includes(occupation)) {
          console.log(`✅ Occupation correspondante trouvée: ${occupation}`);
          ajouterEmployeAOccupation(occupation);
        } else {
          console.log(`❌ Occupation non correspondante: ${occupation} (pas dans:`, occupations, ')');
        }
      }

      // Chercher dans le champ occupations (array)
      if (emp.occupations && Array.isArray(emp.occupations)) {
        console.log(`📋 Analyse occupations array pour ${emp.nom}:`, emp.occupations);
        emp.occupations.forEach(occ => {
          if (occ && typeof occ === 'string' && occ.trim() && 
              occ !== 'Non spécifié' && occ !== 'Valide' && occ !== 'Échue') {
            const occupation = occ.trim();
            console.log(`🎯 Occupation trouvée (occupations array): ${occupation}`);
            
            // Vérifier si cette occupation est dans la liste des occupations à afficher
            if (occupations.includes(occupation)) {
              console.log(`✅ Occupation correspondante trouvée: ${occupation}`);
              ajouterEmployeAOccupation(occupation);
            } else {
              console.log(`❌ Occupation non correspondante: ${occupation} (pas dans:`, occupations, ')');
            }
          }
        });
      } else {
        console.log(`❌ Pas d'occupations array valides pour ${emp.nom}:`, emp.occupations);
      }
    });

    console.log('📊 Groupes finaux par occupation:', groupes);
    console.log('📊 Nombre d\'employés par occupation:', Object.entries(groupes).map(([occ, emps]) => `${occ}: ${emps.length}`));
    return groupes;
  }, [travailleurs, occupations]);

  console.log('📋 Occupations à afficher:', occupations);
  console.log('👥 Employés groupés par occupation:', employesParOccupation);

  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-green-700">
          <Users className="w-5 h-5" />
          Métiers détectés chez vos employés
          <Badge variant="outline" className="ml-auto text-green-600">
            {occupations.length} métier{occupations.length > 1 ? 's' : ''}
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-sm text-green-700 mb-4">
          Occupations trouvées dans votre base de données d'employés :
        </div>

        <div className="space-y-3">
          {occupations.map((occupation) => {
            const employes = employesParOccupation[occupation] || [];
            
            console.log(`🔍 Rendu occupation ${occupation}:`, {
              nombreEmployes: employes.length,
              employes: employes.map(e => ({
                id: e.id,
                nom: e.nom,
                prenom: e.prenom,
                nomEmploye: e.nomEmploye,
                soustraitant: e.soustraitant
              }))
            });
            
            return (
              <div key={occupation} className="bg-white rounded-lg p-4 border border-green-200">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <Briefcase className="w-4 h-4 text-green-600" />
                    <span className="font-semibold text-green-800">{occupation}</span>
                    <Badge variant="outline" className="text-green-600">
                      {employes.length} employé{employes.length > 1 ? 's' : ''}
                    </Badge>
                  </div>
                  {onMetierSelect && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onMetierSelect(occupation)}
                      className="text-green-700 border-green-300 hover:bg-green-100"
                    >
                      Analyser AST
                    </Button>
                  )}
                </div>

                {/* Liste des employés pour cette occupation */}
                {employes.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {employes.map((employe) => {
                      const nomAffiche = employe.nomEmploye || `${employe.prenom || ''} ${employe.nom || ''}`.trim() || 'Nom non spécifié';
                      const soustraitant = employe.soustraitant || 'Entreprise non spécifiée';
                      
                      console.log(`👤 Rendu employé:`, {
                        id: employe.id,
                        nomAffiche,
                        soustraitant,
                        donneesBrutes: employe
                      });
                      
                      return (
                        <div key={employe.id} className="flex items-center gap-2 p-2 bg-green-50 rounded text-sm">
                          <User className="w-3 h-3 text-green-600" />
                          <span className="text-green-800 font-medium">
                            {nomAffiche}
                          </span>
                          <span className="text-green-600 text-xs">
                            ({soustraitant})
                          </span>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-sm text-gray-500 italic">
                    Aucun employé trouvé pour cette occupation (occupation: {occupation})
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {occupations.length === 0 && (
          <div className="text-sm text-gray-500 italic text-center py-4">
            Aucune occupation détectée dans votre base de données
          </div>
        )}

        <div className="text-xs text-green-600 mt-4">
          💡 Cliquez sur "Analyser AST" pour voir l'analyse sécuritaire des tâches pour ce métier
        </div>
      </CardContent>
    </Card>
  );
};
