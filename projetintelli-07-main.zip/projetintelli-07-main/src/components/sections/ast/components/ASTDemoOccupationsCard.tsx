
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TreePine } from "lucide-react";

interface ASTDemoOccupationsCardProps {
  onMetierSelect?: (metier: string) => void;
}

const DEMO_METIERS = ['Calorifugeur', 'Arpenteur', 'Électricien', 'Plombier'];

export const ASTDemoOccupationsCard = ({ onMetierSelect }: ASTDemoOccupationsCardProps) => {
  return (
    <Card className="border-purple-200 bg-purple-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-purple-700">
          <TreePine className="w-5 h-5" />
          Métiers de Test Disponibles
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-sm text-purple-600 mb-4">
          Métiers avec données AST prêtes à utiliser :
        </div>
        <div className="space-y-3">
          {DEMO_METIERS.map((metier) => (
            <div key={metier} className="border border-purple-200 rounded-lg p-3 bg-white">
              <div className="flex items-center justify-between">
                <Badge variant="secondary" className="bg-purple-100 text-purple-700 border-purple-200">
                  {metier}
                </Badge>
                {onMetierSelect && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => onMetierSelect(metier)}
                    className="flex items-center gap-1 text-xs bg-purple-50 hover:bg-purple-100 text-purple-700 border-purple-200"
                  >
                    <TreePine className="w-3 h-3" />
                    Voir AST
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
