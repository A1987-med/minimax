
import React from 'react';
import { useQuery } from "@tanstack/react-query";
import { occupationService } from '@/services/occupationService';
import { ASTLoadingCard } from './ASTLoadingCard';
import { ASTErrorCard } from './ASTErrorCard';
import { ASTEmptyOccupationsCard } from './ASTEmptyOccupationsCard';
import { ASTDetectedOccupationsCard } from './ASTDetectedOccupationsCard';
import { ASTDemoOccupationsCard } from './ASTDemoOccupationsCard';

interface ASTOccupationsDisplayProps {
  onMetierSelect?: (metier: string) => void;
}

export const ASTOccupationsDisplay = ({ onMetierSelect }: ASTOccupationsDisplayProps) => {
  // Charger les occupations des employés
  const { data: occupationsEmployes = [], isLoading, error } = useQuery({
    queryKey: ['employee-occupations'],
    queryFn: () => occupationService.getEmployeeOccupations(),
  });

  console.log('🔍 AST Occupations Display:', {
    nombreOccupations: occupationsEmployes.length,
    occupations: occupationsEmployes
  });

  if (isLoading) {
    return <ASTLoadingCard />;
  }

  if (error) {
    return <ASTErrorCard error={error} />;
  }

  return (
    <div className="space-y-4">
      {occupationsEmployes.length === 0 ? (
        <ASTEmptyOccupationsCard employeesCount={0} />
      ) : (
        <ASTDetectedOccupationsCard 
          occupations={occupationsEmployes} 
          onMetierSelect={onMetierSelect} 
        />
      )}

      <ASTDemoOccupationsCard onMetierSelect={onMetierSelect} />
    </div>
  );
};
