
import React from 'react';
import { UserCheck, Building2, Briefcase } from "lucide-react";

interface Travailleur {
  id: string;
  nom: string;
  prenom: string;
  occupation: string;
  sous_traitant: string;
}

interface ASTTravailleurCardProps {
  travailleur: Travailleur;
}

export const ASTTravailleurCard = ({ travailleur }: ASTTravailleurCardProps) => {
  return (
    <div className="p-3 border rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors">
      <div className="flex items-start justify-between">
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-2">
            <UserCheck className="w-4 h-4 text-green-600" />
            <span className="font-medium text-sm">
              {travailleur.prenom} {travailleur.nom}
            </span>
          </div>
          
          <div className="space-y-1">
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Building2 className="w-3 h-3" />
              <span>{travailleur.sous_traitant}</span>
            </div>
            
            <div className="flex items-center gap-2 text-xs text-gray-600">
              <Briefcase className="w-3 h-3" />
              <span>{travailleur.occupation}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
