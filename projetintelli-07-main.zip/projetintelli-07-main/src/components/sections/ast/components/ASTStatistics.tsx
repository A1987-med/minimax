
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { BarChart3 } from "lucide-react";

interface ASTStatisticsProps {
  stats: {
    totalTaches: number;
    totalOperations: number;
    totalSousOperations: number;
    totalRisques: number;
    totalOutils: number;
    totalMateriaux: number;
  };
}

export const ASTStatistics = ({ stats }: ASTStatisticsProps) => {
  return (
    <Card className="border-primary/20 bg-primary/10 dark:bg-primary/5">
      <CardContent className="p-4">
        <div className="flex items-center gap-4">
          <BarChart3 className="w-5 h-5 text-primary" />
          <div className="flex gap-6 text-sm">
            <span className="text-primary font-medium">📋 {stats.totalTaches} tâches</span>
            <span className="text-blue-600 dark:text-blue-400 font-medium">🏗️ {stats.totalOperations} opérations</span>
            <span className="text-purple-600 dark:text-purple-400 font-medium">🔧 {stats.totalSousOperations} sous-opérations</span>
            <span className="text-red-600 dark:text-red-400 font-medium">⚠️ {stats.totalRisques} risques</span>
            <span className="text-green-600 dark:text-green-400 font-medium">🛠️ {stats.totalOutils} outils</span>
            <span className="text-orange-600 dark:text-orange-400 font-medium">📦 {stats.totalMateriaux} matériaux</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
