
import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, AlertTriangle } from "lucide-react";
import { ASTRisquesList } from './ASTRisquesList';

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface SousOperation {
  id: string;
  nom: string;
  description: string;
  risques: Risque[];
}

interface ASTSousOperationCardProps {
  sousOperation: SousOperation;
  isExpanded: boolean;
  onToggle: (id: string, event?: React.MouseEvent) => void;
}

export const ASTSousOperationCard = ({ 
  sousOperation, 
  isExpanded, 
  onToggle 
}: ASTSousOperationCardProps) => {
  
  const handleBadgeClick = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    
    console.log('🟣 Badge sous-opération cliqué:', sousOperation.nom);
    
    // Forcer l'ouverture de la sous-opération
    if (!isExpanded) {
      onToggle(sousOperation.id, event);
    }
  };

  return (
    <div className="border-l-4 border-purple-300 dark:border-purple-700 pl-4">
      <div className="p-3 border border-purple-200 dark:border-purple-800 rounded bg-purple-50 dark:bg-purple-900/20">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={(e) => onToggle(sousOperation.id, e)}
              className="p-1 h-6 w-6"
            >
              {isExpanded ? 
                <ChevronDown className="w-3 h-3" /> : 
                <ChevronRight className="w-3 h-3" />
              }
            </Button>
            <span className="font-medium text-purple-800 dark:text-purple-300">{sousOperation.nom}</span>
          </div>
          {sousOperation.risques && sousOperation.risques.length > 0 && (
            <Badge 
              variant="outline" 
              className="text-red-600 dark:text-red-400 text-xs cursor-pointer hover:bg-red/10 transition-colors"
              onClick={handleBadgeClick}
            >
              {sousOperation.risques.length} risque(s)
            </Badge>
          )}
        </div>
        <div className="text-sm text-purple-600 dark:text-purple-400 mb-2">{sousOperation.description}</div>
        
        {isExpanded && sousOperation.risques && sousOperation.risques.length > 0 && (
          <div className="mt-2 space-y-1">
            <h6 className="text-xs font-medium text-red-600 mb-1 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Risques spécifiques:
            </h6>
            <ASTRisquesList risques={sousOperation.risques} title="" />
          </div>
        )}
      </div>
    </div>
  );
};
