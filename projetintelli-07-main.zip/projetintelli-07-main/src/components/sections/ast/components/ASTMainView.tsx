
import React from 'react';
import { ASTOccupationsDisplay } from './ASTOccupationsDisplay';
import { ASTCalorifugeurDemo } from '../ASTCalorifugeurDemo';
import { ASTControls } from './ASTControls';
import { ASTStatistics } from './ASTStatistics';
import { ASTTacheCard } from './ASTTacheCard';

interface ASTMainViewProps {
  corpsMetier: string;
  onMetierSelect?: (metier: string) => void;
  isLoading: boolean;
  stats: any;
  taches: any[];
  expandedTaches: Set<string>;
  expandedOperations: Set<string>;
  expandedSousOperations: Set<string>;
  onExpandAll: () => void;
  onCollapseAll: () => void;
  onRefresh: () => void;
  onToggleTache: (id: string) => void;
  onToggleOperation: (id: string) => void;
  onOperationBadgeClick: (id: string, event: React.MouseEvent) => void;
  onToggleSousOperation: (id: string, event?: React.MouseEvent) => void;
}

export const ASTMainView = ({
  corpsMetier,
  onMetierSelect,
  isLoading,
  stats,
  taches,
  expandedTaches,
  expandedOperations,
  expandedSousOperations,
  onExpandAll,
  onCollapseAll,
  onRefresh,
  onToggleTache,
  onToggleOperation,
  onOperationBadgeClick,
  onToggleSousOperation
}: ASTMainViewProps) => {
  return (
    <div className="space-y-4">
      <ASTOccupationsDisplay onMetierSelect={onMetierSelect} />
      
      {/* Charger automatiquement les données de démo pour le calorifugeur */}
      {corpsMetier === 'Calorifugeur' && <ASTCalorifugeurDemo />}
      
      <ASTControls
        corpsMetier={corpsMetier}
        isLoading={isLoading}
        onExpandAll={onExpandAll}
        onCollapseAll={onCollapseAll}
        onRefresh={onRefresh}
      />

      <ASTStatistics stats={stats} />

      <div className="space-y-3">
        {taches.map((tache) => (
          <ASTTacheCard
            key={tache.id}
            tache={tache}
            isExpanded={expandedTaches.has(tache.id)}
            expandedOperations={expandedOperations}
            expandedSousOperations={expandedSousOperations}
            onToggle={onToggleTache}
            onOperationToggle={onToggleOperation}
            onOperationBadgeClick={onOperationBadgeClick}
            onSousOperationToggle={onToggleSousOperation}
          />
        ))}
      </div>
    </div>
  );
};
