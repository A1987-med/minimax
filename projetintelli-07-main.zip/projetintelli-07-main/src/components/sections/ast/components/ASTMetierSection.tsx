
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Briefcase } from "lucide-react";
import { ASTTravailleurCard } from './ASTTravailleurCard';

interface Travailleur {
  id: string;
  nom: string;
  prenom: string;
  occupation: string;
  sous_traitant: string;
}

interface ASTMetierSectionProps {
  metier: string;
  travailleurs: Travailleur[];
}

export const ASTMetierSection = ({ metier, travailleurs }: ASTMetierSectionProps) => {
  const hasASTDeveloped = metier.toLowerCase().includes('calorifugeur') || metier.toLowerCase().includes('arpenteur');

  return (
    <div className="border rounded-lg p-4 bg-white shadow-sm">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-800">{metier}</h3>
          <Badge variant="secondary">
            {travailleurs.length} travailleur{travailleurs.length > 1 ? 's' : ''}
          </Badge>
        </div>
        
        {hasASTDeveloped && (
          <Badge variant="default" className="bg-green-100 text-green-800">
            AST Disponible
          </Badge>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {travailleurs.map((travailleur) => (
          <ASTTravailleurCard key={travailleur.id} travailleur={travailleur} />
        ))}
      </div>

      {hasASTDeveloped ? (
        <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
          <p className="text-sm text-green-800">
            <strong>✅ AST Développé:</strong> Une analyse sécuritaire des tâches complète est disponible 
            pour ce corps de métier dans la section AST principale.
          </p>
        </div>
      ) : (
        <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>ℹ️ À développer:</strong> L'analyse sécuritaire des tâches pour ce métier peut être 
            ajoutée selon les besoins du projet.
          </p>
        </div>
      )}
    </div>
  );
};
