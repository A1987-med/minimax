
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface ASTRisquesListProps {
  risques: Risque[];
  title: string;
}

export const ASTRisquesList = ({ risques, title }: ASTRisquesListProps) => {
  const getRisqueColor = (niveau: string) => {
    switch (niveau) {
      case 'faible': return 'text-green-700 bg-green-100 border-green-300 dark:text-green-300 dark:bg-green-900/50 dark:border-green-700';
      case 'moyen': return 'text-yellow-700 bg-yellow-100 border-yellow-300 dark:text-yellow-300 dark:bg-yellow-900/50 dark:border-yellow-700';
      case 'eleve': return 'text-orange-700 bg-orange-100 border-orange-300 dark:text-orange-300 dark:bg-orange-900/50 dark:border-orange-700';
      case 'critique': return 'text-red-700 bg-red-100 border-red-300 dark:text-red-300 dark:bg-red-900/50 dark:border-red-700';
      default: return 'text-gray-700 bg-gray-100 border-gray-300 dark:text-gray-300 dark:bg-gray-800 dark:border-gray-600';
    }
  };

  if (risques.length === 0) return null;

  return (
    <div>
      <h5 className="flex items-center gap-2 font-medium text-red-700 dark:text-red-400 mb-2">
        <AlertTriangle className="w-4 h-4" />
        {title}
      </h5>
      <div className="space-y-2">
        {risques.map((risque) => (
          <div key={risque.id} className={`p-3 border rounded-lg ${getRisqueColor(risque.niveau)}`}>
            <div className="flex items-center justify-between mb-2">
              <span className="font-medium">{risque.description}</span>
              <Badge className={getRisqueColor(risque.niveau)}>
                {risque.niveau.toUpperCase()}
              </Badge>
            </div>
            {risque.mesuresPrevention && risque.mesuresPrevention.length > 0 && (
              <div className="text-sm">
                <strong>Mesures de prévention :</strong>
                <ul className="list-disc list-inside mt-1">
                  {risque.mesuresPrevention.map((mesure, index) => (
                    <li key={index}>{mesure}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
