
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users } from "lucide-react";

export const ASTLoadingCard = () => {
  return (
    <Card className="border-blue-200 bg-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-blue-700">
          <Users className="w-5 h-5" />
          Chargement des métiers...
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-sm text-blue-600">
          Recherche des occupations dans la base de données...
        </div>
      </CardContent>
    </Card>
  );
};
