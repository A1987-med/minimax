
import React from 'react';
import { RefreshCw } from "lucide-react";

export const ASTLoadingState = () => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-center p-8">
        <RefreshCw className="w-8 h-8 animate-spin text-primary" />
        <span className="ml-2 text-lg text-foreground">Chargement des données AST...</span>
      </div>
    </div>
  );
};
