
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";

interface ASTErrorCardProps {
  error: Error;
}

export const ASTErrorCard = ({ error }: ASTErrorCardProps) => {
  console.error('❌ ERREUR CHARGEMENT:', error);
  
  return (
    <Card className="border-red-200 bg-red-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-red-700">
          <AlertCircle className="w-5 h-5" />
          Erreur de chargement
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-sm text-red-600">
          Erreur: {error.message}
        </div>
      </CardContent>
    </Card>
  );
};
