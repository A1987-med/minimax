
import React from 'react';
import { Package } from "lucide-react";

interface Materiau {
  id: string;
  nom: string;
  type: string;
  precautions: string[];
}

interface ASTMateriauxListProps {
  materiaux: Materiau[];
}

export const ASTMateriauxList = ({ materiaux }: ASTMateriauxListProps) => {
  if (materiaux.length === 0) return null;

  return (
    <div>
      <h5 className="flex items-center gap-2 font-medium text-green-700 dark:text-green-400 mb-2">
        <Package className="w-4 h-4" />
        Matériaux
      </h5>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {materiaux.map((materiau) => (
          <div key={materiau.id} className="p-2 border border-green-200 dark:border-green-800 rounded bg-green-50 dark:bg-green-900/20">
            <div className="font-medium text-green-800 dark:text-green-300">{materiau.nom}</div>
            <div className="text-sm text-green-600 dark:text-green-400">{materiau.type}</div>
            {materiau.precautions && materiau.precautions.length > 0 && (
              <div className="text-xs text-green-500 dark:text-green-400 mt-1">
                {materiau.precautions.join(', ')}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
