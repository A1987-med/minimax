
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Users, AlertCircle } from "lucide-react";

interface ASTEmptyOccupationsCardProps {
  employeesCount: number;
}

export const ASTEmptyOccupationsCard = ({ employeesCount }: ASTEmptyOccupationsCardProps) => {
  return (
    <Card className="border-orange-200 bg-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-orange-700">
          <Users className="w-5 h-5" />
          Métiers du Chantier
          <Badge variant="outline" className="ml-auto text-orange-600">
            {employeesCount} employés
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div>
              <h4 className="font-semibold text-yellow-800 mb-2">Aucune occupation détectée</h4>
              <div className="text-sm text-yellow-700 space-y-2">
                <p>• Employés trouvés : <strong>{employeesCount}</strong></p>
                <p>• Recherche uniquement dans le champ "occupation"</p>
                <p>• Vérifiez que le champ "Occupation" est bien rempli dans Gestion RH</p>
                <p>• Consultez la console pour plus de détails (F12)</p>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
