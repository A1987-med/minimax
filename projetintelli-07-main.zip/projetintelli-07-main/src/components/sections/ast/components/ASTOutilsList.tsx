
import React from 'react';
import { Wrench } from "lucide-react";

interface Outil {
  id: string;
  nom: string;
  type: string;
  securiteRequise: string[];
}

interface ASTOutilsListProps {
  outils: Outil[];
}

export const ASTOutilsList = ({ outils }: ASTOutilsListProps) => {
  if (outils.length === 0) return null;

  return (
    <div>
      <h5 className="flex items-center gap-2 font-medium text-orange-700 dark:text-orange-400 mb-2">
        <Wrench className="w-4 h-4" />
        Outils
      </h5>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
        {outils.map((outil) => (
          <div key={outil.id} className="p-2 border border-orange-200 dark:border-orange-800 rounded bg-orange-50 dark:bg-orange-900/20">
            <div className="font-medium text-orange-800 dark:text-orange-300">{outil.nom}</div>
            <div className="text-sm text-orange-600 dark:text-orange-400">{outil.type}</div>
            {outil.securiteRequise && outil.securiteRequise.length > 0 && (
              <div className="text-xs text-orange-500 dark:text-orange-400 mt-1">
                {outil.securiteRequise.join(', ')}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
