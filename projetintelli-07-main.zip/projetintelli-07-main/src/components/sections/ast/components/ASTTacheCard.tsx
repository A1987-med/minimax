
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, FileText } from "lucide-react";
import { ASTOperationCard } from './ASTOperationCard';

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface Outil {
  id: string;
  nom: string;
  type: string;
  securiteRequise: string[];
}

interface Materiau {
  id: string;
  nom: string;
  type: string;
  precautions: string[];
}

interface SousOperation {
  id: string;
  nom: string;
  description: string;
  risques: Risque[];
}

interface Operation {
  id: string;
  nom: string;
  description: string;
  sousOperations: SousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

interface Tache {
  id: string;
  nom: string;
  description: string;
  operations: Operation[];
}

interface ASTTacheCardProps {
  tache: Tache;
  isExpanded: boolean;
  expandedOperations: Set<string>;
  expandedSousOperations: Set<string>;
  onToggle: (id: string) => void;
  onOperationToggle: (id: string) => void;
  onOperationBadgeClick: (id: string, event: React.MouseEvent) => void;
  onSousOperationToggle: (id: string, event?: React.MouseEvent) => void;
}

export const ASTTacheCard = ({ 
  tache, 
  isExpanded, 
  expandedOperations,
  expandedSousOperations,
  onToggle, 
  onOperationToggle,
  onOperationBadgeClick,
  onSousOperationToggle
}: ASTTacheCardProps) => {
  
  const handleBadgeClick = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    
    console.log('🔵 Badge tâche cliqué:', tache.nom);
    
    // Forcer l'ouverture de la tâche
    if (!isExpanded) {
      onToggle(tache.id);
    }
    
    // Ouvrir toutes les opérations de cette tâche
    tache.operations?.forEach(operation => {
      if (!expandedOperations.has(operation.id)) {
        onOperationToggle(operation.id);
      }
    });
  };

  return (
    <Card className="border-2 border-primary/20 dark:border-primary/30">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggle(tache.id)}
              className="p-1 hover:bg-primary/10"
            >
              {isExpanded ? 
                <ChevronDown className="w-4 h-4" /> : 
                <ChevronRight className="w-4 h-4" />
              }
            </Button>
            <FileText className="w-5 h-5 text-primary" />
            <div className="flex-1">
              <CardTitle className="text-base text-primary font-semibold">{tache.nom}</CardTitle>
              <p className="text-sm text-muted-foreground mt-1">{tache.description}</p>
            </div>
          </div>
          <Badge 
            variant="outline" 
            className="text-primary border-primary/30 shrink-0 cursor-pointer hover:bg-primary/10 transition-colors"
            onClick={handleBadgeClick}
          >
            {tache.operations ? tache.operations.length : 0} opération(s)
          </Badge>
        </div>
      </CardHeader>
      
      {isExpanded && (
        <CardContent className="pt-0">
          <div className="ml-8 space-y-3">
            {(tache.operations || []).map((operation) => (
              <ASTOperationCard
                key={operation.id}
                operation={operation}
                isExpanded={expandedOperations.has(operation.id)}
                expandedSousOperations={expandedSousOperations}
                onToggle={onOperationToggle}
                onBadgeClick={onOperationBadgeClick}
                onSousOperationToggle={onSousOperationToggle}
              />
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  );
};
