
import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, RefreshCw, Plus } from "lucide-react";

interface ASTEmptyStateProps {
  corpsMetier: string;
  onRefresh: () => void;
}

export const ASTEmptyState = ({ corpsMetier, onRefresh }: ASTEmptyStateProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">
          Organigramme AST - {corpsMetier}
        </h3>
        <div className="flex items-center gap-2">
          <Button 
            variant="outline" 
            size="sm" 
            onClick={onRefresh}
            className="flex items-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            Actualiser
          </Button>
          <Button variant="outline" size="sm" className="flex items-center gap-2">
            <Plus className="w-4 h-4" />
            Ajouter une tâche
          </Button>
        </div>
      </div>

      <Card className="border-2 border-dashed border-muted bg-muted/50">
        <CardContent className="p-8 text-center">
          <Upload className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
          <h3 className="text-lg font-medium text-foreground mb-2">
            Aucune donnée AST disponible pour {corpsMetier}
          </h3>
          <p className="text-muted-foreground mb-4">
            Chargez un PDF contenant les analyses sécuritaires des tâches pour ce corps de métier dans l'onglet "Gestion PDFs"
          </p>
          <Badge variant="outline" className="text-amber-600 border-amber-200 bg-amber-50 dark:text-amber-400 dark:border-amber-800 dark:bg-amber-900/20">
            📋 En attente de documentation PDF
          </Badge>
        </CardContent>
      </Card>
    </div>
  );
};
