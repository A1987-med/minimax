
import React from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, Settings } from "lucide-react";
import { ASTSousOperationCard } from './ASTSousOperationCard';
import { ASTRisquesList } from './ASTRisquesList';
import { ASTOutilsList } from './ASTOutilsList';
import { ASTMateriauxList } from './ASTMateriauxList';

interface Risque {
  id: string;
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve' | 'critique';
  mesuresPrevention: string[];
}

interface Outil {
  id: string;
  nom: string;
  type: string;
  securiteRequise: string[];
}

interface Materiau {
  id: string;
  nom: string;
  type: string;
  precautions: string[];
}

interface SousOperation {
  id: string;
  nom: string;
  description: string;
  risques: Risque[];
}

interface Operation {
  id: string;
  nom: string;
  description: string;
  sousOperations: SousOperation[];
  risques: Risque[];
  outils: Outil[];
  materiaux: Materiau[];
}

interface ASTOperationCardProps {
  operation: Operation;
  isExpanded: boolean;
  expandedSousOperations: Set<string>;
  onToggle: (id: string) => void;
  onBadgeClick: (id: string, event: React.MouseEvent) => void;
  onSousOperationToggle: (id: string, event?: React.MouseEvent) => void;
}

export const ASTOperationCard = ({ 
  operation, 
  isExpanded, 
  expandedSousOperations,
  onToggle, 
  onBadgeClick,
  onSousOperationToggle
}: ASTOperationCardProps) => {
  
  const handleBadgeClick = (event: React.MouseEvent) => {
    event.preventDefault();
    event.stopPropagation();
    
    console.log('🟢 Badge opération cliqué:', operation.nom);
    
    // Forcer l'ouverture de l'opération
    if (!isExpanded) {
      onToggle(operation.id);
    }
    
    // Ouvrir toutes les sous-opérations
    operation.sousOperations?.forEach(sousOp => {
      if (!expandedSousOperations.has(sousOp.id)) {
        onSousOperationToggle(sousOp.id);
      }
    });
    
    // Appeler aussi le callback parent
    onBadgeClick(operation.id, event);
  };

  const totalRisques = (operation.risques?.length || 0) + 
                      (operation.sousOperations?.reduce((sum, so) => sum + (so.risques?.length || 0), 0) || 0);

  return (
    <div className="border-l-4 border-blue-300 dark:border-blue-700 pl-4">
      <div className="p-3 border border-blue-200 dark:border-blue-800 rounded bg-blue-50 dark:bg-blue-900/20">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onToggle(operation.id)}
              className="p-1 h-6 w-6"
            >
              {isExpanded ? 
                <ChevronDown className="w-3 h-3" /> : 
                <ChevronRight className="w-3 h-3" />
              }
            </Button>
            <Settings className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span className="font-medium text-blue-800 dark:text-blue-300">{operation.nom}</span>
          </div>
          <div className="flex gap-1">
            {operation.sousOperations && operation.sousOperations.length > 0 && (
              <Badge 
                variant="outline" 
                className="text-purple-600 dark:text-purple-400 text-xs cursor-pointer hover:bg-purple/10 transition-colors"
                onClick={handleBadgeClick}
              >
                {operation.sousOperations.length} sous-op
              </Badge>
            )}
            {totalRisques > 0 && (
              <Badge 
                variant="outline" 
                className="text-red-600 dark:text-red-400 text-xs cursor-pointer hover:bg-red/10 transition-colors"
                onClick={handleBadgeClick}
              >
                {totalRisques} risque(s)
              </Badge>
            )}
            {operation.outils && operation.outils.length > 0 && (
              <Badge 
                variant="outline" 
                className="text-orange-600 dark:text-orange-400 text-xs cursor-pointer hover:bg-orange/10 transition-colors"
                onClick={handleBadgeClick}
              >
                {operation.outils.length} outil(s)
              </Badge>
            )}
            {operation.materiaux && operation.materiaux.length > 0 && (
              <Badge 
                variant="outline" 
                className="text-green-600 dark:text-green-400 text-xs cursor-pointer hover:bg-green/10 transition-colors"
                onClick={handleBadgeClick}
              >
                {operation.materiaux.length} matériau(x)
              </Badge>
            )}
          </div>
        </div>
        <div className="text-sm text-blue-600 dark:text-blue-400 mb-2">{operation.description}</div>
        
        {isExpanded && (
          <div className="mt-3 space-y-3">
            {operation.sousOperations && operation.sousOperations.length > 0 && (
              <div className="space-y-2">
                <h6 className="text-xs font-medium text-purple-600 dark:text-purple-400 mb-1">Sous-opérations:</h6>
                {operation.sousOperations.map((sousOp) => (
                  <ASTSousOperationCard
                    key={sousOp.id}
                    sousOperation={sousOp}
                    isExpanded={expandedSousOperations.has(sousOp.id)}
                    onToggle={onSousOperationToggle}
                  />
                ))}
              </div>
            )}
            
            <ASTRisquesList risques={operation.risques || []} title="Risques de l'opération" />
            <ASTOutilsList outils={operation.outils || []} />
            <ASTMateriauxList materiaux={operation.materiaux || []} />
          </div>
        )}
      </div>
    </div>
  );
};
