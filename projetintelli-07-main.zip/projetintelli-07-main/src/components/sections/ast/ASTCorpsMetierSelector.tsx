
import React from 'react';
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
import { occupationService } from '@/services/occupationService';
import { entryService } from '@/services/accueilService';
import { User, Building2 } from "lucide-react";

interface ASTCorpsMetierSelectorProps {
  selectedCorpsMetier: string;
  onCorpsMetierChange: (value: string) => void;
}

export const ASTCorpsMetierSelector = ({
  selectedCorpsMetier,
  onCorpsMetierChange
}: ASTCorpsMetierSelectorProps) => {
  // Charger toutes les occupations (employés + statiques)
  const { data: occupations = [], isLoading } = useQuery({
    queryKey: ['all-occupations'],
    queryFn: () => occupationService.getAllOccupations(),
  });

  // Charger tous les employés pour afficher les détails
  const { data: employees = [] } = useQuery({
    queryKey: ['employees-for-details'],
    queryFn: () => entryService.getAll(),
  });

  // Métiers de test avec données AST disponibles
  const metiersTest = ['Calorifugeur', 'Arpenteur', 'Électricien', 'Plombier'];

  // Séparer les occupations par source
  const occupationsEmployes = occupations.filter(occ => occ.source === 'employees');
  const occupationsStatiques = occupations.filter(occ => occ.source === 'static');

  // Trouver les employés pour l'occupation sélectionnée
  const employesPourOccupation = React.useMemo(() => {
    if (!selectedCorpsMetier) return [];
    
    return employees.filter(emp => {
      // Vérifier dans le champ occupation (string)
      if (emp.occupation && emp.occupation.trim() === selectedCorpsMetier) {
        return true;
      }
      
      // Vérifier dans le champ occupations (array)
      if (emp.occupations && Array.isArray(emp.occupations)) {
        return emp.occupations.includes(selectedCorpsMetier);
      }
      
      return false;
    });
  }, [employees, selectedCorpsMetier]);

  return (
    <div className="space-y-3">
      <Label htmlFor="occupation-selector" className="text-base font-medium">
        Occupation pour l'analyse AST
      </Label>
      <Select value={selectedCorpsMetier} onValueChange={onCorpsMetierChange} disabled={isLoading}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder={isLoading ? "Chargement..." : "Sélectionner une occupation..."} />
        </SelectTrigger>
        <SelectContent className="bg-popover border border-border shadow-lg z-50">
          {/* Section: Occupations détectées chez vos employés */}
          {occupationsEmployes.length > 0 && (
            <>
              <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                Occupations de vos employés ({occupationsEmployes.length})
              </div>
              {occupationsEmployes.map((occupation) => (
                <SelectItem key={occupation.nom} value={occupation.nom} className="cursor-pointer hover:bg-accent hover:text-accent-foreground">
                  <div className="flex items-center justify-between w-full">
                    <span>{occupation.nom}</span>
                    <Badge variant="outline" className="text-xs ml-2 bg-green-100 text-green-700 border-green-300">
                      {occupation.employeesCount} emp.
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </>
          )}
          
          {/* Séparateur si on a les deux sections */}
          {occupationsEmployes.length > 0 && (
            <div className="h-px bg-border mx-2 my-1"></div>
          )}
          
          {/* Section: Métiers de test */}
          <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
            Métiers de démonstration ({metiersTest.length})
          </div>
          {metiersTest.map((metier) => (
            <SelectItem key={metier} value={metier} className="cursor-pointer hover:bg-accent hover:text-accent-foreground">
              <div className="flex items-center justify-between w-full">
                <span>{metier}</span>
                <Badge variant="outline" className="text-xs ml-2 bg-purple-100 text-purple-700 border-purple-300">
                  Démo
                </Badge>
              </div>
            </SelectItem>
          ))}

          {/* Section: Catalogue d'occupations */}
          {occupationsStatiques.length > 0 && (
            <>
              <div className="h-px bg-border mx-2 my-1"></div>
              <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground bg-muted/50">
                Catalogue d'occupations ({occupationsStatiques.length})
              </div>
              {occupationsStatiques.map((occupation) => (
                <SelectItem key={occupation.nom} value={occupation.nom} className="cursor-pointer hover:bg-accent hover:text-accent-foreground">
                  <div className="flex items-center justify-between w-full">
                    <span>{occupation.nom}</span>
                    <Badge variant="outline" className="text-xs ml-2 bg-blue-100 text-blue-700 border-blue-300">
                      Catalogue
                    </Badge>
                  </div>
                </SelectItem>
              ))}
            </>
          )}
        </SelectContent>
      </Select>
      
      {selectedCorpsMetier && (
        <div className="space-y-3">
          <div className="flex items-center gap-2 p-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-800/30 rounded-lg">
            <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-blue-700 dark:text-blue-300">
              Analyse sécuritaire activée pour : <strong>{selectedCorpsMetier}</strong>
              {employesPourOccupation.length > 0 && (
                <span className="ml-1 text-green-600">
                  ({employesPourOccupation.length} employé{employesPourOccupation.length > 1 ? 's' : ''})
                </span>
              )}
            </span>
          </div>

          {/* Liste des employés pour cette occupation */}
          {employesPourOccupation.length > 0 && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <div className="text-sm font-medium text-green-800 mb-3">
                Employés concernés par cette analyse :
              </div>
              <div className="space-y-2">
                {employesPourOccupation.map((employe) => {
                  const nomAffiche = employe.nomEmploye || `${employe.prenom || ''} ${employe.nom || ''}`.trim() || 'Nom non spécifié';
                  const soustraitant = employe.soustraitant || employe.nomSousTraitant || employe.entreprise || 'Entreprise non spécifiée';
                  
                  return (
                    <div key={employe.id} className="flex items-center gap-3 p-2 bg-white rounded border border-green-100">
                      <User className="w-4 h-4 text-green-600 flex-shrink-0" />
                      <div className="flex-1">
                        <div className="font-medium text-green-900 text-sm">
                          {nomAffiche}
                        </div>
                        <div className="flex items-center gap-1 text-xs text-green-700">
                          <Building2 className="w-3 h-3" />
                          {soustraitant}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
      
      {occupationsEmployes.length === 0 && !isLoading && (
        <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
          <div className="text-sm text-yellow-700">
            <strong>Aucune occupation détectée chez vos employés.</strong><br />
            Vérifiez que le champ "Occupation" est rempli dans Gestion RH, ou utilisez les métiers de démonstration.
          </div>
        </div>
      )}
    </div>
  );
};
