
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ChevronDown, ChevronRight, Briefcase, Wrench, Cog } from "lucide-react";
import { calorifugeurASTData } from '../../../data/calorifugeurData';
import { CalorifugeurTache, CalorifugeurOperation, CalorifugeurSousOperation, CalorifugeurOutil } from '../../../types/calorifugeur';

export const ASTCalorifugeurOrganigramme = () => {
  const [expandedTaches, setExpandedTaches] = useState<Set<string>>(new Set());
  const [expandedOperations, setExpandedOperations] = useState<Set<string>>(new Set());

  const toggleTache = (tacheId: string) => {
    setExpandedTaches(prev => {
      const newSet = new Set(prev);
      if (newSet.has(tacheId)) {
        newSet.delete(tacheId);
      } else {
        newSet.add(tacheId);
      }
      return newSet;
    });
  };

  const toggleOperation = (operationId: string) => {
    setExpandedOperations(prev => {
      const newSet = new Set(prev);
      if (newSet.has(operationId)) {
        newSet.delete(operationId);
      } else {
        newSet.add(operationId);
      }
      return newSet;
    });
  };

  const expandAll = () => {
    const allTaches = new Set(calorifugeurASTData.taches.map(t => t.id));
    const allOperations = new Set(calorifugeurASTData.taches.flatMap(t => t.operations.map(op => op.id)));
    setExpandedTaches(allTaches);
    setExpandedOperations(allOperations);
  };

  const collapseAll = () => {
    setExpandedTaches(new Set());
    setExpandedOperations(new Set());
  };

  const totalOperations = calorifugeurASTData.taches.reduce((sum, tache) => sum + tache.operations.length, 0);
  const totalSousOperations = calorifugeurASTData.taches.reduce((sum, tache) => 
    sum + tache.operations.reduce((subSum, op) => subSum + op.sousOperations.length, 0), 0
  );
  const totalOutils = calorifugeurASTData.taches.reduce((sum, tache) => 
    sum + tache.operations.reduce((subSum, op) => subSum + (op.outils?.length || 0), 0), 0
  );

  return (
    <div className="space-y-6">
      {/* En-tête et statistiques */}
      <Card className="border-blue-200 bg-blue-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-blue-800">
            <Briefcase className="w-6 h-6" />
            AST - Métier de Calorifugeur
          </CardTitle>
          <div className="flex gap-4 text-sm text-blue-600">
            <div className="flex items-center gap-1">
              <span className="font-medium">{calorifugeurASTData.taches.length}</span>
              <span>tâches principales</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-medium">{totalOperations}</span>
              <span>opérations</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-medium">{totalSousOperations}</span>
              <span>sous-opérations</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="font-medium">{totalOutils}</span>
              <span>outils/équipements</span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Button onClick={expandAll} variant="outline" size="sm">
              Tout développer
            </Button>
            <Button onClick={collapseAll} variant="outline" size="sm">
              Tout fermer
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Organigramme hiérarchique */}
      <div className="space-y-4">
        {calorifugeurASTData.taches.map((tache: CalorifugeurTache) => (
          <Card key={tache.id} className="border-l-4 border-l-blue-500">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleTache(tache.id)}
                    className="p-1"
                  >
                    {expandedTaches.has(tache.id) ? 
                      <ChevronDown className="w-4 h-4" /> : 
                      <ChevronRight className="w-4 h-4" />
                    }
                  </Button>
                  <Briefcase className="w-5 h-5 text-blue-600" />
                  <div>
                    <CardTitle className="text-lg text-blue-800">
                      Tâche {tache.numero}: {tache.nom}
                    </CardTitle>
                    <p className="text-sm text-gray-600 mt-1">{tache.description}</p>
                  </div>
                </div>
                <Badge variant="outline" className="text-blue-600 border-blue-300">
                  {tache.operations.length} opération(s)
                </Badge>
              </div>
            </CardHeader>

            {expandedTaches.has(tache.id) && (
              <CardContent className="pt-0">
                <div className="ml-8 space-y-3">
                  {tache.operations.map((operation: CalorifugeurOperation, opIndex: number) => (
                    <Card key={operation.id} className="border-l-4 border-l-green-400 bg-green-50">
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => toggleOperation(operation.id)}
                              className="p-1"
                            >
                              {expandedOperations.has(operation.id) ? 
                                <ChevronDown className="w-3 h-3" /> : 
                                <ChevronRight className="w-3 h-3" />
                              }
                            </Button>
                            <Wrench className="w-4 h-4 text-green-600" />
                            <div>
                              <div className="font-medium text-green-800">
                                {tache.numero}.{opIndex + 1} {operation.nom}
                              </div>
                              <p className="text-xs text-green-600 mt-1">{operation.description}</p>
                            </div>
                          </div>
                          <div className="flex gap-1">
                            {operation.sousOperations.length > 0 && (
                              <Badge variant="outline" className="text-green-600 border-green-300 text-xs">
                                {operation.sousOperations.length} sous-op
                              </Badge>
                            )}
                            {operation.outils && operation.outils.length > 0 && (
                              <Badge variant="outline" className="text-orange-600 border-orange-300 text-xs bg-orange-50">
                                <Wrench className="w-3 h-3 mr-1" />
                                {operation.outils.length} outil(s)
                              </Badge>
                            )}
                          </div>
                        </div>
                      </CardHeader>

                      {expandedOperations.has(operation.id) && (
                        <CardContent className="pt-0">
                          <div className="ml-6 space-y-4">
                            {/* Outils - Section mise en évidence */}
                            {operation.outils && operation.outils.length > 0 && (
                              <div className="bg-orange-100 border-2 border-orange-300 rounded-lg p-4">
                                <h6 className="text-sm font-bold text-orange-700 mb-3 flex items-center gap-2">
                                  <Wrench className="w-4 h-4" />
                                  🔧 OUTILS ET ÉQUIPEMENTS REQUIS
                                </h6>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                  {operation.outils.map((outil: CalorifugeurOutil, outilIndex: number) => (
                                    <div key={outilIndex} className="p-3 border-2 border-orange-400 rounded-lg bg-white shadow-sm">
                                      <div className="font-bold text-orange-800 text-sm flex items-center gap-2">
                                        <Wrench className="w-3 h-3" />
                                        {outil.nom}
                                      </div>
                                      <div className="text-xs text-orange-600 font-medium mt-1">
                                        Type: {outil.type}
                                      </div>
                                      {outil.securiteRequise && outil.securiteRequise.length > 0 && (
                                        <div className="text-xs text-red-600 font-medium mt-1 bg-red-50 p-1 rounded">
                                          ⚠️ Sécurité: {outil.securiteRequise.join(', ')}
                                        </div>
                                      )}
                                    </div>
                                  ))}
                                </div>
                              </div>
                            )}
                            
                            {/* Sous-opérations */}
                            {operation.sousOperations.length > 0 && (
                              <div className="space-y-2">
                                <h6 className="text-sm font-medium text-purple-600 mb-2 flex items-center gap-1">
                                  <Cog className="w-4 h-4" />
                                  Sous-opérations:
                                </h6>
                                {operation.sousOperations.map((sousOp: CalorifugeurSousOperation, sousOpIndex: number) => (
                                  <div key={sousOp.id} className="flex items-center gap-3 p-3 border border-purple-200 rounded bg-purple-50">
                                    <Cog className="w-3 h-3 text-purple-600 flex-shrink-0" />
                                    <div className="flex-1">
                                      <div className="text-sm font-medium text-purple-800">
                                        {tache.numero}.{opIndex + 1}.{sousOpIndex + 1} {sousOp.nom}
                                      </div>
                                      <p className="text-xs text-purple-600 mt-1">{sousOp.description}</p>
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                        </CardContent>
                      )}
                    </Card>
                  ))}
                </div>
              </CardContent>
            )}
          </Card>
        ))}
      </div>
    </div>
  );
};
