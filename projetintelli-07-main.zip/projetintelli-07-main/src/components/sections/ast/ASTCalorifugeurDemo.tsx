import React, { useEffect, useRef } from 'react';
import { astDataService } from '../../../services/astDataService';
import type { ASTData } from '../../../services/astTypes';

interface ASTCalorifugeurDemoProps {
  onLoadComplete?: () => void;
  onStatClick?: (section: string) => void;
}

const calorifugeurRealData: ASTData = {
  corpsMetier: 'Calorifugeur',
  extractedAt: new Date().toISOString(),
  taches: [
    {
      nom: "Préparer les travaux",
      description: "Préparation complète des travaux de calorifugeage",
      operations: [
        {
          nom: "Recevoir les consignes",
          description: "Réception et analyse des consignes de travail",
          sousOperations: [
            {
              nom: "Se rendre sur les lieux des travaux",
              description: "Déplacement sur le site d'intervention",
              risques: []
            },
            {
              nom: "Vérifier les particularités du chantier",
              description: "Analyse des spécificités du chantier",
              risques: []
            },
            {
              nom: "Vérifier les conditions météorologiques (température, vent, pluie, etc.), s'il y a lieu",
              description: "Contrôle des conditions météorologiques",
              risques: []
            }
          ],
          risques: [],
          outils: [
            {
              nom: "Crayons",
              type: "Équipement de traçage",
              securiteRequise: []
            },
            {
              nom: "Crayons feutres",
              type: "Équipement de traçage",
              securiteRequise: []
            },
            {
              nom: "Rubans à mesurer",
              type: "Équipement de traçage",
              securiteRequise: []
            }
          ],
          materiaux: []
        },
        {
          nom: "Mettre en place les mesures de sécurité nécessaires",
          description: "Installation complète des mesures de sécurité",
          sousOperations: [
            {
              nom: "Participer aux rencontres de sécurité",
              description: "Participation aux briefings sécurité",
              risques: []
            },
            {
              nom: "Prendre connaissance des mesures de sécurité et de l'analyse de risque",
              description: "Étude des procédures de sécurité",
              risques: []
            },
            {
              nom: "Vérifier les éléments de sécurité sur le permis de travail",
              description: "Contrôle du permis de travail",
              risques: []
            },
            {
              nom: "Vérifier les règles internes et particulières du client, en lien avec la santé et la sécurité",
              description: "Conformité aux règles client",
              risques: []
            },
            {
              nom: "Déterminer l'équipement de sécurité requis et s'assurer de sa disponibilité et de son bon état",
              description: "Vérification des EPI",
              risques: []
            },
            {
              nom: "Vérifier les risques liés à la qualité de l'air, s'il y a lieu",
              description: "Contrôle de la qualité de l'air",
              risques: []
            },
            {
              nom: "Lire les fiches signalétiques des produits à utiliser",
              description: "Lecture des fiches de sécurité",
              risques: []
            },
            {
              nom: "Établir le ou les périmètres de sécurité",
              description: "Délimitation des zones de sécurité",
              risques: []
            },
            {
              nom: "Installer des filets sous les échafaudages, empêchant la chute d'outils, de matériaux, etc.",
              description: "Installation des filets de protection",
              risques: []
            },
            {
              nom: "Cadenasser la machinerie, s'il y a lieu",
              description: "Verrouillage des équipements",
              risques: []
            }
          ],
          risques: [],
          outils: [
            {
              nom: "Échafaudage",
              type: "Matériel d'accès",
              securiteRequise: ["formation échafaudage"]
            },
            {
              nom: "Échelles",
              type: "Matériel d'accès",
              securiteRequise: []
            },
            {
              nom: "Escabeaux 6 pi, 8 pi, 10 pi",
              type: "Matériel d'accès",
              securiteRequise: []
            },
            {
              nom: "Casques de sécurité",
              type: "EPI",
              securiteRequise: []
            },
            {
              nom: "Gants",
              type: "EPI",
              securiteRequise: []
            },
            {
              nom: "Lunettes de sécurité",
              type: "EPI",
              securiteRequise: []
            }
          ],
          materiaux: []
        }
      ]
    },
    {
      nom: "Ériger des échafaudages",
      description: "Construction et installation d'échafaudages sécurisés",
      operations: [
        {
          nom: "Faire l'inventaire des éléments",
          description: "Inventaire complet des composants d'échafaudage",
          sousOperations: [
            {
              nom: "Prendre les mesures de l'échafaudage",
              description: "Relevé des dimensions nécessaires",
              risques: []
            },
            {
              nom: "Identifier les obstacles pour l'installation",
              description: "Analyse des contraintes d'installation",
              risques: []
            },
            {
              nom: "Calculer le nombre d'éléments de l'échafaudage",
              description: "Calcul des besoins en matériaux",
              risques: []
            },
            {
              nom: "Procéder à l'inspection visuelle de l'équipement",
              description: "Contrôle de l'état des composants",
              risques: []
            },
            {
              nom: "Détecter les bris",
              description: "Identification des défauts",
              risques: []
            },
            {
              nom: "Remplacer les éléments endommagés",
              description: "Remplacement des pièces défectueuses",
              risques: []
            }
          ],
          risques: [],
          outils: [
            {
              nom: "Calculatrices",
              type: "Équipement de calcul",
              securiteRequise: []
            },
            {
              nom: "Rubans à mesurer",
              type: "Équipement de mesure",
              securiteRequise: []
            },
            {
              nom: "Règles graduées",
              type: "Équipement de mesure",
              securiteRequise: []
            }
          ],
          materiaux: []
        }
      ]
    },
    {
      nom: "Installer de l'isolant rigide ou semi-rigide sur de la tuyauterie",
      description: "Installation d'isolation sur réseaux de tuyauterie",
      operations: [
        {
          nom: "Dégeler la tuyauterie, s'il y a lieu",
          description: "Dégivrage préalable si nécessaire",
          sousOperations: [
            {
              nom: "S'assurer de la mise hors service",
              description: "Vérification de l'arrêt du système",
              risques: []
            },
            {
              nom: "Chauffer la tuyauterie (chalumeau)",
              description: "Réchauffage au chalumeau",
              risques: [
                {
                  description: "Risque de brûlure",
                  niveau: "eleve",
                  mesuresPrevention: ["Port d'EPI ignifuge", "Formation chalumeau"]
                }
              ]
            },
            {
              nom: "Utiliser un produit de déglaçage",
              description: "Application de produit de déglaçage",
              risques: []
            }
          ],
          risques: [],
          outils: [
            {
              nom: "Chalumeaux",
              type: "Outils de chauffage",
              securiteRequise: ["formation chalumeau", "permis feu"]
            }
          ],
          materiaux: []
        }
      ]
    }
  ]
};

export const ASTCalorifugeurDemo = ({ onLoadComplete, onStatClick }: ASTCalorifugeurDemoProps = {}) => {
  const hasLoadedRef = useRef(false);

  useEffect(() => {
    // Éviter les appels multiples qui causent la boucle iPad
    if (hasLoadedRef.current) {
      console.log('🔄 ASTCalorifugeurDemo déjà chargé, éviter la boucle iPad');
      return;
    }

    console.log('📋 ========== DÉBUT CHARGEMENT UNIQUE CALORIFUGEUR ==========');
    
    // Sauvegarder les vraies données du calorifugeur
    astDataService.saveASTData(calorifugeurRealData);
    console.log('✅ Données réelles du calorifugeur sauvegardées avec hiérarchie complète');
    
    // Marquer comme chargé pour éviter la répétition
    hasLoadedRef.current = true;
    
    // Appeler la fonction de callback si fournie
    if (onLoadComplete) {
      onLoadComplete();
    }
    
    console.log('📋 ========== FIN CHARGEMENT UNIQUE CALORIFUGEUR ==========');
  }, []); // Dépendances vides pour éviter les re-renders

  return null;
};
