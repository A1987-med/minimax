
import React from 'react';
import { astDataService } from '../../../services/astDataService';
import { ASTOccupationsDisplay } from './components/ASTOccupationsDisplay';
import { ASTEmptyState } from './components/ASTEmptyState';
import { ASTUploadManager } from './ASTUploadManager';
import { ASTLoadingState } from './components/ASTLoadingState';
import { ASTMainView } from './components/ASTMainView';
import { useASTData } from './hooks/useASTData';
import { useASTExpansion } from './hooks/useASTExpansion';

interface ASTOrganigrammeProps {
  corpsMetier: string;
  refreshKey?: number;
  onMetierSelect?: (metier: string) => void;
}

export const ASTOrganigramme = ({ corpsMetier, refreshKey, onMetierSelect }: ASTOrganigrammeProps) => {
  const { taches, isLoading, stats, loadASTData } = useASTData(corpsMetier, refreshKey);
  const {
    expandedTaches,
    expandedOperations,
    expandedSousOperations,
    toggleTache,
    toggleOperation,
    toggleSousOperation,
    handleOperationBadgeClick,
    expandAll,
    collapseAll
  } = useASTExpansion();

  const hasExtractedData = astDataService.hasASTData(corpsMetier);

  if (isLoading) {
    return <ASTLoadingState />;
  }

  // Si pas de corps de métier sélectionné, afficher la liste des occupations
  if (!corpsMetier) {
    return <ASTOccupationsDisplay onMetierSelect={onMetierSelect} />;
  }

  // Si on a des données extraites, afficher la vue principale
  if (hasExtractedData && taches.length > 0) {
    return (
      <ASTMainView
        corpsMetier={corpsMetier}
        onMetierSelect={onMetierSelect}
        isLoading={isLoading}
        stats={stats}
        taches={taches}
        expandedTaches={expandedTaches}
        expandedOperations={expandedOperations}
        expandedSousOperations={expandedSousOperations}
        onExpandAll={() => expandAll(taches)}
        onCollapseAll={collapseAll}
        onRefresh={loadASTData}
        onToggleTache={toggleTache}
        onToggleOperation={toggleOperation}
        onOperationBadgeClick={handleOperationBadgeClick}
        onToggleSousOperation={toggleSousOperation}
      />
    );
  }

  // Pour tous les autres cas (pas de données ou occupation personnalisée)
  // Afficher les occupations + le gestionnaire d'upload
  return (
    <div className="space-y-4">
      <ASTOccupationsDisplay onMetierSelect={onMetierSelect} />
      <ASTUploadManager 
        corpsMetier={corpsMetier} 
        onDataExtracted={loadASTData}
      />
    </div>
  );
};
