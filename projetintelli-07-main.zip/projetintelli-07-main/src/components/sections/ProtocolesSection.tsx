import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ArrowDown, Shield, Search, AlertTriangle, UserCheck, Camera, Video, TreePine, ClipboardList, FileText, Phone } from "lucide-react";

// Import des sections existantes
import { SignalementSection } from './SignalementSection';
import { PreventionSection } from './PreventionSection';
import { PreventionGeneraleSection } from './PreventionGeneraleSection';
import { ASTSection } from './ASTSection';
import { PhotoInspectionSection } from './PhotoInspectionSection';
import { VideoInspectionSection } from './VideoInspectionSection';
import { UrgencesSection } from './UrgencesSection';
import SaisiePresence from '../../pages/SaisiePresence';

interface ProtocolesSectionProps {
  onBack: () => void;
  setASTOperationLock?: (locked: boolean) => void;
}

export const ProtocolesSection = ({ onBack, setASTOperationLock }: ProtocolesSectionProps) => {
  const [selectedProtocol, setSelectedProtocol] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState("tolerances-zero");

  const protocols = [
    {
      id: 'monoxyde',
      title: 'Exposition au monoxyde de carbone',
      icon: '☠️',
      color: 'border-red-200 hover:bg-red-50',
      items: [
        'Ventilation obligatoire dans les espaces confinés',
        'Détecteurs de CO fonctionnels sur le chantier',
        'Interdiction d\'utiliser des moteurs à combustion en espace fermé',
        'Formation sur les signes d\'intoxication au CO',
        'Évacuation immédiate si détection de CO'
      ]
    },
    {
      id: 'chutes-hauteur',
      title: 'Chutes de hauteur de plus de 3 mètres',
      icon: '🪂',
      color: 'border-orange-200 hover:bg-orange-50',
      items: [
        'Harnais de sécurité obligatoire avec longe anti-chute',
        'Points d\'ancrage certifiés et inspectés',
        'Garde-corps installés sur tous les bords exposés',
        'Formation sur l\'utilisation des EPI anti-chute',
        'Inspection quotidienne des équipements de protection'
      ]
    },
    {
      id: 'chutes-echelle',
      title: 'Chutes de hauteur à partir d\'une échelle',
      icon: '🪜',
      color: 'border-yellow-200 hover:bg-yellow-50',
      items: [
        'Échelle positionnée selon la règle du 4:1',
        'Inspection visuelle avant chaque utilisation',
        'Maintien de 3 points de contact en permanence',
        'Interdiction de porter des charges lourdes',
        'Sécurisation de la base et du sommet de l\'échelle'
      ]
    },
    {
      id: 'zones-dangereuses',
      title: 'Exposition aux zones dangereuses d\'une machine',
      icon: '⚙️',
      color: 'border-red-200 hover:bg-red-50',
      items: [
        'Protecteurs et dispositifs de sécurité en place',
        'Procédures de cadenassage/étiquetage appliquées',
        'Formation spécifique à l\'équipement',
        'Zone de travail délimitée et signalisée',
        'Arrêt d\'urgence accessible et fonctionnel'
      ]
    },
    {
      id: 'electrisation',
      title: 'Électrisation avec ligne électrique aérienne',
      icon: '⚡',
      color: 'border-purple-200 hover:bg-purple-50',
      items: [
        'Distance de sécurité minimale respectée (3m minimum)',
        'Signalisation des lignes électriques présentes',
        'Formation sur les risques électriques',
        'Interdiction d\'approcher avec équipements conducteurs',
        'Coordination avec Hydro-Québec si nécessaire'
      ]
    },
    {
      id: 'echafaudage',
      title: 'Effondrement d\'un échafaudage',
      icon: '🏗️',
      color: 'border-blue-200 hover:bg-blue-50',
      items: [
        'Montage par personnel qualifié et certifié',
        'Inspection quotidienne par personne compétente',
        'Respect des charges maximales autorisées',
        'Ancrage et contreventement adéquats',
        'Planchers antidérapants et garde-corps installés'
      ]
    },
    {
      id: 'creusement',
      title: 'Effondrement des parois d\'un creusement',
      icon: '⛏️',
      color: 'border-brown-200 hover:bg-amber-50',
      items: [
        'Étançonnement obligatoire pour creusements > 1,2m',
        'Inspection par ingénieur pour sols instables',
        'Évacuation des déblais à distance sécuritaire',
        'Échelles d\'accès/sortie tous les 7,5m maximum',
        'Surveillance continue des conditions du sol'
      ]
    },
    {
      id: 'amiante',
      title: 'Exposition aux poussières d\'amiante',
      icon: '🫁',
      color: 'border-gray-200 hover:bg-gray-50',
      items: [
        'Identification obligatoire avant travaux (bâtiments < 1980)',
        'Procédures de décontamination strictes',
        'EPI respiratoires certifiés (P100 minimum)',
        'Confinement des zones de travail',
        'Surveillance de la qualité de l\'air'
      ]
    },
    {
      id: 'silice',
      title: 'Exposition aux poussières de silice',
      icon: '💨',
      color: 'border-slate-200 hover:bg-slate-50',
      items: [
        'Méthodes de travail limitant la poussière',
        'Aspiration à la source obligatoire',
        'Protection respiratoire adéquate (N95 minimum)',
        'Humidification des matériaux avant découpe',
        'Surveillance médicale des travailleurs exposés'
      ]
    },
    {
      id: 'roches',
      title: 'Roches instables',
      icon: '🪨',
      color: 'border-stone-200 hover:bg-stone-50',
      items: [
        'Inspection géologique préalable obligatoire',
        'Purgeage des roches instables par personnel qualifié',
        'Protection contre les chutes de pierres',
        'Surveillance continue des parois rocheuses',
        'Évacuation immédiate si signes d\'instabilité'
      ]
    }
  ];

  if (selectedProtocol) {
    const protocol = protocols.find(p => p.id === selectedProtocol);
    if (!protocol) return null;

    return (
      <div className="space-y-6">
        <div className="flex items-center gap-4 mb-6">
          <Button variant="outline" onClick={() => setSelectedProtocol(null)} className="flex items-center gap-2">
            <ArrowDown className="w-4 h-4 rotate-90" />
            Retour aux tolérances zéro
          </Button>
          <h1 className="text-3xl font-bold text-red-600">{protocol.title}</h1>
        </div>

        <Card className="border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-red-800">
              <AlertTriangle className="w-5 h-5" />
              <span className="text-2xl">{protocol.icon}</span>
              TOLÉRANCE ZÉRO - {protocol.title}
            </CardTitle>
            <CardDescription className="text-red-700 font-medium">
              Cette situation représente un danger immédiat. Tout manquement peut entraîner un arrêt de travail immédiat.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {protocol.items.map((item, index) => (
                <div key={index} className="flex items-start gap-3 p-3 bg-white rounded-lg border border-red-200">
                  <Badge className="mt-1 bg-red-600">{index + 1}</Badge>
                  <p className="flex-1 font-medium">{item}</p>
                </div>
              ))}
            </div>
            
            <div className="mt-6 p-4 bg-red-100 rounded-lg border border-red-300">
              <h4 className="font-semibold text-red-800 mb-2 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4" />
                🚨 CONSÉQUENCES EN CAS DE NON-RESPECT :
              </h4>
              <ul className="text-sm text-red-700 space-y-1 font-medium">
                <li>• Arrêt immédiat des travaux par l'inspecteur CNESST</li>
                <li>• Amendes pouvant atteindre plusieurs milliers de dollars</li>
                <li>• Poursuites criminelles en cas d'accident grave</li>
                <li>• Responsabilité civile de l'employeur et des dirigeants</li>
              </ul>
            </div>

            <div className="mt-4 p-4 bg-orange-50 rounded-lg border border-orange-300">
              <h4 className="font-semibold text-orange-800 mb-2">⚠️ En cas de situation dangereuse :</h4>
              <p className="text-sm text-orange-700 font-medium">
                Arrêter immédiatement le travail et contacter le CoSS : Abdelhamid Ouldzeid - (438) 439-2609
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 mb-6">
        <Button variant="outline" onClick={onBack} className="flex items-center gap-2">
          <ArrowDown className="w-4 h-4 rotate-90" />
          Retour
        </Button>
        <h1 className="text-3xl font-bold text-indigo-600">Protocoles SST</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5 lg:grid-cols-10 h-auto p-1">
          <TabsTrigger 
            value="tolerances-zero" 
            className="data-[state=active]:bg-red-100 data-[state=active]:text-red-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <Shield className="w-4 h-4" />
            <span>Tolérances Zéro</span>
          </TabsTrigger>
          <TabsTrigger 
            value="saisie-presence" 
            className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <UserCheck className="w-4 h-4" />
            <span>Saisie Présences</span>
          </TabsTrigger>
          <TabsTrigger 
            value="signalement" 
            className="data-[state=active]:bg-orange-100 data-[state=active]:text-orange-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <AlertTriangle className="w-4 h-4" />
            <span>Signalement</span>
          </TabsTrigger>
          <TabsTrigger 
            value="inspections" 
            className="data-[state=active]:bg-green-100 data-[state=active]:text-green-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <Shield className="w-4 h-4" />
            <span>Listes de contrôle et Doc.</span>
          </TabsTrigger>
          <TabsTrigger 
            value="prevention" 
            className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <FileText className="w-4 h-4" />
            <span>Prévention</span>
          </TabsTrigger>
          <TabsTrigger 
            value="ast" 
            className="data-[state=active]:bg-amber-100 data-[state=active]:text-amber-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <TreePine className="w-4 h-4" />
            <span>AST</span>
          </TabsTrigger>
          <TabsTrigger 
            value="photo-inspection" 
            className="data-[state=active]:bg-teal-100 data-[state=active]:text-teal-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <Camera className="w-4 h-4" />
            <span>Photos</span>
          </TabsTrigger>
          <TabsTrigger 
            value="video-inspection" 
            className="data-[state=active]:bg-purple-100 data-[state=active]:text-purple-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <Video className="w-4 h-4" />
            <span>Vidéos</span>
          </TabsTrigger>
          <TabsTrigger 
            value="rapport-journalier" 
            className="data-[state=active]:bg-emerald-100 data-[state=active]:text-emerald-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <ClipboardList className="w-4 h-4" />
            <span>Rapports</span>
          </TabsTrigger>
          <TabsTrigger 
            value="urgences" 
            className="data-[state=active]:bg-red-100 data-[state=active]:text-red-700 text-xs p-2 h-auto flex flex-col items-center gap-1"
          >
            <Phone className="w-4 h-4" />
            <span>Urgences</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="tolerances-zero" className="space-y-6">
          <Card className="border-red-200 bg-red-50">
            <CardContent className="p-4">
              <div className="flex items-center gap-2 text-red-700 mb-2">
                <AlertTriangle className="w-5 h-5" />
                <span className="font-bold">ATTENTION - TOLÉRANCES ZÉRO</span>
              </div>
              <p className="text-red-800 font-medium">
                Ces 10 situations représentent un danger immédiat selon la CNESST. 
                Tout manquement peut entraîner un arrêt de travail et des sanctions sévères.
              </p>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {protocols.map((protocol, index) => (
              <Card 
                key={protocol.id}
                className={`hover:shadow-lg transition-shadow cursor-pointer border-2 ${protocol.color} relative overflow-hidden`}
                onClick={() => setSelectedProtocol(protocol.id)}
              >
                <div className="absolute top-2 right-2 bg-red-600 text-white text-xs font-bold px-2 py-1 rounded">
                  #{index + 1}
                </div>
                <CardHeader className="text-center">
                  <div className="mx-auto w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 text-3xl border-2 border-red-200">
                    {protocol.icon}
                  </div>
                  <CardTitle className="text-gray-800 text-sm leading-tight">{protocol.title}</CardTitle>
                  <CardDescription className="text-red-600 font-semibold">
                    TOLÉRANCE ZÉRO
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {protocol.items.slice(0, 2).map((item, itemIndex) => (
                      <div key={itemIndex} className="text-sm text-gray-600 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 bg-red-400 rounded-full"></div>
                        {item}
                      </div>
                    ))}
                    <div className="text-sm text-red-600 italic font-medium">
                      +{protocol.items.length - 2} autres mesures...
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-red-600" />
                Mots-clés CNESST
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Monoxyde</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Chutes</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Échelle</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Machine</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Électrique</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Échafaudage</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Creusement</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Amiante</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Silice</Badge>
                <Badge variant="outline" className="justify-center border-red-300 text-red-700">Roches</Badge>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="saisie-presence">
          <React.Suspense fallback={<div>Chargement...</div>}>
            <SaisiePresence />
          </React.Suspense>
        </TabsContent>

        <TabsContent value="signalement">
          <SignalementSection onBack={() => {}} />
        </TabsContent>

        <TabsContent value="inspections">
          <PreventionSection onBack={() => {}} />
        </TabsContent>

        <TabsContent value="prevention">
          <PreventionGeneraleSection onBack={() => {}} />
        </TabsContent>

        <TabsContent value="ast">
          <ASTSection setASTOperationLock={setASTOperationLock} />
        </TabsContent>

        <TabsContent value="photo-inspection">
          <PhotoInspectionSection onBack={() => {}} />
        </TabsContent>

        <TabsContent value="video-inspection">
          <VideoInspectionSection onBack={() => {}} />
        </TabsContent>

        <TabsContent value="rapport-journalier">
          <div className="text-center p-8">
            <h3 className="text-lg font-semibold mb-2">Rapports d'Inspection</h3>
            <p className="text-muted-foreground">Cette section sera intégrée prochainement</p>
          </div>
        </TabsContent>

        <TabsContent value="urgences">
          <UrgencesSection onBack={() => {}} />
        </TabsContent>
      </Tabs>
    </div>
  );
};
