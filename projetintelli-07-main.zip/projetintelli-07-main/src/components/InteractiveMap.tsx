
import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Navigation } from "lucide-react";

interface Position {
  latitude: number;
  longitude: number;
}

interface InteractiveMapProps {
  userPosition?: Position | null;
  onPositionUpdate?: (position: Position) => void;
}

interface RallyPoint {
  id: string;
  name: string;
  lat: number;
  lng: number;
  type: 'primary' | 'secondary' | 'emergency';
}

export const InteractiveMap = ({ userPosition }: InteractiveMapProps) => {
  const [selectedZone, setSelectedZone] = useState<RallyPoint | null>(null);

  // Points de rassemblement fictifs pour la démonstration
  const rallyPoints: RallyPoint[] = [
    { id: 'A', name: 'Zone A - Parking principal', lat: 45.5647, lng: -73.7560, type: 'primary' },
    { id: 'B', name: 'Zone B - Entrée secondaire', lat: 45.5645, lng: -73.7555, type: 'secondary' },
    { id: 'C', name: 'Zone C - Point d\'urgence', lat: 45.5649, lng: -73.7562, type: 'emergency' }
  ];

  const handleZoneClick = (point: RallyPoint) => {
    setSelectedZone(point);
  };

  const openInMaps = (point: RallyPoint) => {
    const url = `https://www.google.com/maps?q=${point.lat},${point.lng}`;
    window.open(url, '_blank');
  };

  const getZoneIcon = (id: string) => {
    return id === 'A' ? '🅰️' : id === 'B' ? '🅱️' : '🆘';
  };

  const getZoneColor = (type: string) => {
    switch (type) {
      case 'primary': return 'border-green-300 bg-green-50 hover:bg-green-100';
      case 'secondary': return 'border-blue-300 bg-blue-50 hover:bg-blue-100';
      case 'emergency': return 'border-red-300 bg-red-50 hover:bg-red-100';
      default: return 'border-gray-300 bg-gray-50 hover:bg-gray-100';
    }
  };

  return (
    <div className="w-full space-y-4">
      <div className="h-64 rounded-lg overflow-hidden border border-gray-300 bg-gray-100 flex items-center justify-center">
        <div className="text-center space-y-4 w-full max-w-md">
          <div className="text-lg font-semibold text-gray-700">Plan d'évacuation</div>
          <div className="space-y-2">
            {rallyPoints.map((point) => (
              <button
                key={point.id}
                onClick={() => handleZoneClick(point)}
                className={`w-full flex items-center justify-between p-3 rounded shadow-sm transition-all cursor-pointer ${getZoneColor(point.type)}`}
              >
                <span className="font-medium">
                  {getZoneIcon(point.id)} {point.name}
                </span>
                <span className="text-sm text-gray-500">
                  Cliquer pour GPS
                </span>
              </button>
            ))}
          </div>
          {userPosition && (
            <div className="bg-blue-100 p-2 rounded">
              <strong>📍 Votre position</strong>
              <br />
              {userPosition.latitude.toFixed(6)}, {userPosition.longitude.toFixed(6)}
            </div>
          )}
        </div>
      </div>

      {selectedZone && (
        <div className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-lg flex items-center gap-2">
              {getZoneIcon(selectedZone.id)} {selectedZone.name}
            </h3>
            <Badge 
              variant="outline" 
              className={selectedZone.type === 'emergency' ? 'border-red-200 text-red-700' : 
                         selectedZone.type === 'primary' ? 'border-green-200 text-green-700' : 
                         'border-blue-200 text-blue-700'}
            >
              {selectedZone.type === 'emergency' ? 'Urgence' : 
               selectedZone.type === 'primary' ? 'Principal' : 'Secondaire'}
            </Badge>
          </div>
          
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <MapPin className="w-4 h-4" />
              <span className="font-mono">
                Latitude: {selectedZone.lat.toFixed(6)} | Longitude: {selectedZone.lng.toFixed(6)}
              </span>
            </div>
            
            <div className="flex gap-2">
              <Button 
                size="sm" 
                onClick={() => openInMaps(selectedZone)}
                className="flex items-center gap-2"
              >
                <Navigation className="w-4 h-4" />
                Ouvrir dans Google Maps
              </Button>
              
              <Button 
                variant="outline" 
                size="sm" 
                onClick={() => setSelectedZone(null)}
              >
                Fermer
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
