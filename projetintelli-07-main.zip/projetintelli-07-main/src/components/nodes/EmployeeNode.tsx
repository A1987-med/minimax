
import React, { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { User, Mail, Phone } from 'lucide-react';

interface EmployeeNodeData {
  name: string;
  position: string;
  email?: string;
  phone?: string;
  avatar?: string;
}

interface EmployeeNodeProps {
  data: EmployeeNodeData;
}

export const EmployeeNode = memo(({ data }: EmployeeNodeProps) => {
  return (
    <div className="bg-white rounded-lg shadow-lg border-2 border-blue-200 p-4 min-w-[200px] hover:shadow-xl transition-shadow">
      <Handle 
        type="target" 
        position={Position.Top} 
        className="w-3 h-3 bg-blue-500 border-2 border-white" 
      />
      
      <div className="flex items-center gap-3 mb-3">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
          {data.avatar ? (
            <img src={data.avatar} alt={data.name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <User className="w-6 h-6 text-white" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-semibold text-gray-800 truncate">{data.name}</h3>
          <p className="text-sm text-gray-600 truncate">{data.position}</p>
        </div>
      </div>
      
      {(data.email || data.phone) && (
        <div className="space-y-1 text-xs text-gray-500">
          {data.email && (
            <div className="flex items-center gap-1">
              <Mail className="w-3 h-3" />
              <span className="truncate">{data.email}</span>
            </div>
          )}
          {data.phone && (
            <div className="flex items-center gap-1">
              <Phone className="w-3 h-3" />
              <span>{data.phone}</span>
            </div>
          )}
        </div>
      )}
      
      <Handle 
        type="source" 
        position={Position.Bottom} 
        className="w-3 h-3 bg-blue-500 border-2 border-white" 
      />
    </div>
  );
});

EmployeeNode.displayName = 'EmployeeNode';
