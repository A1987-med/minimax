
import React, { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { Building2, Users } from 'lucide-react';

interface DepartmentNodeData {
  name: string;
  description?: string;
  employeeCount?: number;
  color?: string;
}

interface DepartmentNodeProps {
  data: DepartmentNodeData;
}

export const DepartmentNode = memo(({ data }: DepartmentNodeProps) => {
  const bgColor = data.color || 'from-purple-400 to-purple-600';
  
  return (
    <div className="bg-white rounded-lg shadow-lg border-2 border-purple-200 p-4 min-w-[220px] hover:shadow-xl transition-shadow">
      <Handle 
        type="target" 
        position={Position.Top} 
        className="w-3 h-3 bg-purple-500 border-2 border-white" 
      />
      
      <div className="text-center mb-3">
        <div className={`w-16 h-16 bg-gradient-to-br ${bgColor} rounded-lg mx-auto mb-3 flex items-center justify-center`}>
          <Building2 className="w-8 h-8 text-white" />
        </div>
        <h3 className="font-bold text-lg text-gray-800">{data.name}</h3>
        {data.description && (
          <p className="text-sm text-gray-600 mt-1">{data.description}</p>
        )}
      </div>
      
      {data.employeeCount && (
        <div className="flex items-center justify-center gap-1 text-sm text-gray-500 bg-gray-50 rounded-lg py-1">
          <Users className="w-4 h-4" />
          <span>{data.employeeCount} employés</span>
        </div>
      )}
      
      <Handle 
        type="source" 
        position={Position.Bottom} 
        className="w-3 h-3 bg-purple-500 border-2 border-white" 
      />
    </div>
  );
});

DepartmentNode.displayName = 'DepartmentNode';
