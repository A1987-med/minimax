
import React, { memo } from 'react';
import { Handle, Position } from '@xyflow/react';
import { Crown, User, Briefcase } from 'lucide-react';

interface ManagerNodeData {
  name: string;
  position: string;
  department?: string;
  level: 'CEO' | 'Director' | 'Manager';
  avatar?: string;
}

interface ManagerNodeProps {
  data: ManagerNodeData;
}

export const ManagerNode = memo(({ data }: ManagerNodeProps) => {
  const getLevelColor = (level: string) => {
    switch (level) {
      case 'CEO': return 'from-yellow-400 to-orange-500';
      case 'Director': return 'from-green-400 to-green-600';
      case 'Manager': return 'from-indigo-400 to-indigo-600';
      default: return 'from-gray-400 to-gray-600';
    }
  };

  const getLevelIcon = (level: string) => {
    switch (level) {
      case 'CEO': return Crown;
      case 'Director': return Briefcase;
      case 'Manager': return User;
      default: return User;
    }
  };

  const LevelIcon = getLevelIcon(data.level);
  const colorClass = getLevelColor(data.level);
  
  return (
    <div className="bg-white rounded-lg shadow-lg border-2 border-indigo-200 p-4 min-w-[240px] hover:shadow-xl transition-shadow">
      <Handle 
        type="target" 
        position={Position.Top} 
        className="w-3 h-3 bg-indigo-500 border-2 border-white" 
      />
      
      <div className="text-center mb-3">
        <div className={`w-16 h-16 bg-gradient-to-br ${colorClass} rounded-full mx-auto mb-3 flex items-center justify-center relative`}>
          {data.avatar ? (
            <img src={data.avatar} alt={data.name} className="w-full h-full rounded-full object-cover" />
          ) : (
            <User className="w-8 h-8 text-white" />
          )}
          <div className="absolute -top-1 -right-1 w-6 h-6 bg-white rounded-full flex items-center justify-center shadow-md">
            <LevelIcon className="w-3 h-3 text-gray-700" />
          </div>
        </div>
        <h3 className="font-bold text-lg text-gray-800">{data.name}</h3>
        <p className="text-sm text-gray-600">{data.position}</p>
        {data.department && (
          <p className="text-xs text-gray-500 mt-1 bg-gray-100 px-2 py-1 rounded-full inline-block">
            {data.department}
          </p>
        )}
      </div>
      
      <div className="text-xs text-center">
        <span className={`px-2 py-1 rounded-full text-white bg-gradient-to-r ${colorClass}`}>
          {data.level}
        </span>
      </div>
      
      <Handle 
        type="source" 
        position={Position.Bottom} 
        className="w-3 h-3 bg-indigo-500 border-2 border-white" 
      />
    </div>
  );
});

ManagerNode.displayName = 'ManagerNode';
