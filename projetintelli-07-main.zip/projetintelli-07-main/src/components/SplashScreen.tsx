
import React from 'react';

export const SplashScreen = () => {
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-blue-600 to-purple-700 flex items-center justify-center z-50">
      <div className="text-center text-white">
        <div className="w-24 h-24 rounded-full overflow-hidden mx-auto mb-6 shadow-2xl border-4 border-white">
          <img
            src="https://images.unsplash.com/photo-1487958449943-2429e8be8625?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&q=80"
            alt="Innovation dans la gestion de la prévention sur chantiers"
            className="w-full h-full object-cover"
          />
        </div>
        <h1 className="text-4xl font-bold mb-2 max-w-sm mx-auto">Intelli-SST</h1>
        <p className="text-xl opacity-90 mb-4">Innovation en Prévention</p>
        <p className="text-lg opacity-75">Travaux de Construction</p>
        <div className="mt-8">
          <div className="w-8 h-8 border-4 border-white border-t-transparent rounded-full animate-spin mx-auto"></div>
        </div>
      </div>
    </div>
  );
};
