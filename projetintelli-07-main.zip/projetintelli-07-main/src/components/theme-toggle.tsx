
import * as React from "react"
import { Moon, Sun, Monitor } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()

  const cycleTheme = () => {
    if (theme === "light") {
      setTheme("dim")
    } else {
      setTheme("light")
    }
  }

  const getIcon = () => {
    if (theme === "light") {
      return <Sun className="h-[1.2rem] w-[1.2rem] text-yellow-500 drop-shadow-sm neon-glow" />
    } else {
      return <Monitor className="h-[1.2rem] w-[1.2rem] text-blue-500 drop-shadow-sm neon-glow" />
    }
  }

  return (
    <Button
      variant="outline"
      size="icon"
      onClick={cycleTheme}
      className="relative bg-white/60 dark:bg-gray-800/60 backdrop-blur-sm border-white/20 dark:border-gray-700/20 hover:bg-white/80 dark:hover:bg-gray-800/80 shadow-lg hover:shadow-xl transition-all duration-500 transform hover:scale-110 perspective-hover floating-card overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-yellow-400/10 via-blue-400/10 to-purple-400/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-pulse"></div>
      <div className="relative z-10">
        {getIcon()}
      </div>
      <span className="sr-only">Basculer le thème</span>
    </Button>
  )
}
