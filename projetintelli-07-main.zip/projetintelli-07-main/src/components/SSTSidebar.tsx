import React from 'react';
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { ThemeToggle } from "@/components/theme-toggle";
import { 
  Shield, 
  Bell,
  Home,
  Sparkles,
  Zap,
  BookOpen,
  Building2,
  Settings,
  ClipboardList
} from "lucide-react";

const mainSections = [
  {
    title: "Accueil",
    icon: Home,
    action: "accueil",
    color: "text-gray-700 hover:bg-gradient-to-r hover:from-gray-100 hover:to-gray-200 dark:text-gray-300 dark:hover:from-gray-800 dark:hover:to-gray-700"
  },
  {
    title: "Projet & Informations",
    icon: Building2,
    action: "projet-informations",
    color: "text-blue-600 hover:bg-gradient-to-r hover:from-blue-100 hover:to-blue-200 dark:text-blue-400 dark:hover:from-blue-900/50 dark:hover:to-blue-800/50"
  },
  {
    title: "Gestion RH",
    icon: Settings,
    action: "gestion",
    color: "text-slate-600 hover:bg-gradient-to-r hover:from-slate-100 hover:to-slate-200 dark:text-slate-400 dark:hover:from-slate-900/50 dark:hover:to-slate-800/50"
  },
  {
    title: "Inspection SST",
    icon: ClipboardList,
    action: "rapport-journalier",
    color: "text-emerald-600 hover:bg-gradient-to-r hover:from-emerald-100 hover:to-emerald-200 dark:text-emerald-400 dark:hover:from-emerald-900/50 dark:hover:to-emerald-800/50"
  },
  {
    title: "Protocoles SST",
    icon: BookOpen,
    action: "protocoles",
    color: "text-indigo-600 hover:bg-gradient-to-r hover:from-indigo-100 hover:to-indigo-200 dark:text-indigo-400 dark:hover:from-indigo-900/50 dark:hover:to-indigo-800/50"
  }
];

interface SSTSidebarProps {
  onSectionSelect: (section: string) => void;
}

export function SSTSidebar({ onSectionSelect }: SSTSidebarProps) {
  const handleSectionClick = (action: string) => {
    if (action === 'accueil') {
      // Retourner à l'écran principal avec les cartes
      onSectionSelect(null);
    } else {
      onSectionSelect(action);
    }
  };

  return (
    <Sidebar className="border-r border-white/20 backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 shadow-2xl">
      <SidebarHeader className="border-b border-white/20 p-4 bg-gradient-to-r from-red-500/10 to-orange-500/10 dark:from-red-500/20 dark:to-orange-500/20 relative overflow-hidden">
        {/* Particules flottantes */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-2 left-4 w-1 h-1 bg-yellow-400 rounded-full animate-pulse opacity-70"></div>
          <div className="absolute top-6 right-8 w-1 h-1 bg-blue-400 rounded-full animate-pulse delay-300 opacity-70"></div>
          <div className="absolute bottom-4 left-8 w-1 h-1 bg-pink-400 rounded-full animate-pulse delay-700 opacity-70"></div>
        </div>
        
        <div className="flex items-center gap-2 relative z-10">
          <div className="w-16 h-16 bg-gradient-to-br from-red-500 via-orange-500 to-yellow-500 rounded-2xl flex items-center justify-center shadow-2xl transform hover:scale-110 transition-all duration-500 perspective-hover relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-pink-500/20 via-purple-500/20 to-indigo-500/20 animate-pulse"></div>
            <Shield className="w-9 h-9 text-white drop-shadow-lg relative z-10" />
            <Sparkles className="w-4 h-4 text-yellow-200 absolute -top-1 -right-1 animate-pulse" />
            <Zap className="w-3 h-3 text-blue-200 absolute -bottom-1 -left-1 animate-pulse delay-500" />
          </div>
          <div className="flex-1">
            <h2 className="font-bold text-sm title-3d holographic">
              Intelli-SST
            </h2>
            <p className="text-[10px] text-gray-600 dark:text-gray-400 font-medium neon-glow">
              Travaux de Construction ✨
            </p>
          </div>
          <div className="flex items-center gap-2">
            <ThemeToggle />
            <SidebarTrigger className="hover:bg-white/20 dark:hover:bg-gray-800/20 transition-all duration-300 perspective-hover" />
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent className="p-3 bg-gradient-to-b from-transparent to-white/5 dark:to-gray-900/20 relative">
        {/* Effets de fond animés */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-r from-blue-500/5 to-purple-500/5 rounded-full blur-xl animate-pulse"></div>
          <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-to-r from-pink-500/5 to-orange-500/5 rounded-full blur-xl animate-pulse delay-1000"></div>
        </div>
        
        <SidebarGroup className="relative z-10">
          <SidebarGroupLabel className="text-red-700 dark:text-red-400 font-bold text-sm uppercase flex items-center gap-2 whitespace-nowrap mb-2 morphing-border px-3 py-2 rounded-lg floating-card">
            <Bell className="w-4 h-4 animate-pulse neon-glow" />
            <span className="holographic">
              SECTIONS
            </span>
          </SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu className="space-y-2">
              {mainSections.map((section, index) => (
                <SidebarMenuItem key={section.title}>
                  <SidebarMenuButton 
                    className={`${section.color} transition-all duration-500 rounded-xl font-medium shadow-sm hover:shadow-2xl transform hover:scale-105 hover:-translate-y-1 border border-transparent hover:border-white/20 dark:hover:border-gray-700/20 backdrop-blur-sm perspective-hover floating-card relative overflow-hidden group`}
                    style={{ animationDelay: `${index * 100}ms` }}
                    onClick={() => {
                      console.log(`Section clicked from sidebar: ${section.action}`);
                      handleSectionClick(section.action);
                    }}
                  >
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 -skew-x-12 group-hover:animate-pulse"></div>
                    <section.icon className="w-4 h-4 drop-shadow-sm relative z-10 group-hover:animate-pulse" />
                    <span className="font-medium relative z-10">{section.title}</span>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
        
        {/* Décoratif avec effet holographique */}
        <div className="mt-auto h-20 bg-gradient-to-t from-orange-200/30 via-red-200/20 to-transparent dark:from-orange-900/20 dark:via-red-900/10 rounded-lg relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 via-pink-500/10 to-blue-500/10 animate-pulse"></div>
          <div className="absolute bottom-2 left-2 w-2 h-2 bg-yellow-400 rounded-full animate-pulse"></div>
          <div className="absolute top-2 right-4 w-1 h-1 bg-blue-400 rounded-full animate-pulse delay-500"></div>
        </div>
      </SidebarContent>
    </Sidebar>
  );
}
