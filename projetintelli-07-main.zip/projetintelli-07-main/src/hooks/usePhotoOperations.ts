import { useState } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { photoStorageService } from '@/services/photoStorageService';
import { supabasePhotoStorageService } from '@/services/supabasePhotoStorageService';
import { extractExifData } from '@/services/exifService';
import type { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';

export const usePhotoOperations = () => {
  const [isSaving, setIsSaving] = useState(false);
  const { toast } = useToast();

  const processPhotoData = async (
    photosData: string[], 
    setPhotos: React.Dispatch<React.SetStateAction<AnalyzedPhoto[]>>,
    startAnalysisForPhoto: (photo: AnalyzedPhoto) => void
  ): Promise<void> => {
    console.log('🔄 ========== DÉBUT TRAITEMENT PHOTOS ==========');
    console.log('📸 Nombre de photos à traiter:', photosData.length);

    for (let i = 0; i < photosData.length; i++) {
      const photoData = photosData[i];
      console.log(`📸 Traitement photo ${i + 1}/${photosData.length}`);

      try {
        // Convertir dataURL en File
        const response = await fetch(photoData);
        const blob = await response.blob();
        const timestamp = Date.now();
        const randomId = Math.random().toString(36).substring(2, 8);
        const fileName = `photo-${timestamp}-${randomId}.jpg`;
        const file = new File([blob], fileName, { type: 'image/jpeg' });

        console.log('📁 Fichier créé:', { name: file.name, size: file.size, type: file.type });

        // Extraire les données EXIF (avec gestion d'erreur et timeout plus long)
        console.log('📊 Extraction des données EXIF...');
        let exifData = {};
        try {
          exifData = await extractExifData(file);
          console.log('📊 Données EXIF extraites:', exifData);
        } catch (error) {
          console.warn('⚠️ Échec extraction EXIF, continuons sans:', error);
          exifData = {};
        }

        // Upload vers Supabase
        console.log('☁️ Upload vers Supabase...');
        const { url, photoInspection } = await supabasePhotoStorageService.uploadPhoto(file);
        console.log('✅ Upload Supabase réussi');

        // Créer l'objet AnalyzedPhoto
        const newPhoto: AnalyzedPhoto = {
          id: photoInspection.id,
          file: file,
          url: url,
          analysis: undefined,
          analyzing: false,
          analysisStartTime: undefined,
          exifData: exifData
        };

        console.log('📷 Photo créée avec EXIF:', {
          id: newPhoto.id,
          hasExif: !!newPhoto.exifData && Object.keys(newPhoto.exifData).length > 0,
          exifDate: newPhoto.exifData?.dateTime
        });

        // Ajouter la photo EN HAUT de la liste (au début)
        setPhotos(prev => [newPhoto, ...prev]);

        // Lancer l'analyse
        console.log('🤖 Démarrage de l\'analyse IA...');
        startAnalysisForPhoto(newPhoto);

        toast({
          title: "Photo ajoutée avec succès ✅",
          description: `Photo ${i + 1}/${photosData.length} uploadée et analyse démarrée`,
          duration: 3000,
        });

      } catch (error) {
        console.error(`❌ Erreur traitement photo ${i + 1}:`, error);
        toast({
          title: "Erreur d'upload ❌",
          description: `Impossible d'uploader la photo ${i + 1}: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          variant: "destructive",
          duration: 5000,
        });
      }
    }

    console.log('🔄 ========== FIN TRAITEMENT PHOTOS ==========');
  };

  const handleRetryAnalysis = async (
    photoId: string,
    photos: AnalyzedPhoto[],
    setPhotos: (updater: (prev: AnalyzedPhoto[]) => AnalyzedPhoto[]) => void,
    startAnalysisForPhoto: (photo: AnalyzedPhoto) => void
  ) => {
    console.log('🔄 Relancement analyse pour photo:', photoId);
    
    const photoToAnalyze = photos.find(p => p.id === photoId);
    if (!photoToAnalyze) {
      console.error('❌ Photo non trouvée pour relance:', photoId);
      return;
    }
    
    await supabasePhotoStorageService.markAsAnalyzing(photoId);
    
    setPhotos(prev => prev.map(photo => 
      photo.id === photoId 
        ? { 
            ...photo, 
            analyzing: true,
            analysisStartTime: Date.now(),
            analysis: undefined
          }
        : photo
    ));

    setTimeout(() => {
      startAnalysisForPhoto({
        ...photoToAnalyze,
        analyzing: true,
        analysisStartTime: Date.now(),
        analysis: undefined
      });
    }, 500);

    toast({
      title: "Analyse relancée",
      description: `L'analyse Claude de la photo ${photoId.slice(-4)} a été relancée`,
      duration: 3000,
    });
  };

  const handleRemovePhoto = async (
    photoId: string,
    setPhotos: (updater: (prev: AnalyzedPhoto[]) => AnalyzedPhoto[]) => void
  ) => {
    console.log('🗑️ Suppression photo:', photoId);
    
    try {
      await supabasePhotoStorageService.deletePhoto(photoId);
      setPhotos(prev => prev.filter(photo => photo.id !== photoId));
      
      toast({
        title: "Photo supprimée",
        description: "La photo a été supprimée de Supabase",
        duration: 3000,
      });
    } catch (error) {
      console.error('❌ Erreur suppression photo:', error);
      toast({
        title: "Erreur de suppression",
        description: "Impossible de supprimer la photo de Supabase",
        variant: "destructive"
      });
    }
  };

  const handleSaveAll = async (photos: AnalyzedPhoto[]) => {
    if (photos.length === 0) {
      toast({
        title: "Aucune photo à sauvegarder",
        description: "Ajoutez des photos avant de sauvegarder",
        variant: "destructive"
      });
      return;
    }

    setIsSaving(true);
    
    try {
      console.log('💾 === DÉBUT SAUVEGARDE GLOBALE ===');
      console.log('💾 Sauvegarde de', photos.length, 'photos...');
      
      await photoStorageService.savePhotos(photos);
      
      toast({
        title: "Sauvegarde réussie ! 💾",
        description: `${photos.length} photo(s) et analyses sauvegardées dans Supabase`,
        duration: 4000,
      });
      
      console.log('✅ Sauvegarde globale terminée avec succès');
      
    } catch (error) {
      console.error('❌ Erreur sauvegarde globale:', error);
      toast({
        title: "Erreur de sauvegarde",
        description: "Impossible de sauvegarder toutes les photos",
        variant: "destructive",
        duration: 6000,
      });
    } finally {
      setIsSaving(false);
    }
  };

  return {
    isSaving,
    processPhotoData,
    handleRetryAnalysis,
    handleRemovePhoto,
    handleSaveAll
  };
};
