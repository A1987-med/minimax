
import { useState, useEffect } from 'react';
import { inspectionService } from '@/services/preventionService';

export const useProchaineInspection = (refreshTrigger: number = 0) => {
  const [prochaineInspection, setProchaineInspection] = useState<string>('--/--');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProchaineInspection = async () => {
      console.log('📅 Récupération de la prochaine inspection...');
      setIsLoading(true);
      setError(null);

      try {
        const inspections = await inspectionService.getAll();
        console.log('📊 Inspections récupérées:', inspections);

        // Filtrer les inspections futures et programmées
        const now = new Date();
        const inspectionsFutures = inspections.filter(inspection => {
          const dateInspection = new Date(inspection.dateInspection);
          return dateInspection >= now && (inspection.statut === 'planifiee' || inspection.statut === 'en_cours');
        });

        console.log('🔮 Inspections futures:', inspectionsFutures);

        if (inspectionsFutures.length > 0) {
          // Trier par date pour trouver la plus proche
          inspectionsFutures.sort((a, b) => new Date(a.dateInspection).getTime() - new Date(b.dateInspection).getTime());
          
          const prochaine = inspectionsFutures[0];
          const dateFormatted = new Date(prochaine.dateInspection).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: '2-digit'
          });
          
          console.log('📅 Prochaine inspection trouvée:', dateFormatted);
          setProchaineInspection(dateFormatted);
        } else {
          console.log('⚠️ Aucune inspection programmée');
          setProchaineInspection('À planifier');
        }
      } catch (err) {
        console.error('❌ Erreur lors de la récupération des inspections:', err);
        setError('Erreur de récupération');
        setProchaineInspection('--/--');
      } finally {
        setIsLoading(false);
      }
    };

    fetchProchaineInspection();
  }, [refreshTrigger]);

  return { prochaineInspection, isLoading, error };
};
