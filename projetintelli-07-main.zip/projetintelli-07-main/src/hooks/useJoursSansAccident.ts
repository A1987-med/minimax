
import { useState, useEffect } from 'react';
import { signalementService } from '@/services/supabaseService';

export const useJoursSansAccident = (refreshTrigger?: number) => {
  const [joursSansAccident, setJoursSansAccident] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const calculerJoursSansAccident = async () => {
      try {
        console.log('🔄 Calcul des jours sans accident...');
        setIsLoading(true);
        setError(null);
        
        // Récupérer tous les signalements
        const signalements = await signalementService.getAll();
        console.log('📊 Signalements récupérés:', signalements);
        
        if (signalements.length === 0) {
          console.log('📭 Aucun signalement trouvé - compteur à 0');
          // Aucun signalement enregistré, commencer à 0
          setJoursSansAccident(0);
          return;
        }
        
        // Filtrer les signalements qui sont des accidents/incidents graves
        const accidents = signalements.filter(s => {
          const isAccident = s.type_incident.toLowerCase().includes('accident') ||
                           s.type_incident.toLowerCase().includes('blessure') ||
                           s.type_incident.toLowerCase().includes('chute');
          const isGrave = s.gravite === 'elevee' || s.gravite === 'critique';
          
          console.log(`🔍 Signalement: ${s.type_incident}, gravité: ${s.gravite}, isAccident: ${isAccident}, isGrave: ${isGrave}`);
          
          return isAccident || isGrave;
        });
        
        console.log('⚠️ Accidents trouvés:', accidents.length);
        
        if (accidents.length === 0) {
          console.log('✅ Aucun accident trouvé, tous les signalements sont mineurs');
          // Aucun accident grave, calculer depuis le premier signalement
          const premierSignalement = signalements.sort((a, b) => 
            new Date(a.date_incident).getTime() - new Date(b.date_incident).getTime()
          )[0];
          
          if (premierSignalement) {
            const dateDebut = new Date(premierSignalement.date_incident);
            const aujourdhui = new Date();
            const diffTime = aujourdhui.getTime() - dateDebut.getTime();
            const diffJours = Math.floor(diffTime / (1000 * 60 * 60 * 24));
            console.log(`📅 Jours calculés depuis le premier signalement: ${diffJours}`);
            setJoursSansAccident(Math.max(0, diffJours));
          } else {
            setJoursSansAccident(0); // Aucun signalement = 0 jours
          }
        } else {
          // Trouver le dernier accident
          const dernierAccident = accidents.sort((a, b) => 
            new Date(b.date_incident).getTime() - new Date(a.date_incident).getTime()
          )[0];
          
          console.log('🚨 Dernier accident:', dernierAccident);
          
          // Calculer la différence en jours
          const dateAccident = new Date(dernierAccident.date_incident);
          const aujourdhui = new Date();
          const diffTime = aujourdhui.getTime() - dateAccident.getTime();
          const diffJours = Math.floor(diffTime / (1000 * 60 * 60 * 24));
          
          console.log(`📅 Jours calculés depuis le dernier accident: ${diffJours}`);
          setJoursSansAccident(Math.max(0, diffJours));
        }
        
        console.log('✅ Calcul terminé');
      } catch (err) {
        console.error('❌ Erreur calcul jours sans accident:', err);
        setError('Erreur lors du calcul');
        setJoursSansAccident(0);
      } finally {
        setIsLoading(false);
      }
    };

    calculerJoursSansAccident();
  }, [refreshTrigger]); // Le hook se recalcule quand refreshTrigger change

  // Fonction pour forcer le recalcul
  const recalculer = () => {
    setIsLoading(true);
    // Le useEffect va se déclencher automatiquement
  };

  return { joursSansAccident, isLoading, error, recalculer };
};
