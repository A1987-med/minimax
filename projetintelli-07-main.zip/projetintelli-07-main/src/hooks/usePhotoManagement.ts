
import { useState, useEffect, useRef } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { useNativeFeatures } from '@/hooks/useNativeFeatures';
import { photoStorageService } from '@/services/photoStorageService';
import { useClaudeAnalysis } from '@/hooks/useClaudeAnalysis';
import { usePhotoOperations } from '@/hooks/usePhotoOperations';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';

export const usePhotoManagement = () => {
  const [photos, setPhotos] = useState<AnalyzedPhoto[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [debugInfo, setDebugInfo] = useState<string>('');
  const { takePicture, selectFromGallery } = useNativeFeatures();
  const { toast } = useToast();
  const { startAnalysisForPhoto } = useClaudeAnalysis();
  const { isSaving, processPhotoData, handleRetryAnalysis, handleRemovePhoto, handleSaveAll } = usePhotoOperations();
  
  const saveTimeoutRef = useRef<NodeJS.Timeout>();

  // Charger les photos sauvegardées au montage du composant
  useEffect(() => {
    console.log('🔄 useEffect de chargement initial déclenché');
    loadSavedPhotos();
  }, []);

  useEffect(() => {
    const checkStuckAnalyses = () => {
      const now = Date.now();
      const ANALYSIS_TIMEOUT = 2 * 60 * 1000; // 2 minutes

      setPhotos(prev => prev.map(photo => {
        if (photo.analyzing && photo.analysisStartTime) {
          const elapsed = now - photo.analysisStartTime;
          if (elapsed > ANALYSIS_TIMEOUT) {
            console.log('⏰ Analyse bloquée détectée pour photo:', photo.id, 'depuis', Math.round(elapsed / 1000), 'secondes');
            toast({
              title: "Analyse bloquée détectée",
              description: `L'analyse de la photo ${photo.id.slice(-4)} semble bloquée. Vous pouvez la relancer.`,
              variant: "destructive",
              duration: 5000,
            });
            return {
              ...photo,
              analyzing: false,
              analysis: {
                nonConformites: [{
                  type: "🚨 ANALYSE BLOQUÉE - RELANCER NÉCESSAIRE",
                  description: "L'analyse automatique a été interrompue après timeout. Cliquez sur 'Relancer l'analyse' pour réessayer.",
                  gravite: 'moyen' as const,
                  solution: "Utiliser le bouton 'Relancer l'analyse' ou vérification manuelle"
                }],
                risques: [],
                scoreGlobal: 50,
                recommandations: ["Relancer l'analyse avec le bouton dédié", "En cas d'échec répété, effectuer une vérification manuelle"]
              }
            };
          }
        }
        return photo;
      }));
    };

    const interval = setInterval(checkStuckAnalyses, 30000);
    return () => clearInterval(interval);
  }, [toast]);

  const loadSavedPhotos = async () => {
    console.log('📂 ========== DÉBUT CHARGEMENT SUPABASE ==========');
    setIsLoading(true);
    setDebugInfo('Chargement depuis Supabase...');
    
    try {
      setDebugInfo('Initialisation du service Supabase...');
      console.log('🔧 Initialisation du service Supabase...');
      await photoStorageService.init();
      
      setDebugInfo('Récupération des photos depuis Supabase...');
      console.log('📂 Chargement des photos depuis Supabase...');
      const loadedPhotos = await photoStorageService.loadPhotos();
      
      console.log('📊 RÉSULTAT FINAL du chargement:', {
        nombre: loadedPhotos.length,
        photos: loadedPhotos.map(p => ({
          id: p.id.slice(-8),
          fileName: p.file?.name,
          hasUrl: !!p.url,
          hasAnalysis: !!p.analysis,
          analyzing: p.analyzing,
          nonConformitesCount: p.analysis?.nonConformites?.length || 0
        }))
      });
      
      setDebugInfo(`${loadedPhotos.length} photos chargées depuis Supabase`);
      setPhotos(loadedPhotos);
      
      if (loadedPhotos.length > 0) {
        toast({
          title: "Photos restaurées avec succès ✅",
          description: `${loadedPhotos.length} photo(s) et analyses rechargées depuis Supabase`,
          duration: 4000,
        });
      } else {
        console.log('📭 Aucune photo sauvegardée trouvée dans Supabase');
        setDebugInfo('Aucune photo trouvée dans Supabase');
      }
      
    } catch (error) {
      console.error('❌ ERREUR CRITIQUE chargement photos:', error);
      setDebugInfo(`ERREUR: ${error instanceof Error ? error.message : 'Erreur inconnue'}`);
      
      toast({
        title: "Erreur de chargement ❌",
        description: `Impossible de charger les photos depuis Supabase: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        variant: "destructive",
        duration: 8000,
      });
      
      setPhotos([]);
    } finally {
      setIsLoading(false);
      console.log('📂 ========== FIN CHARGEMENT SUPABASE ==========');
    }
  };

  const clearSavedPhotos = async () => {
    try {
      await photoStorageService.clearPhotos();
      console.log('🗑️ Données Supabase supprimées');
      toast({
        title: "Données effacées",
        description: "Toutes les photos ont été supprimées de Supabase",
        duration: 3000,
      });
    } catch (error) {
      console.error('❌ Erreur lors de la suppression des données Supabase:', error);
    }
  };

  // Wrapper pour startAnalysisForPhoto avec setPhotos
  const startAnalysis = (photo: AnalyzedPhoto) => {
    startAnalysisForPhoto(photo, setPhotos);
  };

  return {
    photos,
    setPhotos,
    isLoading,
    isSaving,
    debugInfo,
    takePicture,
    selectFromGallery,
    loadSavedPhotos,
    clearSavedPhotos,
    startAnalysisForPhoto: startAnalysis,
    processPhotoData: (photosData: string[]) => processPhotoData(photosData, setPhotos, startAnalysis),
    handleRetryAnalysis: (photoId: string) => handleRetryAnalysis(photoId, photos, setPhotos, startAnalysis),
    handleRemovePhoto: (photoId: string) => handleRemovePhoto(photoId, setPhotos),
    handleSaveAll: () => handleSaveAll(photos),
    toast
  };
};
