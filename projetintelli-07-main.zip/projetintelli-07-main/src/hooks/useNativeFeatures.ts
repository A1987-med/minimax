import { Capacitor } from '@capacitor/core';

// Types pour les fonctionnalités natives
interface Position {
  latitude: number;
  longitude: number;
}

interface DeviceInfo {
  platform: string;
  model: string;
  operatingSystem: string;
  osVersion: string;
}

export const useNativeFeatures = () => {
  const isNative = Capacitor.isNativePlatform();
  
  // Détection spécifique iPad/Safari
  const isIPad = /iPad|iPhone|iPod/.test(navigator.userAgent) || 
    (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);

  const takePicture = async (): Promise<string | null> => {
    console.log('=== DEBUT takePicture ===');
    console.log('takePicture appelée, isNative:', isNative, 'isIPad:', isIPad, 'isSafari:', isSafari);
    
    if (!isNative) {
      console.log('=== MODE WEB - Using web camera API ===');
      try {
        console.log('Création de l\'élément input file...');
        // Créer un élément input file pour la capture photo
        const input = document.createElement('input');
        input.type = 'file';
        
        // Adaptation spéciale pour iPad/Safari
        if (isIPad && isSafari) {
          console.log('🍎 Mode iPad Safari détecté - Configuration spéciale');
          input.accept = 'image/*'; // Safari iPad préfère image/* simple
          input.capture = 'environment'; // Force caméra arrière
        } else {
          input.accept = 'image/*,.heic,.dng'; // Formats étendus pour autres navigateurs
          input.capture = 'environment';
        }
        
        console.log('Élément input créé:', input);
        
        return new Promise((resolve, reject) => {
          console.log('Promise créée, définition des handlers...');
          
          input.onchange = (event) => {
            console.log('=== EVENT ONCHANGE DÉCLENCHÉ ===');
            console.log('Event:', event);
            const file = (event.target as HTMLInputElement).files?.[0];
            console.log('Fichier sélectionné:', file);
            
            if (file) {
              console.log('Fichier trouvé, type:', file.type, 'taille:', file.size);
              
              // Pour les images, on utilise FileReader pour convertir en DataURL
              try {
                const reader = new FileReader();
                reader.onload = (e) => {
                  console.log('=== IMAGE CONVERTIE EN DATA URL ===');
                  const dataUrl = e.target?.result as string;
                  console.log('Data URL créée:', dataUrl.substring(0, 50) + '...');
                  resolve(dataUrl);
                };
                reader.onerror = (error) => {
                  console.error('=== ERREUR LECTURE FICHIER ===', error);
                  reject(new Error('Erreur lors de la lecture du fichier image'));
                };
                reader.readAsDataURL(file);
              } catch (error) {
                console.error('=== ERREUR CONVERSION IMAGE ===', error);
                reject(new Error('Erreur lors de la conversion de l\'image'));
              }
            } else {
              console.log('=== AUCUN FICHIER SÉLECTIONNÉ ===');
              resolve(null);
            }
          };
          
          input.oncancel = () => {
            console.log('=== CAPTURE ANNULÉE ===');
            resolve(null);
          };
          
          // Déclencher la sélection de fichier
          console.log('Déclenchement du clic sur input...');
          input.click();
          console.log('Input.click() exécuté');
        });
      } catch (error) {
        console.error('=== ERREUR GÉNÉRALE WEB CAMERA ===');
        console.error('Erreur lors de l\'accès à la caméra web:', error);
        throw new Error('Erreur lors de l\'accès à la caméra. Veuillez vérifier les permissions de votre navigateur.');
      }
    }

    try {
      console.log('Utilisation de l\'API Capacitor Camera...');
      const { Camera, CameraResultType, CameraSource } = await import('@capacitor/camera');
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera
      });
      console.log('Photo prise avec succès via Capacitor');
      return image.dataUrl || null;
    } catch (error) {
      console.error('Erreur lors de la prise de photo avec Capacitor:', error);
      throw new Error('Erreur lors de la prise de photo. Veuillez vérifier les permissions de la caméra.');
    }
  };

  const selectFromGallery = async (): Promise<string[] | null> => {
    console.log('=== DEBUT selectFromGallery MULTIPLE ===');
    console.log('selectFromGallery appelée, isNative:', isNative, 'isIPad:', isIPad, 'isSafari:', isSafari);
    
    if (!isNative) {
      console.log('=== MODE WEB - Using web file picker for multiple gallery selection ===');
      try {
        console.log('Création de l\'élément input file pour galerie multiple...');
        // Créer un élément input file pour la sélection multiple depuis la galerie
        const input = document.createElement('input');
        input.type = 'file';
        
        // Configuration spéciale pour iPad Safari
        if (isIPad && isSafari) {
          console.log('🍎 Mode iPad Safari - Configuration galerie optimisée');
          input.accept = 'image/*'; // Safari iPad fonctionne mieux avec image/* simple
          input.multiple = true;
          // Pas de capture pour forcer la galerie sur iPad
        } else {
          input.accept = 'image/*,.heic,.dng'; // Formats étendus pour autres
          input.multiple = true;
        }
        
        console.log('Élément input galerie multiple créé:', input);
        
        return new Promise((resolve, reject) => {
          console.log('Promise galerie multiple créée, définition des handlers...');
          
          // Timeout spécial pour iPad (parfois Safari prend plus de temps)
          let timeoutId: NodeJS.Timeout | null = null;
          if (isIPad) {
            timeoutId = setTimeout(() => {
              console.log('⏰ Timeout iPad - Résolution avec null');
              resolve(null);
            }, 30000); // 30 secondes pour iPad
          }
          
          input.onchange = async (event) => {
            if (timeoutId) clearTimeout(timeoutId);
            
            console.log('=== EVENT ONCHANGE GALERIE MULTIPLE DÉCLENCHÉ ===');
            console.log('Event galerie:', event);
            const files = (event.target as HTMLInputElement).files;
            console.log('Fichiers galerie sélectionnés:', files?.length);
            
            if (files && files.length > 0) {
              console.log('Fichiers galerie trouvés, traitement de', files.length, 'fichiers...');
              
              const dataUrls: string[] = [];
              let processedCount = 0;
              const totalFiles = Math.min(files.length, 20);
              
              // Traitement séquentiel pour iPad (plus stable)
              for (let i = 0; i < totalFiles; i++) {
                const file = files[i];
                console.log(`Traitement fichier ${i + 1}:`, {
                  name: file.name,
                  type: file.type,
                  size: file.size
                });
                
                try {
                  await new Promise<void>((fileResolve, fileReject) => {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                      const dataUrl = e.target?.result as string;
                      dataUrls.push(dataUrl);
                      processedCount++;
                      
                      console.log(`Image ${processedCount} convertie, total: ${processedCount}/${totalFiles}`);
                      fileResolve();
                    };
                    reader.onerror = (error) => {
                      console.error(`=== ERREUR LECTURE FICHIER ${i + 1} ===`, error);
                      processedCount++;
                      fileResolve(); // Continue même en cas d'erreur
                    };
                    reader.readAsDataURL(file);
                  });
                } catch (error) {
                  console.error(`=== ERREUR CONVERSION IMAGE ${i + 1} ===`, error);
                  processedCount++;
                }
              }
              
              console.log('=== TOUTES LES IMAGES GALERIE CONVERTIES ===');
              console.log('Total images converties:', dataUrls.length);
              resolve(dataUrls.length > 0 ? dataUrls : null);
            } else {
              console.log('=== AUCUN FICHIER GALERIE SÉLECTIONNÉ ===');
              resolve(null);
            }
          };
          
          input.oncancel = () => {
            if (timeoutId) clearTimeout(timeoutId);
            console.log('=== SÉLECTION GALERIE ANNULÉE ===');
            resolve(null);
          };
          
          // Déclencher la sélection de fichier
          console.log('Déclenchement du clic sur input galerie multiple...');
          input.click();
          console.log('Input galerie multiple.click() exécuté');
        });
      } catch (error) {
        console.error('=== ERREUR GÉNÉRALE WEB GALERIE MULTIPLE ===');
        console.error('Erreur lors de l\'accès à la galerie web:', error);
        throw new Error('Erreur lors de l\'accès à la galerie.');
      }
    }

    try {
      console.log('Utilisation de l\'API Capacitor Camera pour la galerie...');
      const { Camera, CameraResultType, CameraSource } = await import('@capacitor/camera');
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Photos // Source galerie pour Capacitor
      });
      console.log('Photo sélectionnée avec succès depuis la galerie via Capacitor');
      return image.dataUrl ? [image.dataUrl] : null;
    } catch (error) {
      console.error('Erreur lors de la sélection depuis la galerie avec Capacitor:', error);
      throw new Error('Erreur lors de la sélection depuis la galerie.');
    }
  };

  const getCurrentPosition = async (): Promise<Position | null> => {
    console.log('getCurrentPosition appelée, isNative:', isNative);
    
    if (!isNative) {
      console.log('Using web geolocation API');
      try {
        return new Promise((resolve, reject) => {
          if (!navigator.geolocation) {
            console.error('Geolocation is not supported by this browser');
            reject(new Error('La géolocalisation n\'est pas supportée par ce navigateur'));
            return;
          }

          navigator.geolocation.getCurrentPosition(
            (position) => {
              console.log('Web geolocation success:', position);
              resolve({
                latitude: position.coords.latitude,
                longitude: position.coords.longitude
              });
            },
            (error) => {
              console.error('Web geolocation error:', error);
              let errorMessage = 'Erreur de géolocalisation';
              switch (error.code) {
                case error.PERMISSION_DENIED:
                  errorMessage = 'Permission de géolocalisation refusée';
                  break;
                case error.POSITION_UNAVAILABLE:
                  errorMessage = 'Position non disponible';
                  break;
                case error.TIMEOUT:
                  errorMessage = 'Timeout de géolocalisation';
                  break;
              }
              reject(new Error(errorMessage));
            },
            {
              enableHighAccuracy: true,
              timeout: 10000,
              maximumAge: 300000
            }
          );
        });
      } catch (error) {
        console.error('Error getting web location:', error);
        throw new Error('Erreur lors de l\'obtention de la position web');
      }
    }

    try {
      console.log('Tentative d\'importation du module Geolocation...');
      const { Geolocation } = await import('@capacitor/geolocation');
      console.log('Module Geolocation importé avec succès');
      
      // Vérifier et demander les permissions
      console.log('Vérification des permissions de géolocalisation...');
      const permissions = await Geolocation.checkPermissions();
      console.log('État des permissions:', permissions);

      if (permissions.location !== 'granted') {
        console.log('Demande de permissions de géolocalisation...');
        const requestResult = await Geolocation.requestPermissions();
        console.log('Résultat de la demande de permissions:', requestResult);
        
        if (requestResult.location !== 'granted') {
          console.error('Permissions de géolocalisation refusées par l\'utilisateur');
          throw new Error('Permissions de géolocalisation refusées. Veuillez autoriser l\'accès à la localisation dans les paramètres de l\'application.');
        }
      }

      console.log('Permissions accordées, obtention de la position...');
      const coordinates = await Geolocation.getCurrentPosition({
        enableHighAccuracy: true,
        timeout: 15000
      });
      
      console.log('Position obtenue avec succès:', coordinates);
      return {
        latitude: coordinates.coords.latitude,
        longitude: coordinates.coords.longitude
      };
    } catch (error) {
      console.error('Erreur complète lors de l\'obtention de la position:', error);
      if (error instanceof Error) {
        throw error;
      } else {
        throw new Error(`Erreur lors de l'obtention de la position: ${String(error)}`);
      }
    }
  };

  const getDeviceInfo = async (): Promise<DeviceInfo | null> => {
    if (!isNative) {
      return {
        platform: 'web',
        model: 'Unknown',
        operatingSystem: navigator.platform,
        osVersion: 'Unknown'
      };
    }

    try {
      const { Device } = await import('@capacitor/device');
      const info = await Device.getInfo();
      return {
        platform: info.platform,
        model: info.model,
        operatingSystem: info.operatingSystem,
        osVersion: info.osVersion
      };
    } catch (error) {
      console.error('Error getting device info:', error);
      return null;
    }
  };

  const makePhoneCall = (phoneNumber: string) => {
    try {
      if (isNative) {
        window.open(`tel:${phoneNumber}`, '_system');
      } else {
        window.open(`tel:${phoneNumber}`, '_blank');
      }
    } catch (error) {
      console.error('Error making phone call:', error);
    }
  };

  const sendEmail = (email: string, subject?: string) => {
    try {
      const mailtoUrl = `mailto:${email}${subject ? `?subject=${encodeURIComponent(subject)}` : ''}`;
      if (isNative) {
        window.open(mailtoUrl, '_system');
      } else {
        window.open(mailtoUrl, '_blank');
      }
    } catch (error) {
      console.error('Error sending email:', error);
    }
  };

  return {
    takePicture,
    selectFromGallery,
    getCurrentPosition,
    getDeviceInfo,
    makePhoneCall,
    sendEmail,
    isNative
  };
};
