
import { useState } from 'react';
import { useToast } from "@/components/ui/use-toast";
import { analyzePhoto } from '@/services/photoAnalysisService';
import { supabasePhotoStorageService } from '@/services/supabasePhotoStorageService';
import { AnalyzedPhoto } from '@/components/sections/PhotoInspectionSection';

export const useClaudeAnalysis = () => {
  const { toast } = useToast();

  // Fonction améliorée pour convertir l'analyse Claude en format standardisé
  const normalizeClaudeAnalysis = (rawAnalysis: any) => {
    console.log('🔧 ANALYSE CLAUDE REÇUE (COMPLÈTE):', JSON.stringify(rawAnalysis, null, 2));
    
    // Si l'analyse est déjà au bon format
    if (rawAnalysis?.nonConformites && Array.isArray(rawAnalysis.nonConformites)) {
      console.log('✅ Analyse déjà au bon format');
      return {
        nonConformites: rawAnalysis.nonConformites || [],
        risques: rawAnalysis.risques || [],
        scoreGlobal: rawAnalysis.scoreGlobal || 75,
        recommandations: rawAnalysis.recommandations || [],
        environmentAnalysis: rawAnalysis.environmentAnalysis || null,
        environmentDescription: rawAnalysis.environmentDescription || null
      };
    }
    
    // Initialiser les structures de données
    const nonConformites = [];
    const risques = [];
    const recommandations = [];
    let scoreGlobal = 75; // Score par défaut
    
    // Analyse environnementale par défaut
    const environmentAnalysis = {
      humans: { 
        detected: false, 
        count: 'Non analysé', 
        equipmentStatus: 'Non analysé', 
        activities: [] 
      },
      safety: { 
        helmet: 'Non analysé', 
        vest: 'Non analysé', 
        harness: 'Non analysé', 
        boots: 'Non analysé' 
      },
      materials: { 
        construction: [], 
        tools: [], 
        storage: 'Non analysé' 
      },
      hazards: { 
        level: 'Non évalué', 
        zones: [], 
        conditions: 'Non analysé' 
      },
      infrastructure: { 
        lighting: 'Non analysé', 
        surfaces: 'Non analysé', 
        access: 'Non analysé' 
      }
    };

    // TRAITEMENT DU NOUVEAU FORMAT DE CLAUDE - observation_personnel
    if (rawAnalysis?.observation_personnel) {
      const obs = rawAnalysis.observation_personnel;
      
      // Analyser les équipements
      if (obs.equipements) {
        const equipText = typeof obs.equipements === 'string' ? obs.equipements.toLowerCase() : '';
        
        // Vérifier les EPI manquants
        if (!equipText.includes('casque') || equipText.includes('sans casque')) {
          nonConformites.push({
            type: "🪖 EPI manquant - Casque de sécurité",
            description: `Personnel sans casque détecté: ${obs.equipements}`,
            gravite: 'eleve' as const,
            solution: "Port obligatoire du casque de sécurité sur le chantier"
          });
          scoreGlobal -= 20;
        }
        
        if (!equipText.includes('gilet') && !equipText.includes('veste')) {
          nonConformites.push({
            type: "🦺 EPI manquant - Gilet haute visibilité",
            description: `Personnel sans gilet de sécurité: ${obs.equipements}`,
            gravite: 'moyen' as const,
            solution: "Port obligatoire du gilet haute visibilité"
          });
          scoreGlobal -= 15;
        }
        
        if (!equipText.includes('harnais') && rawAnalysis?.dangers_observables?.deniveles) {
          nonConformites.push({
            type: "🔗 EPI manquant - Harnais de sécurité",
            description: "Personnel sans harnais près de zones en hauteur",
            gravite: 'critique' as const,
            solution: "Port obligatoire du harnais avec point d'ancrage certifié"
          });
          scoreGlobal -= 25;
        }
        
        // Reconnaître les équipements présents
        if (equipText.includes('casque') && equipText.includes('gilet')) {
          recommandations.push("✅ Port correct des EPI de base observé (casques et gilets)");
          scoreGlobal += 10;
        }
      }
      
      // Analyser les positions et activités
      if (obs.positions) {
        const positionsText = typeof obs.positions === 'string' ? obs.positions.toLowerCase() : '';
        if (positionsText.includes('proche') || positionsText.includes('près')) {
          risques.push({
            type: "Proximité avec équipements",
            description: `Personnel en position potentiellement dangereuse: ${obs.positions}`,
            probabilite: 'moyen' as const,
            impact: 'moyen' as const,
            prevention: "Maintenir une distance de sécurité avec les équipements en mouvement"
          });
        }
      }
    }

    // TRAITEMENT DES MATÉRIAUX ET ÉQUIPEMENTS - AVEC PROTECTION CONTRE LES ERREURS
    if (rawAnalysis?.materiaux) {
      const mat = rawAnalysis.materiaux;
      
      if (mat.equipements) {
        recommandations.push(`🏗️ Équipements présents: ${mat.equipements}`);
        
        // Vérifier la sécurité des équipements
        const equipText = typeof mat.equipements === 'string' ? mat.equipements.toLowerCase() : '';
        if (equipText.includes('grue') || equipText.includes('engin')) {
          risques.push({
            type: "Équipements lourds en service",
            description: `Présence d'engins de chantier: ${mat.equipements}`,
            probabilite: 'moyen' as const,
            impact: 'eleve' as const,
            prevention: "Maintenir périmètre de sécurité autour des engins en mouvement"
          });
        }
      }
      
      // CORRECTION DE L'ERREUR : Vérifier le type avant d'appeler toLowerCase()
      if (mat.armatures) {
        let armaturesText = '';
        if (typeof mat.armatures === 'string') {
          armaturesText = mat.armatures.toLowerCase();
        } else if (typeof mat.armatures === 'object') {
          // Si c'est un objet, extraire les informations pertinentes
          armaturesText = JSON.stringify(mat.armatures).toLowerCase();
        }
        
        if (armaturesText.includes('non protégées') || armaturesText.includes('exposées')) {
          nonConformites.push({
            type: "⚠️ Armatures non protégées",
            description: `Armatures d'attente exposées: ${typeof mat.armatures === 'string' ? mat.armatures : 'Armatures détectées'}`,
            gravite: 'moyen' as const,
            solution: "Installer des cache-armatures ou protections anti-perforation"
          });
          scoreGlobal -= 15;
        }
      }
    }

    // TRAITEMENT DE L'OBSERVATION MICROSCOPIQUE (nouveau format)
    if (rawAnalysis?.observation_microscopique) {
      const obs = rawAnalysis.observation_microscopique;
      
      if (obs.personnes) {
        const nombre = obs.personnes.nombre || 0;
        if (nombre > 0) {
          recommandations.push(`👥 ${nombre} personne(s) détectée(s) sur le chantier`);
          
          // Analyser les équipements visibles
          if (obs.personnes.equipements_visibles) {
            const equipText = obs.personnes.equipements_visibles.toLowerCase();
            if (equipText.includes('gilet')) {
              recommandations.push("✅ Port du gilet haute visibilité observé");
              scoreGlobal += 10;
            }
            if (equipText.includes('casque')) {
              recommandations.push("✅ Port du casque observé");
              scoreGlobal += 10;
            }
          }
          
          // Analyser les positions
          if (obs.personnes.position) {
            recommandations.push(`📍 Position: ${obs.personnes.position}`);
          }
        }
      }
    }

    // TRAITEMENT DE L'ENVIRONNEMENT
    if (rawAnalysis?.environnement) {
      const env = rawAnalysis.environnement;
      
      if (env.protection_collective) {
        if (env.protection_collective.cloture) {
          recommandations.push("✅ Périmètre de sécurité présent");
          scoreGlobal += 5;
        }
        
        if (env.protection_collective.garde_corps) {
          recommandations.push("✅ Garde-corps de protection en place");
          scoreGlobal += 10;
        }
      }
      
      if (env.meteo) {
        if (env.meteo.luminosite && env.meteo.luminosite.includes("bonne")) {
          recommandations.push("✅ Bonnes conditions de visibilité");
          scoreGlobal += 5;
        }
      }
    }

    // TRAITEMENT DES DANGERS OBSERVABLES
    if (rawAnalysis?.dangers_observables) {
      const dangers = rawAnalysis.dangers_observables;
      
      if (dangers.deniveles) {
        nonConformites.push({
          type: "🏗️ Risque de chute - Dénivellés",
          description: `Excavation importante détectée: ${dangers.deniveles}`,
          gravite: 'eleve' as const,
          solution: "Installer des garde-corps et signalisation de sécurité"
        });
        
        risques.push({
          type: "Chute en hauteur/profondeur",
          description: "Excavation non sécurisée avec risque de chute",
          probabilite: 'eleve' as const,
          impact: 'critique' as const,
          prevention: "Barrières de protection, signalisation et formation du personnel"
        });
        
        scoreGlobal -= 25;
      }
      
      // Traitement des armatures d'attente avec protection d'erreur
      if (dangers.armatures_attente) {
        let protectionText = '';
        if (typeof dangers.armatures_attente.protection === 'string') {
          protectionText = dangers.armatures_attente.protection.toLowerCase();
        }
        
        if (protectionText.includes('visible') && protectionText.includes('capuchons')) {
          recommandations.push("✅ Armatures d'attente protégées par des capuchons");
          scoreGlobal += 15;
        }
      }
    }

    // TRAITEMENT DU NOUVEAU FORMAT ENVIRONMENT ANALYSIS
    if (rawAnalysis?.environmentAnalysis) {
      // On garde l'analyse environnementale telle quelle
      Object.assign(environmentAnalysis, rawAnalysis.environmentAnalysis);
    }

    // FALLBACK - Si aucune analyse spécifique n'a été détectée, créer une analyse basique
    if (nonConformites.length === 0 && risques.length === 0) {
      // Essayer d'extraire des informations générales
      const analysisText = JSON.stringify(rawAnalysis).toLowerCase();
      
      if (analysisText.includes('personne') || analysisText.includes('ouvrier') || analysisText.includes('travailleur')) {
        recommandations.push("👥 Personnel détecté sur le chantier");
        
        if (analysisText.includes('casque')) {
          recommandations.push("✅ Port du casque observé");
          scoreGlobal += 5;
        }
        
        if (analysisText.includes('gilet') || analysisText.includes('veste')) {
          recommandations.push("✅ Port du gilet de sécurité observé");
          scoreGlobal += 5;
        }
        
        if (!analysisText.includes('danger') && !analysisText.includes('risque')) {
          nonConformites.push({
            type: "✅ Situation apparemment conforme",
            description: "Aucun danger immédiat détecté par l'analyse automatique",
            gravite: 'faible' as const,
            solution: "Maintenir les bonnes pratiques de sécurité"
          });
          scoreGlobal = Math.max(scoreGlobal, 80);
        }
      } else {
        // Si vraiment aucune information n'est extractible
        nonConformites.push({
          type: "🔍 Analyse incomplète",
          description: "L'analyse automatique n'a pas pu extraire suffisamment d'informations de la photo",
          gravite: 'moyen' as const,
          solution: "Effectuer une inspection visuelle manuelle pour compléter l'analyse"
        });
        scoreGlobal = 60;
      }
    }

    // Recommandations générales
    if (nonConformites.length > 0) {
      recommandations.push("🔍 Effectuer une inspection de sécurité approfondie");
      recommandations.push("📋 Documenter les mesures correctives à prendre");
    }
    
    if (recommandations.length === 0) {
      recommandations.push("✅ Continuer la surveillance des bonnes pratiques");
      recommandations.push("🔍 Maintenir la vigilance sur les procédures de sécurité");
    }

    // S'assurer que le score reste dans une plage raisonnable
    scoreGlobal = Math.max(20, Math.min(95, scoreGlobal));

    // Récupérer la description environnementale
    let environmentDescription = rawAnalysis?.environmentDescription || 
      "Description environnementale non disponible. L'analyse automatique n'a pas pu générer une description complète.";

    const finalAnalysis = {
      nonConformites,
      risques,
      scoreGlobal,
      recommandations,
      environmentAnalysis,
      environmentDescription
    };

    console.log('🎯 ANALYSE FINALE GÉNÉRÉE:', {
      nonConformitesCount: finalAnalysis.nonConformites.length,
      risquesCount: finalAnalysis.risques.length,
      scoreGlobal: finalAnalysis.scoreGlobal,
      recommendationsCount: finalAnalysis.recommandations.length,
      hasEnvironmentAnalysis: !!finalAnalysis.environmentAnalysis,
      details: finalAnalysis
    });

    return finalAnalysis;
  };

  const startAnalysisForPhoto = async (photo: AnalyzedPhoto, updatePhotos: (updater: (prev: AnalyzedPhoto[]) => AnalyzedPhoto[]) => void) => {
    try {
      console.log('🔍 Analyse IA Claude en cours pour la photo:', photo.id);
      const rawAnalysis = await analyzePhoto(photo.url);
      
      console.log('📊 Analyse brute reçue de Claude:', rawAnalysis);
      
      // Normaliser l'analyse reçue
      const analysis = normalizeClaudeAnalysis(rawAnalysis);
      
      console.log('📊 Analyse normalisée:', {
        nonConformitesCount: analysis.nonConformites?.length || 0,
        risquesCount: analysis.risques?.length || 0,
        scoreGlobal: analysis.scoreGlobal,
        recommendationsCount: analysis.recommandations?.length || 0,
        hasEnvironmentAnalysis: !!analysis.environmentAnalysis
      });
      
      // Mettre à jour dans Supabase - Conversion des types pour compatibilité
      const supabaseAnalysis = {
        nonConformites: (analysis.nonConformites || []).map(nc => ({
          type: nc.type || 'Non-conformité détectée',
          description: nc.description || 'Description non disponible',
          gravite: (nc.gravite === 'critique' ? 'eleve' : nc.gravite) || 'moyen',
          solution: nc.solution || 'Vérification manuelle recommandée'
        })),
        risques: (analysis.risques || []).map(risque => ({
          type: risque.type || 'Risque identifié',
          description: risque.description || 'Description non disponible',
          niveau: (risque.impact === 'critique' ? 'eleve' : (risque.impact as 'faible' | 'moyen' | 'eleve')) || 'moyen',
          prevention: risque.prevention || 'Mesures préventives à définir'
        })),
        scoreGlobal: analysis.scoreGlobal || 75,
        recommandations: analysis.recommandations || ['Inspection manuelle recommandée'],
        environmentAnalysis: analysis.environmentAnalysis,
        environmentDescription: analysis.environmentDescription
      };
      
      await supabasePhotoStorageService.updateAnalysis(photo.id, supabaseAnalysis, false);
      
      updatePhotos(prev => prev.map(p => 
        p.id === photo.id 
          ? { 
              ...p, 
              analyzing: false,
              analysis,
              analysisStartTime: undefined
            }
          : p
      ));
      
      console.log('✅ Analyse Claude terminée et sauvegardée pour:', photo.id);
      
      toast({
        title: "Analyse Claude terminée ✅",
        description: `${analysis.nonConformites?.length || 0} non-conformité(s) et ${analysis.risques?.length || 0} risque(s) détecté(s) - Score: ${analysis.scoreGlobal}%`,
        duration: 6000,
      });
      
    } catch (error) {
      console.error('❌ Erreur analyse photo:', error);
      
      const errorAnalysis = {
        nonConformites: [{
          type: "Erreur d'analyse Claude",
          description: `L'analyse automatique avec Claude a échoué: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
          gravite: 'moyen' as const,
          solution: "Vérification manuelle recommandée ou relancer l'analyse"
        }],
        risques: [],
        scoreGlobal: 50,
        recommandations: ["Contacter un expert", "Reprendre la photo", "Relancer l'analyse"],
        environmentAnalysis: {
          humans: { 
            detected: false, 
            count: 'Erreur analyse', 
            equipmentStatus: 'Non analysé', 
            activities: [] 
          },
          safety: { 
            helmet: 'Erreur analyse', 
            vest: 'Erreur analyse', 
            harness: 'Erreur analyse', 
            boots: 'Erreur analyse' 
          },
          materials: { 
            construction: [], 
            tools: [], 
            storage: 'Erreur analyse' 
          },
          hazards: { 
            level: 'Non évalué', 
            zones: [], 
            conditions: 'Erreur analyse' 
          },
          infrastructure: { 
            lighting: 'Erreur analyse', 
            surfaces: 'Erreur analyse', 
            access: 'Erreur analyse' 
          }
        },
        environmentDescription: `Erreur d'analyse Claude: ${error instanceof Error ? error.message : 'Erreur inconnue'}`
      };
      
      const supabaseErrorAnalysis = {
        nonConformites: errorAnalysis.nonConformites,
        risques: [],
        scoreGlobal: errorAnalysis.scoreGlobal,
        recommandations: errorAnalysis.recommandations,
        environmentAnalysis: errorAnalysis.environmentAnalysis,
        environmentDescription: errorAnalysis.environmentDescription
      };
      
      await supabasePhotoStorageService.updateAnalysis(photo.id, supabaseErrorAnalysis, false);
      
      updatePhotos(prev => prev.map(p => 
        p.id === photo.id 
          ? { 
              ...p, 
              analyzing: false,
              analysisStartTime: undefined,
              analysis: errorAnalysis
            }
          : p
      ));
      
      toast({
        title: "Erreur d'analyse Claude ❌",
        description: "L'analyse a échoué. Vous pouvez la relancer ou effectuer une vérification manuelle.",
        variant: "destructive",
        duration: 6000,
      });
    }
  };

  return {
    startAnalysisForPhoto
  };
};
