export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      analysis_stats: {
        Row: {
          analysis_type: string
          average_processing_time: number | null
          created_at: string | null
          id: string
          success_rate: number | null
          total_analyses: number | null
          updated_at: string | null
        }
        Insert: {
          analysis_type: string
          average_processing_time?: number | null
          created_at?: string | null
          id?: string
          success_rate?: number | null
          total_analyses?: number | null
          updated_at?: string | null
        }
        Update: {
          analysis_type?: string
          average_processing_time?: number | null
          created_at?: string | null
          id?: string
          success_rate?: number | null
          total_analyses?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      ast_data: {
        Row: {
          corps_metier: string
          created_at: string
          data: Json
          id: string
          updated_at: string
        }
        Insert: {
          corps_metier: string
          created_at?: string
          data: Json
          id?: string
          updated_at?: string
        }
        Update: {
          corps_metier?: string
          created_at?: string
          data?: Json
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      checklists_prevention: {
        Row: {
          completee_par: string | null
          created_at: string
          date_completion: string | null
          id: string
          items: Json | null
          observations: string | null
          statut: string | null
          titre: string
          type_checklist: string
          updated_at: string
        }
        Insert: {
          completee_par?: string | null
          created_at?: string
          date_completion?: string | null
          id?: string
          items?: Json | null
          observations?: string | null
          statut?: string | null
          titre: string
          type_checklist: string
          updated_at?: string
        }
        Update: {
          completee_par?: string | null
          created_at?: string
          date_completion?: string | null
          id?: string
          items?: Json | null
          observations?: string | null
          statut?: string | null
          titre?: string
          type_checklist?: string
          updated_at?: string
        }
        Relationships: []
      }
      entries_accueil: {
        Row: {
          adresse: string | null
          age: number | null
          allergie: string | null
          carte_asp: string | null
          carte_asp_name: string | null
          carte_ccq: string | null
          carte_ccq_name: string | null
          carte_secouriste: string | null
          carte_secouriste_name: string | null
          carte_simdut: string | null
          carte_simdut_name: string | null
          cartes_formations: Json | null
          cellulaire_contact: string | null
          code_postal: string | null
          corps_metier: string | null
          courriel: string | null
          created_at: string
          date_accueil: string | null
          date_ajout: string
          date_echeance_carte: string | null
          date_echeancier_secouriste: string | null
          date_entree: string
          entreprise: string | null
          est_cadre: boolean | null
          est_contremaitre: boolean | null
          est_secouriste: boolean | null
          est_sous_traitant: boolean | null
          etiquette_recue: boolean | null
          fonction: string | null
          heure_entree: string
          id: string
          logo: string | null
          maladie: string | null
          nom: string
          nom_contact_accident: string | null
          nom_employe: string | null
          nom_sous_traitant: string | null
          numero_client: string | null
          numero_etiquette: string | null
          numero_immatriculation: string | null
          occupations: Json | null
          prenom: string
          selected_formations: Json | null
          soustraitant: string | null
          telephone: string | null
          updated_at: string
          ville: string | null
        }
        Insert: {
          adresse?: string | null
          age?: number | null
          allergie?: string | null
          carte_asp?: string | null
          carte_asp_name?: string | null
          carte_ccq?: string | null
          carte_ccq_name?: string | null
          carte_secouriste?: string | null
          carte_secouriste_name?: string | null
          carte_simdut?: string | null
          carte_simdut_name?: string | null
          cartes_formations?: Json | null
          cellulaire_contact?: string | null
          code_postal?: string | null
          corps_metier?: string | null
          courriel?: string | null
          created_at?: string
          date_accueil?: string | null
          date_ajout?: string
          date_echeance_carte?: string | null
          date_echeancier_secouriste?: string | null
          date_entree: string
          entreprise?: string | null
          est_cadre?: boolean | null
          est_contremaitre?: boolean | null
          est_secouriste?: boolean | null
          est_sous_traitant?: boolean | null
          etiquette_recue?: boolean | null
          fonction?: string | null
          heure_entree: string
          id?: string
          logo?: string | null
          maladie?: string | null
          nom: string
          nom_contact_accident?: string | null
          nom_employe?: string | null
          nom_sous_traitant?: string | null
          numero_client?: string | null
          numero_etiquette?: string | null
          numero_immatriculation?: string | null
          occupations?: Json | null
          prenom: string
          selected_formations?: Json | null
          soustraitant?: string | null
          telephone?: string | null
          updated_at?: string
          ville?: string | null
        }
        Update: {
          adresse?: string | null
          age?: number | null
          allergie?: string | null
          carte_asp?: string | null
          carte_asp_name?: string | null
          carte_ccq?: string | null
          carte_ccq_name?: string | null
          carte_secouriste?: string | null
          carte_secouriste_name?: string | null
          carte_simdut?: string | null
          carte_simdut_name?: string | null
          cartes_formations?: Json | null
          cellulaire_contact?: string | null
          code_postal?: string | null
          corps_metier?: string | null
          courriel?: string | null
          created_at?: string
          date_accueil?: string | null
          date_ajout?: string
          date_echeance_carte?: string | null
          date_echeancier_secouriste?: string | null
          date_entree?: string
          entreprise?: string | null
          est_cadre?: boolean | null
          est_contremaitre?: boolean | null
          est_secouriste?: boolean | null
          est_sous_traitant?: boolean | null
          etiquette_recue?: boolean | null
          fonction?: string | null
          heure_entree?: string
          id?: string
          logo?: string | null
          maladie?: string | null
          nom?: string
          nom_contact_accident?: string | null
          nom_employe?: string | null
          nom_sous_traitant?: string | null
          numero_client?: string | null
          numero_etiquette?: string | null
          numero_immatriculation?: string | null
          occupations?: Json | null
          prenom?: string
          selected_formations?: Json | null
          soustraitant?: string | null
          telephone?: string | null
          updated_at?: string
          ville?: string | null
        }
        Relationships: []
      }
      image_analysis: {
        Row: {
          analysis_results: Json
          created_at: string | null
          file_name: string
          file_size: number | null
          file_type: string | null
          id: string
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          analysis_results: Json
          created_at?: string | null
          file_name: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          analysis_results?: Json
          created_at?: string | null
          file_name?: string
          file_size?: number | null
          file_type?: string | null
          id?: string
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      inspections: {
        Row: {
          actions_correctives: string | null
          conformite: boolean | null
          created_at: string
          date_prevue: string | null
          date_prochaine_inspection: string | null
          date_realisation: string | null
          description: string | null
          equipement_zone: string | null
          heure_inspection: string | null
          id: string
          inspecteur: string | null
          resultats: Json | null
          status: string | null
          titre: string
          type_inspection: string | null
          updated_at: string
        }
        Insert: {
          actions_correctives?: string | null
          conformite?: boolean | null
          created_at?: string
          date_prevue?: string | null
          date_prochaine_inspection?: string | null
          date_realisation?: string | null
          description?: string | null
          equipement_zone?: string | null
          heure_inspection?: string | null
          id?: string
          inspecteur?: string | null
          resultats?: Json | null
          status?: string | null
          titre: string
          type_inspection?: string | null
          updated_at?: string
        }
        Update: {
          actions_correctives?: string | null
          conformite?: boolean | null
          created_at?: string
          date_prevue?: string | null
          date_prochaine_inspection?: string | null
          date_realisation?: string | null
          description?: string | null
          equipement_zone?: string | null
          heure_inspection?: string | null
          id?: string
          inspecteur?: string | null
          resultats?: Json | null
          status?: string | null
          titre?: string
          type_inspection?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      non_conformites_video: {
        Row: {
          confiance_score: number | null
          created_at: string
          description: string
          id: string
          niveau_gravite: string
          timestamp_video: number
          type_non_conformite: string
          updated_at: string
          video_inspection_id: string
        }
        Insert: {
          confiance_score?: number | null
          created_at?: string
          description: string
          id?: string
          niveau_gravite: string
          timestamp_video: number
          type_non_conformite: string
          updated_at?: string
          video_inspection_id: string
        }
        Update: {
          confiance_score?: number | null
          created_at?: string
          description?: string
          id?: string
          niveau_gravite?: string
          timestamp_video?: number
          type_non_conformite?: string
          updated_at?: string
          video_inspection_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "non_conformites_video_video_inspection_id_fkey"
            columns: ["video_inspection_id"]
            isOneToOne: false
            referencedRelation: "video_inspections"
            referencedColumns: ["id"]
          },
        ]
      }
      photo_inspections: {
        Row: {
          analysis: Json | null
          analysis_result: Json | null
          analysis_start_time: number | null
          analyzing: boolean | null
          analyzing_status: boolean | null
          created_at: string
          date_inspection: string
          file_name: string | null
          file_size: number | null
          file_type: string | null
          id: string
          image_path: string | null
          image_url: string
          nom_fichier: string | null
          taille_fichier: number | null
          timestamp: number | null
          type_fichier: string | null
          updated_at: string
        }
        Insert: {
          analysis?: Json | null
          analysis_result?: Json | null
          analysis_start_time?: number | null
          analyzing?: boolean | null
          analyzing_status?: boolean | null
          created_at?: string
          date_inspection?: string
          file_name?: string | null
          file_size?: number | null
          file_type?: string | null
          id?: string
          image_path?: string | null
          image_url: string
          nom_fichier?: string | null
          taille_fichier?: number | null
          timestamp?: number | null
          type_fichier?: string | null
          updated_at?: string
        }
        Update: {
          analysis?: Json | null
          analysis_result?: Json | null
          analysis_start_time?: number | null
          analyzing?: boolean | null
          analyzing_status?: boolean | null
          created_at?: string
          date_inspection?: string
          file_name?: string | null
          file_size?: number | null
          file_type?: string | null
          id?: string
          image_path?: string | null
          image_url?: string
          nom_fichier?: string | null
          taille_fichier?: number | null
          timestamp?: number | null
          type_fichier?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      signalements: {
        Row: {
          created_at: string
          date_incident: string | null
          description: string
          gravite: string | null
          heure_incident: string | null
          id: string
          latitude: number | null
          lieu: string | null
          longitude: number | null
          mesures_prises: string | null
          photo_url: string | null
          rapporte_par: string | null
          status: string | null
          statut: string | null
          temoin_contact: string | null
          temoin_nom: string | null
          type: string
          type_incident: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          date_incident?: string | null
          description: string
          gravite?: string | null
          heure_incident?: string | null
          id?: string
          latitude?: number | null
          lieu?: string | null
          longitude?: number | null
          mesures_prises?: string | null
          photo_url?: string | null
          rapporte_par?: string | null
          status?: string | null
          statut?: string | null
          temoin_contact?: string | null
          temoin_nom?: string | null
          type: string
          type_incident?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          date_incident?: string | null
          description?: string
          gravite?: string | null
          heure_incident?: string | null
          id?: string
          latitude?: number | null
          lieu?: string | null
          longitude?: number | null
          mesures_prises?: string | null
          photo_url?: string | null
          rapporte_par?: string | null
          status?: string | null
          statut?: string | null
          temoin_contact?: string | null
          temoin_nom?: string | null
          type?: string
          type_incident?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      soustraitants: {
        Row: {
          actif: boolean
          adresse: string | null
          courriel: string | null
          created_at: string
          date_ajout: string
          id: string
          nom: string
          telephone: string | null
          updated_at: string
        }
        Insert: {
          actif?: boolean
          adresse?: string | null
          courriel?: string | null
          created_at?: string
          date_ajout?: string
          id?: string
          nom: string
          telephone?: string | null
          updated_at?: string
        }
        Update: {
          actif?: boolean
          adresse?: string | null
          courriel?: string | null
          created_at?: string
          date_ajout?: string
          id?: string
          nom?: string
          telephone?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      transcriptions_audio: {
        Row: {
          created_at: string
          id: string
          locuteur: string | null
          mots_cles_securite: string[] | null
          texte_transcrit: string
          timestamp_debut: number
          timestamp_fin: number
          updated_at: string
          video_inspection_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          locuteur?: string | null
          mots_cles_securite?: string[] | null
          texte_transcrit: string
          timestamp_debut: number
          timestamp_fin: number
          updated_at?: string
          video_inspection_id: string
        }
        Update: {
          created_at?: string
          id?: string
          locuteur?: string | null
          mots_cles_securite?: string[] | null
          texte_transcrit?: string
          timestamp_debut?: number
          timestamp_fin?: number
          updated_at?: string
          video_inspection_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transcriptions_audio_video_inspection_id_fkey"
            columns: ["video_inspection_id"]
            isOneToOne: false
            referencedRelation: "video_inspections"
            referencedColumns: ["id"]
          },
        ]
      }
      uploaded_files: {
        Row: {
          analysis_id: string | null
          created_at: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id: string
          storage_bucket: string | null
          user_id: string | null
        }
        Insert: {
          analysis_id?: string | null
          created_at?: string | null
          file_name: string
          file_path: string
          file_size: number
          file_type: string
          id?: string
          storage_bucket?: string | null
          user_id?: string | null
        }
        Update: {
          analysis_id?: string | null
          created_at?: string | null
          file_name?: string
          file_path?: string
          file_size?: number
          file_type?: string
          id?: string
          storage_bucket?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "uploaded_files_analysis_id_fkey"
            columns: ["analysis_id"]
            isOneToOne: false
            referencedRelation: "analysis_with_files"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "uploaded_files_analysis_id_fkey"
            columns: ["analysis_id"]
            isOneToOne: false
            referencedRelation: "image_analysis"
            referencedColumns: ["id"]
          },
        ]
      }
      video_inspections: {
        Row: {
          chemin_video: string
          created_at: string
          date_inspection: string
          description_environnement: string | null
          duree_video: number | null
          id: string
          nom_fichier: string
          statut_analyse: string | null
          taille_fichier: number | null
          updated_at: string
        }
        Insert: {
          chemin_video: string
          created_at?: string
          date_inspection: string
          description_environnement?: string | null
          duree_video?: number | null
          id?: string
          nom_fichier: string
          statut_analyse?: string | null
          taille_fichier?: number | null
          updated_at?: string
        }
        Update: {
          chemin_video?: string
          created_at?: string
          date_inspection?: string
          description_environnement?: string | null
          duree_video?: number | null
          id?: string
          nom_fichier?: string
          statut_analyse?: string | null
          taille_fichier?: number | null
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      analysis_with_files: {
        Row: {
          analysis_date: string | null
          analysis_results: Json | null
          analysis_types: Json | null
          file_name: string | null
          file_path: string | null
          file_size: number | null
          file_type: string | null
          id: string | null
          successful_analyses: number | null
          user_id: string | null
        }
        Relationships: []
      }
    }
    Functions: {
      cleanup_old_analyses: {
        Args: Record<PropertyKey, never>
        Returns: number
      }
      get_user_analysis_stats: {
        Args: { user_uuid: string }
        Returns: {
          total_analyses: number
          analysis_types_used: Json
          success_rate: number
          recent_analyses: Json
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
