
import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'

console.log('🍎 iPad - Initialisation de l\'application...');

const rootElement = document.getElementById("root");
if (!rootElement) {
  console.error('🍎 iPad - Élément root non trouvé!');
  throw new Error('Root element not found');
}

console.log('🍎 iPad - Élément root trouvé, création du root React...');
const root = createRoot(rootElement);

console.log('🍎 iPad - Rendu de l\'application...');
root.render(<App />);

console.log('🍎 iPad - Application rendue avec succès');
