import { CalorifugeurAST } from '../types/calorifugeur';

export const calorifugeurASTData: CalorifugeurAST = {
  metier: "Calorifugeur",
  createdAt: new Date().toISOString(),
  taches: [
    {
      id: "tache-1",
      numero: 1,
      nom: "Préparer les travaux",
      description: "Préparation complète des travaux de calorifugeage",
      operations: [
        {
          id: "op-1-1",
          nom: "Recevoir les consignes",
          description: "Réception et analyse des consignes de travail",
          outils: [
            { nom: "crayons", type: "Équipement de traçage", securiteRequise: [] },
            { nom: "crayons feutres", type: "Équipement de traçage", securiteRequise: [] },
            { nom: "rubans à mesurer", type: "Équipement de traçage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-1-1-1", nom: "Se rendre sur les lieux des travaux", description: "Déplacement sur le site d'intervention" },
            { id: "sous-1-1-2", nom: "Vérifier les particularités du chantier", description: "Analyse des spécificités du chantier" },
            { id: "sous-1-1-3", nom: "Vérifier les conditions météorologiques (température, vent, pluie, etc.), s'il y a lieu", description: "Contrôle des conditions météorologiques" }
          ]
        },
        {
          id: "op-1-2",
          nom: "Mettre en place les mesures de sécurité nécessaires",
          description: "Installation complète des mesures de sécurité",
          outils: [
            { nom: "échafaudage", type: "Matériel d'accès", securiteRequise: ["formation échafaudage"] },
            { nom: "échelles", type: "Matériel d'accès", securiteRequise: [] },
            { nom: "escabeaux 6 pi, 8 pi, 10 pi", type: "Matériel d'accès", securiteRequise: [] },
            { nom: "casques de sécurité", type: "EPI", securiteRequise: [] },
            { nom: "gants", type: "EPI", securiteRequise: [] },
            { nom: "lunettes de sécurité", type: "EPI", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-1-2-1", nom: "Participer aux rencontres de sécurité", description: "Participation aux briefings sécurité" },
            { id: "sous-1-2-2", nom: "Prendre connaissance des mesures de sécurité et de l'analyse de risque", description: "Étude des procédures de sécurité" },
            { id: "sous-1-2-3", nom: "Vérifier les éléments de sécurité sur le permis de travail", description: "Contrôle du permis de travail" },
            { id: "sous-1-2-4", nom: "Vérifier les règles internes et particulières du client, en lien avec la santé et la sécurité", description: "Conformité aux règles client" },
            { id: "sous-1-2-5", nom: "Déterminer l'équipement de sécurité requis et s'assurer de sa disponibilité et de son bon état", description: "Vérification des EPI" },
            { id: "sous-1-2-6", nom: "Vérifier les risques liés à la qualité de l'air, s'il y a lieu", description: "Contrôle de la qualité de l'air" },
            { id: "sous-1-2-7", nom: "Lire les fiches signalétiques des produits à utiliser", description: "Lecture des fiches de sécurité" },
            { id: "sous-1-2-8", nom: "Établir le ou les périmètres de sécurité", description: "Délimitation des zones de sécurité" },
            { id: "sous-1-2-9", nom: "Installer des filets sous les échafaudages, empêchant la chute d'outils, de matériaux, etc.", description: "Installation des filets de protection" },
            { id: "sous-1-2-10", nom: "Cadenasser la machinerie, s'il y a lieu", description: "Verrouillage des équipements" }
          ]
        },
        {
          id: "op-1-3",
          nom: "Recevoir les matériaux et l'équipement",
          description: "Réception et vérification des matériaux",
          outils: [
            { nom: "balance analytique", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "appareil pour test d'adhésion", type: "Équipement de test", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-1-3-1", nom: "Vérifier l'état et les quantités de matériaux et d'équipement", description: "Contrôle qualité et quantité" },
            { id: "sous-1-3-2", nom: "Prévoir un lieu d'entreposage", description: "Organisation du stockage" }
          ]
        },
        {
          id: "op-1-4",
          nom: "Préparer les matériaux, l'outillage et l'équipement",
          description: "Préparation et organisation des outils",
          outils: [
            { nom: "porte-outils", type: "Équipement de transport", securiteRequise: [] },
            { nom: "sacs à gants", type: "Équipement de protection", securiteRequise: [] },
            { nom: "tuyau d'arrosage", type: "Équipement de nettoyage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-1-4-1", nom: "Disposer les matériaux, l'outillage et l'équipement aux bons endroits", description: "Positionnement optimal des ressources" },
            { id: "sous-1-4-2", nom: "Organiser son aire de travail", description: "Organisation de l'espace de travail" }
          ]
        },
        {
          id: "op-1-5",
          nom: "Protéger les surfaces environnantes",
          description: "Protection des surfaces adjacentes",
          outils: [
            { nom: "bandes élastiques rondes", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] },
            { nom: "rouleaux à peinture", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-1-5-1", nom: "Recouvrir les surfaces ou les objets à protéger (polythène, filet, etc.)", description: "Installation des protections" },
            { id: "sous-1-5-2", nom: "Fabriquer des abris", description: "Construction d'abris temporaires" }
          ]
        }
      ]
    },
    {
      id: "tache-2",
      numero: 2,
      nom: "Ériger des échafaudages",
      description: "Construction et installation d'échafaudages sécurisés",
      operations: [
        {
          id: "op-2-1",
          nom: "Faire l'inventaire des éléments",
          description: "Inventaire complet des composants d'échafaudage",
          outils: [
            { nom: "calculatrices", type: "Équipement de calcul", securiteRequise: [] },
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "règles graduées", type: "Équipement de mesure", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-2-1-1", nom: "Prendre les mesures de l'échafaudage", description: "Relevé des dimensions nécessaires" },
            { id: "sous-2-1-2", nom: "Identifier les obstacles pour l'installation", description: "Analyse des contraintes d'installation" },
            { id: "sous-2-1-3", nom: "Calculer le nombre d'éléments de l'échafaudage", description: "Calcul des besoins en matériaux" },
            { id: "sous-2-1-4", nom: "Procéder à l'inspection visuelle de l'équipement", description: "Contrôle de l'état des composants" },
            { id: "sous-2-1-5", nom: "Détecter les bris", description: "Identification des défauts" },
            { id: "sous-2-1-6", nom: "Remplacer les éléments endommagés", description: "Remplacement des pièces défectueuses" }
          ]
        },
        {
          id: "op-2-2",
          nom: "Prendre connaissance du mode d'assemblage",
          description: "Étude des procédures d'assemblage",
          outils: [
            { nom: "manuel d'instructions", type: "Documentation", securiteRequise: [] },
            { nom: "schémas techniques", type: "Documentation", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-2-3",
          nom: "Asseoir la base",
          description: "Installation et mise à niveau de la base",
          outils: [
            { nom: "niveaux", type: "Outils de mesure", securiteRequise: [] },
            { nom: "marteaux", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-2-3-1", nom: "Vérifier la solidité du sol", description: "Contrôle de la portance du sol" },
            { id: "sous-2-3-2", nom: "Installer les bases de bois avec les vérins à vis (screw jacks)", description: "Pose des bases réglables" },
            { id: "sous-2-3-3", nom: "Installer les plaques de base et les contreventements", description: "Installation des plaques et contreventements" },
            { id: "sous-2-3-4", nom: "Vérifier le niveau de la base et le trait carré", description: "Contrôle de l'alignement" }
          ]
        },
        {
          id: "op-2-4",
          nom: "Assembler les éléments",
          description: "Assemblage complet de la structure",
          outils: [
            { nom: "marteaux", type: "Outils à main", securiteRequise: [] },
            { nom: "clé 3/4 po", type: "Outils à main", securiteRequise: [] },
            { nom: "clé à molette", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-2-4-1", nom: "Installer les cadres", description: "Montage des cadres verticaux" },
            { id: "sous-2-4-2", nom: "Installer les contreventements", description: "Pose des éléments de contreventement" },
            { id: "sous-2-4-3", nom: "Installer les croisillons", description: "Installation des croisillons" },
            { id: "sous-2-4-4", nom: "Installer les plateformes", description: "Pose des surfaces de travail" },
            { id: "sous-2-4-5", nom: "Installer les échelles", description: "Installation des accès" },
            { id: "sous-2-4-6", nom: "Installer les garde-corps", description: "Mise en place des protections" },
            { id: "sous-2-4-7", nom: "Installer les ancrages", description: "Pose des ancrages" },
            { id: "sous-2-4-8", nom: "Installer les plaques (coups-de-pied)", description: "Installation des coups-de-pied" }
          ]
        },
        {
          id: "op-2-5",
          nom: "Assurer la stabilité de l'échafaudage",
          description: "Vérification et validation de la stabilité",
          outils: [
            { nom: "perceuses électriques", type: "Outils électriques", securiteRequise: ["formation perceuse"] },
            { nom: "pistolets de soudage de goujons", type: "Outils de soudage", securiteRequise: ["formation soudage"] }
          ],
          sousOperations: [
            { id: "sous-2-5-1", nom: "Déterminer les points d'ancrage", description: "Identification des points d'ancrage" },
            { id: "sous-2-5-2", nom: "Poser des ancrages", description: "Installation des ancrages" },
            { id: "sous-2-5-3", nom: "Fixer l'échafaudage", description: "Fixation de la structure" },
            { id: "sous-2-5-4", nom: "Procéder à une inspection finale", description: "Contrôle final" },
            { id: "sous-2-5-5", nom: "Obtenir l'approbation de la personne responsable, s'il y a lieu", description: "Validation par le responsable" }
          ]
        }
      ]
    },
    {
      id: "tache-3",
      numero: 3,
      nom: "Installer de l'isolant rigide ou semi-rigide sur de la tuyauterie",
      description: "Installation d'isolation sur réseaux de tuyauterie",
      operations: [
        {
          id: "op-3-1",
          nom: "Dégeler la tuyauterie, s'il y a lieu",
          description: "Dégivrage préalable si nécessaire",
          outils: [
            { nom: "chalumeaux", type: "Outils de chauffage", securiteRequise: ["formation chalumeau", "permis feu"] }
          ],
          sousOperations: [
            { id: "sous-3-1-1", nom: "S'assurer de la mise hors service", description: "Vérification de l'arrêt du système" },
            { id: "sous-3-1-2", nom: "Chauffer la tuyauterie (chalumeau)", description: "Réchauffage au chalumeau" },
            { id: "sous-3-1-3", nom: "Utiliser un produit de déglaçage", description: "Application de produit de déglaçage" }
          ]
        },
        {
          id: "op-3-2",
          nom: "Essuyer et nettoyer la tuyauterie, s'il y a lieu",
          description: "Nettoyage et préparation de surface",
          outils: [
            { nom: "brosse métallique", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "chiffons", type: "Matériel de nettoyage", securiteRequise: [] },
            { nom: "grattoirs", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "ventilateur", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-2-1", nom: "Enlever toute trace d'eau, de poussière, d'huile, de résidus, etc.", description: "Nettoyage complet de la surface" },
            { id: "sous-3-2-2", nom: "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu", description: "Contrôle de l'humidité" }
          ]
        },
        {
          id: "op-3-3",
          nom: "Appliquer l'apprêt, s'il y a lieu",
          description: "Application de primaire d'accrochage",
          outils: [
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] },
            { nom: "rouleaux à peinture", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-3-4",
          nom: "Mesurer et couper des sections d'isolant",
          description: "Préparation des éléments d'isolation",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] },
            { nom: "scies à onglet", type: "Outils de coupe", securiteRequise: [] },
            { nom: "scies à ruban", type: "Outils de coupe", securiteRequise: [] },
            { nom: "scies circulaires", type: "Outils électriques", securiteRequise: ["formation scie"] }
          ],
          sousOperations: [
            { id: "sous-3-4-1", nom: "Prendre les mesures de la tuyauterie", description: "Relevé dimensionnel" },
            { id: "sous-3-4-2", nom: "Couper l'isolant pour coudes, supports, \"T\", \"Y\", etc.", description: "Découpe des formes spéciales" }
          ]
        },
        {
          id: "op-3-5",
          nom: "Poser des sections d'isolant",
          description: "Installation des éléments d'isolation",
          outils: [
            { nom: "pinces", type: "Outils à main", securiteRequise: [] },
            { nom: "pinces coupantes sur bout", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-5-1", nom: "Positionner l'isolant", description: "Mise en place de l'isolation" },
            { id: "sous-3-5-2", nom: "Fixer à l'aide de fil de fer", description: "Fixation provisoire" },
            { id: "sous-3-5-3", nom: "Couper les joints au besoin", description: "Ajustement des raccordements" }
          ]
        },
        {
          id: "op-3-6",
          nom: "Sceller les joints, s'il y a lieu",
          description: "Étanchéité des raccordements",
          outils: [
            { nom: "colle contact", type: "Produits chimiques", securiteRequise: [] },
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-6-1", nom: "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)", description: "Application de colle pour tubes flexibles" },
            { id: "sous-3-6-2", nom: "Respecter le délai de prise", description: "Temps de polymérisation" },
            { id: "sous-3-6-3", nom: "Réunir les deux côtés", description: "Assemblage des parties" },
            { id: "sous-3-6-4", nom: "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)", description: "Scellement pour matériaux rigides" }
          ]
        },
        {
          id: "op-3-7",
          nom: "Attacher les sections d'isolant",
          description: "Fixation définitive des sections",
          outils: [
            { nom: "fil de fer", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "bande d'acier inoxydable", type: "Matériel de fixation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-7-1", nom: "Installer un deuxième et un troisième fils de fer sur chaque section d'isolant", description: "Fixation multiple par fil de fer" },
            { id: "sous-3-7-2", nom: "Installer une bande d'acier inoxydable de ½ pouce (pour les tuyaux de plus de 300 mm)", description: "Fixation renforcée pour gros diamètres" }
          ]
        },
        {
          id: "op-3-8",
          nom: "Poser le coupe-vapeur, s'il y a lieu",
          description: "Installation de la barrière vapeur",
          outils: [
            { nom: "coupe-vapeur", type: "Matériau d'étanchéité", securiteRequise: [] },
            { nom: "ruban d'aluminium", type: "Matériel de fixation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-8-1", nom: "Couper le coupe-vapeur", description: "Découpe aux dimensions" },
            { id: "sous-3-8-2", nom: "Positionner le coupe-vapeur", description: "Mise en place de la barrière" },
            { id: "sous-3-8-3", nom: "Fixer le coupe-vapeur à l'aide d'un ruban d'aluminium", description: "Fixation par ruban adhésif" }
          ]
        },
        {
          id: "op-3-9",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-3-9-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-3-9-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-3-9-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-4",
      numero: 4,
      nom: "Installer de l'isolant rigide ou semi-rigide sur des appareils et des murs",
      description: "Installation d'isolation sur équipements et parois",
      operations: [
        {
          id: "op-4-1",
          nom: "Dégeler l'appareil, s'il y a lieu",
          description: "Dégivrage préalable de l'équipement",
          outils: [
            { nom: "chalumeaux", type: "Outils de chauffage", securiteRequise: ["formation chalumeau", "permis feu"] }
          ],
          sousOperations: [
            { id: "sous-4-1-1", nom: "S'assurer de la mise hors service", description: "Vérification de l'arrêt du système" },
            { id: "sous-4-1-2", nom: "Chauffer l'appareil avec un chalumeau", description: "Réchauffage de l'équipement" },
            { id: "sous-4-1-3", nom: "Utiliser un produit de déglaçage", description: "Application de produit dégivrant" }
          ]
        },
        {
          id: "op-4-2",
          nom: "Essuyer et nettoyer, s'il y a lieu",
          description: "Nettoyage et préparation des surfaces",
          outils: [
            { nom: "chiffons", type: "Matériel de nettoyage", securiteRequise: [] },
            { nom: "ventilateur", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-4-2-1", nom: "Enlever toute trace d'eau, de poussière, d'huile, de résidus, etc.", description: "Nettoyage complet des surfaces" },
            { id: "sous-4-2-2", nom: "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu", description: "Contrôle de l'humidité ambiante" }
          ]
        },
        {
          id: "op-4-3",
          nom: "Mesurer et couper l'isolant",
          description: "Préparation dimensionnelle de l'isolation",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-4-3-1", nom: "Évaluer les quantités nécessaires", description: "Calcul des besoins en matériaux" },
            { id: "sous-4-3-2", nom: "Maximiser l'utilisation des matériaux", description: "Optimisation de la découpe" },
            { id: "sous-4-3-3", nom: "Utiliser les données des fabricants d'isolant (chart) pour les mesures des segments de coude", description: "Référence aux spécifications fabricant" },
            { id: "sous-4-3-4", nom: "Préparer les patrons, s'il y a lieu", description: "Création de gabarits" }
          ]
        },
        {
          id: "op-4-4",
          nom: "Préparer les ancrages ou les attaches",
          description: "Préparation des systèmes de fixation",
          outils: [
            { nom: "perceuses électriques", type: "Outils électriques", securiteRequise: ["formation perceuse"] },
            { nom: "pistolets de soudage", type: "Outils de soudage", securiteRequise: ["formation soudage"] }
          ],
          sousOperations: [
            { id: "sous-4-4-1", nom: "Vérifier les sortes d'ancrages", description: "Identification des types de fixation" },
            { id: "sous-4-4-2", nom: "Choisir l'outil approprié à l'ancrage", description: "Sélection de l'outillage adapté" },
            { id: "sous-4-4-3", nom: "Déterminer les points d'ancrage", description: "Positionnement des fixations" },
            { id: "sous-4-4-4", nom: "Fixer les ancrages avec ou sans colle, par soudage par points, s'il y a lieu", description: "Installation des points de fixation" }
          ]
        },
        {
          id: "op-4-5",
          nom: "Poser l'isolant",
          description: "Installation de l'isolation",
          outils: [],
          sousOperations: [
            { id: "sous-4-5-1", nom: "Positionner l'isolant sur l'appareil ou le mur", description: "Mise en place de l'isolation" }
          ]
        },
        {
          id: "op-4-6",
          nom: "Fixer l'isolant",
          description: "Fixation définitive de l'isolation",
          outils: [
            { nom: "fil de fer", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "bandes d'acier", type: "Matériel de fixation", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-4-7",
          nom: "Sceller les joints, s'il y a lieu",
          description: "Étanchéité des raccordements",
          outils: [
            { nom: "colle contact", type: "Produits chimiques", securiteRequise: [] },
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-4-7-1", nom: "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)", description: "Application de colle pour matériaux flexibles" },
            { id: "sous-4-7-2", nom: "Respecter le délai de prise", description: "Temps de polymérisation" },
            { id: "sous-4-7-3", nom: "Réunir les deux côtés", description: "Assemblage des parties" },
            { id: "sous-4-7-4", nom: "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)", description: "Scellement pour matériaux rigides" }
          ]
        },
        {
          id: "op-4-8",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-4-8-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-4-8-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-4-8-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-5",
      numero: 5,
      nom: "Installer de l'isolant rigide ou semi-rigide sur des conduits d'air",
      description: "Installation d'isolation sur réseaux de ventilation",
      operations: [
        {
          id: "op-5-1",
          nom: "Essuyer et nettoyer le conduit, s'il y a lieu",
          description: "Préparation des conduits de ventilation",
          outils: [
            { nom: "chiffons", type: "Matériel de nettoyage", securiteRequise: [] },
            { nom: "brosse métallique", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "ventilateur", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-5-1-1", nom: "S'assurer que le conduit peut recevoir des ancrages ou de l'isolant", description: "Vérification de la compatibilité" },
            { id: "sous-5-1-2", nom: "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.", description: "Nettoyage complet du conduit" },
            { id: "sous-5-1-3", nom: "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu", description: "Contrôle de l'humidité" }
          ]
        },
        {
          id: "op-5-2",
          nom: "Fixer les ancrages",
          description: "Installation des points de fixation",
          outils: [
            { nom: "perceuses électriques", type: "Outils électriques", securiteRequise: ["formation perceuse"] },
            { nom: "pistolets de soudage", type: "Outils de soudage", securiteRequise: ["formation soudage"] }
          ],
          sousOperations: [
            { id: "sous-5-2-1", nom: "Localiser les points d'ancrage", description: "Positionnement des fixations" },
            { id: "sous-5-2-2", nom: "Selon le type et l'épaisseur de l'isolant, poser des ancrages avec ou sans colle, par soudage par points, s'il y a lieu", description: "Installation adaptée aux matériaux" },
            { id: "sous-5-2-3", nom: "Replier les ancrages, s'il y a lieu", description: "Mise en forme des ancrages" },
            { id: "sous-5-2-4", nom: "S'assurer de la solidité des ancrages", description: "Vérification de la fixation" }
          ]
        },
        {
          id: "op-5-3",
          nom: "Mesurer et couper l'isolant",
          description: "Préparation dimensionnelle de l'isolation",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-5-3-1", nom: "Évaluer les quantités nécessaires", description: "Calcul des besoins" },
            { id: "sous-5-3-2", nom: "Décider de l'ordre à respecter", description: "Planification de la pose" },
            { id: "sous-5-3-3", nom: "Maximiser l'utilisation des matériaux", description: "Optimisation des découpes" },
            { id: "sous-5-3-4", nom: "Utiliser les données des fabricants d'isolant (chart) pour les mesures des segments de coude, s'il y a lieu", description: "Référence aux spécifications" },
            { id: "sous-5-3-5", nom: "Préparer les patrons, s'il y a lieu", description: "Création de gabarits" }
          ]
        },
        {
          id: "op-5-4",
          nom: "Poser l'isolant",
          description: "Installation de l'isolation",
          outils: [],
          sousOperations: [
            { id: "sous-5-4-1", nom: "Placer les morceaux d'isolant prédécoupés", description: "Positionnement des éléments" },
            { id: "sous-5-4-2", nom: "Respecter la séquence de pose: côtés, dessous, dessus", description: "Ordre d'installation" }
          ]
        },
        {
          id: "op-5-5",
          nom: "Fixer les rondelles de retenue",
          description: "Installation des éléments de maintien",
          outils: [
            { nom: "rondelles de retenue", type: "Matériel de fixation", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-5-6",
          nom: "Couper l'excédent des ancrages",
          description: "Finition des ancrages",
          outils: [
            { nom: "pinces coupantes", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-5-6-1", nom: "Appuyer les pinces coupantes sur la rondelle de retenue", description: "Positionnement de l'outil" },
            { id: "sous-5-6-2", nom: "Couper l'ancrage", description: "Découpe de l'excédent" },
            { id: "sous-5-6-3", nom: "Récupérer la partie coupée", description: "Collecte des chutes" }
          ]
        },
        {
          id: "op-5-7",
          nom: "Sceller les joints, s'il y a lieu",
          description: "Étanchéité des raccordements",
          outils: [
            { nom: "colle contact", type: "Produits chimiques", securiteRequise: [] },
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-5-7-1", nom: "Appliquer de la colle contact sur les deux parties du joint (pour tubes isolants flexibles)", description: "Application pour matériaux flexibles" },
            { id: "sous-5-7-2", nom: "Respecter le délai de prise", description: "Temps de polymérisation" },
            { id: "sous-5-7-3", nom: "Réunir les deux côtés", description: "Assemblage des parties" },
            { id: "sous-5-7-4", nom: "Appliquer du scellant sur les joints (pour verre cellulaire et uréthane)", description: "Scellement pour matériaux rigides" }
          ]
        },
        {
          id: "op-5-8",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-5-8-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-5-8-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-5-8-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-6",
      numero: 6,
      nom: "Appliquer de l'isolant giclé et soufflé",
      description: "Application d'isolation par projection",
      operations: [
        {
          id: "op-6-1",
          nom: "Dégeler la tuyauterie ou l'appareil, s'il y a lieu",
          description: "Dégivrage préalable",
          outils: [
            { nom: "chalumeaux", type: "Outils de chauffage", securiteRequise: ["formation chalumeau", "permis feu"] }
          ],
          sousOperations: [
            { id: "sous-6-1-1", nom: "S'assurer de la mise hors service", description: "Vérification de l'arrêt du système" },
            { id: "sous-6-1-2", nom: "Chauffer la tuyauterie (chalumeau)", description: "Réchauffage au chalumeau" },
            { id: "sous-6-1-3", nom: "Utiliser un produit de déglaçage", description: "Application de produit dégivrant" }
          ]
        },
        {
          id: "op-6-2",
          nom: "Essuyer et nettoyer, s'il y a lieu",
          description: "Préparation des surfaces",
          outils: [
            { nom: "chiffons", type: "Matériel de nettoyage", securiteRequise: [] },
            { nom: "ventilateur", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-6-2-1", nom: "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.", description: "Nettoyage complet" },
            { id: "sous-6-2-2", nom: "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu", description: "Contrôle de l'humidité" }
          ]
        },
        {
          id: "op-6-3",
          nom: "Appliquer de l'apprêt, s'il y a lieu",
          description: "Application de primaire d'accrochage",
          outils: [
            { nom: "essence minérale", type: "Produits chimiques", securiteRequise: [] },
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-6-3-1", nom: "Laver à l'essence minérale", description: "Dégraissage de la surface" },
            { id: "sous-6-3-2", nom: "Laisser sécher", description: "Temps de séchage" },
            { id: "sous-6-3-3", nom: "Appliquer l'apprêt", description: "Application du primaire" },
            { id: "sous-6-3-4", nom: "Ventiler, s'il y a lieu (endroits mal aérés)", description: "Ventilation si nécessaire" }
          ]
        },
        {
          id: "op-6-4",
          nom: "Appliquer l'isolant",
          description: "Projection de l'isolation",
          outils: [
            { nom: "équipement de projection", type: "Matériel de projection", securiteRequise: ["formation projection"] }
          ],
          sousOperations: [
            { id: "sous-6-4-1", nom: "Pulvériser l'isolant sur le substrat", description: "Application par projection" }
          ]
        },
        {
          id: "op-6-5",
          nom: "Uniformiser la surface d'isolant",
          description: "Régularisation de l'épaisseur",
          outils: [
            { nom: "jauge d'épaisseur", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "outil tranchant", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-6-5-1", nom: "Mesurer l'épaisseur de l'isolant appliqué (jauge d'épaisseur)", description: "Contrôle de l'épaisseur" },
            { id: "sous-6-5-2", nom: "Consulter les normes relatives aux épaisseurs minimale et maximale", description: "Vérification des spécifications" },
            { id: "sous-6-5-3", nom: "Ajouter de l'isolant ou retirer de l'isolant (outil tranchant)", description: "Ajustement de l'épaisseur" }
          ]
        },
        {
          id: "op-6-6",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-6-6-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-6-6-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-6-6-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-7",
      numero: 7,
      nom: "Installer des panneaux sandwichs isolants sur des appareils",
      description: "Installation de panneaux composites isolants",
      operations: [
        {
          id: "op-7-1",
          nom: "Essuyer et nettoyer l'appareil, s'il y a lieu",
          description: "Préparation de l'équipement",
          outils: [
            { nom: "chiffons", type: "Matériel de nettoyage", securiteRequise: [] },
            { nom: "ventilateur", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-7-1-1", nom: "Enlever toute trace d'eau, de poussière, de rouille, d'huile, de résidus, etc.", description: "Nettoyage complet de l'appareil" },
            { id: "sous-7-1-2", nom: "Ventiler la pièce pour réduire le taux d'humidité, s'il y a lieu", description: "Contrôle de l'humidité" }
          ]
        },
        {
          id: "op-7-2",
          nom: "Poser les ancrages et les fixations",
          description: "Installation des systèmes de fixation",
          outils: [
            { nom: "perceuses électriques", type: "Outils électriques", securiteRequise: ["formation perceuse"] },
            { nom: "bandes d'acier inoxydable", type: "Matériel de fixation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-7-2-1", nom: "Poser des ancrages sur les côtés et sur le dessus de l'appareil", description: "Installation des points de fixation" },
            { id: "sous-7-2-2", nom: "Poser des bandes d'acier inoxydable", description: "Installation des bandes de serrage" },
            { id: "sous-7-2-3", nom: "Calculer la distance entre chaque ancrage, selon les directives reçues", description: "Espacement des fixations" }
          ]
        },
        {
          id: "op-7-3",
          nom: "Poser les panneaux sandwichs isolants",
          description: "Installation des panneaux composites",
          outils: [
            { nom: "panneaux sandwichs", type: "Matériaux d'isolation", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-7-4",
          nom: "Serrer et sceller les joints",
          description: "Finition des raccordements",
          outils: [
            { nom: "clés", type: "Outils à main", securiteRequise: [] },
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-7-5",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-7-5-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-7-5-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-7-5-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-8",
      numero: 8,
      nom: "Installer un fini protecteur souple",
      description: "Application de finition souple de protection",
      operations: [
        {
          id: "op-8-1",
          nom: "Installer un treillis métallique, s'il y a lieu",
          description: "Installation d'armature métallique",
          outils: [
            { nom: "treillis métallique", type: "Matériau d'armature", securiteRequise: [] },
            { nom: "pinces", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-2",
          nom: "Poser des coins de fer, s'il y a lieu",
          description: "Installation de renforts d'angle",
          outils: [
            { nom: "coins de fer", type: "Matériau de renfort", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-3",
          nom: "Cimenter, s'il y a lieu",
          description: "Application de mortier",
          outils: [
            { nom: "ciment", type: "Matériau de construction", securiteRequise: [] },
            { nom: "truelles", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-4",
          nom: "Mesurer et couper le fini protecteur",
          description: "Préparation du revêtement",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-5",
          nom: "Appliquer l'enduit",
          description: "Application de la première couche",
          outils: [
            { nom: "enduit", type: "Produits chimiques", securiteRequise: [] },
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-6",
          nom: "Poser le fini protecteur",
          description: "Installation du revêtement",
          outils: [
            { nom: "coton", type: "Matériau de finition", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-8-6-1", nom: "Poser le coton en l'étirant", description: "Application tendue du revêtement" },
            { id: "sous-8-6-2", nom: "S'assurer de l'absence de plis", description: "Vérification de la planéité" }
          ]
        },
        {
          id: "op-8-7",
          nom: "Réappliquer de l'enduit",
          description: "Application de la couche de finition",
          outils: [
            { nom: "enduit", type: "Produits chimiques", securiteRequise: [] },
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-8-8",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-8-8-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-8-8-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-8-8-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-9",
      numero: 9,
      nom: "Installer des membranes d'étanchéité",
      description: "Installation de systèmes d'étanchéité",
      operations: [
        {
          id: "op-9-1",
          nom: "Mesurer et couper la membrane",
          description: "Préparation de la membrane",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-9-1-1", nom: "Mesurer en tenant compte du chevauchement", description: "Calcul avec recouvrement" },
            { id: "sous-9-1-2", nom: "Couper la membrane selon la forme et les dimensions désirées", description: "Découpe aux dimensions" }
          ]
        },
        {
          id: "op-9-2",
          nom: "Poser la membrane",
          description: "Installation de la membrane",
          outils: [
            { nom: "membrane d'étanchéité", type: "Matériau d'étanchéité", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-9-2-1", nom: "Vérifier les vents dominants", description: "Analyse des conditions météo" },
            { id: "sous-9-2-2", nom: "Commencer la pose par le dessous", description: "Début de l'installation" },
            { id: "sous-9-2-3", nom: "Continuer la pose par les côtés", description: "Suite de l'installation" },
            { id: "sous-9-2-4", nom: "Terminer la pose par le dessus", description: "Finition de l'installation" }
          ]
        },
        {
          id: "op-9-3",
          nom: "Chauffer les joints",
          description: "Soudage des raccordements",
          outils: [
            { nom: "chalumeaux", type: "Outils de chauffage", securiteRequise: ["formation chalumeau", "permis feu"] }
          ],
          sousOperations: []
        },
        {
          id: "op-9-4",
          nom: "Poser des soupapes, s'il y a lieu",
          description: "Installation d'éléments de ventilation",
          outils: [
            { nom: "soupapes", type: "Équipement de ventilation", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-9-4-1", nom: "Pratiquer des ouvertures dans la membrane", description: "Découpe pour soupapes" },
            { id: "sous-9-4-2", nom: "Insérer les soupapes dans les ouvertures", description: "Installation des soupapes" },
            { id: "sous-9-4-3", nom: "Sceller le pourtour des soupapes", description: "Étanchéité autour des soupapes" }
          ]
        },
        {
          id: "op-9-5",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-9-5-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-9-5-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-9-5-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-10",
      numero: 10,
      nom: "Fabriquer des pièces de fini protecteur rigide ou semi-rigide",
      description: "Fabrication d'éléments de finition sur mesure",
      operations: [
        {
          id: "op-10-1",
          nom: "Prendre les mesures requises",
          description: "Relevé dimensionnel précis",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "règles graduées", type: "Équipement de mesure", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-10-1-1", nom: "Déterminer les parties à fabriquer", description: "Identification des éléments" },
            { id: "sous-10-1-2", nom: "Noter la hauteur, la largeur, la profondeur, le diamètre et la circonférence", description: "Relevé de toutes les dimensions" }
          ]
        },
        {
          id: "op-10-2",
          nom: "Faire un patron",
          description: "Création de gabarit",
          outils: [
            { nom: "carton", type: "Matériau de gabarit", securiteRequise: [] },
            { nom: "crayons", type: "Équipement de traçage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-10-2-1", nom: "Rapporter les mesures prises sur le revêtement", description: "Transfert des dimensions" },
            { id: "sous-10-2-2", nom: "Diviser les mesures au besoin pour faire un \"T\", un coude, un \"Y\", un bout de réservoir, etc.", description: "Décomposition des formes complexes" }
          ]
        },
        {
          id: "op-10-3",
          nom: "Tracer les pièces",
          description: "Marquage sur le matériau",
          outils: [
            { nom: "crayons", type: "Équipement de traçage", securiteRequise: [] },
            { nom: "règles graduées", type: "Équipement de mesure", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-10-3-1", nom: "Copier le patron", description: "Reproduction du gabarit" },
            { id: "sous-10-3-2", nom: "Indiquer les points de repère, s'il y a lieu", description: "Marquage des références" }
          ]
        },
        {
          id: "op-10-4",
          nom: "Tailler les pièces",
          description: "Découpe des éléments",
          outils: [
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] },
            { nom: "scies circulaires", type: "Outils électriques", securiteRequise: ["formation scie"] }
          ],
          sousOperations: []
        },
        {
          id: "op-10-5",
          nom: "Façonner les pièces",
          description: "Mise en forme des éléments",
          outils: [
            { nom: "marteaux", type: "Outils à main", securiteRequise: [] },
            { nom: "plieuses", type: "Outils de formage", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-10-6",
          nom: "Assembler les pièces",
          description: "Assemblage des éléments",
          outils: [
            { nom: "rivets", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "rivetteuses", type: "Outils d'assemblage", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-10-7",
          nom: "Identifier les pièces",
          description: "Marquage d'identification",
          outils: [
            { nom: "étiquettes", type: "Matériel d'identification", securiteRequise: [] },
            { nom: "marqueurs", type: "Équipement de traçage", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-10-8",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-10-8-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-10-8-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-10-8-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-11",
      numero: 11,
      nom: "Installer un fini protecteur rigide ou semi-rigide",
      description: "Installation de finition rigide de protection",
      operations: [
        {
          id: "op-11-1",
          nom: "Mesurer et couper le fini protecteur",
          description: "Préparation du revêtement rigide",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "cisailles", type: "Outils de coupe", securiteRequise: [] },
            { nom: "scies circulaires", type: "Outils électriques", securiteRequise: ["formation scie"] }
          ],
          sousOperations: [
            { id: "sous-11-1-1", nom: "Prendre les mesures et les rapporter sur le fini", description: "Transfert des dimensions" },
            { id: "sous-11-1-2", nom: "Tracer le fini et le découper", description: "Marquage et découpe" },
            { id: "sous-11-1-3", nom: "Ajuster les dimensions des pièces prédécoupées", description: "Ajustement final" }
          ]
        },
        {
          id: "op-11-2",
          nom: "Poser le fini protecteur",
          description: "Installation du revêtement",
          outils: [],
          sousOperations: [
            { id: "sous-11-2-1", nom: "Positionner le fini protecteur", description: "Mise en place du revêtement" }
          ]
        },
        {
          id: "op-11-3",
          nom: "Fixer le fini protecteur (bandes et attaches, vis ou rivets, colle, etc.)",
          description: "Fixation du revêtement",
          outils: [
            { nom: "bandes", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "vis", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "rivets", type: "Matériel de fixation", securiteRequise: [] },
            { nom: "colle", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-11-4",
          nom: "Sceller les joints, s'il y a lieu",
          description: "Étanchéité des raccordements",
          outils: [
            { nom: "silicone", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-11-4-1", nom: "Appliquer de la silicone sur les joints longitudinaux, circulaires et autour des coupes", description: "Scellement complet des joints" }
          ]
        },
        {
          id: "op-11-5",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-11-5-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-11-5-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-11-5-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-12",
      numero: 12,
      nom: "Installer des systèmes coupe-feu",
      description: "Installation de protection contre l'incendie",
      operations: [
        {
          id: "op-12-1",
          nom: "Nettoyer l'ouverture",
          description: "Préparation de l'ouverture",
          outils: [
            { nom: "aspirateur", type: "Équipement de nettoyage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-12-1-1", nom: "Vérifier s'il y a des déchets dans l'ouverture", description: "Inspection de l'ouverture" },
            { id: "sous-12-1-2", nom: "Retirer les déchets, s'il y a lieu", description: "Nettoyage de l'ouverture" }
          ]
        },
        {
          id: "op-12-2",
          nom: "Poser, s'il y a lieu, des supports, rails, ancrages, etc.",
          description: "Installation des supports",
          outils: [
            { nom: "supports", type: "Matériel de support", securiteRequise: [] },
            { nom: "rails", type: "Matériel de support", securiteRequise: [] },
            { nom: "perceuses électriques", type: "Outils électriques", securiteRequise: ["formation perceuse"] }
          ],
          sousOperations: []
        },
        {
          id: "op-12-3",
          nom: "Mesurer et couper le système coupe-feu",
          description: "Préparation du système",
          outils: [
            { nom: "rubans à mesurer", type: "Équipement de mesure", securiteRequise: [] },
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-12-3-1", nom: "Mesurer et couper le matériau selon le cadre déjà installé", description: "Découpe aux dimensions du cadre" },
            { id: "sous-12-3-2", nom: "Faire les coupes nécessaires pour les fils et tuyaux qui passent au travers du système", description: "Découpes pour passages" }
          ]
        },
        {
          id: "op-12-4",
          nom: "Poser le système coupe-feu",
          description: "Installation du système",
          outils: [
            { nom: "système coupe-feu", type: "Matériau de protection", securiteRequise: [] },
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-12-4-1", nom: "Positionner le système coupe-feu", description: "Mise en place du système" },
            { id: "sous-12-4-2", nom: "Appliquer un scellant", description: "Application de produit d'étanchéité" }
          ]
        },
        {
          id: "op-12-5",
          nom: "Remplir une fiche signalétique, s'il y a lieu",
          description: "Documentation de l'installation",
          outils: [
            { nom: "fiche signalétique", type: "Documentation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-12-5-1", nom: "Inscrire la date d'installation du système", description: "Documentation de la date" },
            { id: "sous-12-5-2", nom: "Inscrire le type de système installé", description: "Documentation du type" }
          ]
        },
        {
          id: "op-12-6",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-12-6-1", nom: "Ramasser les débris", description: "Collecte des déchets" },
            { id: "sous-12-6-2", nom: "Ranger les matériaux et l'équipement", description: "Remisage du matériel" },
            { id: "sous-12-6-3", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    },
    {
      id: "tache-13",
      numero: 13,
      nom: "Enlever des matériaux d'isolation contenant de l'amiante ou des moisissures",
      description: "Désamiantage et décontamination",
      operations: [
        {
          id: "op-13-1",
          nom: "Construire les enceintes nécessaires",
          description: "Construction de zone de confinement",
          outils: [
            { nom: "structures de confinement", type: "Matériel de confinement", securiteRequise: ["formation amiante"] },
            { nom: "plastique de protection", type: "Matériel de protection", securiteRequise: [] },
            { nom: "système de ventilation", type: "Équipement de ventilation", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-1-1", nom: "Installer les structures", description: "Montage des structures de confinement" },
            { id: "sous-13-1-2", nom: "Poser un plastique de protection à l'intérieur de la structure (double couche sur le plancher)", description: "Installation des bâches de protection" },
            { id: "sous-13-1-3", nom: "Installer les douches", description: "Installation du sas de décontamination" },
            { id: "sous-13-1-4", nom: "Calculer le volume d'air à traiter", description: "Calcul des besoins de ventilation" },
            { id: "sous-13-1-5", nom: "Installer un système de ventilation à pression négative, s'il y a lieu", description: "Installation de la ventilation" },
            { id: "sous-13-1-6", nom: "Poser les affiches relatives à l'amiante", description: "Signalisation de sécurité" }
          ]
        },
        {
          id: "op-13-2",
          nom: "Défaire les bandes, attaches, ancrages, etc.",
          description: "Démontage des fixations",
          outils: [
            { nom: "pinces coupantes", type: "Outils à main", securiteRequise: [] },
            { nom: "pulvérisateur d'eau", type: "Équipement de mouillage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-2-1", nom: "Couper les attaches", description: "Démontage des fixations" },
            { id: "sous-13-2-2", nom: "Mouiller les surfaces", description: "Humidification pour limiter les poussières" }
          ]
        },
        {
          id: "op-13-3",
          nom: "Retirer le fini protecteur",
          description: "Enlèvement du revêtement",
          outils: [
            { nom: "couteau à lame rétractable", type: "Outils de coupe", securiteRequise: [] },
            { nom: "pulvérisateur d'eau", type: "Équipement de mouillage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-3-1", nom: "Couper le fini", description: "Découpe du revêtement" },
            { id: "sous-13-3-2", nom: "Mouiller les surfaces", description: "Humidification continue" },
            { id: "sous-13-3-3", nom: "Enlever le fini", description: "Retrait du revêtement" }
          ]
        },
        {
          id: "op-13-4",
          nom: "Retirer l'isolant",
          description: "Enlèvement de l'isolation contaminée",
          outils: [
            { nom: "pulvérisateur d'eau", type: "Équipement de mouillage", securiteRequise: [] },
            { nom: "outils à main", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-4-1", nom: "Mouiller l'isolant sur toutes ses faces", description: "Humidification complète" },
            { id: "sous-13-4-2", nom: "Enlever l'isolant graduellement, en continuant de le mouiller", description: "Retrait progressif avec mouillage" }
          ]
        },
        {
          id: "op-13-5",
          nom: "Ramasser les débris",
          description: "Collecte des matériaux contaminés",
          outils: [
            { nom: "pulvérisateur d'eau", type: "Équipement de mouillage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-5-1", nom: "Ramasser les débris minutieusement", description: "Collecte complète des déchets" },
            { id: "sous-13-5-2", nom: "Mouiller les débris", description: "Humidification des déchets" }
          ]
        },
        {
          id: "op-13-6",
          nom: "Déposer les débris dans les sacs recommandés",
          description: "Conditionnement des déchets",
          outils: [
            { nom: "sacs pré-identifiés", type: "Matériel de conditionnement", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-6-1", nom: "Placer les débris dans des sacs pré-identifiés", description: "Mise en sac première couche" },
            { id: "sous-13-6-2", nom: "Placer les sacs dans un autre sac du même type", description: "Double ensachage" }
          ]
        },
        {
          id: "op-13-7",
          nom: "Procéder au nettoyage final",
          description: "Décontamination finale",
          outils: [
            { nom: "aspirateur HEPA", type: "Équipement de nettoyage", securiteRequise: ["formation HEPA"] }
          ],
          sousOperations: [
            { id: "sous-13-7-1", nom: "Passer un aspirateur muni d'un filtre HEPA sur toutes les parois des enceintes", description: "Aspiration finale avec filtre HEPA" }
          ]
        },
        {
          id: "op-13-8",
          nom: "Appliquer un scellant",
          description: "Application de produit d'encapsulation",
          outils: [
            { nom: "scellant", type: "Produits chimiques", securiteRequise: [] },
            { nom: "pinceaux", type: "Outils d'application", securiteRequise: [] }
          ],
          sousOperations: []
        },
        {
          id: "op-13-9",
          nom: "Démanteler les enceintes",
          description: "Démontage du confinement",
          outils: [
            { nom: "outils de démontage", type: "Outils à main", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-9-1", nom: "Enlever les toiles", description: "Retrait des bâches" },
            { id: "sous-13-9-2", nom: "Désassembler les structures", description: "Démontage des structures" }
          ]
        },
        {
          id: "op-13-10",
          nom: "Nettoyer l'aire de travail et ranger l'équipement",
          description: "Nettoyage final et rangement",
          outils: [
            { nom: "balais", type: "Outils de nettoyage", securiteRequise: [] },
            { nom: "contenants de rangement", type: "Équipement de stockage", securiteRequise: [] }
          ],
          sousOperations: [
            { id: "sous-13-10-1", nom: "Ramasser les débris", description: "Collecte finale des déchets" },
            { id: "sous-13-10-2", nom: "Ranger les matériaux", description: "Remisage des matériaux" },
            { id: "sous-13-10-3", nom: "Nettoyer et ranger l'équipement", description: "Nettoyage et rangement de l'équipement" },
            { id: "sous-13-10-4", nom: "Ranger ses outils personnels", description: "Rangement des outils personnels" }
          ]
        }
      ]
    }
  ]
};
