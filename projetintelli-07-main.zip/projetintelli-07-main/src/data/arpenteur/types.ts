
export interface ArpenteurRisque {
  description: string;
  niveau: 'faible' | 'moyen' | 'eleve';
  mesuresPrevention: string[];
}

export interface ArpenteurOutil {
  nom: string;
  type: string;
  securiteRequise: string[];
}

export interface ArpenteurMateriau {
  nom: string;
  type: string;
  precautions: string[];
}

export interface ArpenteurSousOperation {
  nom: string;
  description: string;
  risques: ArpenteurRisque[];
}

export interface ArpenteurOperation {
  nom: string;
  description: string;
  sousOperations: ArpenteurSousOperation[];
  risques: ArpenteurRisque[];
  outils: ArpenteurOutil[];
  materiaux: ArpenteurMateriau[];
}

export interface ArpenteurTache {
  nom: string;
  description: string;
  operations: ArpenteurOperation[];
}
