import { ArpenteurTache } from './types';

export const tacheEffectuerImplantations: ArpenteurTache = {
  nom: "EFFECTUER LES IMPLANTATIONS",
  description: "Matérialiser sur le terrain les points et ouvrages selon les plans",
  operations: [
    {
      nom: "4.1 Préparation et vérification des équipements",
      description: "S'assurer que tous les équipements nécessaires sont prêts et fonctionnels",
      sousOperations: [
        {
          nom: "Vérification du bon fonctionnement des instruments",
          description: "Contrôler l'état et la précision des instruments de mesure",
          risques: [
            {
              description: "Instruments défectueux",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer des vérifications régulières",
                "Calibrer les instruments avant chaque utilisation",
              ],
            },
          ],
        },
        {
          nom: "Préparation des accessoires nécessaires",
          description: "Rassembler tous les accessoires requis pour les travaux",
          risques: [
            {
              description: "Manque d'accessoires",
              niveau: "faible",
              mesuresPrevention: ["Préparer une liste de contrôle"],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "Instruments de mesure",
          type: "Équipement de topographie",
          securiteRequise: ["Vérification avant utilisation", "Calibrage régulier"],
        },
      ],
      materiaux: [
        {
          nom: "Trépieds et accessoires",
          type: "Équipements de support",
          precautions: ["Vérifier l'état", "Transport sécurisé"],
        },
      ],
    },
    {
      nom: "4.2 Implantation des points de référence",
      description: "Établir les points de base pour les travaux d'implantation",
      sousOperations: [
        {
          nom: "Définition des points de base",
          description: "Identifier et établir les points de référence principaux",
          risques: [
            {
              description: "Erreur de positionnement",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser des données de référence précises",
                "Effectuer des mesures de contrôle",
              ],
            },
          ],
        },
        {
          nom: "Matérialisation des points sur le terrain",
          description: "Marquer physiquement les points de référence",
          risques: [
            {
              description: "Déplacement des marqueurs",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des marqueurs durables",
                "Protéger les points",
              ],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "GPS et station totale",
          type: "Instruments de positionnement",
          securiteRequise: ["Précision vérifiée", "Conditions météo appropriées"],
        },
      ],
      materiaux: [
        {
          nom: "Bornes et marqueurs",
          type: "Matériaux de marquage",
          precautions: ["Durabilité assurée", "Visibilité maintenue"],
        },
      ],
    },
    {
      nom: "4.3 Mesures topographiques",
      description: "Effectuer les relevés et calculs nécessaires",
      sousOperations: [
        {
          nom: "Relevé des points existants",
          description: "Mesurer et documenter les points de référence existants",
          risques: [
            {
              description: "Erreur de mesure",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer plusieurs mesures",
                "Utiliser des instruments précis",
              ],
            },
          ],
        },
        {
          nom: "Calcul des altitudes et des distances",
          description: "Calculer les données topographiques nécessaires",
          risques: [
            {
              description: "Erreur de calcul",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des logiciels de calcul",
                "Vérifier les résultats",
              ],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "Station totale",
          type: "Instrument de mesure",
          securiteRequise: ["Calibrage vérifié", "Formation requise"],
        },
      ],
      materiaux: [
        {
          nom: "Carnet de terrain",
          type: "Documentation",
          precautions: ["Protection contre intempéries", "Écriture lisible"],
        },
      ],
    },
    {
      nom: "4.4 Implantation des ouvrages",
      description: "Transférer les éléments des plans sur le terrain",
      sousOperations: [
        {
          nom: "Report des plans sur le terrain",
          description: "Matérialiser les éléments des plans sur le site",
          risques: [
            {
              description: "Erreur de report",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser des instruments précis",
                "Vérifier les implantations",
              ],
            },
          ],
        },
        {
          nom: "Contrôle des alignements et des niveaux",
          description: "Vérifier la conformité des implantations",
          risques: [
            {
              description: "Non-conformité aux plans",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des contrôles réguliers",
                "Ajuster les implantations",
              ],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "Théodolite",
          type: "Instrument d'alignement",
          securiteRequise: ["Précision vérifiée", "Stabilité assurée"],
        },
      ],
      materiaux: [
        {
          nom: "Plans d'exécution",
          type: "Documentation technique",
          precautions: ["Versions à jour", "Protection contre dommages"],
        },
      ],
    },
    {
      nom: "4.5 Suivi des tassements",
      description: "Surveiller les déformations du terrain",
      sousOperations: [
        {
          nom: "Mise en place des repères de nivellement",
          description: "Installer les points de contrôle des tassements",
          risques: [
            {
              description: "Déplacement des repères",
              niveau: "moyen",
              mesuresPrevention: [
                "Protéger les repères",
                "Vérifier leur stabilité",
              ],
            },
          ],
        },
        {
          nom: "Mesure des variations d'altitude",
          description: "Surveiller les changements de niveau",
          risques: [
            {
              description: "Erreur de mesure",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer des mesures régulières",
                "Utiliser des instruments précis",
              ],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "Niveau de précision",
          type: "Instrument de nivellement",
          securiteRequise: ["Calibrage quotidien", "Conditions stables"],
        },
      ],
      materiaux: [
        {
          nom: "Repères de nivellement",
          type: "Points de référence",
          precautions: ["Installation stable", "Protection contre dommages"],
        },
      ],
    },
    {
      nom: "4.6 Contrôle qualité des implantations",
      description: "Vérifier la conformité des travaux d'implantation",
      sousOperations: [
        {
          nom: "Vérification des conformités par rapport aux plans",
          description: "Contrôler que les implantations respectent les spécifications",
          risques: [
            {
              description: "Non-conformité détectée tardivement",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des contrôles à chaque étape",
                "Utiliser des checklists",
              ],
            },
          ],
        },
        {
          nom: "Réalisation de rapports de contrôle",
          description: "Documenter les résultats des vérifications",
          risques: [
            {
              description: "Omission d'informations importantes",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des modèles de rapport",
                "Vérifier les informations",
              ],
            },
          ],
        },
      ],
      risques: [],
      outils: [
        {
          nom: "Instruments de mesure",
          type: "Équipement de contrôle",
          securiteRequise: ["Précision vérifiée", "Étalonnage valide"],
        },
      ],
      materiaux: [
        {
          nom: "Modèles de rapport",
          type: "Documentation",
          precautions: ["Versions standardisées", "Complétude vérifiée"],
        },
      ],
    },
    {
      nom: "4.7 Documenter les implantations",
      description: "Consigner toutes les informations relatives aux implantations",
      sousOperations: [
        {
          nom: "Inscrire les points implantés ou enregistrer les données",
          description: "Documenter précisément tous les points implantés avec leurs coordonnées",
          risques: [
            {
              description: "Perte ou corruption des données d'implantation",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des sauvegardes multiples des données",
                "Utiliser des formats de fichier standardisés",
                "Vérifier l'intégrité des données enregistrées",
                "Maintenir des copies physiques de sauvegarde"
              ]
            },
            {
              description: "Erreur dans l'enregistrement des coordonnées",
              niveau: "eleve",
              mesuresPrevention: [
                "Double vérification des coordonnées saisies",
                "Utiliser des systèmes de validation automatique",
                "Effectuer des contrôles croisés avec les mesures terrain",
                "Documenter le système de coordonnées utilisé"
              ]
            },
            {
              description: "Documentation insuffisante pour traçabilité",
              niveau: "moyen",
              mesuresPrevention: [
                "Inclure la date et l'heure de chaque implantation",
                "Documenter les conditions météorologiques",
                "Enregistrer l'opérateur et les instruments utilisés",
                "Ajouter des photos de référence si nécessaire"
              ]
            }
          ]
        },
        {
          nom: "Inscrire toute autre information pertinente",
          description: "Documenter les codes, symboles et observations complémentaires",
          risques: [
            {
              description: "Informations complémentaires manquantes",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une liste de contrôle des informations à documenter",
                "Standardiser la nomenclature des codes et symboles",
                "Former le personnel aux conventions de documentation",
                "Réviser systématiquement la complétude des dossiers"
              ]
            },
            {
              description: "Codes ou symboles mal interprétés",
              niveau: "moyen",
              mesuresPrevention: [
                "Maintenir un lexique à jour des codes et symboles",
                "Utiliser des conventions standardisées reconnues",
                "Inclure une légende explicative dans chaque document",
                "Valider l'interprétation avec les parties prenantes"
              ]
            },
            {
              description: "Observations de terrain non documentées",
              niveau: "faible",
              mesuresPrevention: [
                "Encourager la documentation d'observations détaillées",
                "Inclure des champs pour remarques dans les formulaires",
                "Photographier les situations particulières",
                "Consigner les conditions spéciales rencontrées"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Carnet de terrain électronique",
          type: "Dispositif d'enregistrement",
          securiteRequise: ["Sauvegarde automatique", "Protection contre intempéries"]
        },
        {
          nom: "Logiciel de topographie",
          type: "Application de gestion des données",
          securiteRequise: ["Validation des données", "Système de sauvegarde"]
        }
      ],
      materiaux: [
        {
          nom: "Formulaires standardisés",
          type: "Documentation",
          precautions: ["Versions approuvées", "Complétude vérifiée"]
        }
      ]
    },
    {
      nom: "4.8 Faire la mise en station des instruments de mesure",
      description: "Installer et calibrer les instruments pour les mesures de contrôle",
      sousOperations: [
        {
          nom: "Effectuer la visée arrière avec la station totale, la station totale robotisée, le niveau, le niveau à laser ou électronique, le GPS",
          description: "Réaliser l'orientation et la vérification des instruments sur un point de référence",
          risques: [
            {
              description: "Erreur d'orientation de l'instrument",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier la stabilité du point de référence",
                "Effectuer plusieurs visées de contrôle",
                "Utiliser des points de référence multiples si possible",
                "Documenter les paramètres de mise en station"
              ]
            },
            {
              description: "Point de référence GPS incorrect ou dégradé",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier la qualité du signal GPS avant utilisation",
                "Effectuer des mesures sur plusieurs points de contrôle",
                "Utiliser des corrections différentielles si disponibles",
                "Documenter les conditions de réception satellite"
              ]
            },
            {
              description: "Instrument mal calibré ou déréglé",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer la calibration selon les procédures fabricant",
                "Vérifier les certificats d'étalonnage",
                "Tester l'instrument sur des distances connues",
                "Maintenir un registre de maintenance des instruments"
              ]
            }
          ]
        },
        {
          nom: "Mesurer les points implantés à partir des points existants",
          description: "Effectuer les mesures de contrôle depuis les références établies",
          risques: [
            {
              description: "Erreur de mesure due aux conditions environnementales",
              niveau: "moyen",
              mesuresPrevention: [
                "Éviter les mesures par temps de forte chaleur ou vent",
                "Attendre la stabilisation thermique des instruments",
                "Protéger les instruments des intempéries",
                "Adapter les méthodes aux conditions météorologiques"
              ]
            },
            {
              description: "Confusion entre les points de référence",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser un système de numérotation clair",
                "Vérifier l'identification avant chaque mesure",
                "Maintenir un carnet de station à jour",
                "Photographier les points de référence si nécessaire"
              ]
            },
            {
              description: "Obstruction de la ligne de visée",
              niveau: "faible",
              mesuresPrevention: [
                "Reconnaître le terrain avant les mesures",
                "Prévoir des points intermédiaires si nécessaire",
                "Adapter la hauteur d'instrument selon les obstacles",
                "Documenter les limitations de visibilité"
              ]
            }
          ]
        },
        {
          nom: "Effectuer des mesures entre les points implantés",
          description: "Vérifier les distances et angles entre les points implantés",
          risques: [
            {
              description: "Erreur de fermeture du polygone de contrôle",
              niveau: "eleve",
              mesuresPrevention: [
                "Calculer systématiquement les erreurs de fermeture",
                "Respecter les tolérances de précision établies",
                "Effectuer des mesures redondantes pour validation",
                "Reprendre les mesures si les tolérances sont dépassées"
              ]
            },
            {
              description: "Accumulation d'erreurs dans les mesures successives",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des cheminements fermés ou appuyés",
                "Répartir les erreurs selon les méthodes reconnues",
                "Effectuer des contrôles intermédiaires réguliers",
                "Documenter la propagation des incertitudes"
              ]
            },
            {
              description: "Non-détection d'un déplacement de point",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des mesures de contrôle régulières",
                "Comparer avec les mesures antérieures",
                "Vérifier la stabilité physique des points",
                "Établir des seuils d'alerte pour les déplacements"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Station totale ou robotisée",
          type: "Instrument de mesure principal",
          securiteRequise: ["Calibration vérifiée", "Batterie chargée", "Protection contre intempéries"]
        },
        {
          nom: "Niveau optique ou électronique",
          type: "Instrument de nivellement",
          securiteRequise: ["Bulle de niveau vérifiée", "Oculaire propre", "Stabilité du trépied"]
        },
        {
          nom: "Récepteur GPS",
          type: "Système de positionnement",
          securiteRequise: ["Signal satellite suffisant", "Correction différentielle", "Antenne stable"]
        }
      ],
      materiaux: [
        {
          nom: "Prismes et supports",
          type: "Équipement de visée",
          precautions: ["Propreté des surfaces réfléchissantes", "Fixation stable", "Hauteur mesurée"]
        },
        {
          nom: "Mires de nivellement",
          type: "Équipement de lecture",
          precautions: ["Verticalité vérifiée", "Graduations lisibles", "Support stable"]
        }
      ]
    },
    {
      nom: "4.9 Protéger les points implantés",
      description: "Assurer la préservation des points d'implantation",
      sousOperations: [
        {
          nom: "Référencer les points susceptibles d'être arrachés par les machines",
          description: "Documenter et protéger les points vulnérables aux activités de chantier",
          risques: [
            {
              description: "Perte de points de référence critiques",
              niveau: "eleve",
              mesuresPrevention: [
                "Documenter précisément la localisation de tous les points",
                "Créer un plan de référencement détaillé",
                "Photographier les points avec leurs références",
                "Établir des points de recoupement supplémentaires"
              ]
            },
            {
              description: "Documentation insuffisante pour la restauration",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser un système de codification standardisé",
                "Enregistrer les coordonnées et descriptions complètes",
                "Créer des croquis détaillés avec mesures",
                "Sauvegarder les données en plusieurs exemplaires"
              ]
            },
            {
              description: "Erreur dans l'identification des points vulnérables",
              niveau: "moyen",
              mesuresPrevention: [
                "Analyser le plan de travail des machines",
                "Consulter les opérateurs d'équipement",
                "Évaluer les zones de circulation et de travail",
                "Prévoir une marge de sécurité autour des points"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Station totale ou GPS",
          type: "Instrument de positionnement",
          securiteRequise: ["Précision maximale", "Conditions optimales", "Validation croisée"]
        },
        {
          nom: "Appareil photo numérique",
          type: "Documentation visuelle",
          securiteRequise: ["Géolocalisation activée", "Résolution suffisante", "Sauvegarde sécurisée"]
        }
      ],
      materiaux: [
        {
          nom: "Carnet de référencement",
          type: "Documentation technique",
          precautions: ["Protection contre intempéries", "Copies multiples", "Système de classement"]
        },
        {
          nom: "Piquets de référence temporaires",
          type: "Marqueurs de sauvegarde",
          precautions: ["Matériaux durables", "Visibilité maintenue", "Coordonnées enregistrées"]
        }
      ]
    }
  ]
};
