
import { ASTData } from '../../services/astTypes';
import { tacheVerifierEntretenirMateriel } from './tache1-materiel';
import { tacheFaireLeveTerrain } from './tache2-leve';
import { tacheTraiterDonnees } from './tache3-donnees';
import { tacheEffectuerImplantations } from './tache4-implantations';
import { tacheEffectuerMiseEnPlan } from './tache5-plan';
import { tacheEstimerQuantites } from './tache6-quantites';

export const arpenteurASTData: ASTData = {
  corpsMetier: "Arpenteur",
  extractedAt: new Date().toISOString(),
  taches: [
    tacheVerifierEntretenirMateriel,
    tacheFaireLeveTerrain,
    tacheTraiterDonnees,
    tacheEffectuerImplantations,
    tacheEffectuerMiseEnPlan,
    tacheEstimerQuantites
  ]
};
