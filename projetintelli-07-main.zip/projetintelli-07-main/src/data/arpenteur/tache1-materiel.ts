import { ArpenteurTache } from './types';

export const tacheVerifierEntretenirMateriel: ArpenteurTache = {
  nom: "Vérifier et entretenir le matériel",
  description: "Maintenir en bon état le matériel d'arpentage et assurer son bon fonctionnement",
  operations: [
    {
      nom: "1.1 S'assurer de l'approvisionnement en matériel",
      description: "Vérifier la disponibilité et l'état du matériel nécessaire",
      sousOperations: [
        {
          nom: "1.1.1 S'assurer de la disponibilité du matériel",
          description: "Contrôler la présence de tout le matériel nécessaire : instruments de mesure, calculatrice, clous, piquets et tiges de fer, crayon, fil à plomb, ruban à mesurer, clés USB ou carte mémoire, ruban fluorescent, peinture et repères, corde, etc.",
          risques: [
            {
              description: "Manipulation d'équipements lourds (station totale, théodolite)",
              niveau: "moyen",
              mesuresPrevention: [
                "Porter des chaussures de sécurité avec embout d'acier",
                "Utiliser des techniques de levage appropriées",
                "Transporter un équipement à la fois",
                "Demander de l'aide pour les équipements lourds"
              ]
            }
          ]
        },
        {
          nom: "1.1.2 Recharger les piles",
          description: "Assurer l'alimentation électrique des équipements : station totale ou station totale robotisée, émetteur radio, cellulaire, GPS, niveau rotatif, carnet de notes électronique, etc.",
          risques: [
            {
              description: "Risque électrique lors de la manipulation des chargeurs",
              niveau: "faible",
              mesuresPrevention: [
                "Vérifier l'état des câbles avant utilisation",
                "Utiliser des prises avec mise à la terre",
                "Éviter l'eau près des équipements électriques",
                "Débrancher après utilisation"
              ]
            }
          ]
        },
        {
          nom: "1.1.3 S'assurer d'avoir de l'essence pour les outils et les machines",
          description: "Faire le plein des équipements à moteur et vérifier les niveaux de carburant",
          risques: [
            {
              description: "Manipulation de produits inflammables",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer le ravitaillement à l'extérieur",
                "Interdire de fumer dans la zone",
                "Utiliser des contenants approuvés",
                "Avoir un extincteur à proximité",
                "Porter des gants résistants aux hydrocarbures"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Station totale",
          type: "Instrument de mesure principal",
          securiteRequise: [
            "Transport dans étui rigide",
            "Manipulation avec précaution",
            "Vérification avant usage",
            "Protection contre l'humidité"
          ]
        },
        {
          nom: "Chargeur de piles",
          type: "Équipement électrique",
          securiteRequise: [
            "Vérification des câbles",
            "Utilisation en lieu sec",
            "Mise à la terre obligatoire"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Essence pour équipements",
          type: "Carburant",
          precautions: [
            "Stockage dans contenants approuvés",
            "Ventilation adéquate",
            "Extincteur à proximité",
            "Interdiction de fumer"
          ]
        }
      ]
    },
    {
      nom: "1.2 Nettoyer et entretenir le matériel",
      description: "Maintenir la propreté et la fonctionnalité des équipements",
      sousOperations: [
        {
          nom: "1.2.1 Nettoyer le matériel de terrain",
          description: "Nettoyer et décontaminer les équipements : chaînes, jalons, station totale, station totale robotisée, théodolite, niveaux rotatifs et manuels, trépieds, véhicules, etc.",
          risques: [
            {
              description: "Contact avec produits de nettoyage",
              niveau: "faible",
              mesuresPrevention: [
                "Porter des gants de protection",
                "Utiliser des produits non toxiques",
                "Assurer une ventilation adéquate",
                "Lire les fiches de sécurité"
              ]
            }
          ]
        },
        {
          nom: "1.2.2 Effectuer l'entretien mécanique",
          description: "Maintenir les équipements motorisés : scie mécanique, débroussailleuse, perceuse à percussion, pistolet de scellement, véhicule tout-terrain",
          risques: [
            {
              description: "Blessures lors de l'entretien mécanique",
              niveau: "moyen",
              mesuresPrevention: [
                "Porter des gants de mécanicien",
                "Utiliser les outils appropriés",
                "S'assurer que l'équipement est arrêté",
                "Suivre les procédures du fabricant"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Produits de nettoyage",
          type: "Solvants et détergents",
          securiteRequise: [
            "Lecture des fiches de sécurité",
            "Port de gants obligatoire",
            "Ventilation requise"
          ]
        },
        {
          nom: "Outils mécaniques",
          type: "Clés, tournevis, pinces",
          securiteRequise: [
            "Vérification avant usage",
            "Utilisation selon leur fonction",
            "Rangement sécuritaire"
          ]
        }
      ],
      materiaux: []
    },
    {
      nom: "1.3 Vérifier et régler la précision des instruments de mesure",
      description: "Contrôler et ajuster tous les instruments de mesure pour garantir leur précision",
      sousOperations: [
        {
          nom: "1.3.1 Vérifier et ajuster le centrage du plomb optique",
          description: "Contrôler et ajuster le centrage du plomb optique pour station totale et théodolite",
          risques: [
            {
              description: "Erreurs de centrage affectant la précision des mesures",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une plaque de centrage appropriée",
                "Effectuer le réglage sur surface stable",
                "Vérifier sur plusieurs positions",
                "Documenter les ajustements effectués"
              ]
            }
          ]
        },
        {
          nom: "1.3.2 Vérifier et ajuster le centrage de l'embase",
          description: "Contrôler et ajuster la précision du centrage de l'embase de l'instrument",
          risques: [
            {
              description: "Décentrage de l'embase causant des erreurs systématiques",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des outils de centrage calibrés",
                "Effectuer des mesures de contrôle",
                "Vérifier la stabilité de l'embase",
                "Respecter les tolérances du fabricant"
              ]
            }
          ]
        },
        {
          nom: "1.3.3 Vérifier et ajuster la nivelle de la canne à prisme",
          description: "Contrôler et ajuster la précision de la nivelle de la canne à prisme",
          risques: [
            {
              description: "Nivelle défectueuse causant des erreurs de verticalité",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser un niveau de référence certifié",
                "Effectuer le test de retournement",
                "Vérifier la sensibilité de la nivelle",
                "Remplacer si nécessaire"
              ]
            }
          ]
        },
        {
          nom: "1.3.4 Vérifier et ajuster la nivelle de la mire",
          description: "Contrôler et ajuster la précision de la nivelle de la mire de nivellement",
          risques: [
            {
              description: "Mire mal verticalisée affectant les mesures de dénivelée",
              niveau: "moyen",
              mesuresPrevention: [
                "Tester la nivelle sur surface connue",
                "Vérifier l'étalonnage régulièrement",
                "Contrôler la fixation de la nivelle",
                "Documenter les vérifications"
              ]
            }
          ]
        },
        {
          nom: "1.3.5 Vérifier et ajuster périodiquement la station totale robotisée",
          description: "Contrôler et ajuster la collimation et l'axe de tourillon de la station totale robotisée",
          risques: [
            {
              description: "Dérèglement de la collimation et de l'axe de tourillon",
              niveau: "eleve",
              mesuresPrevention: [
                "Suivre strictement les procédures du fabricant",
                "Utiliser des cibles de référence certifiées",
                "Effectuer les tests en conditions optimales",
                "Documenter tous les paramètres de réglage",
                "Faire appel au service technique si nécessaire"
              ]
            }
          ]
        },
        {
          nom: "1.3.6 Vérifier le télémètre ou la station totale",
          description: "Contrôler la précision des mesures de distance du télémètre ou de la station totale",
          risques: [
            {
              description: "Erreurs de mesure de distance",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des distances de référence connues",
                "Effectuer des mesures multiples",
                "Vérifier les corrections atmosphériques",
                "Contrôler l'état des prismes"
              ]
            }
          ]
        },
        {
          nom: "1.3.7 Vérifier les instruments de mesure installés sur la machinerie lourde",
          description: "Contrôler le bon fonctionnement des instruments de guidage sur les équipements de terrassement",
          risques: [
            {
              description: "Défaillance des systèmes de guidage de machinerie",
              niveau: "eleve",
              mesuresPrevention: [
                "Coordonner avec les opérateurs de machinerie",
                "Vérifier les points de référence",
                "Tester les communications radio",
                "Valider les paramètres de projet",
                "Effectuer des mesures de contrôle terrain"
              ]
            }
          ]
        },
        {
          nom: "1.3.8 Vérifier les instruments de mesure utilisés par les autres corps de métier",
          description: "Contrôler et valider les instruments utilisés par d'autres équipes sur le projet",
          risques: [
            {
              description: "Incompatibilité ou imprécision des instruments tiers",
              niveau: "moyen",
              mesuresPrevention: [
                "Établir des protocoles de vérification",
                "Former les autres équipes aux bonnes pratiques",
                "Effectuer des contrôles croisés",
                "Documenter les validations"
              ]
            }
          ]
        },
        {
          nom: "1.3.9 Effectuer le test de collimation du niveau",
          description: "Vérifier et ajuster la collimation du niveau de chantier",
          risques: [
            {
              description: "Erreur de collimation du niveau",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser la méthode des deux portées",
                "Effectuer le test sur terrain plat",
                "Respecter les distances recommandées",
                "Ajuster selon les spécifications"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Réglages incorrects affectant la précision générale",
          niveau: "eleve",
          mesuresPrevention: [
            "Suivre les procédures d'étalonnage du fabricant",
            "Maintenir un carnet de vérifications",
            "Effectuer des contrôles réguliers",
            "Former le personnel aux bonnes pratiques"
          ]
        }
      ],
      outils: [
        {
          nom: "Outils de réglage et d'étalonnage",
          type: "Instruments de précision",
          securiteRequise: [
            "Manipulation délicate requise",
            "Stockage en environnement contrôlé",
            "Étalonnage périodique obligatoire",
            "Protection contre les chocs"
          ]
        },
        {
          nom: "Cibles et mires de référence",
          type: "Équipements de test",
          securiteRequise: [
            "Vérification de l'intégrité",
            "Nettoyage avant usage",
            "Transport sécurisé"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Plaques de centrage",
          type: "Accessoires de réglage",
          precautions: [
            "Vérifier la planéité",
            "Maintenir propres",
            "Protéger contre les rayures"
          ]
        }
      ]
    },
    {
      nom: "Vérifier et régler la précision des instruments de mesure",
      description: "Contrôler et ajuster la précision des équipements d'arpentage",
      sousOperations: [
        {
          nom: "Vérifier l'étalonnage des instruments",
          description: "Contrôler la précision des mesures angulaires et linéaires",
          risques: [
            {
              description: "Erreurs de mesure dues à un mauvais étalonnage",
              niveau: "moyen",
              mesuresPrevention: [
                "Suivre les procédures d'étalonnage du fabricant",
                "Utiliser des références connues",
                "Documenter tous les réglages",
                "Effectuer des mesures de contrôle"
              ]
            }
          ]
        },
        {
          nom: "Ajuster les collimateurs",
          description: "Régler la visée optique des instruments",
          risques: [
            {
              description: "Fatigue oculaire lors des réglages fins",
              niveau: "faible",
              mesuresPrevention: [
                "Faire des pauses visuelles régulières",
                "Utiliser un éclairage adéquat",
                "Nettoyer les oculaires avant usage",
                "Ajuster la dioptrie selon l'opérateur"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Mires d'étalonnage",
          type: "Références de mesure",
          securiteRequise: [
            "Vérification de la rectitude",
            "Protection contre les chocs",
            "Stockage vertical"
          ]
        },
        {
          nom: "Tournevis de précision",
          type: "Outils de réglage",
          securiteRequise: [
            "Utilisation délicate",
            "Éviter les sur-serrages",
            "Rangement organisé"
          ]
        }
      ],
      materiaux: []
    },
    {
      nom: "Faire calibrer les instruments de mesure",
      description: "Procéder au calibrage professionnel des équipements de précision",
      sousOperations: [
        {
          nom: "Planifier le calibrage périodique",
          description: "Organiser le calendrier de calibrage selon les normes",
          risques: [
            {
              description: "Interruption des travaux pendant le calibrage",
              niveau: "faible",
              mesuresPrevention: [
                "Planifier pendant les périodes creuses",
                "Prévoir des équipements de rechange",
                "Informer les équipes à l'avance",
                "Coordonner avec le laboratoire de calibrage"
              ]
            }
          ]
        },
        {
          nom: "Préparer les instruments pour l'envoi",
          description: "Emballer et documenter les équipements",
          risques: [
            {
              description: "Dommages lors du transport",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser les emballages d'origine",
                "Protéger contre les chocs et vibrations",
                "Assurer les équipements",
                "Documenter l'état avant envoi"
              ]
            }
          ]
        }
      ],
      risques: [],
      outils: [
        {
          nom: "Emballages de transport",
          type: "Protection des instruments",
          securiteRequise: [
            "Mousse de protection",
            "Étiquetage fragile",
            "Documentation incluse"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Matériel d'emballage",
          type: "Protection transport",
          precautions: [
            "Vérification de l'étanchéité",
            "Protection contre l'humidité",
            "Identification claire"
          ]
        }
      ]
    },
    {
      nom: "1.5 Effectuer la gestion de fichiers informatiques",
      description: "Gérer et maintenir l'organisation des données numériques et des systèmes informatiques",
      sousOperations: [
        {
          nom: "1.5.1 Créer des répertoires",
          description: "Organiser l'arborescence des dossiers pour une gestion efficace des projets",
          risques: [
            {
              description: "Désorganisation des fichiers et perte de données",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une nomenclature standardisée",
                "Créer une structure cohérente par projet",
                "Documenter l'organisation des dossiers",
                "Former le personnel à la structure"
              ]
            }
          ]
        },
        {
          nom: "1.5.2 Effectuer des sauvegardes",
          description: "Protéger les données importantes par des copies de sécurité régulières",
          risques: [
            {
              description: "Perte définitive de données critiques",
              niveau: "eleve",
              mesuresPrevention: [
                "Programmer des sauvegardes automatiques",
                "Utiliser plusieurs supports de sauvegarde",
                "Vérifier l'intégrité des sauvegardes",
                "Stocker des copies hors site",
                "Tester régulièrement la restauration"
              ]
            }
          ]
        },
        {
          nom: "1.5.3 Défragmenter le disque",
          description: "Optimiser les performances du système en réorganisant les données sur le disque",
          risques: [
            {
              description: "Ralentissement du système et perte de productivité",
              niveau: "faible",
              mesuresPrevention: [
                "Planifier la défragmentation en dehors des heures de travail",
                "Sauvegarder avant la défragmentation",
                "Utiliser les outils appropriés",
                "Surveiller l'espace disque disponible"
              ]
            }
          ]
        },
        {
          nom: "1.5.4 Utiliser des logiciels de détection de virus",
          description: "Protéger le système contre les menaces informatiques et les logiciels malveillants",
          risques: [
            {
              description: "Infection par virus et compromission des données",
              niveau: "eleve",
              mesuresPrevention: [
                "Maintenir l'antivirus à jour",
                "Effectuer des analyses régulières",
                "Éviter les sources douteuses",
                "Former sur les bonnes pratiques de sécurité",
                "Sauvegarder avant les analyses"
              ]
            }
          ]
        },
        {
          nom: "1.5.5 Éliminer les fichiers non pertinents",
          description: "Nettoyer le système en supprimant les fichiers temporaires et obsolètes",
          risques: [
            {
              description: "Suppression accidentelle de fichiers importants",
              niveau: "moyen",
              mesuresPrevention: [
                "Identifier clairement les fichiers à supprimer",
                "Effectuer une sauvegarde préventive",
                "Utiliser des outils de nettoyage fiables",
                "Vérifier le contenu avant suppression"
              ]
            }
          ]
        },
        {
          nom: "1.5.6 Mettre à jour des logiciels",
          description: "Maintenir les applications et le système d'exploitation à jour",
          risques: [
            {
              description: "Incompatibilité après mise à jour et perte de fonctionnalités",
              niveau: "moyen",
              mesuresPrevention: [
                "Tester les mises à jour sur un système de test",
                "Sauvegarder avant les mises à jour majeures",
                "Lire les notes de version",
                "Planifier les mises à jour en période creuse",
                "Maintenir une version de secours"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Cybersécurité et confidentialité des données",
          niveau: "eleve",
          mesuresPrevention: [
            "Utiliser des mots de passe robustes",
            "Chiffrer les données sensibles",
            "Maintenir les logiciels de sécurité à jour",
            "Former le personnel aux bonnes pratiques",
            "Effectuer des audits de sécurité réguliers"
          ]
        }
      ],
      outils: [
        {
          nom: "Logiciels de sauvegarde",
          type: "Applications de protection des données",
          securiteRequise: [
            "Configuration de sauvegardes automatiques",
            "Chiffrement des données sauvegardées",
            "Vérification de l'intégrité des sauvegardes",
            "Tests de restauration périodiques"
          ]
        },
        {
          nom: "Antivirus et anti-malware",
          type: "Logiciels de sécurité",
          securiteRequise: [
            "Mise à jour automatique des définitions",
            "Analyse en temps réel activée",
            "Planification d'analyses complètes",
            "Configuration des alertes"
          ]
        },
        {
          nom: "Outils de défragmentation",
          type: "Utilitaires système",
          securiteRequise: [
            "Utilisation des outils certifiés",
            "Planification en dehors des heures de travail",
            "Surveillance de l'espace disque"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Supports de sauvegarde",
          type: "Disques externes, cloud",
          precautions: [
            "Vérification de la capacité suffisante",
            "Stockage en lieu sécurisé",
            "Rotation des supports",
            "Test périodique de l'intégrité"
          ]
        },
        {
          nom: "Documentation système",
          type: "Procédures et guides",
          precautions: [
            "Maintenir à jour",
            "Accès contrôlé",
            "Copies de sauvegarde",
            "Formation du personnel"
          ]
        }
      ]
    }
  ]
};
