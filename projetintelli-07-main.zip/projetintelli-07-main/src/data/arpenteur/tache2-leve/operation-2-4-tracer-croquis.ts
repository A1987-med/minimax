
import { ArpenteurOperation } from '../types';

export const operation24TracerCroquis: ArpenteurOperation = {
  nom: "2.4 Tracer un croquis, s'il y a lieu",
  description: "Réaliser un croquis de la zone de levé si nécessaire",
  sousOperations: [
    {
      nom: "2.4.1 Faire le tour des lieux et les dessiner, s'il y a lieu",
      description: "Effectuer un parcours complet de la zone et réaliser un croquis représentatif des éléments importants",
      risques: [
        {
          description: "Omission d'éléments importants du terrain",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Faire un tour complet et systématique de la zone",
            "Noter tous les détails significatifs pour le levé",
            "Vérifier le croquis avec les documents existants",
            "Prendre des photos de référence si nécessaire",
            "Consulter les plans disponibles pour validation"
          ]
        },
        {
          description: "Croquis inexact ou disproportionné",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Utiliser une échelle appropriée et cohérente",
            "Respecter les proportions relatives",
            "Vérifier les distances approximatives",
            "Annoter les dimensions importantes"
          ]
        }
      ]
    },
    {
      nom: "2.4.2 Indiquer les points codes s'il y a beaucoup de détails à relever",
      description: "Mettre en place un système de codification pour les nombreux détails à mesurer",
      risques: [
        {
          description: "Confusion dans le système de codification",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Établir un système de codes clair et logique",
            "Documenter la signification de chaque code",
            "Utiliser des codes normalisés si disponibles",
            "Vérifier la cohérence du système de codage",
            "Communiquer le système aux équipes concernées"
          ]
        },
        {
          description: "Oubli ou erreur dans l'attribution des codes",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Tenir une liste de référence des codes utilisés",
            "Vérifier systématiquement l'attribution des codes",
            "Utiliser des codes distincts et non ambigus",
            "Réviser la codification avant les mesures"
          ]
        }
      ]
    },
    {
      nom: "2.4.3 Donner l'information au contremaître ou au dessinateur",
      description: "Transmettre les informations du croquis et des codes aux personnes responsables",
      risques: [
        {
          description: "Transmission incomplète ou erronée des informations",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Préparer un document de transmission clair",
            "Expliquer verbalement les éléments complexes",
            "S'assurer de la compréhension du destinataire",
            "Conserver une copie des informations transmises",
            "Prévoir un suivi pour validation"
          ]
        },
        {
          description: "Mauvaise interprétation des codes ou du croquis",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Fournir une légende complète des codes",
            "Annoter clairement le croquis",
            "Répondre aux questions d'interprétation",
            "Valider la compréhension avec des exemples"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Croquis incomplet ou inexact affectant la suite des travaux",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Prendre le temps nécessaire pour un croquis complet",
        "Utiliser une échelle appropriée et constante",
        "Vérifier les proportions et les relations spatiales",
        "Valider avec les documents de référence disponibles"
      ]
    }
  ],
  outils: [
    {
      nom: "Matériel de dessin",
      type: "Papeterie technique",
      securiteRequise: [
        "Protéger contre l'humidité et les intempéries",
        "Utiliser du papier résistant aux conditions extérieures",
        "Prévoir des crayons et stylos de rechange",
        "Utiliser une planchette rigide comme support"
      ]
    },
    {
      nom: "Appareil photo",
      type: "Équipement de documentation",
      securiteRequise: [
        "Protéger contre les chocs et l'humidité",
        "Vérifier l'autonomie de la batterie",
        "S'assurer de l'espace de stockage suffisant",
        "Nettoyer l'objectif régulièrement"
      ]
    },
    {
      nom: "Mètre ruban",
      type: "Instrument de mesure",
      securiteRequise: [
        "Vérifier l'état du ruban avant utilisation",
        "Manipuler avec précaution pour éviter les coupures",
        "Nettoyer après usage en milieu poussiéreux",
        "Ranger correctement pour éviter les plis"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Papier millimétré",
      type: "Support de dessin",
      precautions: [
        "Conserver au sec dans une pochette étanche",
        "Utiliser une planchette rigide comme support",
        "Prévoir plusieurs feuilles de rechange",
        "Choisir un format adapté à la zone à dessiner"
      ]
    },
    {
      nom: "Crayons et stylos",
      type: "Outils d'écriture",
      precautions: [
        "Utiliser des instruments résistants aux intempéries",
        "Prévoir des mines de rechange",
        "Tester le fonctionnement avant utilisation",
        "Utiliser des couleurs différentes pour la codification"
      ]
    },
    {
      nom: "Étiquettes de codification",
      type: "Matériel de marquage",
      precautions: [
        "Utiliser des étiquettes résistantes aux intempéries",
        "S'assurer de la lisibilité des codes",
        "Prévoir suffisamment d'étiquettes",
        "Utiliser un système de couleurs cohérent"
      ]
    }
  ]
};
