
import { ArpenteurOperation } from '../types';

export const operation21PreparerTravail: ArpenteurOperation = {
  nom: "2.1 Préparer le travail",
  description: "Préparer le travail de levé de terrain",
  sousOperations: [
    {
      nom: "2.1.1 Prendre connaissance du travail",
      description: "Analyser tous les aspects du travail à effectuer : type de travail, endroit, limites, tolérances et exigences, délais, vérifier les plans de chantier, contraintes d'exécution",
      risques: [
        {
          description: "Mauvaise compréhension des exigences du projet",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Étudier attentivement tous les documents",
            "Clarifier les points ambigus avec le client",
            "Vérifier la concordance entre les différents documents",
            "Noter toutes les contraintes particulières"
          ]
        },
        {
          description: "Plans de chantier obsolètes ou incorrects",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier la date et la version des plans",
            "Confirmer avec le responsable de projet",
            "Comparer avec les conditions terrain",
            "Signaler toute incohérence"
          ]
        }
      ]
    },
    {
      nom: "2.1.2 Planifier le temps de travail et le calendrier de réalisation des travaux",
      description: "Établir un planning détaillé tenant compte des contraintes temporelles et des conditions de réalisation",
      risques: [
        {
          description: "Planification irréaliste ou dépassement des délais",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Prévoir des marges de sécurité dans les délais",
            "Tenir compte des conditions météorologiques",
            "Évaluer la complexité du terrain",
            "Coordonner avec les autres intervenants",
            "Prévoir des créneaux de rattrapage"
          ]
        },
        {
          description: "Conflit avec d'autres activités sur le chantier",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Coordonner avec le maître d'œuvre",
            "Respecter les plages horaires autorisées",
            "Communiquer le planning aux équipes",
            "Prévoir des alternatives en cas d'imprévu"
          ]
        }
      ]
    },
    {
      nom: "2.1.3 Choisir le matériel nécessaire",
      description: "Sélectionner les instruments et équipements appropriés selon la nature du travail et les conditions du terrain",
      risques: [
        {
          description: "Matériel inadapté ou insuffisant",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Analyser les besoins selon le type de levé",
            "Vérifier la disponibilité des équipements",
            "Prévoir du matériel de rechange",
            "S'assurer de la compatibilité des instruments",
            "Vérifier l'état et la calibration du matériel"
          ]
        },
        {
          description: "Oubli d'équipements essentiels",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Utiliser une liste de vérification",
            "Préparer le matériel la veille",
            "Vérifier l'inventaire avant le départ",
            "Prévoir les accessoires nécessaires"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Préparation insuffisante du travail",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Vérifier tous les documents nécessaires",
        "Planifier les étapes de travail",
        "S'assurer de la disponibilité des équipements"
      ]
    }
  ],
  outils: [
    {
      nom: "Documents techniques",
      type: "Documentation",
      securiteRequise: [
        "Vérifier la validité des documents",
        "Conserver les originaux en sécurité"
      ]
    },
    {
      nom: "Planning de travail",
      type: "Outil de planification",
      securiteRequise: [
        "Mettre à jour régulièrement",
        "Partager avec les équipes concernées"
      ]
    },
    {
      nom: "Liste d'inventaire matériel",
      type: "Outil de gestion",
      securiteRequise: [
        "Tenir à jour l'état du matériel",
        "Vérifier avant chaque sortie"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Plans et cartes",
      type: "Documents de référence",
      precautions: [
        "Protéger contre les intempéries",
        "Manipuler avec précaution"
      ]
    },
    {
      nom: "Cahier des charges",
      type: "Document contractuel",
      precautions: [
        "Conserver une copie de sauvegarde",
        "Respecter les spécifications"
      ]
    }
  ]
};
