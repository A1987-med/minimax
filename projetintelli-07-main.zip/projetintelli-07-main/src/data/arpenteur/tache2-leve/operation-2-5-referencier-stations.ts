
import { ArpenteurOperation } from '../types';

export const operation25ReferencierStations: ArpenteurOperation = {
  nom: "2.5 Référencer les stations",
  description: "Établir les références précises des stations de mesure",
  sousOperations: [
    {
      nom: "2.5.1 Localiser les stations par rapport aux éléments existants (poteau, maison, etc.)",
      description: "Situer précisément chaque station en référence à des éléments permanents du terrain",
      risques: [
        {
          description: "Mauvaise identification des éléments de référence",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Choisir des éléments permanents et stables",
            "Vérifier l'ancienneté et la solidité des références",
            "Documenter précisément la localisation",
            "Prendre des photos des éléments de référence",
            "Utiliser plusieurs éléments de référence pour chaque station"
          ]
        },
        {
          description: "Mesures de localisation imprécises",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser des instruments de mesure calibrés",
            "Effectuer des mesures redondantes",
            "Vérifier la cohérence des distances mesurées",
            "Noter les conditions de mesure",
            "Contrôler avec d'autres méthodes si possible"
          ]
        }
      ]
    },
    {
      nom: "2.5.2 Reporter les points codes (p.codes et description de points)",
      description: "Transcrire et organiser tous les codes de points avec leurs descriptions détaillées",
      risques: [
        {
          description: "Erreur de transcription des codes de points",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier systématiquement chaque transcription",
            "Utiliser un système de double vérification",
            "Maintenir la cohérence du système de codage",
            "Clarifier les codes ambigus immédiatement",
            "Conserver les notes originales comme référence"
          ]
        },
        {
          description: "Descriptions de points incomplètes ou inexactes",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Rédiger des descriptions claires et détaillées",
            "Utiliser une terminologie standardisée",
            "Inclure toutes les informations pertinentes",
            "Vérifier la correspondance code-description",
            "Réviser avant la finalisation"
          ]
        }
      ]
    },
    {
      nom: "2.5.3 Enregistrer les données dans le carnet de notes (manuel ou électronique)",
      description: "Consigner de manière organisée toutes les données de référencement dans le support de documentation",
      risques: [
        {
          description: "Perte ou corruption des données enregistrées",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Effectuer des sauvegardes régulières des données électroniques",
            "Utiliser un carnet de notes résistant aux intempéries",
            "Dupliquer les informations critiques",
            "Vérifier l'intégrité des données enregistrées",
            "Prévoir des supports de sauvegarde multiples"
          ]
        },
        {
          description: "Données mal organisées ou difficiles à retrouver",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Suivre un système d'organisation cohérent",
            "Numéroter et dater toutes les pages",
            "Créer un index des données importantes",
            "Utiliser des séparateurs ou des onglets",
            "Maintenir la lisibilité de l'écriture"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Référencement insuffisant ou incorrect des stations",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Utiliser le système de coordonnées approprié",
        "Vérifier les calculs et les mesures",
        "Documenter complètement la méthode utilisée",
        "Effectuer des contrôles de cohérence",
        "Conserver toutes les données de référencement"
      ]
    }
  ],
  outils: [
    {
      nom: "GPS de précision",
      type: "Instrument de positionnement",
      securiteRequise: [
        "Vérifier la calibration avant utilisation",
        "S'assurer de la réception satellite optimale",
        "Protéger contre les chocs et l'humidité",
        "Maintenir l'alimentation suffisante",
        "Utiliser les corrections différentielles appropriées"
      ]
    },
    {
      nom: "Carnet de terrain électronique",
      type: "Support d'enregistrement numérique",
      securiteRequise: [
        "Vérifier l'autonomie de la batterie",
        "Protéger contre les conditions météorologiques",
        "Effectuer des sauvegardes régulières",
        "Maintenir la synchronisation des données",
        "Prévoir un support de sauvegarde physique"
      ]
    },
    {
      nom: "Instruments de mesure de distance",
      type: "Équipement de mesure",
      securiteRequise: [
        "Vérifier l'étalonnage régulièrement",
        "Nettoyer les optiques avant utilisation",
        "Protéger contre la poussière et l'humidité",
        "Manipuler avec précaution",
        "Ranger dans leur étui de protection"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Points de référence permanents",
      type: "Repères géodésiques et éléments fixes",
      precautions: [
        "Vérifier l'intégrité et la stabilité des repères",
        "S'assurer de leur validité officielle",
        "Documenter leur état et leur accessibilité",
        "Protéger contre les dommages accidentels",
        "Signaler tout problème aux autorités compétentes"
      ]
    },
    {
      nom: "Supports de documentation",
      type: "Carnets et supports numériques",
      precautions: [
        "Utiliser des matériaux résistants aux intempéries",
        "Prévoir des supports de sauvegarde multiples",
        "Organiser selon un système logique et cohérent",
        "Protéger contre la perte ou le vol",
        "Maintenir la lisibilité et l'accessibilité"
      ]
    },
    {
      nom: "Matériel de marquage et d'identification",
      type: "Outils de repérage visuel",
      precautions: [
        "Utiliser des couleurs et symboles normalisés",
        "S'assurer de la durabilité du marquage",
        "Maintenir la visibilité dans toutes conditions",
        "Respecter les codes et conventions en vigueur",
        "Prévoir le retrait après les travaux si nécessaire"
      ]
    }
  ]
};
