
import { ArpenteurOperation } from '../types';

export const operation23EtablirStations: ArpenteurOperation = {
  nom: "2.3 Établir ou choisir des stations",
  description: "Déterminer les points de station pour les mesures",
  sousOperations: [
    {
      nom: "2.3.1 Choisir les points de départ",
      description: "Sélectionner les points de référence appropriés : bornes, clous géoréférencés, repères géodésiques, etc.",
      risques: [
        {
          description: "Choix de points de référence inadéquats ou instables",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier la stabilité et l'intégrité des repères",
            "Consulter les fiches descriptives officielles",
            "Contrôler la précision des coordonnées connues",
            "S'assurer de la visibilité depuis les points",
            "Valider avec des mesures de contrôle"
          ]
        },
        {
          description: "Utilisation de repères non validés ou obsolètes",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier la date de dernière validation",
            "Consulter les bases de données officielles",
            "Effectuer des mesures de vérification",
            "Documenter les points utilisés"
          ]
        }
      ]
    },
    {
      nom: "2.3.2 Établir des points de station avec la station totale, la station totale robotisée ou le système de localisation (GPS)",
      description: "Créer et matérialiser les points de station nécessaires : clous, tiges, tuyaux, etc.",
      risques: [
        {
          description: "Installation incorrecte ou instable des points de station",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Choisir un emplacement stable et durable",
            "Utiliser le matériel de matérialisation approprié",
            "S'assurer de l'enfoncement suffisant",
            "Vérifier la stabilité après installation",
            "Protéger contre les dommages accidentels"
          ]
        },
        {
          description: "Erreur de positionnement des stations",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser des instruments calibrés",
            "Effectuer des mesures de contrôle",
            "Vérifier les coordonnées calculées",
            "Documenter précisément l'emplacement",
            "Effectuer des mesures redondantes"
          ]
        },
        {
          description: "Interférences lors de l'utilisation du GPS",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Vérifier la réception satellite",
            "Éviter les zones d'obstruction",
            "Utiliser des corrections DGPS si disponibles",
            "Effectuer des mesures multiples",
            "Valider avec d'autres méthodes si nécessaire"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Réseau de stations inadéquat pour la précision requise",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Planifier la géométrie du réseau",
        "Respecter les normes de précision",
        "Prévoir des stations de contrôle",
        "Optimiser la répartition des points"
      ]
    }
  ],
  outils: [
    {
      nom: "Station totale",
      type: "Instrument de mesure",
      securiteRequise: [
        "Transport dans étui de protection",
        "Manipulation avec précaution",
        "Vérification de l'étalonnage",
        "Protection contre les intempéries"
      ]
    },
    {
      nom: "GPS/GNSS",
      type: "Système de positionnement",
      securiteRequise: [
        "Vérifier la réception satellite",
        "Utiliser les corrections appropriées",
        "Protéger contre les chocs",
        "Maintenir l'alimentation"
      ]
    },
    {
      nom: "Marteau et masse",
      type: "Outils d'installation",
      securiteRequise: [
        "Utiliser des gestes sûrs",
        "Porter des lunettes de protection",
        "Vérifier l'état des outils",
        "Éviter les surfaces glissantes"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Clous d'arpentage",
      type: "Matérialisation de points",
      precautions: [
        "Utiliser la longueur appropriée",
        "S'assurer de la qualité du métal",
        "Marquer clairement les points",
        "Protéger contre l'arrachement"
      ]
    },
    {
      nom: "Tiges et tuyaux",
      type: "Repères temporaires",
      precautions: [
        "Choisir le diamètre approprié",
        "Assurer un enfoncement suffisant",
        "Marquer la hauteur de référence",
        "Protéger contre les dommages"
      ]
    },
    {
      nom: "Peinture de marquage",
      type: "Identification visuelle",
      precautions: [
        "Utiliser des couleurs normalisées",
        "Assurer une bonne visibilité",
        "Protéger contre l'effacement",
        "Respecter l'environnement"
      ]
    }
  ]
};
