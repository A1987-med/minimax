
import { ArpenteurOperation } from '../types';

export const operation22PreparerLieux: ArpenteurOperation = {
  nom: "2.2 Préparer les lieux",
  description: "Préparer et sécuriser la zone de travail",
  sousOperations: [
    {
      nom: "2.2.1 Repérer les éléments pertinents",
      description: "Identifier et localiser les éléments importants du terrain : bornes, tuyaux, piquets, vestiges, repères géodésiques, services (Info-Excavation)",
      risques: [
        {
          description: "Omission d'éléments critiques pour le levé",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Effectuer un parcours systématique de la zone",
            "Consulter les plans de services existants",
            "Vérifier avec Info-Excavation",
            "Documenter tous les éléments trouvés",
            "Photographier les repères importants"
          ]
        },
        {
          description: "Dommage aux services souterrains",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Contacter Info-Excavation avant tout travail",
            "Respecter les délais de localisation",
            "Utiliser un détecteur de services",
            "Marquer clairement les services localisés",
            "Éviter les excavations près des services"
          ]
        },
        {
          description: "Confusion entre vrais et faux repères",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier l'authenticité des repères géodésiques",
            "Consulter les fiches descriptives officielles",
            "Contrôler l'état et l'intégrité des bornes",
            "Valider avec des mesures de contrôle"
          ]
        }
      ]
    },
    {
      nom: "2.2.2 Dégager les lieux ou les faire dégager par d'autres corps de métier",
      description: "Libérer l'espace de travail des obstacles et coordonner avec les autres équipes",
      risques: [
        {
          description: "Blessures lors du déblaiement",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Porter les équipements de protection individuelle",
            "Utiliser les outils appropriés",
            "Travailler en équipe pour les charges lourdes",
            "Identifier les dangers avant de commencer",
            "S'assurer de la stabilité des objets à déplacer"
          ]
        },
        {
          description: "Conflit avec d'autres corps de métier",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Coordonner avec le responsable de chantier",
            "Communiquer les besoins d'espace clairement",
            "Respecter les priorités de travail",
            "Planifier les interventions en commun"
          ]
        },
        {
          description: "Détérioration d'éléments importants",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Identifier les éléments à préserver",
            "Protéger les repères et bornes",
            "Manipuler avec précaution",
            "Documenter l'état avant et après"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Risques liés à la circulation",
      niveau: 'eleve' as const,
      mesuresPrevention: [
        "Signaler sa présence",
        "Porter des EPI haute visibilité",
        "Coordonner avec les autorités si nécessaire"
      ]
    },
    {
      description: "Préparation insuffisante du site",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Effectuer une reconnaissance complète",
        "Coordonner avec tous les intervenants",
        "Prévoir les accès et dégagements nécessaires"
      ]
    }
  ],
  outils: [
    {
      nom: "Matériel de signalisation",
      type: "Équipement de sécurité",
      securiteRequise: [
        "Vérifier la visibilité des éléments",
        "S'assurer de la stabilité des supports"
      ]
    },
    {
      nom: "Détecteur de services",
      type: "Équipement de localisation",
      securiteRequise: [
        "Vérifier l'étalonnage avant usage",
        "Tester sur services connus",
        "Maintenir à distance des interférences"
      ]
    },
    {
      nom: "Outils de déblaiement",
      type: "Équipement de terrain",
      securiteRequise: [
        "Vérifier l'état avant utilisation",
        "Utiliser selon leur fonction",
        "Ranger après usage"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Cônes et barrières",
      type: "Signalisation",
      precautions: [
        "Installer selon les normes",
        "Vérifier régulièrement la position"
      ]
    },
    {
      nom: "Peinture de marquage",
      type: "Matériel de repérage",
      precautions: [
        "Utiliser les couleurs réglementaires",
        "Assurer une bonne adhérence",
        "Protéger contre l'effacement"
      ]
    },
    {
      nom: "Matériel de protection",
      type: "Protection des repères",
      precautions: [
        "Installer solidement",
        "Assurer la visibilité",
        "Retirer après les travaux"
      ]
    }
  ]
};
