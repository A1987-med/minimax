
import { ArpenteurOperation } from '../types';

export const operation26MiseEnStation: ArpenteurOperation = {
  nom: "2.6 Faire la mise en station des instruments de mesure",
  description: "Installer et calibrer les instruments sur les stations",
  sousOperations: [
    {
      nom: "2.6.1 Faire le centrage ou la résection, le nivellement et le réglage des instruments sur la station choisie",
      description: "Centrer, niveler et régler les instruments de mesure : station totale, station totale robotisée, récepteur GPS, niveau à laser ou niveau électronique",
      risques: [
        {
          description: "Centrage imprécis de l'instrument",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser un fil à plomb ou un laser de centrage",
            "Vérifier le centrage sous plusieurs angles",
            "Ajuster minutieusement la position du trépied",
            "Contrôler la stabilité de l'ensemble",
            "Respecter les tolérances de centrage requises"
          ]
        },
        {
          description: "Nivellement incorrect de l'instrument",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser les niveaux sphériques et tubulaires",
            "Effectuer un nivellement précis en plusieurs étapes",
            "Vérifier le nivellement après chaque réglage",
            "Contrôler la stabilité pendant les mesures",
            "Effectuer des vérifications périodiques"
          ]
        },
        {
          description: "Mauvais réglage des paramètres d'instrument",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Suivre la procédure de mise en station standard",
            "Vérifier les paramètres de configuration",
            "Effectuer les réglages selon le manuel",
            "Documenter les paramètres utilisés"
          ]
        }
      ]
    },
    {
      nom: "2.6.2 Effectuer la visée arrière",
      description: "Réaliser la visée arrière avec les instruments appropriés : station totale, station totale robotisée, niveau, niveau à laser ou électronique, GPS (vérification sur un point de référence)",
      risques: [
        {
          description: "Erreur de visée arrière compromettant l'orientation",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Identifier clairement le point de référence",
            "Vérifier les coordonnées du point visé",
            "Effectuer plusieurs visées de contrôle",
            "Calculer et vérifier l'orientation obtenue",
            "Documenter précisément la procédure"
          ]
        },
        {
          description: "Point de référence incorrect ou déplacé",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier l'intégrité du point de référence",
            "Contrôler avec les coordonnées connues",
            "Effectuer des mesures de validation",
            "Utiliser plusieurs points de contrôle si possible"
          ]
        },
        {
          description: "Conditions atmosphériques défavorables",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Attendre des conditions plus favorables",
            "Appliquer les corrections atmosphériques",
            "Utiliser des méthodes alternatives si nécessaire",
            "Documenter les conditions de mesure"
          ]
        }
      ]
    },
    {
      nom: "2.6.3 Optimiser la précision des stations",
      description: "Améliorer et contrôler la précision des stations établies",
      risques: [
        {
          description: "Précision insuffisante pour les exigences du projet",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Respecter les normes de précision requises",
            "Effectuer des mesures redondantes",
            "Utiliser des méthodes de contrôle appropriées",
            "Calculer et analyser les écarts",
            "Reprendre les mesures si nécessaire"
          ]
        },
        {
          description: "Erreurs systématiques non détectées",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Effectuer des contrôles croisés",
            "Utiliser différentes méthodes de mesure",
            "Vérifier la calibration des instruments",
            "Analyser la cohérence des résultats"
          ]
        }
      ]
    },
    {
      nom: "2.6.4 Préparer les carnets de notes (manuel et électronique)",
      description: "Organiser et préparer les supports d'enregistrement des données",
      risques: [
        {
          description: "Perte ou corruption des données",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser des carnets résistants aux intempéries",
            "Sauvegarder régulièrement les données électroniques",
            "Tenir des carnets manuels en parallèle",
            "Vérifier le fonctionnement des équipements électroniques",
            "Prévoir des supports de sauvegarde"
          ]
        },
        {
          description: "Organisation défaillante des données",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Établir un système de numérotation logique",
            "Préparer des formulaires standardisés",
            "Définir une méthode de classement claire",
            "Former l'équipe aux procédures d'enregistrement"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Instrument mal calibré",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Suivre la procédure de mise en station",
        "Vérifier les niveaux",
        "Effectuer les réglages nécessaires"
      ]
    }
  ],
  outils: [
    {
      nom: "Station totale",
      type: "Instrument de mesure angulaire et distance",
      securiteRequise: [
        "Manipuler avec précaution",
        "Protéger contre les intempéries",
        "Vérifier la calibration régulièrement",
        "Utiliser un trépied stable"
      ]
    },
    {
      nom: "Station totale robotisée",
      type: "Instrument automatisé",
      securiteRequise: [
        "Vérifier la batterie et les connexions",
        "Protéger contre les interférences",
        "Maintenir la liaison radio/Bluetooth",
        "Surveiller le fonctionnement automatique"
      ]
    },
    {
      nom: "Récepteur GPS/GNSS",
      type: "Système de positionnement satellitaire",
      securiteRequise: [
        "Vérifier la réception satellite",
        "Utiliser les corrections DGPS",
        "Protéger l'antenne",
        "Maintenir l'alimentation"
      ]
    },
    {
      nom: "Niveau à laser",
      type: "Instrument de nivellement",
      securiteRequise: [
        "Protéger le laser",
        "Vérifier l'horizontalité",
        "Éviter les vibrations",
        "Respecter les consignes de sécurité laser"
      ]
    },
    {
      nom: "Niveau électronique",
      type: "Instrument de nivellement numérique",
      securiteRequise: [
        "Vérifier l'état des batteries",
        "Protéger contre l'humidité",
        "Calibrer selon les procédures",
        "Maintenir propres les optiques"
      ]
    },
    {
      nom: "Trépied",
      type: "Support",
      securiteRequise: [
        "Vérifier la solidité des fixations",
        "S'assurer de la stabilité du sol",
        "Régler correctement la hauteur"
      ]
    },
    {
      nom: "Fil à plomb",
      type: "Outil de centrage",
      securiteRequise: [
        "Protéger contre le vent",
        "Vérifier la verticalité",
        "Utiliser avec précaution"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Carnet de terrain résistant",
      type: "Support d'enregistrement manuel",
      precautions: [
        "Protéger contre l'humidité",
        "Utiliser de l'encre indélébile",
        "Numéroter les pages",
        "Conserver en lieu sûr"
      ]
    },
    {
      nom: "Collecteur de données électronique",
      type: "Support d'enregistrement numérique",
      precautions: [
        "Vérifier l'autonomie",
        "Effectuer des sauvegardes régulières",
        "Protéger contre les chocs",
        "Maintenir à jour le logiciel"
      ]
    },
    {
      nom: "Plaques de mise en station",
      type: "Accessoires de positionnement",
      precautions: [
        "Nettoyer avant utilisation",
        "Vérifier l'état des surfaces",
        "Positionner correctement",
        "Protéger contre le déplacement"
      ]
    },
    {
      nom: "Supports de sauvegarde",
      type: "Stockage de données",
      precautions: [
        "Vérifier la capacité",
        "Protéger contre la corruption",
        "Étiqueter clairement",
        "Conserver des copies multiples"
      ]
    }
  ]
};

export const operation27PrendreMesures: ArpenteurOperation = {
  nom: "2.7 Prendre des mesures",
  description: "Effectuer les mesures topographiques nécessaires",
  sousOperations: [
    {
      nom: "2.7.1 Mesurer des angles",
      description: "Mesurer des angles avec la station totale, la station totale robotisée ou le théodolite",
      risques: [
        {
          description: "Erreur de lecture angulaire",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Lire attentivement les graduations",
            "Effectuer plusieurs lectures",
            "Vérifier la cohérence des mesures",
            "Utiliser la méthode des séries pour les mesures précises",
            "Contrôler l'horizontalité de l'instrument"
          ]
        },
        {
          description: "Erreur de pointé sur la cible",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Utiliser des cibles appropriées et visibles",
            "Ajuster correctement la mise au point",
            "Pointer le centre de la cible",
            "Vérifier l'absence de parallaxe",
            "Effectuer des visées répétées"
          ]
        },
        {
          description: "Déplacement de l'instrument pendant la mesure",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Vérifier la stabilité du trépied",
            "Éviter les vibrations",
            "Protéger contre le vent",
            "Contrôler le nivellement régulièrement"
          ]
        }
      ]
    },
    {
      nom: "2.7.2 Mesurer des distances",
      description: "Mesurer des distances avec la station totale, la station totale robotisée, la chaîne, l'odomètre, le ruban à mesurer ou le GPS",
      risques: [
        {
          description: "Obstacle ou terrain dangereux sur le parcours",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Évaluer les risques du parcours avant de commencer",
            "Utiliser des méthodes alternatives si nécessaire",
            "Porter les EPI appropriés",
            "Signaler sa présence sur les voies de circulation",
            "Travailler en équipe pour la sécurité"
          ]
        },
        {
          description: "Erreur de mesure due aux conditions atmosphériques",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Appliquer les corrections atmosphériques",
            "Mesurer la température et la pression",
            "Éviter les mesures par temps de brouillard",
            "Tenir compte de la réfraction",
            "Utiliser des instruments compensés"
          ]
        },
        {
          description: "Erreur de manipulation des instruments de mesure directe",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Maintenir la chaîne ou le ruban tendu et horizontal",
            "Vérifier l'étalonnage des instruments",
            "Effectuer des mesures répétées",
            "Corriger la température pour les mesures précises",
            "Éviter les obstacles sur le trajet"
          ]
        }
      ]
    },
    {
      nom: "2.7.3 Mesurer l'élévation",
      description: "Mesurer l'élévation avec la station totale, la station totale robotisée, le niveau, le niveau à laser ou électronique, ou le GPS",
      risques: [
        {
          description: "Erreur de nivellement",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier le réglage et la calibration des niveaux",
            "Effectuer des cheminements fermés",
            "Respecter les portées maximales recommandées",
            "Utiliser des mires appropriées et stables",
            "Contrôler les erreurs de fermeture"
          ]
        },
        {
          description: "Réfraction atmosphérique affectant les mesures",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Éviter les mesures près du sol par temps chaud",
            "Équilibrer les portées avant et arrière",
            "Effectuer les mesures aux heures optimales",
            "Utiliser des méthodes de correction appropriées"
          ]
        }
      ]
    },
    {
      nom: "2.7.4 Effectuer un relevé en X, Y, Z",
      description: "Effectuer un relevé en coordonnées tridimensionnelles avec la station totale, la station totale robotisée, le GPS ou le numériseur (scanner) laser 3D",
      risques: [
        {
          description: "Erreur de système de coordonnées",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier le système de projection utilisé",
            "Contrôler les paramètres de transformation",
            "Valider avec des points de contrôle connus",
            "Documenter le système de référence",
            "Effectuer des vérifications croisées"
          ]
        },
        {
          description: "Densité de points insuffisante ou excessive",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Adapter la densité aux exigences du projet",
            "Respecter les spécifications techniques",
            "Optimiser le temps de levé",
            "Vérifier la couverture complète de la zone"
          ]
        },
        {
          description: "Erreur de manipulation du scanner 3D",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Former l'opérateur aux procédures",
            "Vérifier l'étalonnage du scanner",
            "Assurer des conditions d'éclairage appropriées",
            "Contrôler la qualité des données en temps réel"
          ]
        }
      ]
    },
    {
      nom: "2.7.5 Entrer les points codes (p.codes et description de points)",
      description: "Enregistrer les codes de points et leurs descriptions dans le système de mesure",
      risques: [
        {
          description: "Erreur de codification ou description incorrecte",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Utiliser un système de codification standardisé",
            "Vérifier la correspondance code-description",
            "Former l'équipe aux conventions adoptées",
            "Contrôler la saisie en temps réel",
            "Maintenir un dictionnaire de codes à jour"
          ]
        },
        {
          description: "Perte ou corruption des données de codification",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Sauvegarder régulièrement les données",
            "Utiliser des supports redondants",
            "Vérifier l'intégrité des fichiers",
            "Maintenir des copies de sauvegarde",
            "Documenter les procédures de récupération"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Mesures imprécises compromettant la qualité du levé",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Calibrer régulièrement tous les instruments",
        "Répéter les mesures critiques",
        "Vérifier les conditions météorologiques",
        "Respecter les procédures de mesure",
        "Effectuer des contrôles de qualité systématiques"
      ]
    },
    {
      description: "Organisation défaillante des mesures",
      niveau: 'faible' as const,
      mesuresPrevention: [
        "Planifier l'ordre des mesures",
        "Optimiser les déplacements",
        "Coordonner le travail d'équipe",
        "Documenter le progrès en temps réel"
      ]
    }
  ],
  outils: [
    {
      nom: "Station totale",
      type: "Instrument de mesure angulaire et distance",
      securiteRequise: [
        "Manipuler avec précaution lors des déplacements",
        "Vérifier l'état des batteries régulièrement",
        "Nettoyer les optiques avec des produits appropriés",
        "Protéger contre la poussière et l'humidité",
        "Utiliser un trépied stable et approprié"
      ]
    },
    {
      nom: "Station totale robotisée",
      type: "Instrument automatisé de mesure",
      securiteRequise: [
        "Vérifier la batterie et les connexions radio",
        "Protéger contre les interférences électromagnétiques",
        "Maintenir la liaison avec la télécommande",
        "Surveiller le fonctionnement automatique",
        "Prévoir un mode de fonctionnement manuel de secours"
      ]
    },
    {
      nom: "Théodolite",
      type: "Instrument de mesure angulaire",
      securiteRequise: [
        "Manipuler avec précaution extrême",
        "Vérifier le nivellement avant chaque série",
        "Protéger contre les chocs et vibrations",
        "Nettoyer régulièrement les optiques"
      ]
    },
    {
      nom: "GPS/GNSS",
      type: "Système de positionnement satellitaire",
      securiteRequise: [
        "Vérifier la réception satellite avant utilisation",
        "Utiliser les corrections DGPS appropriées",
        "Protéger l'antenne contre les dommages",
        "Maintenir l'alimentation suffisante",
        "Éviter les zones d'obstruction ou de réflexion"
      ]
    },
    {
      nom: "Niveau optique/électronique",
      type: "Instrument de nivellement",
      securiteRequise: [
        "Vérifier l'étalonnage régulièrement",
        "Protéger contre les vibrations et chocs",
        "Maintenir propres les optiques",
        "Contrôler le nivellement sphérique",
        "Vérifier l'état des batteries pour les niveaux électroniques"
      ]
    },
    {
      nom: "Scanner laser 3D",
      type: "Instrument de numérisation tridimensionnelle",
      securiteRequise: [
        "Former spécifiquement l'opérateur",
        "Vérifier l'étalonnage avant usage",
        "Protéger contre la poussière et l'humidité",
        "Contrôler la température de fonctionnement",
        "Respecter les consignes de sécurité laser"
      ]
    },
    {
      nom: "Chaîne d'arpenteur",
      type: "Instrument de mesure directe",
      securiteRequise: [
        "Vérifier l'étalonnage et l'état des maillons",
        "Manipuler avec précaution pour éviter les blessures",
        "Maintenir propre et lubrifiée",
        "Ranger correctement après usage"
      ]
    },
    {
      nom: "Ruban à mesurer",
      type: "Instrument de mesure directe",
      securiteRequise: [
        "Vérifier l'étalonnage périodiquement",
        "Éviter les pliures et déformations",
        "Protéger contre la corrosion",
        "Manipuler avec précaution les extrémités"
      ]
    },
    {
      nom: "Odomètre",
      type: "Instrument de mesure de distance par roulement",
      securiteRequise: [
        "Vérifier l'étalonnage sur distance connue",
        "Maintenir la roue propre et en bon état",
        "Adapter à la nature du terrain",
        "Contrôler régulièrement les mécanismes"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Prismes réflecteurs",
      type: "Cibles de mesure pour instruments électro-optiques",
      precautions: [
        "Nettoyer régulièrement avec des produits appropriés",
        "Vérifier l'alignement et la fixation",
        "Protéger contre les dommages et rayures",
        "Contrôler la constante de prisme",
        "Transporter dans des étuis de protection"
      ]
    },
    {
      nom: "Mires de nivellement",
      type: "Supports gradués pour mesures d'élévation",
      precautions: [
        "Vérifier la verticalité lors de l'utilisation",
        "Contrôler l'état des graduations",
        "Nettoyer régulièrement",
        "Protéger contre les déformations",
        "Assurer une base stable"
      ]
    },
    {
      nom: "Cibles de scanner",
      type: "Repères pour la numérisation 3D",
      precautions: [
        "Positionner selon les spécifications du fabricant",
        "Maintenir propres et non déformées",
        "Assurer une bonne visibilité",
        "Documenter les positions",
        "Contrôler la stabilité pendant le scan"
      ]
    },
    {
      nom: "Supports et accessoires de mesure",
      type: "Équipements auxiliaires",
      precautions: [
        "Vérifier la stabilité avant utilisation",
        "Maintenir en bon état de fonctionnement",
        "Adapter aux conditions du terrain",
        "Ranger et transporter avec précaution"
      ]
    }
  ]
};

export const operation28VerifierFermeture: ArpenteurOperation = {
  nom: "2.8 Vérifier la fermeture",
  description: "Contrôler la précision du levé par vérification de fermeture",
  sousOperations: [
    {
      nom: "2.8.1 Effectuer la visée arrière",
      description: "Réaliser la visée arrière avec les instruments appropriés : station totale, station totale robotisée, niveau, niveau à laser ou électronique, GPS (vérification sur un point de référence)",
      risques: [
        {
          description: "Erreur de visée arrière compromettant la vérification",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Identifier clairement le point de référence de départ",
            "Vérifier les coordonnées du point de contrôle",
            "Effectuer plusieurs visées de vérification",
            "Calculer et analyser l'écart de fermeture",
            "Documenter précisément la procédure de contrôle"
          ]
        },
        {
          description: "Point de référence déplacé ou endommagé",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier l'intégrité physique du point",
            "Contrôler avec les coordonnées d'origine",
            "Effectuer des mesures de validation croisées",
            "Utiliser plusieurs points de contrôle si disponibles"
          ]
        },
        {
          description: "Conditions de mesure différentes entre aller et retour",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Maintenir des conditions de mesure similaires",
            "Appliquer les mêmes corrections atmosphériques",
            "Effectuer les mesures dans des délais rapprochés",
            "Documenter les conditions de chaque mesure"
          ]
        }
      ]
    },
    {
      nom: "2.8.2 Optimiser la précision des stations",
      description: "Améliorer et contrôler la précision finale des stations de mesure",
      risques: [
        {
          description: "Précision finale insuffisante pour la fermeture",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Respecter les tolérances de fermeture requises",
            "Effectuer des mesures redondantes de contrôle",
            "Utiliser des méthodes de compensation appropriées",
            "Calculer et analyser tous les écarts",
            "Reprendre les mesures critiques si nécessaire"
          ]
        },
        {
          description: "Accumulation d'erreurs systématiques",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Effectuer des contrôles de cohérence globale",
            "Analyser la répartition des erreurs",
            "Vérifier l'absence d'erreurs systématiques",
            "Utiliser des méthodes de détection d'erreurs grossières"
          ]
        },
        {
          description: "Non-respect des spécifications de précision",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Vérifier les exigences de précision du projet",
            "Calculer les indicateurs de qualité appropriés",
            "Comparer aux normes et standards applicables",
            "Documenter les résultats de l'analyse de précision"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Fermeture non conforme aux tolérances",
      niveau: 'eleve' as const,
      mesuresPrevention: [
        "Respecter les tolérances de fermeture spécifiées",
        "Analyser les sources d'erreur principales",
        "Reprendre les mesures défaillantes si nécessaire",
        "Documenter les actions correctives entreprises"
      ]
    },
    {
      description: "Erreurs de calcul dans la vérification",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Utiliser un logiciel de calcul validé",
        "Vérifier les formules et algorithmes utilisés",
        "Effectuer des contrôles croisés des résultats",
        "Maintenir une traçabilité des calculs"
      ]
    },
    {
      description: "Interprétation incorrecte des résultats",
      niveau: 'faible' as const,
      mesuresPrevention: [
        "Former l'équipe aux critères d'acceptation",
        "Documenter clairement les seuils de tolérance",
        "Valider l'interprétation avec un responsable expérimenté"
      ]
    }
  ],
  outils: [
    {
      nom: "Station totale",
      type: "Instrument de mesure de contrôle",
      securiteRequise: [
        "Vérifier la calibration avant les mesures de contrôle",
        "Maintenir les mêmes conditions que lors du levé initial",
        "Protéger contre les variations de température",
        "Utiliser le même trépied si possible"
      ]
    },
    {
      nom: "Station totale robotisée",
      type: "Instrument automatisé de contrôle",
      securiteRequise: [
        "Vérifier la batterie et les connexions",
        "Maintenir la liaison radio stable",
        "Contrôler le fonctionnement automatique",
        "Prévoir un mode manuel de secours"
      ]
    },
    {
      nom: "GPS/GNSS",
      type: "Système de positionnement de vérification",
      securiteRequise: [
        "Vérifier la disponibilité des satellites",
        "Utiliser les mêmes corrections DGPS",
        "Maintenir des conditions de réception similaires",
        "Contrôler la précision en temps réel"
      ]
    },
    {
      nom: "Niveau optique/électronique",
      type: "Instrument de nivellement de contrôle",
      securiteRequise: [
        "Vérifier l'étalonnage du niveau",
        "Contrôler la stabilité du trépied",
        "Maintenir propres les optiques",
        "Respecter les mêmes portées qu'au levé initial"
      ]
    },
    {
      nom: "Calculatrice scientifique ou logiciel",
      type: "Outil de calcul des écarts",
      securiteRequise: [
        "Vérifier le bon fonctionnement des fonctions",
        "S'assurer de l'autonomie suffisante",
        "Sauvegarder les calculs intermédiaires",
        "Utiliser des logiciels validés"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Formulaires de calcul de fermeture",
      type: "Documentation de contrôle",
      precautions: [
        "Utiliser les formules appropriées au type de levé",
        "Documenter tous les calculs intermédiaires",
        "Conserver une copie de sauvegarde des calculs",
        "Annoter clairement les résultats et conclusions"
      ]
    },
    {
      nom: "Points de référence certifiés",
      type: "Repères de contrôle",
      precautions: [
        "Vérifier l'intégrité physique des points",
        "Contrôler les coordonnées de référence",
        "Documenter l'état des repères utilisés",
        "Signaler tout problème constaté"
      ]
    },
    {
      nom: "Carnet de vérification",
      type: "Support d'enregistrement des contrôles",
      precautions: [
        "Enregistrer toutes les mesures de contrôle",
        "Noter les conditions de mesure",
        "Documenter les écarts calculés",
        "Annoter les actions correctives si nécessaires"
      ]
    }
  ]
};

export const operation29CompilerNotes: ArpenteurOperation = {
  nom: "2.9 Compiler les notes",
  description: "Organiser et vérifier toutes les données collectées",
  sousOperations: [
    {
      nom: "2.9.1 Classer les notes",
      description: "Organiser et classer toutes les notes de terrain collectées",
      risques: [
        {
          description: "Perte ou confusion des données lors du classement",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Numéroter toutes les pages de notes de terrain",
            "Utiliser un système de classement logique et cohérent",
            "Vérifier la complétude des données avant classement",
            "Créer un index des notes par station ou zone",
            "Conserver l'ordre chronologique des mesures"
          ]
        },
        {
          description: "Erreur dans l'organisation des données",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Établir une méthode de classement standardisée",
            "Vérifier la cohérence des numéros de points",
            "Contrôler l'intégrité des séquences de mesures",
            "Annoter clairement les changements de station"
          ]
        }
      ]
    },
    {
      nom: "2.9.2 Habiller les croquis",
      description: "Compléter et finaliser les croquis avec tous les éléments nécessaires",
      risques: [
        {
          description: "Croquis incomplet ou mal orienté",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Ajouter la pagination sur tous les croquis",
            "Tracer clairement toutes les rues et voies",
            "Indiquer la flèche du nord de façon visible",
            "Ajouter l'échelle et les dimensions",
            "Inclure la légende des symboles utilisés",
            "Dater et signer les croquis"
          ]
        },
        {
          description: "Informations manquantes sur les croquis",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Vérifier que tous les éléments importants sont représentés",
            "Ajouter les repères et points de référence",
            "Inclure les informations de localisation",
            "Annoter les détails particuliers"
          ]
        }
      ]
    },
    {
      nom: "2.9.3 Transférer les données dans l'ordinateur",
      description: "Saisir et transférer toutes les données de terrain dans le système informatique",
      risques: [
        {
          description: "Erreur de saisie des données",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier la saisie par double contrôle",
            "Utiliser des logiciels avec validation automatique",
            "Effectuer des contrôles de cohérence",
            "Vérifier les unités et les formats de données",
            "Contrôler les ordres de grandeur des mesures"
          ]
        },
        {
          description: "Perte de données lors du transfert",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Vérifier l'intégrité des fichiers transférés",
            "Utiliser des supports de transfert fiables",
            "Effectuer des sauvegardes avant et après transfert",
            "Contrôler le nombre de points transférés",
            "Valider la complétude des données"
          ]
        },
        {
          description: "Incompatibilité des formats de données",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Vérifier la compatibilité des formats",
            "Utiliser des logiciels de conversion appropriés",
            "Tester le transfert sur un échantillon",
            "Documenter les procédures de conversion"
          ]
        }
      ]
    },
    {
      nom: "2.9.4 Effectuer une sauvegarde des données ou faire des photocopies",
      description: "Créer des copies de sécurité de toutes les données et documents",
      risques: [
        {
          description: "Sauvegarde incomplète ou défaillante",
          niveau: 'eleve' as const,
          mesuresPrevention: [
            "Effectuer des sauvegardes multiples sur différents supports",
            "Vérifier l'intégrité des sauvegardes créées",
            "Tester la restauration des données sauvegardées",
            "Conserver les sauvegardes en lieux sécurisés séparés",
            "Documenter les procédures de sauvegarde et restauration"
          ]
        },
        {
          description: "Détérioration ou perte des documents originaux",
          niveau: 'moyen' as const,
          mesuresPrevention: [
            "Faire des photocopies de qualité des carnets de terrain",
            "Numériser les croquis et documents importants",
            "Conserver les originaux dans des conditions appropriées",
            "Utiliser des supports de stockage durables",
            "Étiqueter clairement toutes les copies"
          ]
        },
        {
          description: "Accès non autorisé aux données sensibles",
          niveau: 'faible' as const,
          mesuresPrevention: [
            "Protéger les données par des mots de passe",
            "Chiffrer les données sensibles",
            "Contrôler l'accès aux supports de sauvegarde",
            "Respecter les règles de confidentialité"
          ]
        }
      ]
    }
  ],
  risques: [
    {
      description: "Données incomplètes ou erronées compromettant les étapes suivantes",
      niveau: 'moyen' as const,
      mesuresPrevention: [
        "Vérifier la complétude de toutes les données collectées",
        "Contrôler la cohérence entre les différentes sources",
        "Effectuer des vérifications croisées systématiques",
        "Documenter toutes les anomalies détectées",
        "Valider les données avant de passer aux étapes suivantes"
      ]
    },
    {
      description: "Organisation défaillante des informations",
      niveau: 'faible' as const,
      mesuresPrevention: [
        "Établir une méthode de classement claire et cohérente",
        "Utiliser des outils de gestion documentaire appropriés",
        "Former l'équipe aux procédures d'organisation",
        "Maintenir un système de traçabilité des documents"
      ]
    }
  ],
  outils: [
    {
      nom: "Ordinateur portable",
      type: "Équipement informatique",
      securiteRequise: [
        "Protéger contre les chocs et l'humidité",
        "Vérifier l'autonomie de la batterie",
        "Maintenir à jour les logiciels",
        "Effectuer des sauvegardes régulières",
        "Utiliser des mots de passe sécurisés"
      ]
    },
    {
      nom: "Logiciel de topographie",
      type: "Application spécialisée",
      securiteRequise: [
        "Vérifier les licences et mises à jour",
        "Maîtriser les fonctionnalités du logiciel",
        "Effectuer des sauvegardes des projets",
        "Valider les calculs et résultats",
        "Documenter les paramètres utilisés"
      ]
    },
    {
      nom: "Scanner/Photocopieur",
      type: "Équipement de numérisation",
      securiteRequise: [
        "Vérifier la qualité de numérisation",
        "Nettoyer régulièrement les surfaces de scan",
        "Régler la résolution appropriée",
        "Contrôler l'état des consommables"
      ]
    },
    {
      nom: "Supports de sauvegarde",
      type: "Dispositifs de stockage",
      securiteRequise: [
        "Utiliser des supports fiables et durables",
        "Vérifier l'espace de stockage disponible",
        "Protéger contre les champs magnétiques",
        "Étiqueter clairement les supports",
        "Tester régulièrement l'intégrité des données"
      ]
    }
  ],
  materiaux: [
    {
      nom: "Carnet de terrain original",
      type: "Document source",
      precautions: [
        "Conserver en lieu sûr et sec",
        "Manipuler avec précaution",
        "Éviter l'exposition directe au soleil",
        "Protéger contre l'humidité et la poussière",
        "Ne pas altérer les données originales"
      ]
    },
    {
      nom: "Croquis et dessins",
      type: "Documentation graphique",
      precautions: [
        "Protéger contre les pliures et déchirures",
        "Conserver à plat dans des pochettes appropriées",
        "Éviter l'exposition à la lumière directe",
        "Manipuler avec des mains propres",
        "Faire des copies avant manipulation intensive"
      ]
    },
    {
      nom: "Supports de stockage numérique",
      type: "Dispositifs électroniques",
      precautions: [
        "Protéger contre les chocs et vibrations",
        "Éviter l'exposition aux températures extrêmes",
        "Protéger contre l'humidité et la poussière",
        "Éviter les champs électromagnétiques",
        "Effectuer des vérifications périodiques"
      ]
    },
    {
      nom: "Documentation de référence",
      type: "Manuels et procédures",
      precautions: [
        "Maintenir à jour avec les dernières versions",
        "Conserver en bon état de consultation",
        "Organiser pour un accès facile",
        "Protéger contre la détérioration"
      ]
    }
  ]
};
