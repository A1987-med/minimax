import { ArpenteurTache } from './types';

export const tacheEffectuerMiseEnPlan: ArpenteurTache = {
  nom: "EFFECTUER LA MISE EN PLAN",
  description: "Créer les plans techniques à partir des données de terrain",
  operations: [
    {
      nom: "5.1 Préparer le travail",
      description: "Organiser et préparer les éléments nécessaires à la mise en plan",
      sousOperations: [
        {
          nom: "Prendre connaissance du dossier",
          description: "Examiner et comprendre l'ensemble des documents du projet",
          risques: [
            {
              description: "Informations manquantes ou incohérentes dans le dossier",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer un inventaire complet des documents reçus",
                "Vérifier la version et la date de chaque document",
                "Signaler immédiatement les incohérences détectées",
                "Demander les clarifications nécessaires avant de commencer"
              ]
            },
            {
              description: "Mauvaise compréhension des objectifs du projet",
              niveau: "eleve",
              mesuresPrevention: [
                "Lire attentivement tous les documents contractuels",
                "Identifier les livrables attendus et les délais",
                "Clarifier les exigences spéciales ou non-standard",
                "Documenter les points nécessitant des éclaircissements"
              ]
            }
          ]
        },
        {
          nom: "Consulter les plans et les devis d'ingénierie",
          description: "Analyser les documents techniques de conception",
          risques: [
            {
              description: "Plans ou devis obsolètes ou non conformes",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier les numéros de révision et dates d'émission",
                "Confirmer l'approbation des documents par les autorités",
                "Comparer avec les standards et codes en vigueur",
                "Valider la cohérence entre plans et devis"
              ]
            },
            {
              description: "Erreur d'interprétation des spécifications techniques",
              niveau: "moyen",
              mesuresPrevention: [
                "Consulter les légendes et notes explicatives",
                "Vérifier les unités de mesure utilisées",
                "Clarifier les symboles et notations spéciales",
                "Demander des précisions sur les points ambigus"
              ]
            }
          ]
        },
        {
          nom: "Consulter les plans cadastraux, s'il y a lieu",
          description: "Examiner les documents officiels de propriété foncière",
          risques: [
            {
              description: "Plans cadastraux non à jour ou incorrects",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier la date de dernière mise à jour",
                "Confirmer avec le registre foncier officiel",
                "Identifier les modifications récentes non reportées",
                "Effectuer des vérifications terrain si nécessaire"
              ]
            },
            {
              description: "Conflits entre limites cadastrales et projet",
              niveau: "eleve",
              mesuresPrevention: [
                "Comparer les limites avec les relevés terrain",
                "Vérifier les servitudes et droits de passage",
                "Identifier les empiètements potentiels",
                "Consulter un arpenteur-géomètre si nécessaire"
              ]
            }
          ]
        },
        {
          nom: "Consulter les plans tels que construits antérieurs",
          description: "Analyser les documents des constructions existantes",
          risques: [
            {
              description: "Plans 'tel que construit' non représentatifs de la réalité",
              niveau: "moyen",
              mesuresPrevention: [
                "Comparer avec les observations terrain récentes",
                "Vérifier les modifications non documentées",
                "Effectuer des sondages de vérification si nécessaire",
                "Documenter les écarts constatés"
              ]
            },
            {
              description: "Informations sur les infrastructures souterraines manquantes",
              niveau: "eleve",
              mesuresPrevention: [
                "Consulter les services publics pour localisation",
                "Vérifier les plans de réseaux existants",
                "Effectuer des détections d'infrastructures cachées",
                "Coordonner avec les gestionnaires de réseaux"
              ]
            }
          ]
        },
        {
          nom: "Recueillir les renseignements manquants",
          description: "Compléter les informations nécessaires au projet",
          risques: [
            {
              description: "Retards dus aux informations manquantes",
              niveau: "moyen",
              mesuresPrevention: [
                "Identifier rapidement les besoins d'information",
                "Établir un échéancier pour l'obtention des données",
                "Développer des solutions alternatives si possible",
                "Communiquer les impacts sur le planning"
              ]
            },
            {
              description: "Informations erronées ou non vérifiées",
              niveau: "moyen",
              mesuresPrevention: [
                "Valider les sources d'information",
                "Effectuer des recoupements entre différentes sources",
                "Documenter la provenance de chaque information",
                "Établir un niveau de confiance pour chaque donnée"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Préparation insuffisante du travail",
          niveau: "moyen",
          mesuresPrevention: [
            "Établir un plan de travail détaillé",
            "Vérifier la disponibilité de tous les outils",
            "S'assurer de l'accès aux données nécessaires"
          ]
        }
      ],
      outils: [
        {
          nom: "Logiciels de DAO",
          type: "Applications de conception",
          securiteRequise: [
            "Licence valide et à jour",
            "Formation appropriée sur le logiciel",
            "Sauvegarde automatique configurée"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Documentation de projet",
          type: "Références techniques",
          precautions: [
            "Utiliser les versions les plus récentes",
            "Conserver les originaux en sécurité"
          ]
        }
      ]
    },
    {
      nom: "5.2 Prendre connaissance de la liste des points mesurés ou calculés",
      description: "Analyser et valider les données d'entrée pour la mise en plan",
      sousOperations: [
        {
          nom: "Valider le format de données",
          description: "Vérifier la compatibilité et l'intégrité des formats de fichiers de données",
          risques: [
            {
              description: "Format de données incompatible avec les logiciels",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier la compatibilité des formats avant traitement",
                "Utiliser des outils de conversion standardisés",
                "Tester l'importation sur un échantillon de données",
                "Maintenir des formats de sauvegarde multiples"
              ]
            },
            {
              description: "Corruption ou altération des fichiers de données",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer une vérification d'intégrité des fichiers",
                "Utiliser des sommes de contrôle pour validation",
                "Conserver des copies de sauvegarde non modifiées",
                "Documenter toute anomalie détectée dans les données"
              ]
            },
            {
              description: "Perte de précision lors de la conversion",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des formats préservant la précision maximale",
                "Vérifier les paramètres de conversion",
                "Effectuer des tests de validation post-conversion",
                "Documenter les limitations de précision acceptables"
              ]
            }
          ]
        },
        {
          nom: "Transférer les points à l'ordinateur",
          description: "Importer et organiser les données de points dans le système informatique",
          risques: [
            {
              description: "Erreur lors du transfert de données",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer une vérification systématique post-transfert",
                "Comparer les statistiques avant et après transfert",
                "Utiliser des protocoles de transfert sécurisés",
                "Maintenir un journal détaillé des opérations de transfert"
              ]
            },
            {
              description: "Perte de données durant le transfert",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des sauvegardes avant tout transfert",
                "Utiliser des méthodes de transfert avec vérification",
                "Contrôler le nombre de points avant et après transfert",
                "Implémenter des mécanismes de récupération d'erreur"
              ]
            },
            {
              description: "Mauvaise organisation des données importées",
              niveau: "faible",
              mesuresPrevention: [
                "Utiliser une structure de dossiers standardisée",
                "Appliquer une nomenclature cohérente aux fichiers",
                "Créer un index des données importées",
                "Documenter la structure organisationnelle utilisée"
              ]
            }
          ]
        },
        {
          nom: "Vérification de la complétude des données",
          description: "S'assurer que toutes les données nécessaires sont disponibles",
          risques: [
            {
              description: "Données manquantes ou incomplètes",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer un contrôle systématique des données",
                "Comparer avec les notes de terrain",
                "Vérifier la cohérence des coordonnées",
                "Signaler immédiatement les manques"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Utilisation de données erronées",
          niveau: "eleve",
          mesuresPrevention: [
            "Contrôler la précision des coordonnées",
            "Vérifier les calculs de base",
            "Comparer avec les données de référence"
          ]
        }
      ],
      outils: [
        {
          nom: "Tableur de vérification",
          type: "Logiciel de validation",
          securiteRequise: [
            "Formules de contrôle validées",
            "Sauvegarde régulière des données"
          ]
        },
        {
          nom: "Logiciel de transfert de données",
          type: "Application d'importation",
          securiteRequise: [
            "Protocoles sécurisés activés",
            "Vérification d'intégrité des données"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Listes de coordonnées",
          type: "Données géodésiques",
          precautions: [
            "Vérifier l'intégrité des fichiers",
            "Conserver des copies de sauvegarde"
          ]
        },
        {
          nom: "Fichiers de données terrain",
          type: "Données brutes d'instruments",
          precautions: [
            "Validation du format avant traitement",
            "Archivage sécurisé des originaux"
          ]
        }
      ]
    },
    {
      nom: "5.3 Classer les entités",
      description: "Organiser et catégoriser les éléments à représenter sur le plan",
      sousOperations: [
        {
          nom: "Attribuer les couches",
          description: "Organiser les entités par catégories et affecter les couches appropriées",
          risques: [
            {
              description: "Attribution incorrecte des couches",
              niveau: "moyen",
              mesuresPrevention: [
                "Suivre les standards de classification établis",
                "Utiliser une nomenclature de couches cohérente",
                "Vérifier la logique d'organisation des couches",
                "Documenter les règles d'attribution utilisées"
              ]
            },
            {
              description: "Confusion entre les différentes couches",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des noms de couches explicites et standardisés",
                "Appliquer une hiérarchie claire entre les couches",
                "Éviter la multiplication excessive des couches",
                "Maintenir une documentation des couches utilisées"
              ]
            },
            {
              description: "Perte d'information par mauvaise organisation",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier que toutes les entités sont assignées",
                "Éviter la superposition d'informations incompatibles",
                "Maintenir la traçabilité des éléments par couche",
                "Effectuer des contrôles de cohérence réguliers"
              ]
            }
          ]
        },
        {
          nom: "Déterminer le style des lignes, les couleurs, etc.",
          description: "Définir l'apparence visuelle des éléments selon les normes",
          risques: [
            {
              description: "Non-conformité aux standards graphiques",
              niveau: "moyen",
              mesuresPrevention: [
                "Respecter les normes de représentation en vigueur",
                "Utiliser les bibliothèques de styles standardisées",
                "Vérifier la conformité avec les exigences du projet",
                "Maintenir la cohérence visuelle entre les éléments"
              ]
            },
            {
              description: "Lisibilité insuffisante du plan",
              niveau: "moyen",
              mesuresPrevention: [
                "Choisir des couleurs contrastées et distinctes",
                "Adapter l'épaisseur des lignes à l'échelle",
                "Éviter la surcharge visuelle du plan",
                "Tester la lisibilité à l'échelle d'impression"
              ]
            },
            {
              description: "Confusion entre différents types d'éléments",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser des styles distincts pour chaque type",
                "Respecter les conventions établies",
                "Créer une légende claire et complète",
                "Valider les choix avec les standards métier"
              ]
            }
          ]
        },
        {
          nom: "Hiérarchisation des éléments",
          description: "Organiser les entités par ordre d'importance et type",
          risques: [
            {
              description: "Classification incorrecte des éléments",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des standards de classification reconnus",
                "Respecter la hiérarchie des couches",
                "Documenter les critères de classification",
                "Valider avec les spécifications du projet"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Omission d'éléments importants",
          niveau: "moyen",
          mesuresPrevention: [
            "Suivre une méthode systématique",
            "Utiliser des listes de contrôle",
            "Effectuer des vérifications croisées"
          ]
        }
      ],
      outils: [
        {
          nom: "Système de gestion des couches",
          type: "Fonctionnalité DAO",
          securiteRequise: [
            "Nomenclature standardisée",
            "Droits d'accès appropriés"
          ]
        },
        {
          nom: "Bibliothèques de styles",
          type: "Ressources graphiques standardisées",
          securiteRequise: [
            "Versions approuvées et validées",
            "Compatibilité avec le logiciel utilisé"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Standards de classification",
          type: "Références techniques",
          precautions: [
            "Utiliser les versions approuvées",
            "Respecter les conventions établies"
          ]
        },
        {
          nom: "Chartes graphiques",
          type: "Guides de style visuel",
          precautions: [
            "Respecter les normes de représentation",
            "Maintenir la cohérence visuelle"
          ]
        }
      ]
    },
    {
      nom: "5.4 Faire le dessin",
      description: "Créer la représentation graphique des éléments du plan",
      sousOperations: [
        {
          nom: "Relier les points, s'il y a lieu",
          description: "Connecter les points de mesure selon la logique du terrain et du projet",
          risques: [
            {
              description: "Erreurs de connexion entre les points",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier la logique géométrique des connexions",
                "Respecter l'ordre chronologique des mesures",
                "Contrôler la cohérence avec les notes de terrain",
                "Valider les distances et angles de liaison"
              ]
            },
            {
              description: "Omission de points importants dans les liaisons",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une méthode systématique de vérification",
                "Comparer avec le croquis de terrain",
                "Vérifier l'intégralité des données importées",
                "Effectuer un contrôle visuel complet"
              ]
            },
            {
              description: "Connexions incorrectes affectant la précision",
              niveau: "eleve",
              mesuresPrevention: [
                "Respecter les tolérances de précision établies",
                "Utiliser les outils de validation géométrique",
                "Effectuer des contrôles de fermeture",
                "Documenter les écarts et justifications"
              ]
            }
          ]
        },
        {
          nom: "Tracer les alignements, les profils, les coupes et les surfaces",
          description: "Dessiner les éléments géométriques principaux du projet",
          risques: [
            {
              description: "Erreurs dans le tracé des alignements",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier les calculs d'implantation",
                "Respecter les spécifications techniques du projet",
                "Utiliser les outils de précision appropriés",
                "Effectuer des contrôles de cohérence géométrique"
              ]
            },
            {
              description: "Profils ou coupes non conformes aux données terrain",
              niveau: "eleve",
              mesuresPrevention: [
                "Comparer avec les mesures de terrain",
                "Vérifier les calculs d'altitude",
                "Respecter les échelles de représentation",
                "Valider avec les données topographiques"
              ]
            },
            {
              description: "Surfaces mal définies ou incomplètes",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier la fermeture des polygones",
                "Contrôler la cohérence des limites",
                "Calculer et valider les superficies",
                "Respecter les conventions de représentation"
              ]
            }
          ]
        },
        {
          nom: "Tracer les courbes de niveau",
          description: "Représenter la topographie par des courbes d'égale altitude",
          risques: [
            {
              description: "Courbes de niveau incorrectes ou incohérentes",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier la logique d'écoulement des eaux",
                "Respecter l'équidistance établie",
                "Contrôler la cohérence avec les points cotés",
                "Valider les formes topographiques"
              ]
            },
            {
              description: "Interpolation erronée entre les points mesurés",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser des méthodes d'interpolation appropriées",
                "Vérifier la densité des points de mesure",
                "Contrôler les zones de forte pente",
                "Valider avec la connaissance du terrain"
              ]
            },
            {
              description: "Représentation illisible ou surchargée",
              niveau: "faible",
              mesuresPrevention: [
                "Adapter l'équidistance à l'échelle du plan",
                "Utiliser des styles de lignes appropriés",
                "Éviter la surcharge d'information",
                "Respecter les standards cartographiques"
              ]
            }
          ]
        },
        {
          nom: "Montrer les éléments d'infrastructures",
          description: "Représenter les infrastructures existantes et projetées",
          risques: [
            {
              description: "Omission d'infrastructures importantes",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser une liste de vérification complète",
                "Consulter les plans de réseaux existants",
                "Vérifier avec les observations terrain",
                "Coordonner avec les gestionnaires d'infrastructures"
              ]
            },
            {
              description: "Représentation incorrecte des infrastructures",
              niveau: "moyen",
              mesuresPrevention: [
                "Respecter les symboles et conventions établis",
                "Vérifier les dimensions et positions",
                "Utiliser les bonnes échelles de représentation",
                "Valider avec les plans techniques"
              ]
            },
            {
              description: "Conflits entre infrastructures non détectés",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer des analyses de superposition",
                "Vérifier les clearances réglementaires",
                "Identifier les interférences potentielles",
                "Coordonner avec les différents intervenants"
              ]
            }
          ]
        },
        {
          nom: "Création des éléments graphiques",
          description: "Dessiner les alignements, profils et surfaces",
          risques: [
            {
              description: "Fatigue oculaire prolongée",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser un éclairage adéquat",
                "Ajuster la luminosité de l'écran",
                "Faire des pauses visuelles toutes les heures",
                "Utiliser des lunettes anti-reflets si nécessaire"
              ]
            },
            {
              description: "Troubles musculo-squelettiques",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser un siège ergonomique",
                "Ajuster la hauteur du bureau",
                "Positionner l'écran à la bonne distance",
                "Faire des étirements réguliers"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Erreurs de représentation graphique",
          niveau: "moyen",
          mesuresPrevention: [
            "Respecter les standards de dessin",
            "Utiliser les symboles appropriés",
            "Vérifier l'échelle de représentation"
          ]
        }
      ],
      outils: [
        {
          nom: "Logiciels de DAO",
          type: "Applications de dessin",
          securiteRequise: [
            "Formation appropriée",
            "Licence valide",
            "Sauvegarde automatique activée",
            "Mises à jour régulières"
          ]
        },
        {
          nom: "Écran haute résolution",
          type: "Équipement d'affichage",
          securiteRequise: [
            "Réglage de la luminosité",
            "Position ergonomique",
            "Nettoyage régulier"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Bibliothèques de symboles",
          type: "Éléments graphiques standardisés",
          precautions: [
            "Utiliser les versions approuvées",
            "Respecter les conventions"
          ]
        }
      ]
    },
    {
      nom: "5.5 Habiller le plan",
      description: "Ajouter les annotations, cotations et éléments informatifs",
      sousOperations: [
        {
          nom: "Placer la flèche du nord",
          description: "Positionner l'indicateur d'orientation géographique sur le plan",
          risques: [
            {
              description: "Orientation incorrecte de la flèche du nord",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier l'orientation avec les données géodésiques",
                "Respecter les conventions cartographiques établies",
                "Utiliser le système de coordonnées approprié",
                "Valider avec les mesures d'azimut terrain"
              ]
            },
            {
              description: "Positionnement inapproprié sur le plan",
              niveau: "faible",
              mesuresPrevention: [
                "Placer dans une zone libre du plan",
                "Respecter les standards de mise en page",
                "Assurer la visibilité sans masquer d'éléments",
                "Utiliser une taille appropriée à l'échelle"
              ]
            },
            {
              description: "Confusion entre nord magnétique et géographique",
              niveau: "moyen",
              mesuresPrevention: [
                "Spécifier clairement le type de nord utilisé",
                "Appliquer la déclinaison magnétique si nécessaire",
                "Documenter la référence utilisée",
                "Respecter les exigences du projet"
              ]
            }
          ]
        },
        {
          nom: "Déterminer l'échelle",
          description: "Définir et indiquer l'échelle de représentation du plan",
          risques: [
            {
              description: "Échelle inappropriée au contenu du plan",
              niveau: "moyen",
              mesuresPrevention: [
                "Adapter l'échelle à la densité d'information",
                "Respecter les standards du type de plan",
                "Vérifier la lisibilité de tous les éléments",
                "Considérer le format de sortie final"
              ]
            },
            {
              description: "Incohérence entre échelle graphique et numérique",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier la correspondance des échelles",
                "Utiliser des outils de validation automatique",
                "Tester par mesure directe sur le plan",
                "Documenter les vérifications effectuées"
              ]
            },
            {
              description: "Échelle non adaptée à l'usage prévu",
              niveau: "moyen",
              mesuresPrevention: [
                "Consulter les exigences spécifiques du projet",
                "Respecter les normes professionnelles",
                "Considérer les besoins des utilisateurs finaux",
                "Valider avec les standards réglementaires"
              ]
            }
          ]
        },
        {
          nom: "Compléter le cartouche",
          description: "Remplir toutes les informations requises dans le bloc-titre",
          risques: [
            {
              description: "Informations manquantes ou incorrectes dans le cartouche",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une liste de vérification du cartouche",
                "Valider toutes les informations avec les documents source",
                "Respecter les standards de l'organisation",
                "Faire réviser par un responsable"
              ]
            },
            {
              description: "Non-conformité aux standards du cartouche",
              niveau: "faible",
              mesuresPrevention: [
                "Utiliser les modèles approuvés",
                "Respecter la charte graphique établie",
                "Vérifier les exigences réglementaires",
                "Maintenir la cohérence avec les autres plans"
              ]
            },
            {
              description: "Erreurs dans les signatures et approbations",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier les autorités de signature",
                "Respecter les processus d'approbation",
                "Documenter les dates et révisions",
                "Conserver la traçabilité des modifications"
              ]
            }
          ]
        },
        {
          nom: "Inscrire les dimensions (volume, superficie, longueur), s'il y a lieu",
          description: "Ajouter les mesures quantitatives nécessaires au plan",
          risques: [
            {
              description: "Erreurs de calcul des dimensions",
              niveau: "eleve",
              mesuresPrevention: [
                "Utiliser des outils de calcul automatique validés",
                "Effectuer des vérifications croisées des calculs",
                "Respecter les règles d'arrondissement établies",
                "Documenter les méthodes de calcul utilisées"
              ]
            },
            {
              description: "Unités de mesure inappropriées ou incohérentes",
              niveau: "moyen",
              mesuresPrevention: [
                "Respecter les unités spécifiées au projet",
                "Maintenir la cohérence dans tout le plan",
                "Indiquer clairement les unités utilisées",
                "Vérifier les conversions si nécessaire"
              ]
            },
            {
              description: "Positionnement illisible des dimensions",
              niveau: "faible",
              mesuresPrevention: [
                "Placer les dimensions sans masquer d'éléments",
                "Utiliser une taille de texte appropriée",
                "Respecter les conventions de placement",
                "Assurer la lisibilité à l'échelle d'impression"
              ]
            }
          ]
        },
        {
          nom: "Produire la légende, s'il y a lieu",
          description: "Créer la légende explicative des symboles et conventions utilisés",
          risques: [
            {
              description: "Légende incomplète ou imprécise",
              niveau: "moyen",
              mesuresPrevention: [
                "Inventorier tous les symboles utilisés dans le plan",
                "Utiliser des descriptions claires et standardisées",
                "Respecter les conventions établies",
                "Vérifier la correspondance symbole-description"
              ]
            },
            {
              description: "Symboles non conformes aux standards",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser les bibliothèques de symboles approuvées",
                "Respecter les normes graphiques en vigueur",
                "Valider avec les standards métier",
                "Maintenir la cohérence visuelle"
              ]
            },
            {
              description: "Légende mal organisée ou illisible",
              niveau: "faible",
              mesuresPrevention: [
                "Organiser logiquement les éléments de légende",
                "Utiliser une hiérarchie visuelle claire",
                "Adapter la taille à l'espace disponible",
                "Tester la lisibilité à l'échelle finale"
              ]
            }
          ]
        },
        {
          nom: "Inscrire les cotes",
          description: "Ajouter les dimensions et mesures nécessaires sur le plan",
          risques: [
            {
              description: "Cotation incorrecte ou manquante",
              niveau: "eleve",
              mesuresPrevention: [
                "Vérifier toutes les cotes par calcul inverse",
                "Respecter les tolérances de précision",
                "Utiliser les standards de cotation appropriés",
                "Valider avec les mesures de terrain"
              ]
            },
            {
              description: "Surcharge de cotation nuisant à la lisibilité",
              niveau: "faible",
              mesuresPrevention: [
                "Coter uniquement les éléments nécessaires",
                "Organiser les cotes de façon hiérarchique",
                "Éviter les superpositions et conflits visuels",
                "Respecter les principes de lisibilité"
              ]
            },
            {
              description: "Inconsistance dans le style de cotation",
              niveau: "faible",
              mesuresPrevention: [
                "Utiliser un style de cotation uniforme",
                "Respecter les standards graphiques",
                "Maintenir la cohérence des polices et tailles",
                "Appliquer les conventions établies"
              ]
            }
          ]
        },
        {
          nom: "Inscrire les autres détails pertinents",
          description: "Ajouter les annotations et informations complémentaires nécessaires",
          risques: [
            {
              description: "Omission d'informations importantes",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une liste de vérification complète",
                "Consulter les exigences spécifiques du projet",
                "Réviser avec les spécialistes concernés",
                "Documenter les éléments critiques"
              ]
            },
            {
              description: "Annotations incorrectes ou ambiguës",
              niveau: "moyen",
              mesuresPrevention: [
                "Utiliser une terminologie standardisée",
                "Vérifier l'exactitude de toutes les annotations",
                "Respecter les conventions établies",
                "Faire valider par les experts métier"
              ]
            },
            {
              description: "Surcharge d'information nuisant à la lisibilité",
              niveau: "faible",
              mesuresPrevention: [
                "Hiérarchiser l'information par importance",
                "Utiliser des références aux documents annexes",
                "Organiser l'information de façon logique",
                "Maintenir l'équilibre visuel du plan"
              ]
            }
          ]
        },
        {
          nom: "Alléger le plan",
          description: "Optimiser la présentation pour améliorer la lisibilité et réduire la complexité visuelle",
          risques: [
            {
              description: "Suppression d'éléments essentiels",
              niveau: "eleve",
              mesuresPrevention: [
                "Identifier clairement les éléments critiques",
                "Consulter les exigences minimales du projet",
                "Valider les allègements avec les responsables",
                "Documenter les éléments conservés et supprimés"
              ]
            },
            {
              description: "Plan insuffisamment détaillé après allègement",
              niveau: "moyen",
              mesuresPrevention: [
                "Maintenir le niveau de détail requis",
                "Vérifier la conformité aux standards",
                "Tester la compréhension avec les utilisateurs",
                "Équilibrer simplicité et complétude"
              ]
            },
            {
              description: "Perte de cohérence dans la représentation",
              niveau: "moyen",
              mesuresPrevention: [
                "Appliquer les règles d'allègement uniformément",
                "Maintenir la hiérarchie d'information",
                "Respecter les principes graphiques établis",
                "Valider l'homogénéité du résultat final"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Plan illisible ou mal organisé",
          niveau: "moyen",
          mesuresPrevention: [
            "Respecter les principes de lisibilité",
            "Organiser l'information de façon logique",
            "Utiliser des polices appropriées"
          ]
        }
      ],
      outils: [
        {
          nom: "Outils de texte et cotation",
          type: "Fonctionnalités DAO",
          securiteRequise: [
            "Paramètres de style validés",
            "Modèles standardisés"
          ]
        },
        {
          nom: "Bibliothèques de symboles cartographiques",
          type: "Ressources graphiques",
          securiteRequise: [
            "Versions approuvées et validées",
            "Conformité aux standards"
          ]
        },
        {
          nom: "Calculatrice de précision",
          type: "Outil de calcul",
          securiteRequise: [
            "Précision vérifiée",
            "Méthodes de calcul validées"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Standards d'annotation",
          type: "Guides de style",
          precautions: [
            "Respecter les conventions établies",
            "Utiliser la terminologie appropriée"
          ]
        },
        {
          nom: "Modèles de cartouche",
          type: "Templates standardisés",
          precautions: [
            "Utiliser les versions approuvées",
            "Respecter les exigences réglementaires"
          ]
        },
        {
          nom: "Chartes de symboles",
          type: "Références graphiques",
          precautions: [
            "Respecter les standards métier",
            "Maintenir la cohérence visuelle"
          ]
        }
      ]
    },
    {
      nom: "5.6 Imprimer le plan préliminaire",
      description: "Produire une version préliminaire du plan pour révision",
      sousOperations: [
        {
          nom: "Préparation pour impression",
          description: "Configurer les paramètres d'impression et vérifier la mise en page",
          risques: [
            {
              description: "Qualité d'impression insuffisante",
              niveau: "faible",
              mesuresPrevention: [
                "Vérifier les paramètres d'impression",
                "Tester sur une petite section",
                "S'assurer de la qualité du papier",
                "Contrôler les niveaux d'encre"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Gaspillage de ressources",
          niveau: "faible",
          mesuresPrevention: [
            "Vérifier avant impression",
            "Utiliser le mode aperçu",
            "Imprimer en mode brouillon si approprié"
          ]
        }
      ],
      outils: [
        {
          nom: "Traceur grand format",
          type: "Imprimante spécialisée",
          securiteRequise: [
            "Formation sur l'utilisation",
            "Maintenance régulière",
            "Vérification de la qualité d'impression"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Papier de plans",
          type: "Support d'impression",
          precautions: [
            "Stockage à l'abri de l'humidité",
            "Manipulation soigneuse",
            "Vérification de la qualité"
          ]
        }
      ]
    },
    {
      nom: "5.7 Transmettre le plan préliminaire pour la vérification, s'il y a lieu",
      description: "Soumettre le plan préliminaire pour révision et approbation",
      sousOperations: [
        {
          nom: "Préparation de la transmission",
          description: "Préparer le plan et la documentation pour envoi",
          risques: [
            {
              description: "Transmission incomplète ou tardive",
              niveau: "moyen",
              mesuresPrevention: [
                "Vérifier tous les éléments requis",
                "Respecter les délais établis",
                "Confirmer la réception",
                "Inclure toute la documentation nécessaire"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Perte ou dommage durant la transmission",
          niveau: "moyen",
          mesuresPrevention: [
            "Utiliser des moyens de transmission sécurisés",
            "Faire des copies de sauvegarde",
            "Emballer appropriément si envoi physique"
          ]
        }
      ],
      outils: [
        {
          nom: "Système de transmission",
          type: "Plateforme d'échange",
          securiteRequise: [
            "Chiffrement des données",
            "Authentification sécurisée",
            "Traçabilité des échanges"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Supports de transmission",
          type: "Médias physiques ou numériques",
          precautions: [
            "Étiquetage clair",
            "Protection contre les dommages",
            "Vérification de l'intégrité"
          ]
        }
      ]
    },
    {
      nom: "5.8 Vérifier et corriger le plan",
      description: "Examiner le plan et apporter les corrections nécessaires",
      sousOperations: [
        {
          nom: "Contrôle qualité du plan",
          description: "Vérifier la conformité et la précision du plan",
          risques: [
            {
              description: "Erreurs non détectées",
              niveau: "eleve",
              mesuresPrevention: [
                "Effectuer une vérification systématique",
                "Utiliser des listes de contrôle",
                "Faire vérifier par un collègue",
                "Comparer avec les données source"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Plan non conforme aux exigences",
          niveau: "eleve",
          mesuresPrevention: [
            "Respecter tous les standards applicables",
            "Vérifier la conformité réglementaire",
            "Valider avec les spécifications"
          ]
        }
      ],
      outils: [
        {
          nom: "Outils de vérification",
          type: "Fonctionnalités de contrôle",
          securiteRequise: [
            "Paramètres de vérification validés",
            "Procédures de contrôle documentées"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Listes de contrôle",
          type: "Outils de vérification",
          precautions: [
            "Utiliser les versions à jour",
            "Documenter tous les contrôles"
          ]
        }
      ]
    },
    {
      nom: "5.9 Imprimer le plan final",
      description: "Produire la version finale du plan approuvé",
      sousOperations: [
        {
          nom: "Impression finale",
          description: "Produire les exemplaires finaux du plan",
          risques: [
            {
              description: "Défauts d'impression sur la version finale",
              niveau: "moyen",
              mesuresPrevention: [
                "Effectuer un test d'impression préalable",
                "Vérifier la qualité de l'équipement",
                "Contrôler les paramètres d'impression",
                "Inspecter chaque exemplaire produit"
              ]
            }
          ]
        }
      ],
      risques: [
        {
          description: "Retards dans la livraison finale",
          niveau: "moyen",
          mesuresPrevention: [
            "Planifier suffisamment de temps",
            "Prévoir des exemplaires supplémentaires",
            "Vérifier la disponibilité des ressources"
          ]
        }
      ],
      outils: [
        {
          nom: "Traceur grand format",
          type: "Imprimante spécialisée",
          securiteRequise: [
            "Maintenance préventive effectuée",
            "Calibration vérifiée",
            "Qualité d'impression optimale"
          ]
        }
      ],
      materiaux: [
        {
          nom: "Papier de qualité finale",
          type: "Support d'impression premium",
          precautions: [
            "Utiliser du papier de haute qualité",
            "Vérifier la compatibilité avec l'imprimante",
            "Stocker dans des conditions optimales"
          ]
        }
      ]
    }
  ]
};
