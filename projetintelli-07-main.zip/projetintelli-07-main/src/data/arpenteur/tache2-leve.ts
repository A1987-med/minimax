
import { ArpenteurTache } from './types';
import { operation21PreparerTravail } from './tache2-leve/operation-2-1-preparer-travail';
import { operation22PreparerLieux } from './tache2-leve/operation-2-2-preparer-lieux';
import { operation23EtablirStations } from './tache2-leve/operation-2-3-etablir-stations';
import { operation24TracerCroquis } from './tache2-leve/operation-2-4-tracer-croquis';
import { operation25ReferencierStations } from './tache2-leve/operation-2-5-referencier-stations';
import { 
  operation26MiseEnStation,
  operation27PrendreMesures,
  operation28VerifierFermeture,
  operation29CompilerNotes
} from './tache2-leve/operations-restantes';

export const tacheFaireLeveTerrain: ArpenteurTache = {
  nom: "FAIRE LE LEVÉ DE TERRAIN",
  description: "Effectuer le levé de terrain en utilisant les instruments appropriés",
  operations: [
    operation21PreparerTravail,
    operation22PreparerLieux,
    operation23EtablirStations,
    operation24TracerCroquis,
    operation25ReferencierStations,
    operation26MiseEnStation,
    operation27PrendreMesures,
    operation28VerifierFermeture,
    operation29CompilerNotes
  ]
};
